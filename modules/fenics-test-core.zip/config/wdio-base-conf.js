/* eslint-disable no-console */

const ChromedriverUtils = require('../src/webdriver/ChromedriverUtils');
const OpenfinUtils = require('../src/openfin/OpenfinUtils');

(() => {
  const args = require('minimist')(process.argv.slice(2));

  global.environment = args.env;
  global.cleanup = args.cleanup;

  console.log(`Environment is set to ${global.environment}`);
  console.log(`Cleanup is set to ${global.cleanup}`);

  if (global.environment !== 'dev' && global.environment !== 'qa') {
    throw new Error(`${global.environment} is not a valid environment.`);
  }
})();

exports.config = {
  capabilities : [
    {
      browserName   : 'chrome',
      maxInstances  : 1,
      chromeOptions : {
        extensions : [],
        binary     : 'RunOpenFin.bat',
        args       : [
          '--allow-insecure-localhost',
          '--allow-running-insecure-content',
          '--disable-web-security',
          '--noerrdialogs',
          '--v=1',
          '--ignore-certificate-errors',
          '--remember-cert-error-decisions',
          '--disk-cache-size=1',
          `--config=https://fenics-api.${global.environment}.fenicsone.com/v1/openfin-manifest?openFinApplication=fenics%2Ffenics-shell-app`
        ]
      }
    }
  ],

  host           : 'localhost',
  port           : 9515,
  path           : '/wd/hub',
  sync           : false,
  loglevel       : 'trace',
  coloredLogs    : true,
  framework      : 'cucumber',
  waitforTimeout : 20000,
  mochaOpts      : {
    ui        : 'bdd',
    compilers : ['js:babel-register'],
    require   : [],
    timeout   : 500000
  },
  reporters       : ['cucumber'],
  reporterOptions : {
    allure : {
      outputDir                            : 'allure-results',
      disableWebdriverStepsReporting       : true,
      disableWebdriverScreenshotsReporting : true,
      useCucumberStepReporter              : true
    }
  },

  cucumberOpts : {
    backtrace : true,
    compiler  : [
      'js:@babel/register'
    ],
    failAmbiguousDefinitions   : true,
    failFast                   : false,
    ignoreUndefinedDefinitions : true,
    name                       : [],
    snippets                   : true,
    source                     : true,
    profile                    : [],
    require                    : [
      'test/step-def/*.js'
    ],
    snippetSyntax : undefined,
    strict        : true,
    tagExpression : 'not @Pending',
    tagsInTitle   : false,
    timeout       : 120000
  },

  onPrepare : () => [
    console.log('onPrepare'),
    ChromedriverUtils.update(),
    ChromedriverUtils.start()
  ],

  beforeSession : () => [
    console.log('beforeSession')
  ],

  // The suspected issue here is that it's just doing things too quickly. Need to refactor it out into separate commands which run asyncronously
  onComplete : () => [
    console.log('onComplete'),
    ChromedriverUtils.stop(),
    ChromedriverUtils.killJava(),
    ChromedriverUtils.clean(),
    OpenfinUtils.stop(),
    OpenfinUtils.clean()
  ],

  onError : () => [
    console.log('onError')
  ]
};


