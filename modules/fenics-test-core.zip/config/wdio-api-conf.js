const merge = require('deepmerge');
const baseConf = require('./wdio-base-conf');

exports.config = merge(baseConf.config, {
});
