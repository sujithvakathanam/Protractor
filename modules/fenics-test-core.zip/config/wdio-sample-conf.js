const merge = require('deepmerge');
const baseConf = require('./wdio-ui-conf');

exports.config = merge(baseConf.config, {
  specs : [
    'test/feature/**/*.feature'
  ]
});
