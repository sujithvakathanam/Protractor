# fenics-test-core
Fenics core testing framework, common core library for all Fenics test automation frameworks.

## Project setup
- Ensure that the following package dependencies are installed.
```
"webdriverio": "4.13.2",
"wdio-mocha-framework": "0.6.4",
"wdio-teamcity-reporter": "1.1.1",
"eslint": "5.16.0",
"babel-eslint": "10.0.1",
"eslint-plugin-chai-friendly": "0.4.1"
```

- Sample package.json format that should be used. 
```
{
  "name": "example-test-framework",
  "version": "1.0.0",
  "description": "Example app acceptance testing framework",
  "repository": {
    "type": "git",
    "url": "https://github.fenicsone.com/example/example-test-framework"
  },
  "license": "UNLICENSED",
  "scripts": {
    "test": "./node_modules/.bin/wdio ./config/wdio.config.js"
  },
  "dependencies": {
    "@fenics/fenics-test-core": "1.0.5",
    "babel-cli": "6.24.1",
    "babel-plugin-transform-object-rest-spread": "6.26.0",
    "babel-plugin-transform-runtime": "6.23.0",
    "babel-preset-env": "1.7.0",
    "webdriverio": "4.13.2",
    "wdio-mocha-framework": "0.6.4",
    "wdio-teamcity-reporter": "1.1.1"
  },
  "devDependencies": {
    "eslint": "5.16.0",
    "babel-eslint": "10.0.1",
    "eslint-plugin-chai-friendly": "0.4.1"
  }
}
 
```

## Usage
- Setting up your package.json keeping with the format in the [Project setup](##project-setup) section.
- NPM install using: `npm install` or `npm i`.
- NPM install will provide:
    - Eslint.
    - Configuration files under `config/`.
    - Page object files under `pages/`.
    - Test specification files under `test/spec`.
    - `.npmrc` under root.
    - `.gitignore` under root.
    - `RunOpenFin.bat` and `TerminateOpenfin.bat` under root.
- Run tests suites: `npm test` or `./node_modules/.bin/wdio ./config/wdio.config.js`

## Framework Configuration
- API configuration `config/api.config.js` must contain any configuration related to API client connection.
- UI configuration `config/framework.config.js` must contain generic framework vars, user configuration.
    - Editable Fields:
        - `cleanUpRetry`
        - `implicitWaitDuration`
        - `veryShortTimeout`
        - `shortTimeout`
        - `mediumTimeout`
        - `longTimeout`
        - `veryLongTimeout`
        - `logLevel` (can only be `debug`, `info`, `warn`, `error`)
    - Non-Editable Fields:
        - `clearDownScript`
        - `expectedRuntimeVersion`
        - `implicitWaitDurationDefault`
 - WDIO Configration `config/wdio.config.js`, avoid changing any of the variables in here unless absolutely required. E.g. `TARGET_ENV` can be changed to point to different environments.
    
## Mocha tests
All mocha test files should be created under `test/spec/`, with the following format:
```
 describe('Test Stuff', () => {
  before(() => {
    // Test suite setup here.
  });

  after(() => {
    // Test suite clean-up here.
  });

  it('Should test things work.', async () => {
    // Test steps here.
  });
});
```

## Cucumber tests
Cucumber tests should be created under `test/feature` with the following format:
```
Feature: Some feature name
  Some feature description

  Background:
    Given a global administrator named "Greg"
    And a blog named "Greg's anti-tax rants"
    And a customer named "Dr. Bill"
    And a blog named "Expensive Therapy" owned by "Dr. Bill"

  Scenario: Dr. Bill posts to his own blog
    Given I am logged in as Dr. Bill
    When I try to post to "Expensive Therapy"
    Then I should see "Your article was published."
```
```
Feature: Eating Example
  I should be able to eat cucumbers

  Scenario: eat
    Given there are 20 cucumbers
    When I eat 5 cucumbers
    Then I should have 15 cucumbers

  Scenario Outline: eat-data-driven
    Given there are <start> cucumbers
    When I eat <eat> cucumbers
    Then I should have <left> cucumbers
    
    Examples:
      | start | eat | left |
      |    12 |   5 |    7 |
      |    20 |   5 |   15 |
```
Examples are from the official Gherkin reference found here: https://cucumber.io/docs/gherkin/reference/

Cucumber spec definitions should be created under `test/spec-def` with the following format:
```
import {Given as given, When as when, Then as then} from 'cucumber';
import {expect} from 'chai';
...

/**
 * Given definitions
 */
given('there are {int} cucumbers', (start) => {
  // Test setup
});

/**
 * When definitions
 */
given('I eat {int} cucumbers', (eat) => {
 // Test actions
});

/**
 * Then definitions
 */
given('I should have {int} cucumbers', (left) => {
 // Test assertions
});

```
## WebDriverIO (WDIO) Configuration
_Note: This project uses WebDriverIO version 4._

For general information on configuring WebDriverIO, see: http://v4.webdriver.io/guide/testrunner/configurationfile.html

To minimise lines of code dedicated to configuration, this framework provides base configurations which can be
'inherited' from - and properties can be overridden - in project frameworks. This effect is achieved with the
[deepmerge](https://www.npmjs.com/package/deepmerge) library. Sample config files are provided when installing this framework.

**Using this config structure is optional.**

The image below outlines the intended usage. Additional base configurations can be set up for performance and other 
types of testing.

![Config inheritance structure](img/config-structure.png "Config inheritance structure")

## Bootstrap
In order to use `@fenics/fenics-test-core` in your project test framework; `Bootstrap` must be initialised.  
```
import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from './config/framework.config';
import {apiConfig} from './config/api.config';

const bootstrapper = new Bootstrap([frameworkConfig, apiConfig]);

```

`Context` can be obtained after initialising `Bootstrap` from the `global` object.
```
const context = global.context;
```

`Context` provides a flattened configuration reference, logging capabilities, and scenario context.

**Logging:**
```
const logger = context.getLogger();
logger.debug('Hello world!');
logger.info('Hello world!');
logger.warn('Hello world!');
logger.error('Hello world!');
```

**Configuration:**
```
const configuration = context.getConfiguration();
const prop = configuration.someConfigurationProperty;
```

**User Configuration:**
```
const user = context.getUserConfiguration(byUsername);
const oktaId = user.oktaId;
const username = user.username;
const password = user.password;
const lei = user.lei;
const type = user.type;
```

**Scenario Context:**
```
const scenarioContext = context.getScenarioContext();
scenarioContext.set(key, value);
const keyValuePair = scenarioContext.get(key);
const hasKeyValuePair = scenarioContext.has(key);
```

## Page objects
Please ensure you understand the Page Object pattern before writing code for the target applications page objects. Information can be found at [Page Object Pattern](http://v4.webdriver.io/guide/testrunner/pageobjects.html).

We have adapted the use of the Page Object pattern to allow us to more concisely define Cucumber step definitions and to reduce boilerplate code.

A basic example of a page object, `MyPage.js`, would be:
```
import BasePage from '@fenics/fenics-test-core/pages/BasePage';
import Element from '@fenics/fenics-test-core/src/framework/Element';
import {ELEMENTS, APP_DETAILS} from '../constant/app';

const elements = ELEMENTS.myPage

export default class MyPage extends BasePage {
  static async switchTo () {
    await super.waitForWindow(APP_DETAILS.myPageTitle);
  }

  static async waitForPageLoad () {
    await Element.waitForVisible(elements.aStaticLogo, global.context.configuration.mediumTimeout);
  }

  static async enterName (forename, surname) {
    await Element.setText(elements.forenameField, forename);
    await Element.setText(elements.surnameField, surname);
    await Element.click(elements.submitButton, 'name'); 
  }
}
```
*Note: The Element functions override and enhance the standard WDIO element functions.*

*Note: In the Element functions, you can pass in additional parameters which will be passed to the selectors.*

BasePage should contain all functionality accessible from all pages. It is expected that project-specific frameworks will implement their own BasePage.
An example of the inheritance structure to be used is here:

![pom inheritance structure](./img/page-inheritance-diagram.png "POM Inheritance Structure")

By moving the selector data out to a constant store, we can reduce the amount of code within page objects. `app.js` would contain:
```
const APP_DETAILS = {
  myPageTitle : 'Welcome to My Page'
};

const ELEMENTS = {
  myPage : {
    forenameField : {
      selector    : () => 'input#forename',
      description : () => 'forename field'
    },
    surnameField : {
      selector    : () => 'input#surname',
      description : () => 'surname field'
    },
    submitButton : {
      selector    : name => `button#submit-${name}`,
      description : name => `submit button for ${name}`
    }
  } 
};


export {
  APP_DETAILS,
  ELEMENTS
};
```

## Coding Standards
Please see [JavaScript Guidelines](https://github.fenicsone.com/fenics/documentation/wiki/JavaScript-Guidelines)
