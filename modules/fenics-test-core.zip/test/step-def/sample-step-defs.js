import {Given as given, When as when, Then as then} from 'cucumber';

given('I have done something awesome', () => {
  console.log('Look at me go.');
});

when('I tell all my friends', () => {
  console.log('Hey guess what I did?');
});

then('they should celebrate', () => {
  console.log('"We don\'t care", they said.');
});
