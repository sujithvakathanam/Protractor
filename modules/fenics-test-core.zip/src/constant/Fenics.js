const DOMAINS = {
  FENICS_ONE : 'fenicsone.com'
};

const FENICS_SERVICES = {
  NEXUS : `https://nexus.${DOMAINS.FENICS_ONE}`
};

export {
  DOMAINS,
  FENICS_SERVICES
};
