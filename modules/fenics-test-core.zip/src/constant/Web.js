const CONTENT_HEADER = {
  OCTET_STREAM : 'application/octet-stream',
  JSON_FIX     : 'application/jsonfix',
  JSON         : 'application/json',
  JRDJSON      : 'application/jrd+json'

};

const NODE = {
  NODE_TLS_REJECT_UNAUTHORIZED : 0
};

export {
  CONTENT_HEADER,
  NODE
};
