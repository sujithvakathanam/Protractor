const SCRIPTS_FOLDER = 'src/scripts';
const CONFIGS_FOLDER = 'src/framework/config';

const SCRIPTS = {
  OPENFIN : {
    RUN_OPENFIN       : `${SCRIPTS_FOLDER}/openfin/RunOpenFin.bat`,
    TERMINATE_OPENFIN : `${SCRIPTS_FOLDER}/openfin/TerminateOpenfin.bat`
  }
};

const CONFIGS = {
  WDIO_CONFIG      : `${CONFIGS_FOLDER}/wdio.config.sample.js`,
  FRAMEWORK_CONFIG : `${CONFIGS_FOLDER}/framework.config.sample.js`,
  API_CONFIG       : `${CONFIGS_FOLDER}/api.config.sample.js`,
  USERS_CONFIG     : `${CONFIGS_FOLDER}/users.config.sample.js`,
  ESLINTRC_CONFIG  : `${CONFIGS_FOLDER}/ESLINTRC.txt`,
  NPMRC_CONFIG     : `${CONFIGS_FOLDER}/.npmrc`,
  GITIGNORE_CONFIG : `${CONFIGS_FOLDER}/GITIGNORE.txt`
};

export {
  SCRIPTS,
  CONFIGS
};
