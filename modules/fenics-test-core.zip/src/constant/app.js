const APP_DETAILS = {
  launchbarTitle : 'Fenics Launchbar',
  loginPageTitle : 'Fenics Login'
};

const ELEMENTS = {
  loginPage : {
    loadingSpinner : {
      selector    : () => '.loading-spinner.svelte-1obqx4g',
      description : () => 'loading spinner'
    },
    usernameField : {
      selector    : () => 'input.fenics-input.fenics-input-lg.login__form__row__control',
      description : () => 'username field'
    },
    passwordField : {
      selector    : () => '#okta-signin-password',
      description : () => 'password field'
    },
    rememberUsernameCheckbox : {
      selector    : () => 'input.fenics-checkbox-input',
      description : () => 'remember username textbox'
    },
    forgotUsernameButton : {
      selector    : () => 'section.login__form__row.login__form__row--extra-mt.text-cta',
      description : () => 'forgot username button'
    },
    nextButton : {
      selector    : () => 'button.fenics-btn.login__form__row__cta.fenics-btn-primary',
      description : () => 'next button'
    },
    errorMessageLabel : {
      selector    : () => 'div.login__form__row.login__form__row--error',
      description : () => 'error message label'
    },
    signInErrorMessageLabel : {
      selector    : () => 'div.okta-form-infobox-error.infobox.infobox-error',
      description : () => 'sign in error message label'
    },
    signInButton : {
      selector    : () => '#okta-signin-submit',
      description : () => 'sign in button'
    }
  },
  launchbarPage : {
    applicationWrapper : {
      selector    : () => '//ul[descendant::figcaption]',
      description : () => 'wrapper for application buttons'
    },
    loadingSpinner : {
      selector    : () => '//article[@class="loading-spinner-wrap svelte-1obqx4g")]',
      description : () => 'loading spinner'
    },
    applicationButton : {
      selector    : applicationName => `//li[descendant::figcaption[text()="${applicationName}"]]`,
      description : applicationName => `application button for ${applicationName}`
    }
  }
};

export {
  APP_DETAILS,
  ELEMENTS
};
