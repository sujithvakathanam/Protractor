import Bootstrap from './framework';
import {spawnAttachedProcess, spawnDetachedProcess} from './utilities/ShellExec';
import {coercer, isArrayEmpty} from './utilities/ArrayHelper';
import {CONTENT_HEADER, NODE} from './constant/Web';
import {APP_DETAILS, ELEMENTS} from './constant/app';
import {
  BasePage,
  Element,
  LaunchbarPage,
  LoginPage
} from './pages';
import {
  FenicsTransportClient,
  OktaAuthentication,
  WsClient,
  HttpsHandler
} from './api';

const ArrayHelper = {
  coercer,
  isArrayEmpty
};

const ShellExec = {
  spawnAttachedProcess : (script, args) => spawnAttachedProcess(script, args),
  spawnDetachedProcess : (script, args) => spawnDetachedProcess(script, args)
};

export {
  Bootstrap,
  ShellExec,
  ArrayHelper,
  BasePage,
  Element,
  LaunchbarPage,
  LoginPage,
  FenicsTransportClient,
  OktaAuthentication,
  WsClient,
  HttpsHandler,
  CONTENT_HEADER,
  NODE,
  APP_DETAILS,
  ELEMENTS
};
