/* eslint-disable prefer-rest-params, no-await-in-loop  */
import Element from './Element';

class BasePage {
  static async switchToWindow (windowTitle) {
    if (typeof windowTitle !== 'string' && !(windowTitle instanceof RegExp)) {
      throw new Error('Unsupported parameter for switchToWindow, required is "string" or an RegExp');
    }

    const tabs = await global.browser.windowHandles();

    // eslint-disable-next-line no-unused-vars
    for (const tab of tabs.value) {
      await global.browser.switchTab(tab);
      const title = await global.browser.getTitle();

      if (title.match(windowTitle)) {
        return tab;
      }
    }

    throw new Error(`No window found with title matching "${windowTitle}"`);
  }

  static async switchToWindowByElement (element) {
    const numberOfKnownArgs = 1;
    const args = Array.prototype.slice.call(arguments, numberOfKnownArgs);

    const tabs = await global.browser.windowHandles();

    // eslint-disable-next-line no-unused-vars
    for (const tab of tabs.value) {
      await global.browser.switchTab(tab);

      if (await Element.isExisting(element, args)) {
        return tab;
      }
    }

    throw new Error(`No window found with element matching description ${element.description()}`);
  }

  static async waitForWindow (windowTitle) {
    global.context.logger.info(`Switching to window with title ${windowTitle}`);

    await global.browser.waitUntil(
      () => BasePage.switchToWindow(windowTitle), global.context.configuration.mediumTimeout,
      `Timed out after ${global.context.configuration.mediumTimeout} seconds, waiting for tab: ${windowTitle}.`
    );
  }

  static async waitForWindowByElement (element) {
    const numberOfKnownArgs = 1;
    const args = Array.prototype.slice.call(arguments, numberOfKnownArgs);

    global.context.logger.info(`Switching to window with element (description): ${element.description(args)}`);

    await global.browser.waitUntil(
      () => BasePage.switchToWindowByElement(element, args), global.context.configuration.mediumTimeout,
      `Timed out after ${global.context.configuration.mediumTimeout} seconds.`
    );
  }
}

export default BasePage;
