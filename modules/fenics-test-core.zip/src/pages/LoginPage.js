import BasePage from './BasePage.js';
import {ELEMENTS, APP_DETAILS} from '../constant/app';
import Element from './Element';

const elements = ELEMENTS.loginPage;

class LoginPage extends BasePage {
  static async switchTo () {
    await super.waitForWindow(APP_DETAILS.loginPageTitle);
  }

  static async waitForPageLoad () {
    const {pageLoadWaitDuration, shortTimeout} = global.context.configuration;
    const waitDuration = pageLoadWaitDuration || shortTimeout;

    await Element.waitForVisible(elements.loadingSpinner, waitDuration, true);
  }

  static async enterUsername (username) {
    await Element.setText(elements.usernameField, username);
  }

  static async enterPassword (password) {
    await Element.setText(elements.passwordField, password);
  }

  static async clickRememberUsername () {
    await Element.click(elements.rememberUsernameCheckbox);
  }

  static async clickForgotUsername () {
    await Element.click(elements.forgotUsernameButton);
  }

  static async clickNext () {
    await Element.click(elements.nextButton);
  }

  static async clickSignIn () {
    await Element.click(elements.signInButton);
  }

  static async login (username) {
    const user = global.context.getUserConfiguration(username);

    const {passwordFieldWaitDuration, shortTimeout} = global.context.configuration;
    const waitDuration = passwordFieldWaitDuration || shortTimeout;

    await LoginPage.waitForPageLoad();
    await LoginPage.enterUsername(user.username);
    await LoginPage.clickNext();
    await Element.waitForVisible(elements.passwordField, waitDuration);
    await LoginPage.enterPassword(user.password);
    await LoginPage.clickSignIn();
  }
}

export default LoginPage;
