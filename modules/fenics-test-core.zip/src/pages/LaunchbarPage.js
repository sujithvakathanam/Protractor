import BasePage from './BasePage.js';
import Element from './Element';
import {ELEMENTS, APP_DETAILS} from '../constant/app';

const elements = ELEMENTS.launchbarPage;

class LaunchbarPage extends BasePage {
  static async switchTo () {
    await super.waitForWindow(APP_DETAILS.launchbarTitle);
  }

  static async waitForPageLoad () {
    await Element.waitForVisible(elements.applicationWrapper, global.context.configuration.mediumTimeout);
  }

  static async openApplication (applicationName) {
    await LaunchbarPage.waitForPageLoad();
    const waitDuration = 5000;
    await Element.waitForExists(elements.loadingSpinner, waitDuration, true);
    await Element.click(elements.applicationButton, applicationName);
  }
}

export default LaunchbarPage;
