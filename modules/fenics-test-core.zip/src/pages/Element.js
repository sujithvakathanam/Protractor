/* eslint-disable max-params */

class Element {
  static async click (elementData, ...params) {
    global.context.logger.debug(`Clicking on ${elementData.description(...params)}`);

    await global.browser.click(elementData.selector(...params));
  }

  /**
   * Gets the textual content between the opening and closing tag of an HTML element.
   * Use for getting the text in a <div>, <span> or <td>, for example.
   * @param elementData
   * @param params
   * @returns {String|String[]|string}
   */
  static getText (elementData, ...params) {
    global.context.logger.debug(`Getting text of ${elementData.description(...params)}`);

    const result = global.browser.getText(elementData.selector(...params));

    global.context.logger.debug(result);

    return result;
  }

  /**
   * Gets the text from the value attribute of an element.
   * Use for getting the content of an <input> element, or the value attribute of the
   * selected <option> in a <select> element. Note that the 'value' of an option is
   * not necessarily the same as its visible text; it is the identifier of the option.
   * @param elementData
   * @param params
   * @returns {String|String[]|string}
   */
  static getValue (elementData, ...params) {
    global.context.logger.debug(`Getting value of ${elementData.description(...params)}`);

    const result = global.browser.getValue(elementData.selector(...params));

    global.context.logger.debug(result);

    return result;
  }

  /**
   * This function is mis-named, since it actually sets the value attribute and not
   * the textual content (see getText/getValue above), but it is retained for back-compatibility.
   * @param elementData
   * @param text
   * @param params
   * @returns {Promise<void>}
   */
  static async setText (elementData, text = '', ...params) {
    global.context.logger.debug(`Setting value of ${elementData.description(...params)} to ${text}`);

    await global.browser.setValue(elementData.selector(...params), text);
  }

  /**
   * This function sets the value attribute of the element, use it to set the content
   * of <input> elements, and with <select> elements if you wish to set the selected
   * <option> by its 'value' attribute rather than its visible text.
   * @param elementData
   * @param text
   * @param params
   * @returns {Promise<void>}
   */
  static async setValue (elementData, text = '', ...params) {
    global.context.logger.debug(`Setting value of ${elementData.description(...params)} to ${text}`);

    await global.browser.setValue(elementData.selector(...params), text);
  }

  static getChecked (elementData, ...params) {
    return Element.getAttribute(elementData, 'checked', ...params);
  }

  static toggleChecked (elementData, ...params) {
    return Element.click(elementData, ...params);
  }

  static setChecked (elementData, checkedState, ...params) {
    const isChecked = Element.getChecked(elementData, ...params);

    if (Boolean(isChecked) !== checkedState) {
      return Element.toggleChecked(elementData, ...params);
    }

    return isChecked;
  }

  static async selectByVisibleText (elementData, text, ...params) {
    global.context.logger.debug(`Selecting dropdown item '${text}' on ${elementData.description(...params)}`);

    await global.browser.selectByVisibleText(elementData.selector(...params), text);
  }

  static getAttribute (elementData, attributeName, ...params) {
    if (!attributeName) {
      throw new Error('Attribute name must have a value');
    }

    const description = elementData.description(...params);

    global.context.logger.debug(`Getting attribute ${attributeName} value from ${description}`);

    const result = global.browser.getAttribute(elementData.selector(...params), attributeName);

    global.context.logger.debug(result);

    return result;
  }

  static async waitForVisible (elementData, timeout, reverse, ...params) {
    if (reverse) {
      const msg1 = 'Using browser.waitForVisible with the reverse argument set to true is possibly ';
      const msg2 = 'unstable until WDIO v5. See: https://github.com/webdriverio/webdriverio/issues/2208';
      global.context.logger.warn(`${msg1}${msg2}`);
    }

    global.context.logger.debug(`Waiting up to ${timeout}ms for ${elementData.description(...params)} to exist`);

    await global.browser.waitForVisible(elementData.selector(...params), timeout, reverse);
  }

  static async waitForExist (elementData, timeout, reverse, ...params) {
    global.context.logger.debug(`Waiting for up to ${timeout}ms for ${elementData.description(...params)} to exist`);

    await global.browser.waitForExist(elementData.selector(...params), timeout, reverse);
  }

  static async hasFocus (elementData, ...params) {
    global.context.logger.debug(`Checking focus state for ${elementData.description(...params)}`);
    let state = false;

    try {
      state = await global.browser.hasFocus(elementData.selector(...params));
      global.context.logger.debug(state);
    } catch (error) {
      global.context.logger.error(error);
      throw error;
    }

    return state;
  }

  static async isEnabled (elementData, ...params) {
    global.context.logger.debug(`Checking enabled state for ${elementData.description(...params)}`);
    let state = false;

    try {
      state = await global.browser.isEnabled(elementData.selector(...params));
      global.context.logger.debug(state);
    } catch (error) {
      global.context.logger.error(error);
      throw error;
    }

    return state;
  }

  static async isExisting (elementData, ...params) {
    global.context.logger.debug(`Checking existing state for ${elementData.description(...params)}`);
    let state = false;

    try {
      state = await global.browser.isExisting(elementData.selector(...params));
      global.context.logger.debug(state);
    } catch (error) {
      global.context.logger.error(error);
      throw error;
    }

    return state;
  }

  static async isSelected (elementData, ...params) {
    global.context.logger.debug(`Checking selected state for ${elementData.description(...params)}`);
    let state = false;

    try {
      state = await global.browser.isSelected(elementData.selector(...params));
      global.context.logger.debug(state);
    } catch (error) {
      global.context.logger.error(error);
      throw error;
    }

    return state;
  }

  static async isVisible (elementData, ...params) {
    global.context.logger.debug(`Checking visibility state for ${elementData.description(...params)}`);
    let state = false;

    try {
      state = await global.browser.isVisible(elementData.selector(...params));
      global.context.logger.debug(state);
    } catch (error) {
      global.context.logger.error(error);
      throw error;
    }

    return state;
  }
}

export default Element;
