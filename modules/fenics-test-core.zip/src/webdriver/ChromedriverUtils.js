/* eslint-disable no-console */

const {execSync, spawn} = require('child_process');

const WEBDRIVER_MANAGER_LOCATION = 'node_modules\\.bin\\webdriver-manager';
const CHROMEDRIVER_VERSION = '2.34';
const DOWNLOAD_LOCATION = process.cwd();
const SELENIUM_PORT = '9515';

class ChromedriverUtils {
  static update () {
    const cmd = `${WEBDRIVER_MANAGER_LOCATION} update --ignore_ssl --out_dir=${DOWNLOAD_LOCATION} --gecko=false --versions.chrome=${CHROMEDRIVER_VERSION}`;

    console.log(`Starting update with command '${cmd}'`);

    execSync(cmd, {stdio : 'inherit'});
  }

  static start () {
    const cmd = `${WEBDRIVER_MANAGER_LOCATION} start`;
    const args = [
      `--out_dir=${DOWNLOAD_LOCATION}`,
      `--versions.chrome=${CHROMEDRIVER_VERSION}`,
      `--seleniumPort=${SELENIUM_PORT}`
    ];

    console.log(`Starting start with command '${cmd}' with cwd = ${process.cwd()}`);

    global.webdriverProcess = spawn(
      cmd, args,
      {
        shell    : true,
        detached : true
      }
    );
  }

  static stop () {
    console.log('Stopping webdriver process.');

    execSync(`taskkill /f /fi "IMAGENAME eq chromedriver_${CHROMEDRIVER_VERSION}.exe"`, {stdio : 'inherit'});
    execSync('taskkill /f /fi "IMAGENAME eq java.exe*"', {stdio : 'inherit'});
  }

  static clean () {
    if (global.cleanup) {
      const cleanCmd = `${WEBDRIVER_MANAGER_LOCATION} clean --out_dir=${DOWNLOAD_LOCATION}`;

      console.log(`Starting clean with command ${cleanCmd}.`);

      execSync(cleanCmd, {stdio : 'inherit'});
    }
  }
}

module.exports = ChromedriverUtils;
