class ScenarioContext {
  constructor () {
    this.scenarioContext = new Map();
  }

  set (key, value) {
    this.scenarioContext.set(key, value);
  }

  get (key) {
    const pair = this.scenarioContext.get(key);

    if (!pair) {
      throw new Error(`Could not get key value pair, ScenarioContext does not contain "${key}".`);
    }

    return pair;
  }

  contains (key) {
    return this.scenarioContext.has(key);
  }
}

export default ScenarioContext;
