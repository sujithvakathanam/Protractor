import FenicsLogger, {LOG_LEVEL} from '@fenics/fenics-logging';
import ScenarioContext from './ScenarioContext';

class Context {
  static build () {
    return new Context();
  }

  withLogger () {
    this.logger = new FenicsLogger();

    return this;
  }

  withConfiguration (configuration) {
    this.configuration = configuration;
    const logLevel = configuration.logLevel ? LOG_LEVEL[configuration.logLevel] : LOG_LEVEL.info;
    FenicsLogger.setLevel(logLevel);

    let duration = null;

    if (configuration.implicitWaitDuration) {
      duration = configuration.implicitWaitDuration;
    } else {
      duration = configuration.implicitWaitDurationDefault;
    }

    global.browser.timeouts({implicit : duration});

    return this;
  }

  withScenarioContext () {
    this.scenarioContext = new ScenarioContext();

    return this;
  }

  getLogger () {
    if (!this.logger) {
      throw new Error('logger has not been set.');
    }

    return this.logger;
  }

  getConfiguration () {
    if (!this.configuration) {
      throw new Error('configuration has not been set.');
    }

    return this.configuration;
  }

  getScenarioContext () {
    if (!this.scenarioContext) {
      throw new Error('Scenario context has not been set.');
    }

    return this.scenarioContext;
  }

  getUserConfiguration (byUsername) {
    const config = this.getConfiguration();
    let userDetails = {};

    if (config.users) {
      userDetails = config.users.find(user => user.username === byUsername);

      if (userDetails === undefined) {
        throw new Error(`Could not find "${byUsername}" in the configuration!`);
      }
    } else {
      throw new Error('The property "users" does not exist in the configuration!');
    }

    return userDetails;
  }
}

export default Context;
