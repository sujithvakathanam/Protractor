import Context from './Context';
import {coercer} from '../../utilities/ArrayHelper';

class Bootstrap {
  constructor (configuration) {
    coercer(configuration).forEach(config => {
      this.configuration = Object.assign({}, this.configuration, config);
    });

    this.getInstance();
  }

  getInstance () {
    if (!this.context) {
      this.context = Context.build()
        .withLogger()
        .withConfiguration(this.configuration)
        .withScenarioContext();
    }
    global.context = this.context;

    return this.context;
  }
}

export default Bootstrap;
