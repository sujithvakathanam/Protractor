const merge = require('deepmerge');
const baseConf = require('@fenics/fenics-test-core/config/wdio-api-conf');

/**
 * To use this:
 *   1) Create a copy of this sample file and remove the '.sample' suffix
 *   2) Check the baseConf is being properly inherited from the wdio-api-conf.js in fenics-test-core
 *   3) Add your API specs/suites/exclusions below
 *   4) Override any config properties which are set in the base config
 *   5) Create a new run configuration as follows: `./config/wdio-api-conf.js --suite <suiteName> --env=<[dev|qa]>`
 */

exports.config = merge(baseConf.config, {
  specs : [
    /* Test suites to be executed go here.  */
  ],
  exclude : [
    /* Test suites to be excluded go here.  */
  ]
});
