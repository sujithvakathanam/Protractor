const gentlyCopy = require('gently-copy');
const fs = require('fs');

const SCRIPTS_FOLDER = 'src/scripts';
const CONFIGS_FOLDER = 'src/framework/config';

const SCRIPTS = {
  OPENFIN : {
    RUN_OPENFIN       : `${SCRIPTS_FOLDER}/openfin/RunOpenFin.bat`,
    TERMINATE_OPENFIN : `${SCRIPTS_FOLDER}/openfin/TerminateOpenfin.bat`
  }
};

const CONFIGS = {
  FRAMEWORK_CONFIG       : `${CONFIGS_FOLDER}/framework.config.sample.js`,
  API_CONFIG             : `${CONFIGS_FOLDER}/api.config.sample.js`,
  USERS_CONFIG           : `${CONFIGS_FOLDER}/users.config.sample.js`,
  ESLINTRC_CONFIG        : `${CONFIGS_FOLDER}/ESLINTRC.txt`,
  NPMRC_CONFIG           : `${CONFIGS_FOLDER}/.npmrc`,
  GITIGNORE_CONFIG       : `${CONFIGS_FOLDER}/GITIGNORE.txt`,
  WDIO_UI_CONFIG_SAMPLE  : `${CONFIGS_FOLDER}/wdio-ui-conf.sample.js`,
  WDIO_API_CONFIG_SAMPLE : `${CONFIGS_FOLDER}/wdio-api-conf.sample.js`
};

const CONSTANTS = {
  APP_CONSTANTS : `${CONFIGS_FOLDER}/app.sample.js`
};

const scriptsToCopy = [
  SCRIPTS.OPENFIN.RUN_OPENFIN,
  SCRIPTS.OPENFIN.TERMINATE_OPENFIN
];

const configsToCopy = [
  CONFIGS.FRAMEWORK_CONFIG,
  CONFIGS.API_CONFIG,
  CONFIGS.USERS_CONFIG,
  CONFIGS.WDIO_UI_CONFIG_SAMPLE,
  CONFIGS.WDIO_API_CONFIG_SAMPLE
];

const constantsToCopy = [
  CONSTANTS.APP_CONSTANTS
];

gentlyCopy(CONFIGS.NPMRC_CONFIG, process.env.INIT_CWD, {overwrite : true});
gentlyCopy(CONFIGS.ESLINTRC_CONFIG, `${process.env.INIT_CWD}/.eslintrc.js`, {overwrite : true});
gentlyCopy(CONFIGS.GITIGNORE_CONFIG, `${process.env.INIT_CWD}/.gitignore`, {overwrite : true});
gentlyCopy(scriptsToCopy, process.env.INIT_CWD, {overwrite : true});

const frameworkDirs = [
  `${process.env.INIT_CWD}/config/`,
  `${process.env.INIT_CWD}/constant/`,
  `${process.env.INIT_CWD}/pages/`,
  `${process.env.INIT_CWD}/test/`,
  `${process.env.INIT_CWD}/test/spec/`,
  `${process.env.INIT_CWD}/test/feature/`,
  `${process.env.INIT_CWD}/test/step-def/`
];

frameworkDirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
  }
});

gentlyCopy(configsToCopy, `${process.env.INIT_CWD}/config/`, {overwrite : false});
gentlyCopy(constantsToCopy, `${process.env.INIT_CWD}/constant/`, {overwrite : false});
