import WebSocket from 'ws';

class WsClient {
  constructor (accessTokenKey, accessTokenValue, urlOverride) {
    const baseUrl = urlOverride ? urlOverride : `wss://fenics-ws.${global.context.configuration.appDomain}`;
    const url = `${baseUrl}?${accessTokenKey}=${accessTokenValue}`;

    global.context.logger.debug(`New WebSocket created with Url ${url}`);

    this.Ws = new WebSocket(url);
  }

  openWss (onMessageFunction, onOpenFunction) {
    return new Promise((resolve, reject) => {
      this.Ws.on('message', async data => {
        global.context.logger.debug(`WebSocket received message: ${data.toString()}`);
        await onMessageFunction(data);
      });

      this.Ws.on('open', async () => {
        global.context.logger.info('Web socket connection opened.');
        const result = await onOpenFunction();
        resolve(result);
      });

      this.Ws.on('close', () => {
        global.context.logger.info('Web socket connection closed.');
      });

      this.Ws.on('error', error => {
        global.context.logger.error(error);
        reject(error);
      });
    });
  }

  sendData (data) {
    global.context.logger.debug(`WebSocket sending message: ${data.toString()}`);
    this.Ws.send(data);
  }

  closeWss () {
    this.Ws.close();
  }
}

export default WsClient;
