import {ftransport, ftransportMiddlewares} from '@fenics/fenics-transport';
import Fix from '@fenics/fenics-encoding';
import flow from 'lodash/flow';
import {isArrayEmpty} from '../../utilities/ArrayHelper';
import {CONTENT_HEADER} from '../../constant/Web';

// eslint-disable-next-line complexity
const removeEmpty = obj => Object.entries(obj).reduce((acc, [key, val]) => {
  if (val && typeof val === 'object' && !Array.isArray(val)) {
    acc[key] = removeEmpty(val);
  } else if (Array.isArray(val)) {
    acc[key] = val.map(item => removeEmpty(item));
  } else if (val !== '' && val !== undefined && val !== null) {
    acc[key] = val;
  }

  return acc;
}, {});

const removeFixCommonTags = decoded => {
  const asArray = Array.isArray(decoded) ? decoded : [decoded];

  /**
   * Can't use the object destructure + rest operator
   * to remove properties as it will throw a runtime
   * error. This needs to be investigates as there are
   * a set of ES7 features that do not seem to work in
   * web workers (spread operator, class properties)
   */
  return asArray.map(item => {
    const newItem = Object.assign({}, item);

    const OMIT_PROPS_WHITELIST = [
      'BeginString',
      'BodyLength',
      'MsgSeqNum',
      'SenderCompID',
      'SendingTime',
      'SenderSubID',
      'TargetCompID',
      'TargetSubID',
      'CheckSum'
    ];

    OMIT_PROPS_WHITELIST.forEach(propName => {
      delete newItem[propName];
    });

    return newItem;
  });
};

const apiHeaders = user => ({
  'x-auth-userid'   : user.oktaId,
  'x-auth-username' : user.username,
  'x-auth-lei'      : user.lei,
  'x-auth-espeedid' : user.espeed
});

const setFixDictionary = () => Fix.setDictionary({
  5019  : 'TradingSessionID2',
  9303  : 'RoutingInst',
  10042 : 'PricingDuration',
  10043 : 'PrivateDuration',
  10044 : 'GroupDuration'
});

class FenicsTransportClient {
  constructor (context, userName) {
    this.baseUrl = context.getConfiguration().apiUrl;
    this.apiUser = context.getUserConfiguration(userName);

    if (isArrayEmpty(this.apiUser)) {
      throw new Error('User configuration not found.');
    }

    const fixMiddleware = ftransportMiddlewares.payloadFormatterMiddleware({
      encode : flow(removeEmpty, Fix.encode),
      decode : payload => {
        const decoded = Fix.decode(payload, {
          validateBodyLength : false,
          validateChecksum   : false
        });

        return removeFixCommonTags(decoded);
      }
    });

    setFixDictionary();

    this.traderApi = ftransport()
      .content(CONTENT_HEADER.OCTET_STREAM)
      .accept(CONTENT_HEADER.OCTET_STREAM)
      .middlewares([fixMiddleware])
      .url(this.baseUrl)
      .headers(apiHeaders(this.apiUser));

    this.adminApi = ftransport()
      .content(CONTENT_HEADER.JSON_FIX)
      .accept(CONTENT_HEADER.JSON_FIX)
      .url(this.baseUrl)
      .headers(apiHeaders(this.apiUser));
  }

  static postRequest (transport, endpoint, body) {
    transport.url(endpoint)
      .body(body)
      .post()
      .json();
  }

  static getRequest (transport, endpoint, body) {
    transport.url(endpoint)
      .body(body)
      .get()
      .json();
  }
}

export default FenicsTransportClient;
