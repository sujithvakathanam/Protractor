/* eslint-disable max-params,max-lines,max-len */
import HttpsHandler from '../Handlers/HttpsHandler';
import {CONTENT_HEADER, NODE} from '../../constant/Web';

const {URL} = require('url');
const cheerio = require('cheerio');
const queryString = require('querystring');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = NODE.NODE_TLS_REJECT_UNAUTHORIZED;

class OktaAuthentication {
  constructor () {
    this.Handler = new HttpsHandler();
  }

  static getCookieString (setCookies) {
    let cookieStr = '';
    setCookies.forEach(cookie => {
      const setCookie = cookie.split(';')[0];

      if (setCookie !== 'sid=""') {
        cookieStr += `${setCookie}; `;
      }
    });

    return cookieStr;
  }

  async authenticate (username, password) {
    const urlSaml = await this.getStartSaml();

    const webFingerData = await this.webFinger(username);
    const oktaIdpId = webFingerData.oktaIdpId;
    const titleUnd = webFingerData.titleUnd;

    const sessionToken = await this.getSessionToken(username, password, urlSaml, titleUnd);
    const sessionTokenCookiesStr = OktaAuthentication.getCookieString(sessionToken.setCookies);

    const checkAccountHeader = await this.checkAccountSetup(urlSaml, sessionToken.sessionToken, sessionTokenCookiesStr, oktaIdpId, titleUnd);
    const checkAccountCookieStr = OktaAuthentication.getCookieString(checkAccountHeader);

    const loginAppRelayStateSaml = await this.getFenicsLoginApp(urlSaml, checkAccountCookieStr, oktaIdpId);
    const oktaOrgId = loginAppRelayStateSaml.oktaOrgId;

    const samlResponse = await this.getSsoSamlResponse(urlSaml, loginAppRelayStateSaml, checkAccountCookieStr, oktaIdpId, oktaOrgId, titleUnd);
    const loginAppCookieStr = OktaAuthentication.getCookieString(loginAppRelayStateSaml.setCookies);

    const verifyCookiesNLocation = await this.verifySamlResponse(urlSaml, samlResponse, loginAppCookieStr, oktaIdpId, oktaOrgId, titleUnd);

    const verifyCookiesStr = OktaAuthentication.getCookieString(verifyCookiesNLocation.setCookies);
    const verifyNDtCookies = verifyCookiesStr + loginAppCookieStr.split(';')[2];

    const samlRedirect = await this.samlResponseRedirect(verifyCookiesNLocation.location, verifyNDtCookies, oktaOrgId, titleUnd);

    const location = await this.getLoginTicket(samlRedirect);
    const ticket = new URL(location).searchParams.get('ticket');

    const bearerToken = await this.getBearerToken(ticket);

    return bearerToken;
  }

  async getStartSaml () {
    const url = `https://fenics-api.${global.context.configuration.appDomain}/v1//sso/saml/start`;

    const startSamlRedirectUrl = await this.Handler.getDirect(url).then(response => {
      const location = response.headers.location;
      const redirectUrl = new URL(location);

      return redirectUrl;
    });

    return startSamlRedirectUrl;
  }

  async webFinger (username) {
    const path = `/.well-known/webfinger?rel=okta%3Aidp&requestContext=&resource=okta%3Aacct%3A${username}`;
    const headers = {
      Accept             : CONTENT_HEADER.JRDJSON,
      'Accept-Encoding'  : 'deflate',
      'X-Requested-With' : 'XMLHttpRequest',
      'Content-Type'     : CONTENT_HEADER.JSON,
      Connection         : 'keep-alive',
      Host               : 'sso.bgcpartners.com'
    };
    const options = {
      hostname : 'sso.bgcpartners.com',
      path,
      headers
    };

    const userDetails = await this.Handler.get(options, pageData => {
      const jsonData = JSON.parse(pageData);
      const oktaIdpId = jsonData.links['0'].properties['okta:idp:id'];
      const titleUnd = jsonData.links['0'].titles.und;

      return {
        oktaIdpId,
        titleUnd
      };
    });

    return userDetails;
  }

  async getSessionToken (username, password, urlSaml, titleUnd) {
    const escapedUrlSaml = queryString.escape(urlSaml);
    const referer = `https://fenics-loader.${global.context.configuration.appDomain}/fenics/fenics-login-app?fromURI=${escapedUrlSaml}`;
    const postData = JSON.stringify({
      options : {
        warnBeforePasswordExpired : true,
        multiOptionalFactorEnroll : false
      },
      username,
      password
    });
    const headers = {
      Accept            : CONTENT_HEADER.JSON,
      'Accept-Encoding' : 'deflate',
      'Content-Type'    : CONTENT_HEADER.JSON,
      'Content-Length'  : Buffer.byteLength(postData),
      Origin            : `https://fenics-loader.${global.context.configuration.appDomain}`,
      Connection        : 'keep-alive',
      Referer           : referer,
      Host              : titleUnd
    };
    const options = {
      hostname : titleUnd,
      path     : '/api/v1/authn/',
      method   : 'POST',
      headers
    };

    const sessionToken = await this.Handler.request(options, postData, (pageData, response) => {
      const jsonResponse = JSON.parse(pageData);

      return {
        sessionToken : jsonResponse.sessionToken,
        setCookies   : response.headers['set-cookie']
      };
    });

    return sessionToken;
  }

  async checkAccountSetup (urlSaml, sessionToken, cookies, oktaIdpId, titleUnd) {
    const redirectUrlPath = `&redirectUrl=${queryString.escape(`${'https://sso.bgcpartners.com/sso/idps/'}${oktaIdpId}?fromURI=${urlSaml}`)}`;
    const tokenNRedirect = `&token=${sessionToken}${redirectUrlPath}`;
    const path = `${'/login/sessionCookieRedirect?checkAccountSetupComplete=true'}${tokenNRedirect}`;
    const headers = {
      Accept                      : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      Cookie                      : cookies,
      Referer                     : `https://fenics-loader.${global.context.configuration.appDomain}/fenics/fenics-login-app?fromURI=${queryString.escape(urlSaml)}`,
      'Upgrade-Insecure-Requests' : 1,
      Connection                  : 'keep-alive',
      Host                        : titleUnd
    };
    const options = {
      hostname : titleUnd,
      path,
      headers
    };

    const setCookieHeader = await this.Handler.get(options, (pageData, response) => response.headers['set-cookie']);

    return setCookieHeader;
  }

  async getFenicsLoginApp (urlSaml, cookies, oktaIdpId) {
    const path = `/sso/idps/${oktaIdpId}?fromURI=${urlSaml}`;
    const escapedUrlSaml = queryString.escape(urlSaml);
    const referer = `https://fenics-loader.${global.context.configuration.appDomain}/fenics/fenics-login-app?fromURI=${escapedUrlSaml}`;
    const headers = {
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      Cookie                      : cookies,
      Referer                     : referer,
      'Upgrade-Insecure-Requests' : 1,
      Connection                  : 'keep-alive',
      Host                        : 'sso.bgcpartners.com'
    };
    const options = {
      hostname : 'sso.bgcpartners.com',
      path,
      agent    : false,
      headers
    };

    const loginAppPageData = await this.Handler.get(options, (pageData, response) => {
      const dom = cheerio.load(pageData);
      let formAction = dom('form[id="appForm"]').attr('action');
      formAction = queryString.unescape(formAction);
      formAction = formAction.substring(0, formAction.indexOf('/sso/saml'));
      formAction = formAction.substring(formAction.lastIndexOf('/') + 1);
      let samlDoc = dom('input[name="SAMLRequest"]').attr('value');
      samlDoc = queryString.unescape(samlDoc);
      let relayState = dom('input[name="RelayState"]').attr('value');
      relayState = queryString.unescape(relayState);

      return {
        samlDoc,
        relayState,
        setCookies : response.headers['set-cookie'],
        oktaOrgId  : formAction
      };
    });

    return loginAppPageData;
  }

  async getSsoSamlResponse (urlSaml, relayStateSamlDoc, cookies, oktaIdpId, oktaOrgId, titleUnd) {
    const referer = `https://sso.bgcpartners.com/sso/idps/${oktaIdpId}?fromURI=${urlSaml}`;
    const escapedSaml = queryString.escape(relayStateSamlDoc.samlDoc);
    const escapedRelayState = queryString.escape(queryString.escape(relayStateSamlDoc.relayState));
    const postData = `SAMLRequest=${escapedSaml}&RelayState=${escapedRelayState}`;

    const headers = {
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      'Content-Type'              : 'application/x-www-form-urlencoded',
      'Content-Length'            : Buffer.byteLength(postData),
      Origin                      : 'https://sso.bgcpartners.com',
      Connection                  : 'keep-alive',
      Referer                     : referer,
      Host                        : titleUnd,
      Cookie                      : cookies,
      'Upgrade-Insecure-Requests' : 1
    };
    const options = {
      hostname : titleUnd,
      path     : `/app/okta_org2org/${oktaOrgId}/sso/saml`,
      method   : 'POST',
      headers
    };

    const samlResponse = await this.Handler.request(options, postData, pageData => {
      const dom = cheerio.load(pageData);
      let samlDoc = dom('input[name="SAMLResponse"]').attr('value');
      samlDoc = queryString.unescape(samlDoc);
      let relayState = dom('input[name="RelayState"]').attr('value');
      relayState = queryString.unescape(relayState);

      return {
        relayState,
        samlResponse : samlDoc
      };
    });

    return samlResponse;
  }

  async verifySamlResponse (urlSaml, samlResponse, cookieString, oktaIdpId, oktaOrgId, titleUnd) {
    const path = `/sso/saml2/${oktaIdpId}`;
    const escapedSamlResponse = queryString.escape(samlResponse.samlResponse);
    const escapedRelayState = queryString.escape(samlResponse.relayState);
    const postData = `SAMLResponse=${escapedSamlResponse}&RelayState=${escapedRelayState}`;
    const headers = {
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      cookie                      : cookieString,
      'Content-Length'            : Buffer.byteLength(postData),
      'Content-Type'              : 'application/x-www-form-urlencoded',
      Referer                     : `https://${titleUnd}/app/okta_org2org/${oktaOrgId}/sso/saml`,
      Origin                      : `https://${titleUnd}`,
      'Upgrade-Insecure-Requests' : 1,
      Connection                  : 'keep-alive',
      Host                        : 'sso.bgcpartners.com'
    };
    const options = {
      method   : 'POST',
      hostname : 'sso.bgcpartners.com',
      path,
      headers
    };

    const samlResponseVerification = await this.Handler.request(options, postData, (pageData, response) => ({
      setCookies : response.headers['set-cookie'],
      location   : response.headers.location
    }));

    return samlResponseVerification;
  }

  async samlResponseRedirect (location, cookieString, oktaOrgId, titleUnd) {
    const redirectUrl = new URL(location);
    const headers = {
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      Cookie                      : cookieString,
      Referer                     : `https://${titleUnd}/app/okta_org2org/${oktaOrgId}/sso/saml`,
      'Upgrade-Insecure-Requests' : 1,
      Connection                  : 'keep-alive',
      Host                        : redirectUrl.host
    };
    const options = {
      hostname : redirectUrl.hostname,
      path     : `${redirectUrl.pathname}?${queryString.encode(redirectUrl.searchParams)}`,
      headers
    };

    const samlResponseRedirect = await this.Handler.get(options, (pageData, response) => {
      const dom = cheerio.load(pageData);
      let samlDoc = dom('input[name="SAMLResponse"]').attr('value');
      samlDoc = queryString.unescape(samlDoc);
      let relayState = dom('input[name="RelayState"]').attr('value');
      relayState = queryString.unescape(relayState);

      return {
        relayState,
        samlResponse : samlDoc,
        setCookies   : response.headers['set-cookie'],
        referer      : location
      };
    });

    return samlResponseRedirect;
  }

  async getLoginTicket (requestData) {
    const postData = `SAMLResponse=${requestData.samlResponse}&RelayState=${requestData.relayState}`;
    const headers = {
      'Accept-Encoding'           : 'deflate',
      'Accept-Language'           : 'en-GB',
      'Content-Length'            : Buffer.byteLength(postData),
      'Content-Type'              : 'application/x-www-form-urlencoded',
      Referer                     : requestData.referer,
      Origin                      : 'https://sso.bgcpartners.com',
      'Upgrade-Insecure-Requests' : 1,
      Connection                  : 'keep-alive',
      Host                        : `fenics-api.${global.context.configuration.appDomain}`
    };
    const options = {
      hostname : `fenics-api.${global.context.configuration.appDomain}`,
      path     : '/v1/sso/saml/acs',
      method   : 'POST',
      headers
    };

    const loginTicket = await this.Handler.request(options, postData, (pageData, response) => response.headers.location);

    return loginTicket;
  }

  async getBearerToken (ticket) {
    const postData = JSON.stringify({ticket});
    const headers = {
      Accept            : '*/*',
      'Accept-Encoding' : 'deflate',
      'Accept-Language' : 'en-GB',
      'Content-Length'  : Buffer.byteLength(postData),
      'Content-Type'    : CONTENT_HEADER.JSON,
      Referer           : `https://fenics-applications.${global.context.configuration.appDomain}/fenics/fenics-shell-app/v7.1.2/index.html`,
      Origin            : `https://fenics-applications.${global.context.configuration.appDomain}`,
      Connection        : 'keep-alive',
      Host              : `fenics-api.${global.context.configuration.appDomain}`
    };
    const options = {
      hostname : `fenics-api.${global.context.configuration.appDomain}`,
      path     : '/v1/sso/oauth2/authorize',
      method   : 'POST',
      headers
    };

    const bearerToken = await this.Handler.request(options, postData, pageData => JSON.parse(pageData));

    return bearerToken;
  }
}

export default OktaAuthentication;
