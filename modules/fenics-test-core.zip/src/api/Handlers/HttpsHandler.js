/* eslint-disable class-methods-use-this */
import https from 'https';

class HttpsHandler {
  constructor () {
    this.testing = '';
  }

  getDirect (options) {
    return new Promise((resolve, reject) => {
      https.get(options, response => {
        resolve(response);
      }).on('error', error => {
        global.context.logger.error(error);
        reject(error);
      });
    });
  }

  get (options, onFunction) {
    return new Promise((resolve, reject) => {
      let pageData = '';
      https.get(options, response => {
        response.on('data', data => {
          pageData += data.toString();
        });
        response.on('end', () => {
          resolve(onFunction(pageData, response));
        });
      }).on('error', error => {
        global.context.logger.error(error);
        reject(error);
      });
    });
  }

  request (options, postData, onFunction) {
    return new Promise((resolve, reject) => {
      let pageData = '';
      const request = https.request(options, response => {
        response.on('data', data => {
          pageData += data.toString();
        });
        response.on('end', () => {
          resolve(onFunction(pageData, response));
        });
        response.on('error', error => {
          global.context.logger.error(error);
          reject(error);
        });
      });
      request.write(postData);
      request.end();
    });
  }
}

export default HttpsHandler;
