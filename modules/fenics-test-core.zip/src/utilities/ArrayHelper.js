const coercer = collection => (
  Array.isArray(collection) ? collection : Object.values(collection)
);

const isArrayEmpty = collection => !coercer(collection).length;

export {
  coercer,
  isArrayEmpty
};
