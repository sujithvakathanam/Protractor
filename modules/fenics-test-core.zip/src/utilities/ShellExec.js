import {spawnSync, spawn} from 'child_process';

const spawnAttachedProcess = (script, args) => spawnSync(script, args);

const spawnDetachedProcess = (script, args) => {
  const ps = spawn(script, args, {
    detached : true,
    stdio    : 'ignore'
  });
  ps.unref();
};

export {
  spawnAttachedProcess,
  spawnDetachedProcess
};
