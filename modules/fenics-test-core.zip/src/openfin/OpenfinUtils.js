/* eslint-disable no-console */
const {execSync} = require('child_process');

class OpenfinUtils {
  static stop () {
    console.log('Terminating OpenFin');

    execSync('taskkill /f /im "openfin.exe"', {stdio : 'inherit'});
    execSync('taskkill /f /im "OpenFinRVM.exe"', {stdio : 'inherit'});

    // Force a wait to ensure OpenFin has had time to shut down
    execSync('ping -n 3 127.0.0.1 >NUL', {stdio : 'inherit'});
  }

  static clean () {
    console.log('Cleaning OpenFin Cache and Logs');

    execSync('rmdir /s/q %userprofile%\\AppData\\Local\\OpenFin\\apps', {stdio : 'inherit'});
    execSync('rmdir /s/q %userprofile%\\AppData\\Local\\OpenFin\\cache', {stdio : 'inherit'});
    execSync('rmdir /s/q %userprofile%\\AppData\\Local\\OpenFin\\logs', {stdio : 'inherit'});
  }
}

module.exports = OpenfinUtils;
