import EntryPage from './EntryPage';
import {ELEMENTS} from '../../constant/App';

const ndfEntryPageElements = ELEMENTS.ndfEntryPage;
const languageState = selected => (selected ? 'Selected' : 'Unselected');

class NdfEntryPage extends EntryPage {
  static isCurrencySelected (currency) {
    return super.elementHasValue('fenics-radio-button-wrapper-checked', ndfEntryPageElements.currencyButtonElement, 'class', currency);
  }

  static async selectCurrency (currency, selected) {
    const toClick = await this.isCurrencySelected(currency) !== selected;
    await super.selectButton(toClick, ndfEntryPageElements.currencyButtonElement, currency,);
    global.context.getLogger().info(`${languageState(selected)} currency pair: "${currency}".`);
  }
}

export default NdfEntryPage;
