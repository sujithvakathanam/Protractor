import {Element} from '@fenics/fenics-test-core';
import EntryPage from './EntryPage';
import {ELEMENTS} from '../../constant/App';

const fxFwdEntryPageElements = ELEMENTS.fxFwdEntryPage;

class FxFwdEntryPage extends EntryPage {
  static async selectBaseCurrency (currency) {
    await Element.click(fxFwdEntryPageElements.baseCurrencySelectboxElement);
    try {
      await global.browser.waitUntil(
        () => Element.isVisible(fxFwdEntryPageElements.selectOptionElement, currency)
        , global.context.getConfiguration().veryShortTimeout
        , `Timed out after ${global.context.getConfiguration().veryShortTimeout}ms, currency "${currency}" select option drop down not visible.`
      );
    } catch (error) {
      throw error;
    }

    await Element.click(fxFwdEntryPageElements.selectOptionElement, currency);
    global.context.getLogger().info(`Selected base currency: "${currency}".`);
  }

  static async selectCounterCurrency (currency) {
    await Element.click(fxFwdEntryPageElements.counterCurrencySelectboxElement);
    try {
      await global.browser.waitUntil(
        () => Element.isVisible(fxFwdEntryPageElements.selectOptionElement, currency)
        , global.context.getConfiguration().veryShortTimeout
        , `Timed out after ${global.context.getConfiguration().veryShortTimeout}ms, currency "${currency}" select option drop down not visible.`
      );
    } catch (error) {
      throw error;
    }

    await Element.click(fxFwdEntryPageElements.selectOptionElement, currency);
    global.context.getLogger().info(`Selected counter currency: "${currency}".`);
  }
}

export default FxFwdEntryPage;
