import {Element} from '@fenics/fenics-test-core';
import Page from '../Page.js';
import {DIRECTION} from '../../constant/CommonEntryData';
import TenorCalendarPage from '../TenorCalendarPage';
import {ELEMENTS, MODULE_TITLES} from '../../constant/App';

const entryPageElements = ELEMENTS.entryPage;
const languageState = selected => (selected ? 'Selected' : 'Unselected');

class EntryPage extends Page {
  static get sizeButtonText () {
    return Element.getText(entryPageElements.sizeButtonElement);
  }

  static get summaryProductText () {
    return Element.getText(entryPageElements.summaryProductElement);
  }

  static get summarySizeText () {
    return Element.getText(entryPageElements.summarySizeElement);
  }

  static get summaryClientText () {
    return Element.getText(entryPageElements.summaryClientElement);
  }

  static get midPriceText () {
    return Element.getText(entryPageElements.midPriceElement);
  }

  static getSummaryDirectionText () {
    return Element.getText(entryPageElements.summaryDirectionElement);
  }

  static isBuySelected () {
    return super.elementHasValue('direction__button--selected', entryPageElements.buyButtonElement, 'class');
  }

  static isSellSelected () {
    return super.elementHasValue('direction__button--selected', entryPageElements.sellButtonElement, 'class');
  }

  static isSizeSelected () {
    return super.elementHasValue('notional__button--toggled', entryPageElements.sizeButtonElement, 'class');
  }

  static isOriginatorToggled () {
    return super.elementHasValue('fenics-switch-checked', entryPageElements.originatorToggleElement, 'class');
  }

  static isFirmToggled () {
    return super.elementHasValue('fenics-switch-checked', entryPageElements.firmToggleElement, 'class');
  }

  static async switchTo (appPrefix) {
    await super.waitForWindow(`${appPrefix} ${MODULE_TITLES.interestEntryAppTitle}`);
  }

  static async pageHasLoaded () {
    await global.browser.pause(global.context.configuration.shortTimeout);
    await global.browser.waitUntil(
      () => Element.isVisible(entryPageElements.buyButtonElement)
      , global.context.getConfiguration().shortTimeout
      , `Timed out after ${global.context.getConfiguration().shortTimeout}ms, Entry page did not load properly.`
    );
    global.context.getLogger().info('Interest Entry application page has loaded.');
  }

  static async selectNearTenor (tenor, selected, id) {
    await TenorCalendarPage.selectNearTenor(tenor, selected, id);
  }

  static async selectFarTenor (tenor, selected, id) {
    await TenorCalendarPage.selectFarTenor(tenor, selected, id);
  }

  static async selectBuyButton (selected) {
    const toClick = await this.isBuySelected() !== selected;
    await super.selectButton(toClick, entryPageElements.buyButtonElement);
    global.context.getLogger().info(`${languageState(selected)} ${DIRECTION.BUY}.`);

    return entryPageElements.summaryDirectionElement;
  }

  static async selectOfferButton (selected) {
    const toClick = await this.isSellSelected() !== selected;
    await super.selectButton(toClick, entryPageElements.sellButtonElement);
    global.context.getLogger().info(`${languageState(selected)} ${DIRECTION.SELL}.`);

    return entryPageElements.summaryDirectionElement;
  }

  static async selectSizeButton (selected) {
    const toClick = await this.isSizeSelected() !== selected;
    await super.selectButton(toClick, entryPageElements.sizeButtonElement);
    global.context.getLogger().info(`${languageState(selected)} SIZE.`);

    return entryPageElements.summarySizeElement;
  }

  static async clickClientButton (client) {
    await Element.click(entryPageElements.clientContactButtonElement, client);
    global.context.getLogger().info(`Selected client: "${client}".`);
  }

  static async toggleOriginator (selected) {
    const toClick = await this.isOriginatorToggled() !== selected;
    await super.selectButton(toClick, entryPageElements.originatorToggleElement);
    global.context.getLogger().info(`${languageState(selected)} ORIGINATOR.`);
  }

  static async toggleFirm (selected) {
    const toClick = await this.isFirmToggled() !== selected;
    await super.selectButton(toClick, entryPageElements.firmToggleElement);
    global.context.getLogger().info(`${languageState(selected)} FIRM.`);
  }

  static async clickCaptureInterestButton () {
    await Element.click(entryPageElements.captureInterestButtonElement);
    global.context.getLogger().info('Clicked "CAPTURE INTEREST" button.');
  }

  static async clickClearAllButton () {
    await global.browser.pause(global.context.getConfiguration().veryShortTimeout);
    await Element.click(entryPageElements.clearAllButtonElement);
    global.context.getLogger().info('Clicked "CLEAR ALL" button.');
  }
}

export default EntryPage;
