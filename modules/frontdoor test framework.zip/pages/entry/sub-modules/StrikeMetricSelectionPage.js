import Page from '../../Page';
import {STRIKES} from '../../../constant/IROEntryData';
import {ELEMENTS} from '../../../constant/App';
import {Element} from '@fenics/fenics-test-core';

const strikeMetricSelectionPageElements = ELEMENTS.strikeMetricSelectionPage;

class StrikeMetricSelectionPage extends Page {
  static async isStrikeGroupLabelPresent () {
    let isVisible = false;
    try {
      isVisible = await global.browser.waitUntil(
        () => Element.isVisible(strikeMetricSelectionPageElements.strikeGroupLabelElement),
        global.context.getConfiguration().veryShortTimeout
      );
    } catch (error) {
      global.context.getLogger().warn(`STRIKE metric selection label visibility is: ${isVisible}.`);
    }
    global.context.getLogger().info('STRIKE metric selection label is visible.');

    return isVisible;
  }

  static async clickStrikeMetricInput (valueOutput, strike) {
    let elementReturn = null;
    const strikesForChain = new Set([STRIKES.PERCENTAGE, STRIKES.PLUS_MINUS]);
    await Element.click(strikeMetricSelectionPageElements.strikeMetricInputElement, strike);
    global.context.getLogger().info(`Clicked STRIKE metric input "${strike}".`);

    if (strikesForChain.has(strike)) {
      elementReturn = valueOutput;
    }

    return elementReturn;
  }
}

export default StrikeMetricSelectionPage;
