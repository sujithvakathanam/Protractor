import Page from '../../Page.js';
import {ELEMENTS} from '../../../constant/App';
import {Element} from '@fenics/fenics-test-core';

const numberPadPageElements = ELEMENTS.numberPadPage;

class NumberPadPage extends Page {
  static async enterNumberPadEntry (valueOutput, value) {
    const expectedValue = value.toString();
    const inputs = expectedValue.replace(/[^\d]/g, '').split('');

    for (const input of inputs) {
      await Element.click(numberPadPageElements.numberPadGridButtonElement, input);
    }

    let actualValue = '';
    try {
      await global.browser.waitUntil(
        async () => {
          actualValue = await Element.getText(valueOutput);

          return actualValue === expectedValue;
        }
        , global.context.getConfiguration().shortTimeout
        , `Timed out after ${global.context.getConfiguration().shortTimeout}ms, expected: "${expectedValue}" did not equal actual: "${actualValue}".`
      );
    } catch (error) {
      actualValue = await Element.getText(valueOutput);
      if (value !== actualValue) {
        global.context.getLogger().error(error);
        throw error;
      }
    }

    global.context.getLogger().info(`Entered "${expectedValue}" into number pad.`);
  }
}

export default NumberPadPage;
