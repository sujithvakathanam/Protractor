import {Element} from '@fenics/fenics-test-core';
import EntryPage from './EntryPage';
import {ELEMENTS} from '../../constant/App';

const iroEntryPageElements = ELEMENTS.iroEntryPage;

class IROEntryPage extends EntryPage {
  static get firstStrikeFakeInputText () {
    return Element.getText(iroEntryPageElements.strategyGroupStrikeInputOneElement);
  }

  static get secondStrikeFakeInputText () {
    return Element.getText(iroEntryPageElements.strategyGroupStrikeInputTwoElement);
  }

  static get firstIndexFakeInputText () {
    return Element.getText(iroEntryPageElements.strategyGroupIndexInputOneElement);
  }

  static get secondIndexFakeInputText () {
    return Element.getText(iroEntryPageElements.strategyGroupIndexInputTwoElement);
  }

  static get firstTenorsDisplayText () {
    return Element.getText(iroEntryPageElements.strategyGroupTenorDisplayOneElement);
  }

  static get secondTenorsDisplayText () {
    return Element.getText(iroEntryPageElements.strategyGroupTenorDisplayTwoElement);
  }

  static async selectSingleCurrency (currency) {
    await Element.click(iroEntryPageElements.singleCurrencySelectboxElement);
    try {
      await global.browser.waitUntil(
        () => Element.isVisible(iroEntryPageElements.singleCurrencySelectOptionElement, currency)
        , global.context.getConfiguration().veryShortTimeout
        , `Timed out after ${global.context.getConfiguration().veryShortTimeout}ms, currency "${currency}" select option drop down not visible.`
      );
    } catch (error) {
      throw error;
    }

    await Element.click(iroEntryPageElements.singleCurrencySelectOptionElement, currency);
    global.context.getLogger().info(`Selected base currency: "${currency}".`);
  }

  static async selectFirstStrategy (strategy) {
    await Element.click(iroEntryPageElements.strategyGroupSelectboxOneElement);
    try {
      await global.browser.waitUntil(
        () => Element.isVisible(iroEntryPageElements.strategySelectOptionElement, strategy, 'one')
        , global.context.getConfiguration().shortTimeout
        , `Timed out after ${global.context.getConfiguration().shortTimeout}ms, strategy "${strategy}" select option drop down not visible.`
      );
    } catch (error) {
      throw error;
    }

    await Element.click(iroEntryPageElements.strategySelectOptionElement, strategy, 'one');
    global.context.getLogger().info(`Selected first: "${strategy}".`);
  }

  static async selectSecondStrategy (strategy) {
    await Element.click(iroEntryPageElements.strategyGroupSelectboxTwoElement);
    try {
      await global.browser.waitUntil(
        () => Element.isVisible(iroEntryPageElements.strategySelectOptionElement, strategy, 'two')
        , global.context.getConfiguration().shortTimeout
        , `Timed out after ${global.context.getConfiguration().shortTimeout}ms, strategy "${strategy}" select option drop down not visible.`
      );
    } catch (error) {
      throw new Error(`Timed out after ${global.context.getConfiguration().shortTimeout}ms, strategy "${strategy}" select option drop down not visible.`);
    }

    await Element.click(iroEntryPageElements.strategySelectOptionElement, strategy, 'two');
    global.context.getLogger().info(`Selected first: "${strategy}".`);
  }

  static async clickFirstStrikeFakeInput () {
    await Element.click(iroEntryPageElements.strategyGroupStrikeInputOneElement);
    global.context.getLogger().info('Clicked first STRIKE input box');

    return iroEntryPageElements.strategyGroupStrikeInputOneElement;
  }

  static async clickSecondStrikeFakeInput () {
    await Element.click(iroEntryPageElements.strategyGroupStrikeInputTwoElement);
    global.context.getLogger().info('Clicked second STRIKE input box');

    return iroEntryPageElements.strategyGroupStrikeInputTwoElement;
  }

  static async clickFirstIndexFakeInput () {
    await Element.click(iroEntryPageElements.strategyGroupIndexInputOneElement);
    global.context.getLogger().info('Clicked first INDEX input box');

    return iroEntryPageElements.strategyGroupIndexInputOneElement;
  }

  static async clickSecondIndexFakeInput () {
    await Element.click(iroEntryPageElements.strategyGroupIndexInputTwoElement);
    global.context.getLogger().info('Clicked second INDEX input box');

    return iroEntryPageElements.strategyGroupIndexInputTwoElement;
  }

  static async clickFirstExpiryButton () {
    await Element.click(iroEntryPageElements.strategyGroupExpiryOneElement);
    global.context.getLogger().info('Clicked first EXPIRY button.');
  }

  static async clickSecondExpiryButton () {
    await Element.click(iroEntryPageElements.strategyGroupExpiryTwoElement);
    global.context.getLogger().info('Clicked second EXPIRY button.');
  }

  static async clickFirstTailButton () {
    await Element.click(iroEntryPageElements.strategyGroupTailOneElement);
    global.context.getLogger().info('Clicked first TAIL button.');
  }

  static async clickSecondTailButton () {
    await Element.click(iroEntryPageElements.strategyGroupTailTwoElement);
    global.context.getLogger().info('Clicked second TAIL button.');
  }

  static async clickFavouriteCurrenciesLink () {
    await Element.click(iroEntryPageElements.favouriteCurrenciesLinkElement);
    global.context.getLogger().info('Clicked FAVOURITE CURRENCIES link.');
  }

  static async clickFavouriteStrategiesLink () {
    await Element.click(iroEntryPageElements.favouriteStrategiesLinkElement);
    global.context.getLogger().info('Clicked FAVOURITE STRATEGIES link.');
  }

  static async clickFavouriteToolButton () {
    await Element.click(iroEntryPageElements.favouriteToolButtonElement);
    global.context.getLogger().info('Clicked FAVOURITE TOOL button.');
  }
}

export default IROEntryPage;
