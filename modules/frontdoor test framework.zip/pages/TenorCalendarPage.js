import Page from './Page.js';
import {ELEMENTS} from '../constant/App';
import {Element} from '@fenics/fenics-test-core';

const tenorCalendarPageElements = ELEMENTS.tenorCalendarPage;
const languageState = selected => (selected ? 'Selected' : 'Unselected');

class TenorCalendarPage extends Page {
  static isNearTenorSelected (tenor, id) {
    return super.elementHasValue('fenics-radio-button-checked', tenorCalendarPageElements.nearTenorLabelElement, 'class', tenor, id);
  }

  static isFarTenorSelected (tenor, id) {
    return super.elementHasValue('fenics-radio-button-checked', tenorCalendarPageElements.farTenorLabelElement, 'class', tenor, id);
  }

  static async selectNearTenor (tenor, selected, id) {
    const toClick = await this.isNearTenorSelected(tenor, id) !== selected;
    await super.selectButton(toClick, tenorCalendarPageElements.nearTenorButtonElement, tenor, id);
    global.context.getLogger().info(`${languageState(selected)} near tenor: "${tenor}".`);
  }

  static async selectFarTenor (tenor, selected, id) {
    const toClick = await this.isFarTenorSelected(tenor, id) !== selected;
    await super.selectButton(toClick, tenorCalendarPageElements.farTenorButtonElement, tenor, id);
    global.context.getLogger().info(`${languageState(selected)} far tenor: "${tenor}".`);
  }

  static async clickAddTenor () {
    await Element.click(tenorCalendarPageElements.addTenorButtonElement);
    await global.browser.waitUntil(
      () => Element.isVisible(tenorCalendarPageElements.addTenorButtonElement)
      , global.context.getConfiguration().shortTimeout
      , `Timed out after ${global.context.getConfiguration().shortTimeout}, add instrument near/far tenor pop-over is not visible.`
    );
    global.context.getLogger().info('Clicked "ADD" for near/far tenor.');
  }

  static async isNearTenorPopoverPresent (id) {
    let isVisible = false;

    try {
      isVisible = await global.browser.waitUntil(
        () => Element.isVisible(tenorCalendarPageElements.nearLegTenorPopoverElement, id)
        , global.context.getConfiguration().veryShortTimeout
      );
    } catch (error) {
      global.context.getLogger().info(`Near tenor popover visibility is: ${isVisible}.`);
    }

    return isVisible;
  }

  static async isFarTenorPopoverPresent (id) {
    let isVisible = false;

    try {
      isVisible = await global.browser.waitUntil(
        () => Element.isVisible(tenorCalendarPageElements.farLegTenorPopoverElement, id)
        , global.context.getConfiguration().veryShortTimeout
      );
    } catch (error) {
      global.context.getLogger().warn(`Far tenor popover visibility is: ${isVisible}.`);
    }

    return isVisible;
  }
}

export default TenorCalendarPage;
