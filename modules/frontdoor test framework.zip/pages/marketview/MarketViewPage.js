import Page from '../Page.js';
import TenorCalendarPage from '../TenorCalendarPage';
import {Element} from '@fenics/fenics-test-core/src';
import {ELEMENTS} from '../../constant/App';

const marketViewPageElements = ELEMENTS.marketViewPage;

class MarketViewPage extends Page {
  static getProduct (product) {
    return marketViewPageElements.productGridElement(product);
  }

  static async selectNearTenor (tenor, selected) {
    await TenorCalendarPage.selectNearTenor(tenor, selected);
  }

  static async selectFarTenor (tenor, selected) {
    await TenorCalendarPage.selectFarTenor(tenor, selected);
  }

  static async pageHasLoaded () {
    await global.browser.waitUntil(
      async () => {
        let pageVisible = false;
        let spinnerExist = false;
        try {
          pageVisible = await Element.isVisible(marketViewPageElements.marketViewPageTitleElement);
          spinnerExist = await Element.isExisting(marketViewPageElements.appSpinnerIconElement);
        } catch (error) {
          spinnerExist = false;
        }

        return pageVisible && !spinnerExist;
      }
      , global.context.getConfiguration().shortTimeout
      , `Timed out after ${global.context.getConfiguration().shortTimeout}ms, Market View page did not load properly.`
    );
    await global.browser.pause(global.context.getConfiguration().shortTimeout);
  }

  static async addInstrument (product) {
    await Element.click(marketViewPageElements.instrumentAddTenorButtonElement(product));
    global.context.getLogger().info(`Clicked add instrument for product "${product}".`);
  }

  static async addTenor () {
    await  TenorCalendarPage.clickAddTenor();
    await Element.click(marketViewPageElements.marketViewPageTitleElement);
  }
}

export default MarketViewPage;
