import Page from '../Page.js';
import {getFormattedTenors} from '../../utilities/OrderFormatter';
import {DIRECTION} from '../../constant/CommonEntryData';
import {ELEMENTS} from '../../constant/App';

const instrumentOrdersPageElements = ELEMENTS.instrumentOrdersPage;
const directionLanguage = direction => {
  let side = '';
  if (direction === DIRECTION.BUY) {
    side = 'bid';
  } else if (direction === DIRECTION.SELL) {
    side = 'offer';
  } else {
    throw new Error(`"${direction}" is not a valid input, use values from constant DIRECTION.`);
  }

  return side;
};

const orderLanguage = order => (order ? '--' : order);

const mergeElementsSelector = elements => {
  const selector = '';
  const description = elements.length > 0 ? elements[elements.length - 1] : '';

  elements.forEach(element => {
    selector.concat(element.selector);
  });

  return {
    selector    : () => selector,
    description : () => description
  };
};

class InstrumentOrdersPage extends Page {
  static async setInputFieldValue (parentInputElement, inputElement, text = '') {
    await global.browser.waitUntil(async () => {
      await Element.click(parentInputElement);

      return Element.isExisting(inputElement);
    });
    await Element.setText(inputElement, text);
    await global.browser.keys('\uE007');
  }

  static async enterOrder (productElement, {nearTenor, farTenor, bid, bidSize, offer, offerSize}, row) {
    let parentInputElement = null;
    let inputElement = null;
    const instrument = getFormattedTenors(nearTenor, farTenor);

    if (bidSize) {
      parentInputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.bidSizeParentInputElement]);
      inputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.bidSizeInputElement]);
      await this.setInputFieldValue(parentInputElement, inputElement, bidSize);
    }

    if (bid) {
      parentInputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.bidPriceParentInputElement]);
      inputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.bidPriceInputElement]);
      await this.setInputFieldValue(parentInputElement, inputElement, bidSize);
    }

    if (offer) {
      parentInputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.offerPriceParentInputElement]);
      inputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.offerPriceInputElement]);
      await this.setInputFieldValue(parentInputElement, inputElement, bidSize);
    }

    if (offerSize) {
      parentInputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.offerSizeParentInputElement]);
      inputElement = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.offerSizeInputElement]);
      await this.setInputFieldValue(parentInputElement, inputElement, bidSize);
    }

    global.context.getLogger().info(`Entered bid: ${orderLanguage(bid)}@${orderLanguage(bidSize)}M and offer: bid: ${orderLanguage(offer)}@${orderLanguage(offerSize)}M for instrument ${instrument}`);
  }

  static async clickAddOrder (productElement, {nearTenor, farTenor}, direction) {
    const instrument = getFormattedTenors(nearTenor, farTenor);
    const element = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, 1), instrumentOrdersPageElements.actionAddIconElement(directionLanguage(direction))]);
    await Element.click(element);
    global.context.getLogger()(`Clicked add order icon for ${direction} side.`);
  }

  static async clickRemoveOrder (productElement, {nearTenor, farTenor}, direction, row) {
    const instrument = getFormattedTenors(nearTenor, farTenor);
    const element = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.statusClearIconElement(directionLanguage(direction))]);
    await Element.click(element);
    global.context.getLogger()(`Clicked remove order icon for ${direction} side.`);
  }

  static async clickSendOrder (productElement, {nearTenor, farTenor}, direction, row) {
    const instrument = getFormattedTenors(nearTenor, farTenor);
    const element = mergeElementsSelector([productElement, instrumentOrdersPageElements.orderRowElement(instrument, row), instrumentOrdersPageElements.statusSendIconElement(directionLanguage(direction))]);
    await Element.click(element);
    global.context.getLogger()(`Clicked send order icon for ${direction} side.`);
  }
}

export default InstrumentOrdersPage;
