/* eslint-disable prefer-rest-params */
import {BasePage, Element} from '@fenics/fenics-test-core';

class Page extends BasePage {
  static async setTextValue (value = '', elementData) {
    const numberOfKnownArgs = 2;
    const args = Array.prototype.slice.call(arguments, numberOfKnownArgs).filter(arg => arg);

    const clearAndSet = async () => {
      await global.browser.clearElement.apply(null, elementData.selector(args));
      await Element.setText.apply(null, arguments);
      await Element.click.apply(null, arguments);
    };

    let elementText = await Element.getText.apply(null, arguments);
    while (elementText !== value.toString()) {
      await clearAndSet();
      elementText = await Element.getText.apply(null, arguments);
    }
  }

  static async elementHasValue (cssClass) {
    const numberOfKnownArgs = 1;
    const args = Array.prototype.slice.call(arguments, numberOfKnownArgs).filter(arg => arg);

    const labelClass = await Element.getAttribute.apply(null, args);

    return labelClass.includes(cssClass);
  }

  static async selectButton (toClick) {
    const numberOfKnownArgs = 1;
    const args = Array.prototype.slice.call(arguments, numberOfKnownArgs).filter(arg => arg);

    if (toClick) {
      await Element.click.apply(null, args);
    }
  }
}

export default Page;
