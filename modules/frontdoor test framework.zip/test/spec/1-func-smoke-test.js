import {expect} from 'chai';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {MODULE_TITLES} from '../../constant/App';
import {CURRENCY_PAIR, TENOR, CLIENT_CONTACTS} from '../../constant/CommonEntryData';
import TestCommons from '../../utilities/TestCommons';
import LoginPage from '../../pages/LoginPage';
import NdfEntryPage from '../../pages/entry/NdfEntryPage';
import MarketViewPage from '../../pages/marketview/MarketViewPage';

describe('Private negotiation tests - Cash Bonds', () => {
  // Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let loginPage = null;
  let ndfEntryPage = null;
  let ndfMarketViewPage = null;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    loginPage = new LoginPage(context);
    ndfEntryPage = new NdfEntryPage(context);
    ndfMarketViewPage = new MarketViewPage(context);

    // Api setup.

    expect(browser).to.exist;
  });

  after(() => {
    /*
     * TODO: Wait for fix to be applied for execute() in fenics-test-core.
     * execute(testCommons.getTerminateScript());
     */
  });

  it('FUNC-SMOKE-001 - Smoke test NDF Entry App.', async () => {
    const testParams = {
      username     : 'andrew.demetriou@bgcpartners.com',
      currency     : CURRENCY_PAIR.HKD,
      baseCurrency : CURRENCY_PAIR.USD,
      nearTenor    : TENOR.O_N,
      farTenor     : TENOR.S_N,
      bid          : 53,
      size         : 10,
      client       : CLIENT_CONTACTS.BARC
    };

    await loginPage.login(testParams.username, MODULE_TITLES.interestEntryAppLabel);
    await ndfEntryPage.pageHasLoaded();
    await ndfEntryPage.selectCurrency(testParams.currency, true);
    const productText = await ndfEntryPage.summaryProductText;
    expect(productText).to.equal(`${testParams.baseCurrency}/${testParams.currency}`);

    await ndfEntryPage.selectNearTenor(testParams.nearTenor, true);
    await ndfEntryPage.selectFarTenor(testParams.farTenor, true);

    let numPadPage = await ndfEntryPage.selectBuyButton(true);
    await numPadPage.enterNumberPadEntry(testParams.bid);

    numPadPage = await ndfEntryPage.selectSizeButton(true);
    await numPadPage.enterNumberPadEntry(testParams.size);

    await ndfEntryPage.clickClientButton(testParams.client);
    await ndfEntryPage.clickClearAllButton();
  });

  it('FUNC-SMOKE-002 - Smoke test NDF Market View App.', async () => {
    const testParams = {
      username : 'andrew.demetriou@bgcpartners.com',
      orders   : [
        {
          currencyPair : `${CURRENCY_PAIR.USD}/${CURRENCY_PAIR.HKD}`,
          nearTenor    : TENOR.O_N,
          farTenor     : TENOR.S_N,
          bid          : '12',
          bidSize      : '15',
          offer        : '15',
          offerSize    : '15',
          midPrice     : '',
          row          : '1'
        },
        {
          currencyPair : `${CURRENCY_PAIR.USD}/${CURRENCY_PAIR.HKD}`,
          nearTenor    : TENOR.O_N,
          farTenor     : TENOR.S_N,
          bid          : '13',
          bidSize      : '10',
          offer        : '14',
          offerSize    : '10',
          midPrice     : '',
          row          : '2'
        },
        {
          currencyPair : `${CURRENCY_PAIR.USD}/${CURRENCY_PAIR.HKD}`,
          nearTenor    : TENOR.ONE_WEEK,
          farTenor     : TENOR.ONE_MONTH,
          bid          : '12',
          bidSize      : '10',
          offer        : '12',
          offerSize    : '10',
          midPrice     : '',
          row          : '1'
        }
      ]
    };

    await loginPage.login(testParams.username, MODULE_TITLES.marketViewAppLabel);
    await ndfMarketViewPage.pageHasLoaded();

    for (const order of testParams.orders) {
      await ndfMarketViewPage.addInstrument(order.currencyPair);
      await ndfMarketViewPage.selectNearTenor(order.nearTenor, true);
      await ndfMarketViewPage.selectFarTenor(order.farTenor, true);
      await ndfMarketViewPage.addTenor();
    }

    for (const order of testParams.orders) {
      const instrumentPage = await ndfMarketViewPage.getProduct(order.currencyPair);
      await instrumentPage.enterOrder(order, order.row);
    }
  });
});
