import {frameworkConfig} from '../../../../config/framework.config';
import {usersConfig} from '../../../../config/users.config';
import {Bootstrap, LoginPage, LaunchbarPage} from '@fenics/fenics-test-core';
import {Given as given} from 'cucumber';
import {MODULE_TITLES} from '../../../../constant/App';
import EntryPage from '../../../../pages/entry/EntryPage';

// Framework setup.
const bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
bootstrapper.getInstance();

given('I am broker {string} using the Interest Entry Application', async username => {
  await LoginPage.switchTo();
  await LoginPage.login(username);
});

given('I switch to the {application_prefix} Interest Entry Application', async appPrefix => {
  const appTitle = MODULE_TITLES.interestEntryAppTitle;
  try {
    await EntryPage.switchTo(appPrefix);
  } catch (error) {
    await LaunchbarPage.switchTo();
    await LaunchbarPage.openApplication(`${appPrefix} ${appTitle}`);
    await EntryPage.switchTo(appPrefix);
  }
});
