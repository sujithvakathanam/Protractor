import {Then as then} from 'cucumber';
import {expect} from 'chai';
import EntryPage from '../../../../pages/entry/EntryPage';

// Framework setup.
const context = global.context;

// Page objects.
let TenorCalendarPage = null;

then(/^The Summary Product text is equal to "([^"]*)?" in the Interest Entry$/, async currencyPair => {
  const productText = await EntryPage.summaryProductText;
  expect(productText).to.equal(currencyPair);
});

then(/^The Summary Size text is equal to "([^"]*)?" in the Interest Entry$/, async size => {
  const sizeText = await EntryPage.summarySizeText;
  expect(sizeText).to.equal(size);
});

then(/^The Summary Client text is equal to "([^"]*)?" in the Interest Entry$/, async client => {
  const clientText = await EntryPage.summaryClientText;
  expect(clientText).to.equal(client);
});

then(/^The Summary Direction text is equal to "([^"]*)?" in the Interest Entry$/, async direction => {
  const directionText = await EntryPage.getSummaryDirectionText();
  expect(directionText).to.equal(direction);
});

then(/^The Size button text is equal to "([^"]*)?" in the Interest Entry$/, async size => {
  const sizeButtonText = await EntryPage.sizeButtonText;
  expect(sizeButtonText).to.equal(size);
});

then(/^The Mid Price text is equal to "([^"]*)?" in the Interest Entry$/, async midPrice => {
  const midPriceText = await EntryPage.midPriceText;
  expect(midPriceText).to.equal(midPrice);
});

then('The Near Tenor Popover is visible in the Interest Entry', async () => {
  TenorCalendarPage = context.getScenarioContext().get('TenorCalendarPage');
  if (!TenorCalendarPage) {
    throw new Error('You must click the expiry/tail input first! tenorCalendarPage is null!');
  }
  const isVisible = await TenorCalendarPage.isNearTenorPopoverPresent();
  expect(isVisible).to.be.true;
});

then('The Far Tenor Popover is visible in the Interest Entry', async () => {
  TenorCalendarPage = context.getScenarioContext().get('TenorCalendarPage');
  if (!TenorCalendarPage) {
    throw new Error('You must click the expiry/tail input first! tenorCalendarPage is null!');
  }
  const isVisible = await TenorCalendarPage.isFarTenorPopoverPresent();
  expect(isVisible).to.be.true;
});
