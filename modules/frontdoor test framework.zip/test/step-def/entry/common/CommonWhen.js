import {When as when} from 'cucumber';
import EntryPage from '../../../../pages/entry/EntryPage';
import NumberPadPage from '../../../../pages/entry/sub-modules/NumberPadPage';

// Framework setup.
const context = global.context;

// Page object  setup.
let numPadPageValueOutputElement = null;

when('I {selects} near tenor {tenor} in the Interest Entry', async (select, nearTenor) => {
  await EntryPage.selectNearTenor(nearTenor, select);
});

when('I {selects} far tenor {tenor} in the Interest Entry', async (select, farTenor) => {
  await EntryPage.selectFarTenor(farTenor, select);
});

when('I {selects} the BUY button in the Interest Entry', async select => {
  numPadPageValueOutputElement = await EntryPage.selectBuyButton(select);
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when('I {selects} the SELL button in the Interest Entry', async select => {
  numPadPageValueOutputElement = await EntryPage.selectOfferButton(select);
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when('I {selects} the SIZE button in the Interest Entry', async select => {
  numPadPageValueOutputElement = await EntryPage.selectSizeButton(select);
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when(/^I enter "([^"]*)" into the number pad in the Interest Entry$/, async value => {
  numPadPageValueOutputElement = context.getScenarioContext().get('numPadPageValueOutputElement');
  if (!numPadPageValueOutputElement) {
    throw new Error('You must select buy|sell|size button first! numPadPageValueOutputElement is null!');
  }
  await NumberPadPage.enterNumberPadEntry(numPadPageValueOutputElement, value);
});

when('I click the client {client_contacts} button in the Interest Entry', async client => {
  await EntryPage.clickClientButton(client);
});

when('I {selects} the ORIGINATOR toggle button in the Interest Entry', async select => {
  await EntryPage.toggleOriginator(select);
});

when('I {selects} the IS FIRM toggle button in the Interest Entry', async select => {
  await EntryPage.toggleFirm(select);
});

when('I click the CAPTURE INTEREST button in the Interest Entry', async () => {
  await EntryPage.clickCaptureInterestButton();
});

when('I click the CLEAR ALL button in the Interest Entry', async () => {
  await EntryPage.clickClearAllButton();
});
