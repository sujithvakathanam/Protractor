import {Given as given} from 'cucumber';
import NdfEntryPage from '../../../../pages/entry/NdfEntryPage';
import {APP_PREFIXES} from '../../../../constant/App';

given(/^The Ndf Interest Entry Application has loaded$/, async () => {
  await NdfEntryPage.switchTo(APP_PREFIXES.NDF);
  await NdfEntryPage.pageHasLoaded();
});
