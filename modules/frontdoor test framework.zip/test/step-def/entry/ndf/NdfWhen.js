import {When as when} from 'cucumber';
import NdfEntryPage from '../../../../pages/entry/NdfEntryPage';

when('I {selects} currency {currency} in the Ndf Interest Entry', async (select, currency) => {
  await NdfEntryPage.selectCurrency(currency, select);
});
