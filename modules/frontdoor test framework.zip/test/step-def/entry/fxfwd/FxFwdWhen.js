import {When as when} from 'cucumber';
import FxFwdEntryPage from '../../../../pages/entry/FxFwdEntryPage';

when('I select base currency {currency} in the FX Fwd Interest Entry', async currency => {
  await FxFwdEntryPage.selectBaseCurrency(currency);
});

when('I select counter currency {currency} in the FX Fwd Interest Entry', async currency => {
  await FxFwdEntryPage.selectCounterCurrency(currency);
});
