import {Given as given} from 'cucumber';
import FxFwdEntryPage from '../../../../pages/entry/FxFwdEntryPage';

given(/^The FX Fwd Interest Entry Application has loaded$/, async () => {
  await FxFwdEntryPage.pageHasLoaded();
});
