import {When as when} from 'cucumber';
import IROEntryPage from '../../../../pages/entry/IROEntryPage';
import {NumberPadPage} from '../../../../pages/entry/sub-modules/NumberPadPage';
import StrikeMetricSelectionPage from '../../../../pages/entry/sub-modules/StrikeMetricSelectionPage';

// Framework setup.
const context = global.context;

// Page object setup.
let numPadPageValueOutputElement = null;
let strikeMetricValueOutputElement = null;

when('I select single currency {currency} in the IRO Interest Entry', async currency => {
  await IROEntryPage.selectSingleCurrency(currency);
});

when('I select first strategy {strategy} in the IRO Interest Entry', async strategy => {
  await IROEntryPage.selectFirstStrategy(strategy);
});

when('I select second strategy {strategy} in the IRO Interest Entry', async strategy => {
  await IROEntryPage.selectSecondStrategy(strategy);
});

when('I click first strategy strike in the IRO Interest Entry', async () => {
  strikeMetricValueOutputElement = await IROEntryPage.clickFirstStrikeFakeInput();
  context.getScenarioContext().set('strikeMetricValueOutputElement', strikeMetricValueOutputElement);
});

when('I click second strategy strike in the IRO Interest Entry', async () => {
  strikeMetricValueOutputElement = await IROEntryPage.clickSecondStrikeFakeInput();
  context.getScenarioContext().set('strikeMetricValueOutputElement', strikeMetricValueOutputElement);
});

when('I click strike metric {strike_metric} in the IRO Interest Entry', async strike => {
  strikeMetricValueOutputElement = context.getScenarioContext().get('strikeMetricValueOutputElement');
  if (!strikeMetricValueOutputElement) {
    throw new Error('You must click the strike input first! strikeMetricValueOutputElement is null!');
  }
  numPadPageValueOutputElement = await StrikeMetricSelectionPage.clickStrikeMetricInput(strikeMetricValueOutputElement, strike);
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when('I click first strategy index in the IRO Interest Entry', async () => {
  numPadPageValueOutputElement = await IROEntryPage.clickFirstIndexFakeInput();
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when('I click second strategy index in the IRO Interest Entry', async () => {
  numPadPageValueOutputElement = await IROEntryPage.clickSecondIndexFakeInput();
  context.getScenarioContext().set('numPadPageValueOutputElement', numPadPageValueOutputElement);
});

when('I click first strategy expiry in the IRO Interest Entry', async () => {
  await IROEntryPage.clickFirstExpiryButton();
});

when('I click second strategy expiry in the IRO Interest Entry', async () => {
  await IROEntryPage.clickSecondExpiryButton();
});

when('I click first strategy tail in the IRO Interest Entry', async () => {
  await IROEntryPage.clickFirstTailButton();
});

when('I click second strategy tail in the IRO Interest Entry', async () => {
  await IROEntryPage.clickSecondTailButton();
});

when('I click favourite currencies in the IRO Interest Entry', async () => {
  await IROEntryPage.clickFavouriteCurrenciesLink();
});

when('I click favourite strategies in the IRO Interest Entry', async () => {
  await IROEntryPage.clickFavouriteStrategiesLink();
});

when('I click favourite tool in the IRO Interest Entry', async () => {
  await IROEntryPage.clickFavouriteToolButton();
});

when(/^I select near tenor "(one|two)" "([^"]*)" in the IRO Interest Entry$/, async (id, nearTenor) => {
  await IROEntryPage.selectNearTenor(nearTenor, true, id);
});

when(/^I select far tenor "(one|two)" "([^"]*)" in the IRO Interest Entry$/, async (id, farTenor) => {
  await IROEntryPage.selectFarTenor(farTenor, true, id);
});
