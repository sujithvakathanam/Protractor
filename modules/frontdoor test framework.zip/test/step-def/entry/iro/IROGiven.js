import {Given as given} from 'cucumber';
import IROEntryPage from '../../../../pages/entry/IROEntryPage';

given(/^The IRO Interest Entry Application has loaded$/, async () => {
  await IROEntryPage.pageHasLoaded();
});
