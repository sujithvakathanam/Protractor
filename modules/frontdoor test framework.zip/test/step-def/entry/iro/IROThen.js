import {Then as then} from 'cucumber';
import {expect} from 'chai';
import IROEntryPage from '../../../../pages/entry/IROEntryPage';
import StrikeMetricSelectionPage from '../../../../pages/entry/sub-modules/StrikeMetricSelectionPage';
import TenorCalendarPage from '../../../../pages/TenorCalendarPage';

// Framework setup.
const context = global.context;

// Page object setup.
let strikeMetricValueOutputElement = null;

then('The strike group label is visible in the IRO Interest Entry', async () => {
  const isVisible = await StrikeMetricSelectionPage.isStrikeGroupLabelPresent();
  expect(isVisible).to.be.true;
});

then(/^The first Tenor Display label should be equal to "([^"]*)" in the IRO Interest Entry$/, async tenorDisplayText => {
  const actualText = await IROEntryPage.firstTenorsDisplayText;
  expect(actualText.replace('\n', '/')).to.equal(tenorDisplayText);
});

then(/^The second Tenor Display label should be equal to "([^"]*)" in the IRO Interest Entry$/, async tenorDisplayText => {
  const actualText = await IROEntryPage.secondTenorsDisplayText;
  expect(actualText.replace('\n', '/')).to.equal(tenorDisplayText);
});

then(/^The Near Tenor Popover "(one|two)" is visible in the IRO Interest Entry$/, async id => {
  const isVisible = await TenorCalendarPage.isNearTenorPopoverPresent(id);
  expect(isVisible).to.be.true;
});

then(/^The Far Tenor Popover "(one|two)" is visible in the IRO Interest Entry$/, async id => {
  const isVisible = await TenorCalendarPage.isFarTenorPopoverPresent(id);
  expect(isVisible).to.be.true;
});
