import {frameworkConfig} from '../../../../config/framework.config';
import {usersConfig} from '../../../../config/users.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {Given as given} from 'cucumber';
import MarketViewPage from '../../../../pages/marketview/MarketViewPage';

// Framework setup.
const bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
bootstrapper.getInstance();

given(/^The Ndf Market View Application has loaded$/, async () => {
  await MarketViewPage.pageHasLoaded();
});
