import {Bootstrap, LoginPage, LaunchbarPage} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../../../config/framework.config';
import {usersConfig} from '../../../../config/users.config';
import {Given as given} from 'cucumber';
import {MODULE_TITLES} from '../../../../constant/App';

// Framework setup.
const bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
bootstrapper.getInstance();

given(/^I'm broker "([^"]*)?" using the Market View Application$/, async username => {
  await LoginPage.login(username);
});

given('I switch to the {application_prefix} Market View Application', async appPrefix => {
  const appTitle = MODULE_TITLES.marketViewAppTitle;
  try {
    await LoginPage.waitForWindow(`${appPrefix} ${appTitle}`);
  } catch (error) {
    await LoginPage.waitForWindow(MODULE_TITLES.launchbarTitle);
    await LaunchbarPage.openApplication(`${appPrefix} ${appTitle}`);
  }
});
