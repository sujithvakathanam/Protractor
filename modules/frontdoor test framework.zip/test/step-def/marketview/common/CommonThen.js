import {Then as then} from 'cucumber';
import {expect} from 'chai';
import MarketViewPage from '../../../../pages/marketview/MarketViewPage';

// Framework setup.
const context = global.context;

// Page object  setup.
const ndfMarketViewPage = new MarketViewPage(context);

// TODO: Impl of getters and assertions required for market view.

