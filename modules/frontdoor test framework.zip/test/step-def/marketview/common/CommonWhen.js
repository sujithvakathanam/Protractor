import {When as when} from 'cucumber';
import MarketViewPage from '../../../../pages/marketview/MarketViewPage';

when(/^I click add instrument for product "([^"]*)?" in the Market View$/, async currencyPair => {
  await MarketViewPage.addInstrument(currencyPair);
});

when(/^I (select|unselect) near tenor "([^"]*)?" in the Market View$/, async (select, nearTenor) => {
  const toSelect = select === 'select';
  await MarketViewPage.selectNearTenor(nearTenor, toSelect);
});

when(/^I (select|unselect) far tenor "([^"]*)?" in the Market View$/, async (select, farTenor) => {
  const toSelect = select === 'select';
  await MarketViewPage.selectFarTenor(farTenor, toSelect);
});

when(/^I click add tenors button in the Market View$/, async () => {
  await MarketViewPage.addTenor();
});

when(/^I enter the following order in the Market View:$/, async dtOrders => {
  const orders = dtOrders.hashes();
  for (let row = 0; row < orders.length; row += 1) {
    const instrumentPage = await MarketViewPage.getProduct(orders[row].currencyPair);
    await instrumentPage.enterOrder(orders[row], row + 1);
  }
});

when(/^I click add (BUY|SELL) order button for near tenor "([^"]*)?" and far tenor "([^"]*)?" in the Market View$/, async (direction, nearTenor, farTenor) => {
  await MarketViewPage.clickAddOrder({nearTenor,
    farTenor}, direction);
});

when(/^I click remove (BUY|SELL) order button for row ([\d]+) of near tenor "([^"]*)?" and far tenor "([^"]*)?" in the Market View$/, async (direction, row, nearTenor, farTenor) => {
  await MarketViewPage.clickRemoveOrder({nearTenor,
    farTenor}, direction, row);
});

when(/^I click send (BUY|SELL) order button for row ([\d]+) of near tenor "([^"]*)?" and far tenor "([^"]*)?" in the Market View$/, async (direction, row, nearTenor, farTenor) => {
  await MarketViewPage.clickSendOrder({nearTenor,
    farTenor}, direction, row);
});
