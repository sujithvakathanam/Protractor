import {defineParameterType} from 'cucumber';
import {hasKeyValue} from '../../../utilities/GherkinFormatter';
import {CLIENT_CONTACTS, CURRENCY_PAIR, TENOR} from '../../../constant/CommonEntryData';
import {STRATETGIES, STRIKES} from '../../../constant/IROEntryData';
import {APP_PREFIXES} from '../../../constant/App';

// Custom parameters.
defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'application_prefix',
  transformer (prefix) {
    return hasKeyValue(APP_PREFIXES, prefix);
  }
});

defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'currency',
  transformer (currency) {
    return hasKeyValue(CURRENCY_PAIR, currency);
  }
});

defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'strategy',
  transformer (strategy) {
    return hasKeyValue(STRATETGIES, strategy);
  }
});

defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'strike_metric',
  transformer (strikeMetric) {
    return hasKeyValue(STRIKES, strikeMetric);
  }
});

defineParameterType({
  regexp : /"(select|unselect)"/,
  name   : 'selects',
  transformer (selects) {
    return selects === 'select';
  }
});

defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'tenor',
  transformer (tenor) {
    return hasKeyValue(TENOR, tenor);
  }
});

defineParameterType({
  regexp : /"([^"]*)"/,
  name   : 'client_contacts',
  transformer (clientContacts) {
    return hasKeyValue(CLIENT_CONTACTS, clientContacts);
  }
});
