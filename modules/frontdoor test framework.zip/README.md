# frontdoor-test-framework

## Configuration
- Setting up your package.json keeping with the format in the [Project setup](https://github.fenicsone.com/fenics/fenics-test-core/blob/master/README.md##project-setup) section.
- Ensure that `./config/users.config.js` contains the relevant test automation users.
- API configuration `config/api.config.js` must contain any configuration related to API client connection.
- UI configuration `config/framework.config.js` must contain generic framework vars, user configuration.
    - Editable Fields:
        - `cleanUpRetry`
        - `veryShortTimeout`
        - `shortTimeout`
        - `mediumTimeout`
        - `longTimeout`
        - `veryLongTimeout`
        - `users`
    - Non-Editable Fields:
        - `clearDownScript`
        - `expectedRuntimeVersion`
 - WDIO Configration `config/wdio.config.js`, avoid changing any of the variables in here unless absolutely required. E.g. `TARGET_ENV` can be changed to point to different environments.
 Alternatively, you can set `TARGET_ENV` as an environment variable. 
 
## Usage
- NPM install using: `npm install` or `npm i`.
- See what `@fenics/fenics-test-core` provides  in the [Usage](https://github.fenicsone.com/fenics/fenics-test-core/blob/master/README.md##usage) section.
- Run tests suites: `npm test` or `./node_modules/.bin/wdio ./config/wdio.config.js`

***NB:*** ***DO NOT** check in `RunOpenFin.bat` and `TerminateOpenFin.bat` in to source as these are runtime scripts.*

## Page object pattern
Please see [Page objects](https://github.fenicsone.com/fenics/fenics-test-core/blob/master/README.md##page-objects).

## Interest Entry application steps
### Custom Parameters
- `{application_prefix}` -- See ~/constant/App.js -> `APP_PREFIXES`.
- `{currency}` -- See ~/constant/CommonEntryData.js -> `CURRENCY_PAIR`.
- `{strategy}` -- See ~/constant/IROEntryData.js -> `STRATETGIES`.
- `{selects}` -- Can only be: `"select"` returns `true` or `"unselect"` returns `false`.
- `{tenor}` -- See ~/constant/CommonEntryData.js -> `TENOR`.
- `{client_contacts}` -- See ~/constant/CommonEntryData.js -> `CLIENT_CONTACTS`.

### Common Steps
#### Given(s)
- `I am broker {string} using the {application_prefix} Interest Entry Application`
<br>**Description:** Logs into the Fenics Launch Bar application and launches the Interest Entry application.
<br>**Paramters:** `username`, `appPrefix` 
<br>**Example:** `I am broker "andrew.demetriou.auto1@testing.fenicstools.com" using the "Ndf" Interest Entry Application`

- `I switch to the {application_prefix} Interest Entry Application`
<br>**Description:** Switches over to the application window, if not already open, it will launch the application from the Launch Bar.
<br>**Paramters:** `appPrefix` 
<br>**Example:** `Given I switch to the "FX Fwd" Interest Entry Application`

#### When(s)
- `I {selects} near tenor {tenor} in the Interest Entry`
<br>**Description:** Selects or unselects the near tenor specified.
<br>**Paramters:** `select`, `nearTenor` 
<br>**Example:** `When I "select" near tenor "O/N" in the Interest Entry`

- `I {selects} far tenor {tenor} in the Interest Entry`
<br>**Description:** Selects or unselects the far tenor specified.
<br>**Paramters:** `select`, `farTenor` 
<br>**Example:** `When I "select" far tenor "S/N" in the Interest Entry`

- `I {selects} the BUY button in the Interest Entry`
<br>**Description:** Selects or unselects the BUY button.
<br>**Paramters:** `select` 
<br>**Example:** `When I "select" the BUY button in the Interest Entry

- `I {selects} the SELL button in the Interest Entry`
<br>**Description:** Selects or unselects the SELL button.
<br>**Paramters:** `select` 
<br>**Example:** `When I "select" the SELL button in the Interest Entry`

- `I {selects} the SIZE button in the Interest Entry`
<br>**Description:** Selects or unselects the SIZE button.
<br>**Paramters:** `select` 
<br>**Example:** `When I "select" the SIZE button in the Interest Entry`

- `I enter "([^"]*)" into the number pad in the Interest Entry`
<br>**Description:** Enters the number sequence into the number pad.
<br>**Paramters:** `value` 
<br>**Example:** `When I enter "53" into the number pad in the Interest Entry`
<br>**NOTE:** You have to select the BUY | SELL | SIZE button before using this function.

- `I click the client {client_contacts} button in the Interest Entry`
<br>**Description:** Clicks the specified client button.
<br>**Paramters:** `client`
<br>**Example:** `When I click the client "JPM" button in the Interest Entry`

- `I {selects} the ORIGINATOR toggle button in the Interest Entry`
<br>**Description:** Selects or unselects the ORIGINATOR toggle button.
<br>**Paramters:** `select`
<br>**Example:** `When I "unselect" the ORIGINATOR toggle button in the Interest Entry`

- `I {selects} the IS FIRM toggle button in the Interest Entry`
<br>**Description:** Selects or unselects the IS FIRM toggle button.
<br>**Paramters:** `select`
<br>**Example:** `When I "unselect" the IS FIRM toggle button in the Interest Entry`

- `I click the CAPTURE INTEREST button in the Interest Entry`
<br>**Description:** Clicks the CAPTURE INTEREST toggle button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click the CAPTURE INTEREST button in the Interest Entry`

- `I click the CLEAR ALL button in the Interest Entry`
<br>**Description:** Clicks the CLEAR ALL button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click the CLEAR ALL button in the Interest Entry`

#### Then(s)
- `The Summary Product text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Summary Product to equal the specified Product.
<br>**Paramters:** `currencyPair`
<br>**Example:** `Then The Summary Product text is equal to "USD/HKD" in the Interest Entry`

- `The Summary Size text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Summary Size to equal the specified Size.
<br>**Paramters:** `size`
<br>**Example:** `Then The Summary Size text is equal to "10" in the Interest Entry`

- `The Summary Client text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Summary Client to equal the specified Client.
<br>**Paramters:** `client`
<br>**Example:** `Then The Summary Client text is equal to "JPM" in the Interest Entry`

- `The Summary Direction text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Direction to equal the specified Direction.
<br>**Paramters:** `direction`
<br>**Example:** `Then The Summary Direction text is equal to "SELL" in the Interest Entry`

- `The Size button text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Size button to equal the specified Size.
<br>**Paramters:** `size`
<br>**Example:** `Then The Size button text is equal to "15" in the Interest Entry`

- `The Mid Price text is equal to "([^"]*)?" in the Interest Entry`
<br>**Description:** Expects the Mid Price to equal the specified Mid Price.
<br>**Paramters:** `midPrice`
<br>**Example:** `Then The Mid Price text is equal to "154" in the Interest Entry`

- `The Near Tenor Popover is visible in the Interest Entry`
<br>**Description:** Expects the Near Tenor Popover to be visible.
<br>**Paramters:** *N/A* 
<br>**Example:** `The Near Tenor Popover is visible in the Interest Entry`

- `The Far Tenor Popover is visible in the Interest Entry`
<br>**Description:** Expects the Far Tenor Popover to be visible.
<br>**Paramters:** *N/A* 
<br>**Example:** `The Far Tenor Popover is visible in the Interest Entry`

### NDF Steps
#### Given(s)
- `The Ndf Interest Entry Application has loaded`
<br>**Description:** Waits until the Ndf Interest Entry application has loaded correctly.
<br>**Paramters:** *N/A* 
<br>**Example:** `Given The Ndf Interest Entry Application has loaded`

#### When(s)
- `I {selects} currency {currency} in the Ndf Interest Entry`
<br>**Description:** Selects or unselects the currency specified.
<br>**Paramters:** `select`, `currency` 
<br>**Example:** `When I "select" currency "HKD" in the Ndf Interest Entry`

#### Then(s)
***TBC***

### FX Fwd Steps
#### Given(s)
- `The FX Fwd Interest Entry Application has loaded`
<br>**Description:** Waits until the FX Fwd Interest Entry application has loaded correctly.
<br>**Paramters:** *N/A* 
<br>**Example:** `Given The FX Fwd Interest Entry Application has loaded`


#### When(s)
- `I select base currency {currency} in the FX Fwd Interest Entry`
<br>**Description:** Selects the base currency specified via the select box.
<br>**Paramters:** `currency` 
<br>**Example:** `When I select counter currency "GBP" in the FX Fwd Interest Entry`

- `I select counter currency {currency} in the FX Fwd Interest Entry`
<br>**Description:** Selects the counter currency specified via the select box.
<br>**Paramters:** `currency` 
<br>**Example:** `When I select counter currency "CHF" in the FX Fwd Interest Entry`

#### Then(s)
***TBC***

### IRO Steps
#### Given(s)
- `The IRO Interest Entry Application has loaded`
<br>**Description:** Waits until the IRO Interest Entry application has loaded correctly.
<br>**Paramters:** *N/A* 
<br>**Example:** `Given The IRO Interest Entry Application has loaded`

#### When(s)
- `I select single currency {currency} in the IRO Interest Entry`
<br>**Description:** Selects a single currency.
<br>**Paramters:** `currency` 
<br>**Example:** `When I select single currency "USD" in the IRO Interest Entry`

- `I select first strategy {strategy} in the IRO Interest Entry`
<br>**Description:** Selects the first strategy.
<br>**Paramters:** `strategy` 
<br>**Example:** `When I select first strategy "ATM" in the IRO Interest Entry`

- `I select second strategy {strategy} in the IRO Interest Entry`
<br>**Description:** Selects the second strategy.
<br>**Paramters:** `strategy` 
<br>**Example:** `When I select second strategy "ATM" in the IRO Interest Entry`

- `I click first strategy strike in the IRO Interest Entry`
<br>**Description:** Clicks the first strategy strike.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click first strategy strike in the IRO Interest Entry`

- `I click second strategy strike in the IRO Interest Entry`
<br>**Description:** Clicks the second strategy strike.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click second strategy strike in the IRO Interest Entry`

- `I click strike metric {strike_metric} in the IRO Interest Entry`
<br>**Description:** Clicks the specified strike metric button.
<br>**Paramters:** `strike` 
<br>**Example:** `When I click strike metric "percentage" in the IRO Interest Entry`

- `I click first strategy index in the IRO Interest Entry`
<br>**Description:** Clicks the first strategy index input box.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click first strategy index in the IRO Interest Entry`

- `I click second strategy index in the IRO Interest Entry`
<br>**Description:** Clicks the second strategy index input box.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click second strategy index in the IRO Interest Entry`

- `I click first strategy expiry in the IRO Interest Entry`
<br>**Description:** Clicks the first strategy expiry button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click first strategy expiry in the IRO Interest Entry`

- `I click second strategy expiry in the IRO Interest Entry`
<br>**Description:** Clicks the second strategy expiry button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click second strategy expiry in the IRO Interest Entry`

- `I click first strategy tail in the IRO Interest Entry`
<br>**Description:** Clicks the first strategy tail button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click first strategy tail in the IRO Interest Entry`

- `I click second strategy tail in the IRO Interest Entry`
<br>**Description:** Clicks the second strategy tail button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click second strategy tail in the IRO Interest Entry`

- `I click favourite currencies in the IRO Interest Entry`
<br>**Description:** Clicks the favourite currencies link text.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click favourite currencies in the IRO Interest Entry`

- `I click favourite strategies in the IRO Interest Entry`
<br>**Description:** Clicks the favourite strategies link text.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click favourite strategies in the IRO Interest Entry`

- `I click favourite tool in the IRO Interest Entry`
<br>**Description:** Clicks the favourite tool button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click favourite tool in the IRO Interest Entry`

- `I select near tenor "(one|two)" "([^"]*)" in the IRO Interest Entry`
<br>**Description:** Clicks the near tenor in popover menu list.
<br>**Paramters:** `id`, `nearTenor` 
<br>**Example:** `I select near tenor "one" "1M" in the IRO Interest Entry`

- `I select far tenor "(one|two)" "([^"]*)" in the IRO Interest Entry`
<br>**Description:** Clicks the far tenor in popover menu list.
<br>**Paramters:** `id`, `farTenor` 
<br>**Example:** `I select far tenor "two" "5Y" in the IRO Interest Entry`

#### Then(s)
- `The strike group label is visible in the IRO Interest Entry`
<br>**Description:** Expects the strike group labels to be visible.
<br>**Paramters:** *N/A*
<br>**Example:** `Then The strike group label is visible in the IRO Interest Entry`

- `The first Tenor Display label should be equal to "([^"]*)" in the IRO Interest Entry`
<br>**Description:** Expects the First Tenor Display text to equal the specified Tenor Display Text.
<br>**Paramters:** `tenorDisplayText`
<br>**Example:** `Then The first Tenor Display label should be equal to "1M/1Y" in the IRO Interest Entry`

- `The second Tenor Display label should be equal to "([^"]*)" in the IRO Interest Entry`
<br>**Description:** Expects the Second Tenor Display text to equal the specified Tenor Display Text.
<br>**Paramters:** `tenorDisplayText`
<br>**Example:** `Then The second Tenor Display label should be equal to "2M/5Y" in the IRO Interest Entry`

- `The Near Tenor Popover "(one|two)" is visible in the IRO Interest Entry`
<br>**Description:** Expects the Near Tenor Popover to be visible.
<br>**Paramters:** `id`
<br>**Example:** `The Near Tenor Popover "one" is visible in the IRO Interest Entry`

- `The Far Tenor Popover "(one|two)" is visible in the IRO Interest Entry`
<br>**Description:** Expects the Far Tenor Popover to be visible.
<br>**Paramters:** `id`
<br>**Example:** `The Far Tenor Popover "two" is visible in the IRO Interest Entry`

## Market View application steps
### Given(s)
- `I'm broker "([^"]*)?" using the Market View application`
<br>**Description:** Logs into the Fenics Launch Bar application and launches the Interest Entry application.
<br>**Paramters:** `username` 
<br>**Example:** `Given I'm broker "andrew.demetriou.auto1@testing.fenicstools.com" using the Market View Application`

- `The Interest Entry application has loaded`
<br>**Description:** Waits until the Interest Entry application has loaded correctly.
<br>**Paramters:** *N/A* 
<br>**Example:** `Given The Interest Entry application has loaded`

### When(s)
- `I click add instrument for product "([^"]*)?" in the Market View`
<br>**Description:** Clicks the add instrument button for the specified instrument.
<br>**Paramters:** `currencyPair` 
<br>**Example:** `When I click add instrument for product "USD/BTC" in the Market View`

- `I (select|unselect) near tenor "([^"]*)?" in the Market View`
<br>**Description:** Selects or unselects the specified near tenor.
<br>**Paramters:** `select`,`nearTenor`
<br>**Example:** `When I select near tenor "1W" in the Market View`

- `I (select|unselect) far tenor "([^"]*)?" in the Market View`
<br>**Description:** Selects or unselects the specified far tenor.
<br>**Paramters:** `select`,`farTenor`
<br>**Example:** `When I select near tenor "1M" in the Market View`

- `I click add tenors button in the Market View`
<br>**Description:** Clicks the add tenors button.
<br>**Paramters:** *N/A* 
<br>**Example:** `When I click add tenors button in the Market View`

- `I enter the following order in the Market View:`
<br>**Description:** Enters the orders specified via a DataTable.
<br>**Paramters:** `dtOrders` 
<br>**Example:** 
```
When I enter the following order in the Market View:
| currencyPair | nearTenor | farTenor | bid | bidSize | offer | offerSize |
| USD/GBP      | 1M        | 2M       | 12  | 15      | 13    | 10        |
| USD/GBP      | 1W        | 1M       | 15  | 20      | 20    | 15        |
```

- `I click add (BUY|SELL) order button for near tenor "([^"]*)?" and far tenor "([^"]*)?" in the Market View`
<br>**Description:** Clicks the add order '+' button for the specified near/far tenor and direction. 
<br>**Paramters:** `direction`,`nearTenor`,`farTenor` 
<br>**Example:** `When I click add SELL order button for near tenor "1M" and far tenor "3M" in the Market View`

- `I click remove (BUY|SELL) order button for row ([\d]+) of near tenor "([^"]*)?" and far tenor "([^"]*)?" in the Market View`
<br>**Description:** Clicks the remove order '+' button for the specified near/far tenor, row and direction. 
<br>**Paramters:** `direction`, `row`,`nearTenor`,`farTenor` 
<br>**Example:** `When I click add SELL order button for near tenor "1M" and far tenor "3M" in the Market View`

- `I click add instrument for product "([^"]*)?" in the Market View`
<br>**Description:** Clicks the send order '+' button for the specified near/far tenor, row and direction. 
<br>**Paramters:** `direction`, `row`,`nearTenor`,`farTenor` 
<br>**Example:** `When I click add SELL order button for near tenor "1M" and far tenor "3M" in the Market View`

### Then(s)
***TBC***

## Coding Standards
Please see [JavaScript Guidelines](https://github.fenicsone.com/fenics/documentation/wiki/JavaScript-Guidelines)