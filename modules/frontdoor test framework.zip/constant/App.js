const MODULE_TITLES = {
  loginPageTitle        : 'Fenics Login',
  launchbarTitle        : 'Fenics Launchbar',
  interestEntryAppLabel : 'Entry',
  marketViewAppLabel    : 'Market View',
  interestEntryAppTitle : 'Entry',
  marketViewAppTitle    : 'Market View'
};

const APP_PREFIXES = {
  FX_FWD : 'FX Fwd',
  NDF    : 'Ndf',
  IRO    : 'IRO'
};

const ELEMENTS = {
  entryPage : {
    buyButtonElement : {
      selector    : () => '[data-qa=direction-BUY-button]',
      description : () => 'BUY button'
    },
    sellButtonElement : {
      selector    : () => '[data-qa=direction-SELL-button]',
      description : () => 'SELL button'
    },
    midPriceElement : {
      selector    : () => '[data-qa=mid-price-label]',
      description : () => 'MID PRICE label'
    },
    sizeButtonElement : {
      selector    : () => '[data-qa=notional-button]',
      description : () => 'SIZE button'
    },
    summaryProductElement : {
      selector    : () => '//div[@data-qa="instrument-product-label"]/*',
      description : () => 'SUMMARY PRODUCT label'
    },
    summaryDirectionElement : {
      selector    : () => '[data-qa=summary-direction-label]',
      description : () => 'SUMMARY DIRECTION label'
    },
    summarySizeElement : {
      selector    : () => '[data-qa=summary-size-label]',
      description : () => 'SUMMARY SIZE label'
    },
    summaryClientElement : {
      selector    : () => '[data-qa=summary-client-label]',
      description : () => 'SUMMARY CLIENT label'
    },
    clientContactButtonElement : {
      selector    : client => `[data-qa="client-contact-${client}-button"]`,
      description : client => `CLIENT CONTACT "${client}" button`
    },
    originatorToggleElement : {
      selector    : () => '[data-qa=submission-originator-toggle-button]',
      description : () => 'ORIGINATOR toggle'
    },
    firmToggleElement : {
      selector    : () => '[data-qa=submission-isfirm-toggle-button]',
      description : () => 'FIRM toggle'
    },
    captureInterestButtonElement : {
      selector    : () => '[data-qa=submission-capture-interest-button]',
      description : () => 'CAPTURE Interest button'
    },
    clearAllButtonElement : {
      selector    : () => '[data-qa=submission-clear-all-button]',
      description : () => 'CLEAR ALL button'
    }
  },
  fxFwdEntryPage : {
    baseCurrencySelectboxElement : {
      selector    : () => '[data-qa=base-currency-select]',
      description : () => 'BASE CURRENCY select box'
    },
    selectOptionElement : {
      selector    : currency => `//li[@role="option" and text()="${currency}"]`,
      description : currency => `SELECT option "${currency}"`
    },
    counterCurrencySelectboxElement : {
      selector    : () => '[data-qa=submission-originator-toggle-button]',
      description : () => 'COUNTER CURRENCY select box'
    }
  },
  fxFwdMarketViewPage  : {},
  instrumentOrdersPage : {
    tenorPopoverElement : {
      selector    : () => '[data-qa="tenor-popover"]',
      description : () => 'TENOR popover'
    },
    orderRowElement : {
      selector    : (instrument, row) => `//div[@data-qa="grid-row" and descendant::div[@data-qa="tenor-${instrument}-label"]][${row}]`,
      description : (instrument, row) => `INSTRUMENT "${instrument}" ORDER ROW "${row}"`
    },
    actionAddIconElement : {
      selector    : direction => `//div[contains(@class,"${direction}")]/div/i[@data-qa="action-add-icon"]`,
      description : direction => `ADD ACTION icon for "${direction}" side`
    },
    statusClearIconElement : {
      selector    : direction => `//div[contains(@class,"${direction}")]/div/i[@data-qa="status-clear-icon"]`,
      description : direction => `CLEAR icon for "${direction}" side`
    },
    statusSendIconElement : {
      selector    : direction => `//div[contains(@class,"${direction}")]/div/i[@data-qa="status-send-icon"]`,
      description : direction => `SEND icon for "${direction}" side`
    },
    bidSizeParentInputElement : {
      selector    : () => '//div[@data-qa="notional-bid-input"]/div',
      description : () => 'BID SIZE parent input'
    },
    bidSizeInputElement : {
      selector    : () => '//div[@data-qa="notional-bid-input"]/div/div/input',
      description : () => 'BID SIZE input'
    },
    bidPriceParentInputElement : {
      selector    : () => '//div[@data-qa="price-bid-input"]/div',
      description : () => 'BID PRICE parent input'
    },
    bidPriceInputElement : {
      selector    : () => '//div[@data-qa="price-bid-input"]/div/div/input',
      description : () => 'BID PRICE input'
    },
    offerSizeParentInputElement : {
      selector    : () => '//div[@data-qa="notional-offer-input"]/div',
      description : () => 'OFFER SIZE parent input'
    },
    offerSizeInputElement : {
      selector    : () => '//div[@data-qa="notional-offer-input"]/div/div/input',
      description : () => 'OFFER SIZE input'
    },
    offerPriceParentInputElement : {
      selector    : () => '//div[@data-qa="price-offer-input"]/div',
      description : () => 'OFFER PRICE parent input'
    },
    offerPriceInputElement : {
      selector    : () => '//div[@data-qa="price-offer-input"]/div/div/input',
      description : () => 'OFFER PRICE input'
    }
  },
  iroEntryPage : {
    singleCurrencySelectboxElement : {
      selector    : () => '[data-qa=single-currency-selectbox]',
      description : () => 'SINGLE CURRENCY select box'
    },
    singleCurrencySelectOptionElement : {
      selector    : option => `//li[@data-qa="single-currency-selectbox-option" and text()="${option}"]`,
      description : option => `SELECT option "${option}"`
    },
    strategySelectOptionElement : {
      selector    : (option, id) => `//li[@data-qa="strategy-group-selectbox-${id}-option" and text()="${option}"]`,
      description : option => `SELECT option ${option}`
    },
    strategyGroupSelectboxOneElement : {
      selector    : () => '[data-qa=strategy-group-selectbox-one]',
      description : () => 'STRATEGY GROUP one select box'
    },
    strategyGroupSelectboxTwoElement : {
      selector    : () => '[data-qa=strategy-group-selectbox-two]',
      description : () => 'STRATEGY GROUP two select box'
    },
    strategyGroupTenorDisplayOneElement : {
      selector    : () => '[data-qa=tenors-display-one]',
      description : () => 'TENOR DISPLAY one label'
    },
    strategyGroupTenorDisplayTwoElement : {
      selector    : () => '[data-qa=tenors-display-one]',
      description : () => 'TENOR DISPLAY two label'
    },
    strategyGroupStrikeInputOneElement : {
      selector    : () => '[data-qa=fake-input-strike-one]',
      description : () => 'STRIKE one input box'
    },
    strategyGroupStrikeInputTwoElement : {
      selector    : () => '[data-qa=fake-input-strike-two]',
      description : () => 'STRIKE two input box'
    },
    strategyGroupIndexInputOneElement : {
      selector    : () => '[data-qa=fake-input-index-one]',
      description : () => 'INDEX one input box'
    },
    strategyGroupIndexInputTwoElement : {
      selector    : () => '[data-qa=fake-input-index-two]',
      description : () => 'INDEX two input box'
    },
    strategyGroupExpiryOneElement : {
      selector    : () => '[data-qa=expiry-button-one]',
      description : () => 'EXPIRY one button'
    },
    strategyGroupExpiryTwoElement : {
      selector    : () => '[data-qa=expiry-button-two]',
      description : () => 'EXPIRY two button'
    },
    strategyGroupTailOneElement : {
      selector    : () => '[data-qa=tail-button-one]',
      description : () => 'TAIL one button'
    },
    strategyGroupTailTwoElement : {
      selector    : () => '[data-qa=tail-button-two]',
      description : () => 'TAIL two button'
    },
    favouriteCurrenciesLinkElement : {
      selector    : () => '[data-qa=favourite-currencies-link]',
      description : () => 'FAVOURITE CURRENCIES link text'
    },
    favouriteStrategiesLinkElement : {
      selector    : () => '[data-qa=favourite-strategies-link]',
      description : () => 'FAVOURITE STRATEGIES link text'
    },
    favouriteToolButtonElement : {
      selector    : () => '[data-qa=favourite-tool-button]',
      description : () => 'FAVOURITE TOOL button'
    }
  },
  iroMarketViewPage : {},
  marketViewPage    : {
    marketViewPageTitleElement : {
      selector    : () => '[data-qa="super-header-title-label"]',
      description : () => 'MARKET VIEW application title'
    },
    instrumentAddTenorButtonElement : {
      selector    : product => `//button[@title="Add instrument" and child::span[text()="${product}"]]`,
      description : product => `ADD INSTRUMENT "${product}" TENOR button`
    },
    productGridElement : {
      selector    : product => `//div[@data-qa="body-product-grid" and preceding-sibling::div[@data-qa="headers-product-grid" and descendant::span[text()="${product}"]]]`,
      description : product => `PRODUCT "${product}" grid`
    },
    appSpinnerIconElement : {
      selector    : () => '.loading-spinner.svelte-1obqx4g',
      description : () => 'LOADING SPINNER icon'
    }
  },
  ndfEntryPage : {
    currencyLabelElement : {
      selector    : currency => `//div[contains(@class, 'fenics-radio-group-group-outline')]/label[child::span[text()='${currency}']]`,
      description : currency => `CURRENCY label "${currency}"`
    },
    currencyButtonElement : {
      selector    : currency => `//div[contains(@class, 'fenics-radio-group-group-outline')]/label[child::span[text()='${currency}']]/span[2]`,
      description : currency => `CURRENCY button "${currency}"`
    }
  },
  ndfMarketViewPage : {},
  numberPadPage     : {
    numberPadGridButtonElement : {
      selector    : input => `//button[@class="fenics-btn fd-num-pad__button" and text() = "${input}"]`,
      description : input => `NUMBER PAD "${input}" button`
    }
  },
  strikeMetricSelectionPage : {
    strikeGroupLabelElement : {
      selector    : () => '[data-qa=strike-label]',
      description : () => 'STRIKE group label'
    },
    strikeMetricInputElement : {
      selector    : label => `//label[descendant::input[@data-qa="strike-group-${label}"]]`,
      description : label => `STRIKE METRIC "${label}" button`
    }
  },
  tenorCalendarPage : {
    nearLegTenorPopoverElement : {
      selector    : id => (id ? `//*[@data-qa="tenor-popover-${id}-near"]` : ''),
      description : id => `NEAR LEG TENOR popover "${id}"`
    },
    farLegTenorPopoverElement : {
      selector    : id => (id ? `//*[@data-qa="tenor-popover-${id}-far"]` : ''),
      description : id => `FAR LEG TENOR popover "${id}"`
    },
    nearTenorLabelElement : {
      selector    : (tenor, id) => `${(id ? `//*[@data-qa="tenor-popover-${id}-near"]` : '')}//div[contains(@class, 'tenors-column--near-leg')]//label[child::span[text()='${tenor}']]`,
      description : (tenor, id) => `NEAR TENOR "${id}" label "${tenor}"`
    },
    nearTenorButtonElement : {
      selector    : (tenor, id) => `${(id ? `//*[@data-qa="tenor-popover-${id}-near"]` : '')}//div[contains(@class, 'tenors-column--near-leg')]//label[child::span[text()='${tenor}']]/span[2]`,
      description : (tenor, id) => `NEAR TENOR "${id}" button "${tenor}"`
    },
    farTenorLabelElement : {
      selector    : (tenor, id) => `${(id ? `//*[@data-qa="tenor-popover-${id}-far"]` : '')}//div[contains(@class, 'tenors-column--far-leg')]//label[child::span[text()='${tenor}']]`,
      description : (tenor, id) => `FAR TENOR "${id}" label "${tenor}"`
    },
    farTenorButtonElement : {
      selector    : (tenor, id) => `${(id ? `//*[@data-qa="tenor-popover-${id}-far"]` : '')}//div[contains(@class, 'tenors-column--far-leg')]//label[child::span[text()='${tenor}']]/span[2]`,
      description : (tenor, id) => `FAR TENOR "${id}" button "${tenor}"`
    },
    addTenorButtonElement : {
      selector    : () => '.fenics-btn.tenor-popover__btn--submit',
      description : currency => `CURRENCY button "${currency}"`
    }
  }
};

export {
  MODULE_TITLES,
  APP_PREFIXES,
  ELEMENTS
};
