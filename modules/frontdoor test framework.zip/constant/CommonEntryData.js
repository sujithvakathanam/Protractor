const CURRENCY_PAIR = {
  GBP     : 'GBP',
  USD     : 'USD',
  CNY     : 'CNY',
  IDR     : 'IDR',
  INR     : 'INR',
  KRW     : 'KRW',
  MYR     : 'MYR',
  PHP     : 'PHP',
  TWD     : 'TWD',
  VND     : 'VND',
  CNH     : 'CNH',
  HKD     : 'HKD',
  SGD     : 'SGD',
  THB     : 'THB',
  RUB     : 'RUB',
  RUB_NDF : 'RUB-NDF'
};

const TENOR = {
  O_N          : 'O/N',
  T_N          : 'T/N',
  S_N          : 'S/N',
  ONE_WEEK     : '1W',
  ONE_MONTH    : '1M',
  TWO_MONTH    : '2M',
  THREE_MONTH  : '3M',
  FOUR_MONTH   : '4M',
  FIVE_MONTH   : '5M',
  SIX_MONTH    : '6M',
  SEVEN_MONTH  : '7M',
  EIGHT_MONTH  : '8M',
  NINE_MONTH   : '9M',
  TEN_MONTH    : '10M',
  ELEVEN_MONTH : '11M',
  ONE_YEAR     : '1Y',
  TWO_YEAR     : '2Y',
  THREE_YEAR   : '3Y',
  FIVE_YEAR    : '5Y'
};

const DIRECTION = {
  BUY  : 'BUY',
  SELL : 'SELL'
};

const CLIENT_CONTACTS = {
  HSBC          : 'HSBC',
  MS            : 'MS',
  DB            : 'DB',
  BARC          : 'JPM',
  GS            : 'GS',
  CITI          : 'CITI',
  UBS           : 'UBS',
  CS            : 'CS',
  DOVILE        : 'Dovile P',
  FABRICE       : 'Fabrice D',
  JAMES         : 'James T',
  JESS          : 'Jess F',
  QIMING        : 'Qiming L',
  PETER         : 'Peter D',
  VLAD          : 'Vlad C',
  CONTACT_ONE   : 'Contact 1',
  CONTACT_TWO   : 'Contact 2',
  CONTACT_THREE : 'Contact 3',
  CONTACT_FOUR  : 'Contact 4',
  CONTACT_FIVE  : 'Contact 5',
  CONTACT_SIX   : 'Contact 6'
};

const NUMBER_PAD_SPECIAL_CHAR = {
  BACKSPACE : 'backspace'
};

export {
  CURRENCY_PAIR,
  TENOR,
  DIRECTION,
  CLIENT_CONTACTS,
  NUMBER_PAD_SPECIAL_CHAR
};
