/* eslint-disable id-length */
const STRIKES = {
  ATM        : 'atm',
  PERCENTAGE : 'percentage',
  PLUS_MINUS : 'plusminus'
};

const STRATETGIES = {
  ATM   : 'ATM',
  CAP   : 'CAP',
  FLR   : 'FLR',
  WC    : 'WC',
  CFS   : 'CFS',
  P     : 'P',
  R     : 'R',
  WS    : 'WS',
  ISDA  : 'ISDA',
  WEDGE : 'WEDGE'
};

export {
  STRIKES,
  STRATETGIES
};
