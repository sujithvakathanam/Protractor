const hasKeyValue = (json, value) => {
  const foundKey = Object.keys(json).find(key => json[key] === value) !== undefined;

  if (foundKey === false) {
    throw new Error(`Specified value "${value}" is not a valid! Please check JSON object.`);
  }

  return value;
};

export {
  hasKeyValue
};
