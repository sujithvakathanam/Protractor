import {DateTime as dt} from 'luxon';

const formatTenor = tenor => (dt.fromISO(tenor).isValid ? dt.fromISO(tenor).toFormat('dd LLL') : tenor);

const getFormattedTenors = (nearTenor, farTenor) => {
  let firstLine = '';
  let secondLine = '';
  if (dt.fromISO(nearTenor).isValid || dt.fromISO(farTenor).isValid) {
    firstLine = `${formatTenor(nearTenor)}/`;
    secondLine = formatTenor(farTenor);
  } else {
    firstLine = [nearTenor, farTenor].join('');
  }

  return `${firstLine}${secondLine}`;
};

export {
  getFormattedTenors
};
