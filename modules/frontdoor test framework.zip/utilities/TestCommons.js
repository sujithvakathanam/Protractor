import Page from '../pages/Page';
import {join} from 'path';

class TestCommons extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Page object vars.
  }

  getTerminateScript () {
    return require.resolve(join('../', this.configuration.clearDownScript));
  }
}

export default TestCommons;
