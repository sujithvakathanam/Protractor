export const usersConfig = {
  users : [
    {
      oktaId   : '00u2mhoeb9yIEP3nn0i7',
      username : 'andrew.demetriou.auto1@testing.fenicstools.com',
      password : 'NS6Hhg9UBabsMKpp',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u2mhp8z5VN5y7990i7',
      username : 'andrew.demetriou.auto2@testing.fenicstools.com',
      password : 'PLM3GASBp2g2Z5tl',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u2mho656c7dEh1M0i7',
      username : 'andrew.demetriou.auto3@testing.fenicstools.com',
      password : 'PlwXQlCMP45xHNz9',
      lei      : '773',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u2mho4lhIi5refO0i7',
      username : 'andrew.demetriou.auto4@testing.fenicstools.com',
      password : 'WZDKfkuTKQEt2trc',
      lei      : '773',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u2mhri1wOHdbpjF0i7',
      username : 'andrew.demetriou.auto5@testing.fenicstools.com',
      password : 'ToeU3urayZ7m3s3S',
      lei      : '777',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u2mhpzpfeKC56340i7',
      username : 'andrew.demetriou.auto6@testing.fenicstools.com',
      password : '1yU24xtdqlFKPd5w',
      lei      : '777',
      espeed   : 'fencrt01',
      type     : 'trader'
    },
    {
      oktaId   : '00u21jiqraHhWPmjm0i7',
      username : 'qa.1',
      password : 'Password1',
      lei      : '2',
      espeed   : 'afina522',
      type     : 'trader'
    },
    {
      oktaId   : '00u21jjzf0cGs2kE60i7',
      username : 'qa.2',
      password : 'Password1',
      lei      : '885',
      espeed   : 'bsch959e',
      type     : 'trader'
    },
    {
      oktaId   : '00u2b0n465530BGxK0i7',
      username : 'qa.3',
      password : 'Password1',
      lei      : '346',
      espeed   : 'dhanc398',
      type     : 'trader'
    },
    {
      oktaId   : '00u2b0m7qbJqIdUIf0i7',
      username : 'qa.4',
      password : 'Password1',
      lei      : '419',
      espeed   : 'bbure682',
      type     : 'trader'
    }
  ]
};
