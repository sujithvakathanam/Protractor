export const frameworkConfig = {
  clearDownScript        : 'TerminateOpenfin.bat',
  expectedRuntimeVersion : '9.61.33.22',
  cleanUpRetry           : 2,
  veryShortTimeout       : 2000,
  shortTimeout           : 7000,
  mediumTimeout          : 20000,
  longTimeout            : 70000,
  veryLongTimeout        : 500000,
  logLevel               : 'info'
};
