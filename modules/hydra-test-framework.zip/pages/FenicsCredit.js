import Page from './Page.js';
import {UiHydraStrategy} from '../lib/hydra/uiHydraStrategy.js';
import Alerts from './Alerts';

class FenicsCredit extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.headerLogoSelector = '.header__logo__img';
    this.minimiseWindowButtonSelector = '//div[@class="window-control-icon"][2]';
    this.maximiseWindowButtonSelector = '//div[@class="window-control-icon"][2]/*[name()="svg"]';
    this.dropDownButtonSelector = '//section/i[contains(@class, "fenics-dropdown-trigger")]';
    this.signOutButtonSelector = '//button[contains(@text, "Sign out")]';
    this.closeWindowButtonSelector = '//div[@class="window-control-icon"][3]';
    this.ratingSelector = ratingToBeSubscribed => `//button[contains(@class,"background-ghost")]/span[text()='${ratingToBeSubscribed}']/..`;
    this.sectorSelector = sectorToBeSubscribed => `//button[contains(@class,"background-ghost")]/span[text()='${sectorToBeSubscribed}']/..`;
    this.updateSelector = '//button[contains(@text, "Update")]';
    this.cancelSelector = '//button[contains(@text, "Cancel")]';

    // Page object vars.
    this.uiHydraStrategy = new UiHydraStrategy(context);
  }

  get headerLogo () {
    return this.browser.element(this.headerLogoSelector);
  }

  get minimiseWindowButton () {
    return this.browser.element(this.minimiseWindowButtonSelector);
  }

  get maximiseWindowButton () {
    return this.browser.element(this.maximiseWindowButtonSelector);
  }

  get dropDownButton () {
    return this.browser.element(this.dropDownButtonSelector);
  }

  get updateSelectorButton () {
    return this.browser.element(this.updateSelector);
  }

  get cancelSelectorButton () {
    return this.browser.element(this.cancelSelector);
  }

  get signOut () {
    return this.browser.element(this.signOutButtonSelector);
  }

  get closeWindowButton () {
    return this.browser.element(this.closeWindowButtonSelector);
  }

  addOrdersFromFile (fileName) {
    return this.uiHydraStrategy.addOrdersFromFile(fileName);
  }

  addOrders (orders) {
    this.getPortfolio(true);

    return this.uiHydraStrategy.addOrders(orders);
  }

  addOrdersByQuickUpload (securityId) {
    return this.uiHydraStrategy.addOrdersByQuickUpload(securityId);
  }

  async waitForPageLoad (timeout) {
    let foundUpload = false;
    await this.browser.waitUntil(async () => {
      try {
        const elements = await this.browser.elements(
          '//*[contains(@class, "fenics-upload-disabled")]',
          timeout
        );
        foundUpload = elements.value.length === 0;
      } catch (error) {
        foundUpload = false;
      }

      return foundUpload;
    });

    return this.browser.waitUntil(
      () => this.uiHydraStrategy.fileInput.isExisting(),
      timeout,
      `Timed out after ${timeout}ms, file upload input does not exist.`
    );
  }

  getPortfolio (click = false) {
    return this.uiHydraStrategy.getPortfolio(click);
  }

  getSessionPanel (rating = 'HY', click = false, type = 'Session') {
    return this.uiHydraStrategy.getSessionPanel(rating, click, type);
  }

  getTrades (click = false) {
    return this.uiHydraStrategy.getTrades(click);
  }

  getActionPanel () {
    return this.uiHydraStrategy.getActionPanel();
  }

  getAlerts () {
    return new Alerts(this.context);
  }

  refreshPage () {
    return this.browser.refresh();
  }

  clickMinimiseWindow () {
    return this.minimiseWindowButton.click();
  }

  async clickMaximiseWindow () {
    await this.browser.waitUntil(
      () => this.maximiseWindowButton.isVisible(),
      this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout}ms, Maximise Button does not exist`
    );

    return this.maximiseWindowButton.click();
  }

  async clickSignOut () {
    await this.browser.waitUntil(
      () => this.dropDownButton.isVisible(),
      this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout}ms, dropdown Button does not exist`
    );
    await this.dropDownButton.click();

    await this.browser.waitUntil(
      () => this.signOut.isVisible(),
      this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout}ms, Signout Button does not exist`
    );
    await this.signOut.keys('\uE009');
    await this.signOut.click();
    global.console.log('UI- HydraPageModel user has signed out ');
  }

  async setUserSubscriptionRating (rating) {
    await this.browser.waitUntil(
      () => this.dropDownButton.isVisible(),
      this.configuration.veryShortTimeout,
      `Timed out after ${this.configuration.veryShortTimeout}ms, dropdown Button does not exist`
    );
    await this.dropDownButton.click();
    await this.browser.pause(this.configuration.veryShortTimeout);

    this.ratingToBeSubscribed = rating === 'HIGH_YIELD' ? 'High Yield' : 'Investment Grade';

    try {
      await this.browser.waitUntil(
        () => this.browser.element(this.ratingSelector(this.ratingToBeSubscribed)).isVisible()
        , this.configuration.shortTimeout
        , `Timed out after ${this.configuration.shortTimeout}ms, ${rating} Button does not exist`
      );

      await this.browser.element(this.ratingSelector(this.ratingToBeSubscribed)).click();
      await this.browser.waitUntil(
        () => this.updateSelectorButton.isVisible()
        , this.configuration.shortTimeout
        , `Timed out after ${this.configuration.shortTimeout}ms, Update Button does not exist`
      );

      global.console.log(`User is not subscribed to this ${this.ratingToBeSubscribed}. About to subscribe now`);

      return this.updateSelectorButton.click();
    } catch (error) {
      global.console.log(`${this.ratingToBeSubscribed} is already subscribed`);
      await this.cancelSelectorButton.isVisible();

      return this.cancelSelectorButton.click();
    }
  }

  async setUserSubscriptionSector (sector) {
    await this.browser.waitUntil(
      () => this.dropDownButton.isVisible(),
      this.configuration.veryShortTimeout,
      `Timed out after ${this.configuration.veryShortTimeout}ms, dropdown Button does not exist`
    );
    await this.dropDownButton.click();
    await this.browser.pause(this.configuration.veryShortTimeout);

    try {
      await this.browser.waitUntil(
        () => this.browser.element(this.sectorSelector(sector)).isVisible()
        , this.configuration.veryShortTimeout
        , `Timed out after ${this.configuration.veryShortTimeout}ms, ${sector} Button does not exist`
      );

      await this.browser.element(this.sectorSelector(sector)).click();
      await this.browser.waitUntil(
        () => this.updateSelectorButton.isVisible()
        , this.configuration.shortTimeout
        , `Timed out after ${this.configuration.shortTimeout}ms, Update Button does not exist`
      );

      global.console.log(`User is not subscribed to this ${sector}. About to subscribe now`);

      return this.updateSelectorButton.click();
    } catch (error) {
      global.console.log(`${sector} is already subscribed`);
      await this.cancelSelectorButton.isVisible();

      return this.cancelSelectorButton.click();
    }
  }

  clickCloseWindow () {
    return this.closeWindowButton.click();
  }
}

export default FenicsCredit;
