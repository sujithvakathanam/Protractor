import Page from '../Page';

class PricingPage extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.pricingtemSelector = '//li[contains(@class, "header__nav__list__item")][5]';
  }

  get pricingtem () {
    return this.browser.element(this.pricingtemSelector);
  }

  clickPricing () {
    return this.pricingtem.click();
  }
}

export default PricingPage;
