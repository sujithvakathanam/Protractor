import Page from '../Page';

class SystemActivityPage extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.systemActivityLogItemSelector = '//li[contains(@class, "header__nav__list__item")][2]';
    this.refreshBtnSelector = '//button[contains(@class,"fenics-btn-background-ghost")]//span[text()="Refresh"]';
    this.userItemsSelector = '//div[contains(@class,"fenics-table-body")]/table//td[2]';
    this.protocolSelector = '//div[contains(@class,"fenics-table-body")]/table//td[3]';
    this.phaseSelector = '//div[contains(@class,"fenics-table-body")]/table//td[4]';
    this.actionItemsSelector = '//div[contains(@class,"fenics-table-body")]/table//td[5]';
    this.isinSelector = '//div[contains(@class,"fenics-table-body")]/table//td[6]';
    this.bondNameSelector = '//div[contains(@class,"fenics-table-body")]/table//td[7]';
    this.buySelector = '//div[contains(@class,"fenics-table-body")]/table//td[8]';
    this.priceSelector = '//div[contains(@class,"fenics-table-body")]/table//td[9]';
    this.sellSelector = '//div[contains(@class,"fenics-table-body")]/table//td[10]';
  }

  get systemActivityLogItem () {
    return this.browser.element(this.systemActivityLogItemSelector);
  }

  get refreshBtn () {
    return this.browser.element(this.refreshBtnSelector);
  }

  get userItems () {
    return this.browser.elements(this.userItemsSelector);
  }

  get protocol () {
    return this.browser.elements(this.protocolSelector);
  }

  get phase () {
    return this.browser.elements(this.phaseSelector);
  }

  get actionItems () {
    return this.browser.elements(this.actionItemsSelector);
  }

  get isin () {
    return this.browser.elements(this.isinSelector);
  }

  get bondName () {
    return this.browser.elements(this.bondNameSelector);
  }

  get buy () {
    return this.browser.elements(this.buySelector);
  }

  get price () {
    return this.browser.elements(this.priceSelector);
  }

  get sell () {
    return this.browser.elements(this.sellSelector);
  }

  clickSystemActivityLog () {
    return this.systemActivityLogItem.click();
  }

  async getSystemActivityLogs () {
    const logEntries = [];

    const userItems = await this.userItems.getText();
    const protocolItems = await this.protocol.getText();
    const phaseItems = await this.phase.getText();
    const actionItems = await this.actionItems.getText();
    const isin = await this.isin.getText();
    const bondName = await this.bondName.getText();
    const buy = await this.buy.getText();
    const price = await this.price.getText();
    const sell = await this.sell.getText();

    for (let colIndex = 0; colIndex < actionItems.length; colIndex += 1) {
      const logEntry = {
        USER     : userItems[colIndex],
        PROTOCOL : protocolItems[colIndex],
        PHASE    : phaseItems[colIndex],
        ACTION   : actionItems[colIndex],
        ISIN     : isin[colIndex],
        BONDNAME : bondName[colIndex],
        BUY      : buy[colIndex],
        PRICE    : price[colIndex],
        SELL     : sell[colIndex]
      };

      logEntries.push(logEntry);
    }

    return logEntries;
  }

  async getSystemActivityLogsForISIN (securityId) {
    const result = [];
    const logs = await this.getSystemActivityLogs();

    const filteredLog = logs.filter(log => log.ISIN === securityId);
    result.push(filteredLog);

    return result;
  }
}

export default SystemActivityPage;
