import Page from '../Page';

class Configuration extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors vars.
    this.configurationItemSelector = '//li[contains(@class, "header__nav__list__item")][6]';
    this.investmentRatingDropDownSelector = '//label[text() = "Investment Rating"]/following-sibling::div[@class = "fenics-dropdown-trigger"]';
    this.chooseTypeDropDownSelector = '//label[text() = "Choose Type"]/following-sibling::div[@class = "fenics-dropdown-trigger"]';
    this.chooseSectorDropDownSelector = '//label[text() = "Choose Sector"]/following-sibling::div[@class = "fenics-dropdown-trigger"]';
    this.phaseDurationPricingCustomBtnSelector = '//label/span[text()="Pricing:"]/ancestor::label/following-sibling::label/span[text()="Custom"]';
    this.phaseDurationPrivateCustomBtnSelector = '//label/span[text()="Private:"]/ancestor::label/following-sibling::label/span[text()="Custom"]';
    this.phaseDurationGroupCustomBtnSelector = '//label/span[text()="Group:"]/ancestor::label/following-sibling::label/span[text()="Custom"]';
    this.phaseDurationPricingInputSelector = '//label/span[text()="Pricing:"]/ancestor::div[@class = "phase-duration-controls"]/div[2]/div[2]/input';
    this.phaseDurationPrivateInputSelector = '//label/span[text()="Private:"]/ancestor::div[@class = "phase-duration-controls"]/div[2]/div[2]/input';
    this.phaseDurationGroupInputSelector = '//label/span[text()="Group:"]/ancestor::div[@class = "phase-duration-controls"]/div[2]/div[2]/input';
    this.saveBtnSelector = '//button[contains(@class,"fenics-btn button-area-button")][2]';
    this.marketsPopoverTitleSelector = '//div[@class="markets-popover-title"][text()= "IG PN Funds"]';
    this.summaryInvestmentRatingSelector = '//section[@class="summary-section"][1]/div[1]';
    this.summaryTypeSelector = '//section[@class="summary-section"][1]/div[2]';
    this.summarySectorSelector = '//section[@class="summary-section"][1]/div[3]';
    this.summaryPricingSelector = '//section[@class="summary-section"][2]/div[1]';
    this.summaryPrivateSelector = '//section[@class="summary-section"][2]/div[2]';
    this.summaryGroupSelector = '//section[@class="summary-section"][2]/div[3]';
    this.summaryInCompetitionVisibleSelector = '//section[@class="summary-section"][3]/div[1]';
    this.summarySpreadSelector = '//section[@class="summary-section"][4]/div[1]';
    this.marketsPopoverSummaryInvestmentRatingSelector = market => `//div[contains(@class,"fenics-popover-hidden")]//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = 'market-summary markets-popover']/section[1]/div[1]`;
    this.marketsPopoverSummaryTypeSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[1]/div[2]`;
    this.marketsPopoverSummarySectorSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[1]/div[3]`;
    this.marketsPopoverSummaryPricingSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[2]/div[1]`;
    this.marketsPopoverSummaryPrivateSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[2]/div[2]`;
    this.marketsPopoverSummaryGroupSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[2]/div[3]`;
    this.marketsPopoverSummaryInCompetitionVisibleSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[3]/div[1]`;
    this.marketsPopoverSummarySpreadSelector = market => `//div[@class="markets-popover-title"][text()= '${market}']/following-sibling::div[@class = "market-summary markets-popover"]/section[4]/div/div`;
    this.selectInvestmentRatingSelector = rating => `//li[contains(@class,'dropdown-selector-menu-item')]//p[text() = '${rating}']`;
    this.selectSectorSelector = sector => `//li[contains(@class,'dropdown-selector-menu-item')]//p[text() = '${sector}']`;
    this.selectIncompetitionVisibleSelector = inCompetitionVisble => `//label[text() = "In Competition Visible"]/following-sibling::div/label/span[2][text()='${inCompetitionVisble}']`;
    this.selectPricingGlowVisibleSelector = pricingGlowVisible => `//label/span[text()='Pricing:']/ancestor::div[contains(@class,'phase-controls')]//span[text()='${pricingGlowVisible}']`;
    this.selectPrivateGlowVisibleSelector = privateGlowVisible => `//label/span[text()='Private:']/ancestor::div[contains(@class,'phase-controls')]//span[text()='${privateGlowVisible}']`;
    this.selectGroupGlowVisibleSelector = groupGlowVisible => `//label/span[text()='Group:']/ancestor::div[contains(@class,'phase-controls')]//span[text()='${groupGlowVisible}']`;
  }

  get configurationItem () {
    return this.browser.element(this.configurationItemSelector);
  }

  get investmentRatingDropDown () {
    return this.browser.element(this.investmentRatingDropDownSelector);
  }

  get chooseTypeDropDown () {
    return this.browser.element(this.chooseTypeDropDownSelector);
  }

  get chooseSectorDropDown () {
    return this.browser.element(this.chooseSectorDropDownSelector);
  }

  get phaseDurationPricingCustomBtn () {
    return this.browser.element(this.phaseDurationPricingCustomBtnSelector);
  }

  get phaseDurationPrivateCustomBtn () {
    return this.browser.element(this.phaseDurationPrivateCustomBtnSelector);
  }

  get phaseDurationGroupCustomBtn () {
    return this.browser.element(this.phaseDurationGroupCustomBtnSelector);
  }

  get phaseDurationPricingInput () {
    return this.browser.element(this.phaseDurationPricingInputSelector);
  }

  get phaseDurationPrivateInput () {
    return this.browser.element(this.phaseDurationPrivateInputSelector);
  }

  get phaseDurationGroupInput () {
    return this.browser.element(this.phaseDurationGroupInputSelector);
  }

  get saveBtn () {
    return this.browser.element(this.saveBtnSelector);
  }

  get marketsPopoverTitle () {
    return this.browser.element(this.marketsPopoverTitleSelector);
  }

  summaryInvestmentRating () {
    return this.browser.element(this.summaryInvestmentRatingSelector);
  }

  summaryType () {
    return this.browser.element(this.summaryTypeSelector);
  }

  summarySector () {
    return this.browser.element(this.summarySectorSelector);
  }

  summaryPricing () {
    return this.browser.element(this.summaryPricingSelector);
  }

  summaryPrivate () {
    return this.browser.element(this.summaryPrivateSelector);
  }

  summaryGroup () {
    return this.browser.element(this.summaryGroupSelector);
  }

  summaryInCompetitionVisible () {
    return this.browser.element(this.summaryInCompetitionVisibleSelector);
  }

  summarySpread () {
    return this.browser.element(this.summarySpreadSelector);
  }

  marketsPopoverSummaryInvestmentRating (market) {
    return this.browser.element(this.marketsPopoverSummaryInvestmentRatingSelector(market));
  }

  marketsPopoverSummaryType (market) {
    return this.browser.element(this.marketsPopoverSummaryTypeSelector(market));
  }

  marketsPopoverSummarySector (market) {
    return this.browser.element(this.marketsPopoverSummarySectorSelector(market));
  }

  marketsPopoverSummaryPricing (market) {
    return this.browser.element(this.marketsPopoverSummaryPricingSelector(market));
  }

  marketsPopoverSummaryPrivate (market) {
    return this.browser.element(this.marketsPopoverSummaryPrivateSelector(market));
  }

  marketsPopoverSummaryGroup (market) {
    return this.browser.element(this.marketsPopoverSummaryGroupSelector(market));
  }

  marketsPopoverSummaryInCompetitionVisible (market) {
    return this.browser.element(this.marketsPopoverSummaryInCompetitionVisibleSelector(market));
  }

  marketsPopoverSummarySpread (market) {
    return this.browser.element(this.marketsPopoverSummarySpreadSelector(market));
  }

  selectInvestmentRating (rating) {
    return this.browser.element(this.selectInvestmentRatingSelector(rating));
  }

  selectSector (sector) {
    return this.browser.element(this.selectSectorSelector(sector));
  }

  selectIncompetitionVisible (inCompetitionVisble) {
    return this.browser.element(this.selectIncompetitionVisibleSelector(inCompetitionVisble));
  }

  selectPricingGlowVisible (pricingGlowVisible) {
    return this.browser.element(this.selectPricingGlowVisibleSelector(pricingGlowVisible));
  }

  selectPrivateGlowVisible (privateGlowVisible) {
    return this.browser.element(this.selectPrivateGlowVisibleSelector(privateGlowVisible));
  }

  selectGroupGlowVisible (groupGlowVisible) {
    return this.browser.element(this.selectGroupGlowVisibleSelector(groupGlowVisible));
  }

  refreshPage () {
    return this.browser.refresh();
  }

  clickConfiguration () {
    return this.configurationItem.click();
  }

  getSummaryInvestmentRating () {
    return this.summaryInvestmentRating().getText();
  }

  getSummaryType () {
    return this.summaryType().getText();
  }

  getSummarySector () {
    return this.summarySector().getText();
  }

  getSummaryPricing () {
    return this.summaryPricing().getText();
  }

  getSummaryPrivate () {
    return this.summaryPrivate().getText();
  }

  getSummaryGroup () {
    return this.summaryGroup().getText();
  }

  getSummaryInCompetitionVisible () {
    return this.summaryInCompetitionVisible().getText();
  }

  getSummarySpread () {
    return this.summarySpread().getText();
  }

  getMarketsPopoverSummaryInvestmentRating (market) {
    return this.marketsPopoverSummaryInvestmentRating(market).getText();
  }

  getMarketsPopoverSummaryType (market) {
    return this.marketsPopoverSummaryType(market).getText();
  }

  getMarketsPopoverSummarySector (market) {
    return this.marketsPopoverSummarySector(market).getText();
  }

  getMarketsPopoverSummaryPricing (market) {
    return this.marketsPopoverSummaryPricing(market).getText();
  }

  getMarketsPopoverSummaryPrivate (market) {
    return this.marketsPopoverSummaryPrivate(market).getText();
  }

  getMarketsPopoverSummaryGroup (market) {
    return this.marketsPopoverSummaryGroup(market).getText();
  }

  getMarketsPopoverSummaryInCompetitionVisible (market) {
    return this.marketsPopoverSummaryInCompetitionVisible(market).getText();
  }

  getMarketsPopoverSummarySpread (market) {
    return this.marketsPopoverSummarySpread(market).getText();
  }

  async marketEdit (marketConfiguration) {
    await this.browser.waitUntil(() => this.investmentRatingDropDown.isVisible(), this.configuration.shortTimeout);
    await this.investmentRatingDropDown.click();
    await this.browser.waitUntil(() => this.selectInvestmentRating(marketConfiguration.rating).isVisible(), this.configuration.shortTimeout);
    await this.selectInvestmentRating(marketConfiguration.rating).click();
    await this.browser.waitUntil(() => this.chooseSectorDropDown.isVisible(), this.configuration.shortTimeout);
    await this.chooseSectorDropDown.click();
    await this.browser.waitUntil(() => this.selectSector(marketConfiguration.sector).isVisible(), this.configuration.shortTimeout);
    await this.selectSector(marketConfiguration.sector).click();

    await this.browser.waitUntil(() => this.phaseDurationPricingCustomBtn.isVisible(), this.configuration.shortTimeout);
    await this.phaseDurationPricingCustomBtn.click();
    await this.phaseDurationPricingInput.setValue(marketConfiguration.pricingDuration);

    await this.phaseDurationPrivateCustomBtn.click();
    await this.phaseDurationPrivateInput.setValue(marketConfiguration.privateDuration);

    await this.phaseDurationGroupCustomBtn.click();
    await this.phaseDurationGroupInput.setValue(marketConfiguration.groupDuration);

    await this.browser.waitUntil(() => this.selectPricingGlowVisible(marketConfiguration.pricingGlowVisible).isVisible(), this.configuration.shortTimeout);
    await this.selectPricingGlowVisible(marketConfiguration.pricingGlowVisible).click();

    await this.browser.waitUntil(() => this.selectPrivateGlowVisible(marketConfiguration.privateGlowVisible).isVisible(), this.configuration.shortTimeout);
    await this.selectPrivateGlowVisible(marketConfiguration.privateGlowVisible).click();

    await this.browser.waitUntil(() => this.selectGroupGlowVisible(marketConfiguration.groupGlowVisible).isVisible(), this.configuration.shortTimeout);
    await this.selectGroupGlowVisible(marketConfiguration.groupGlowVisible).click();

    await this.selectIncompetitionVisible(marketConfiguration.inCompetitionVisble).click();

    await this.browser.waitUntil(() => this.saveBtn.isVisible(), this.configuration.shortTimeout);
    await this.saveBtn.click();
  }
}

export default Configuration;
