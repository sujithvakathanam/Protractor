import Page from '../Page';

class Dashboard extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.privateNegotiationDashboardItemCountSelector = '//span[@class = "dashboard__item__label"][text()= "Private Negotiations Running"]/preceding-sibling::span[@class = "dashboard__item__count"]';
    this.dashboardItemSelector = '//li[contains(@class, "header__nav__list__item")][1]';
  }

  get privateNegotiationDashboardItemCount () {
    return this.browser.element(this.privateNegotiationDashboardItemCountSelector);
  }

  get dashboardItem () {
    return this.browser.element(this.dashboardItemSelector);
  }

  clickDashboard () {
    return this.dashboardItem.click();
  }

  getLiveRunningPNcount () {
    return this.privateNegotiationDashboardItemCount.getText();
  }
}

export default Dashboard;
