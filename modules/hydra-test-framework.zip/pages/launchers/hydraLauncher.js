import FenicsLaunchBar from '../FenicsLaunchBar';
import FenicsCredit from '../FenicsCredit';
import Page from '../Page';
import FenicsOperator from '../FenicsOperator';
import {MODULE_TITLES} from '../../constant/App';

export class HydraLauncher extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Page object vars.
    this.fenicsCreditPage = new FenicsCredit(context);
    this.fenicsOperatorPage = new FenicsOperator(context);
  }

  async launchFromLaunchbar (forceRestart, hydraClientTitle, launchbarTitle, pageTitle) {
    const hasHydra = await super.hasTabOpen(hydraClientTitle);
    let hydraPage = null;

    if (MODULE_TITLES.hydraClientTitle === hydraClientTitle) {
      hydraPage = this.fenicsCreditPage;
    } else {
      hydraPage = this.fenicsOperatorPage;
    }

    if (!hasHydra) {
      await super.waitForTab(launchbarTitle);
      const launchbarPage = new FenicsLaunchBar(this.context);
      await this.browser.pause(this.configuration.shortTimeout);
      await launchbarPage.openApplication(hydraClientTitle);
      await super.waitForTab(pageTitle);
      await hydraPage.waitForPageLoad();
    } else if (forceRestart) {
      await this.browser.refresh();
      await hydraPage.waitForPageLoad();
    }

    return true;
  }
}
