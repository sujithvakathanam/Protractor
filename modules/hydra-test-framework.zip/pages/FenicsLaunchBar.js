
import Page from './Page.js';

class FenicsLaunchBar extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.applicationIconSelector = applicationName => `//li[descendant::figcaption[text()="${applicationName}"]]`;
  }

  getApplicationButton (applicationName) {
    return this.browser.element(this.applicationIconSelector(applicationName));
  }

  openApplication (applicationName) {
    return this.getApplicationButton(applicationName).click();
  }
}

export default FenicsLaunchBar;
