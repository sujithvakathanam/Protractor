import Page from './Page.js';
import Dashboard from './operator/Dashboard';
import SystemActivityPage from './operator/SystemActivityPage';
import PrivateNegotiationPage from './operator/PrivateNegotiationPage';
import PricingPage from './operator/PricingPage';
import Configuration from './operator/Configuration';

class FenicsOperator extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.headerLogoSelector = '.logo.header__logo';
    this.headerTitleSelector = '//h1[@class = "header__title"][text()="Dashboard"]';
    this.minimiseWindowButtonSelector = '//div[@class="window-control-icon"][1]';
    this.maximiseWindowButtonSelector = '//div[@class="window-control-icon"][2]';
    this.closeWindowButtonSelector = '//div[@class="window-control-icon"][3]';

    // Page object vars.
    this.dashboard = new Dashboard(context);
    this.systemActivity = new SystemActivityPage(context);
    this.privateNegotiation = new PrivateNegotiationPage(context);
    this.pricing = new PricingPage(context);
    this.configuration = new Configuration(context);
  }

  get headerLogo () {
    return this.browser.element(this.headerLogoSelector);
  }

  get headerTitle () {
    return this.browser.element(this.headerTitleSelector);
  }

  get minimiseWindowButton () {
    return this.browser.element(this.minimiseWindowButtonSelector);
  }

  get maximiseWindowButton () {
    return this.browser.element(this.maximiseWindowButtonSelector);
  }

  get closeWindowButton () {
    return this.browser.element(this.closeWindowButtonSelector);
  }

  get dashboardPage () {
    return this.dashboard;
  }

  get systemActivityPage () {
    return this.systemActivity;
  }

  get privateNegotiationPage () {
    return this.privateNegotiation;
  }

  get pricingPage () {
    return this.pricing;
  }

  get configurationPage () {
    return this.configuration;
  }

  refreshPage () {
    return this.browser.refresh();
  }

  clickMinimiseWindow () {
    return this.minimiseWindowButton.click();
  }

  clickMaximiseWindow () {
    return this.maximiseWindowButton.click();
  }

  clickCloseWindow () {
    return this.closeWindowButton.click();
  }

  waitForPageLoad (timeout) {
    return this.browser.waitUntil(
      () => this.headerTitle.isExisting(),
      timeout,
      `Timed out after ${timeout}ms, Dashboard page is not yet loaded`
    );
  }
}

export default FenicsOperator;
