const Launcher = require('webdriverio').Launcher;

const wdio = new Launcher('./config/wdio.config.js');

wdio.run().then((code) => {
  process.exit(code);
}, (error) => {
  console.error('Launcher failed to start the test', error.stacktrace);
  process.exit(1);
});
