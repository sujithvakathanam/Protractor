/* eslint-disable complexity */
import Big from 'big.js';
import {roundToTick} from './asmCalculator';

export const calculateVWAP = (bestBid, bestBidSize, bestOffer, bestOfferSize, region) => {
  const bigBestBid = new Big(bestBid);
  const bigBestOffer = new Big(bestOffer);

  const bidNotionalAmount = bigBestBid * bestBidSize;
  const offerNotionalAmount = bigBestOffer * bestOfferSize;
  const totalSize = bestBidSize + bestOfferSize;
  const price = ((bidNotionalAmount + offerNotionalAmount) / totalSize).valueOf();

  return roundToTick(price, region.VWAP_MIN_PRICE_TICKS, region.VWAP_ROUND_TO_DECIMAL_POINT);
};
