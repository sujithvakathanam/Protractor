import {TRADING_SESSION_PHASE, TRADING_SESSION_STATUS,
  TRADING_SESSION_TYPE, TR_SESS_ID_TO_PHASE} from '../../constant/TradingSession';
import {GRID_TYPE_TO_SESSION_TAG} from '../../constant/Grid';
import {coercer} from './Util';
import get from 'lodash/get';
import {DateTime} from 'luxon';

const DATE_TIME_FORMAT = 'yyyyLLdd-HH:mm:ss.SSS';

export class TradingSession {
  static isOpen ({TradSesStatus, TradingSessionID2}) {
    return Number.parseInt(TradingSessionID2, 10) >= TRADING_SESSION_PHASE.PN_PRICING && !TradingSession.isClosed({
      TradSesStatus,
      TradingSessionID2
    });
  }

  static isClosed (tradingSession) {
    const hasClosedStatus = TradingSession.isPhaseClosed(tradingSession);

    if (TradingSession.isCLOB(tradingSession)) {
      return TradingSession.isPublicPhase(tradingSession) && hasClosedStatus;
    }

    return TradingSession.isGroupPhase(tradingSession) && hasClosedStatus;
  }

  static isPhaseClosed ({TradSesStatus}) {
    return Number.parseInt(TradSesStatus, 10) === TRADING_SESSION_STATUS.CLOSED;
  }

  static isPhaseOpened ({TradSesStatus}) {
    return Number.parseInt(TradSesStatus, 10) === TRADING_SESSION_STATUS.OPENED;
  }

  static isPrivateNegotiation ({TradingSessionDesc}) {
    return TradingSessionDesc === TRADING_SESSION_TYPE.PRIVATE_NEGOTIATION;
  }

  static isMatchingSession ({TradingSessionDesc}) {
    return TradingSessionDesc === TRADING_SESSION_TYPE.MATCHING_SESSION;
  }

  static isCLOB ({TradingSessionDesc}) {
    return TradingSessionDesc === TRADING_SESSION_TYPE.CLOB;
  }

  static isPricingPhase ({TradingSessionID2}) {
    return Number.parseInt(TradingSessionID2, 10) === TRADING_SESSION_PHASE.PN_PRICING;
  }

  static isPrivatePhase ({TradingSessionID2}) {
    return Number.parseInt(TradingSessionID2, 10) === TRADING_SESSION_PHASE.PRIVATE;
  }

  static isGroupPhase ({TradingSessionID2}) {
    return Number.parseInt(TradingSessionID2, 10) === TRADING_SESSION_PHASE.GROUP;
  }

  static isPublicPhase ({TradingSessionID2}) {
    return Number.parseInt(TradingSessionID2, 10) === TRADING_SESSION_PHASE.PUBLIC;
  }

  static getPanelTag ({
    MarketSegmentID,
    TradSesOpenTime,
    TradSesEndTime,
    TradingSessionID2,
    TradingSessionDesc
  }) {
    const starts = TradSesOpenTime ? DateTime.fromFormat(TradSesOpenTime, DATE_TIME_FORMAT, {zone : 'utc'})
      .toMillis() : TradSesOpenTime;
    const ends = TradSesOpenTime ? DateTime.fromFormat(TradSesEndTime, DATE_TIME_FORMAT, {zone : 'utc'})
      .toMillis() : TradSesEndTime;

    return {
      color : 'rgb(0, 225, 88)',
      name  : MarketSegmentID,
      phase : TradingSession.getPhaseName({TradingSessionID2}),
      TradingSessionDesc,
      starts,
      ends
    };
  }

  static getPhaseName ({TradingSessionID2}) {
    if (Reflect.has(TR_SESS_ID_TO_PHASE, TradingSessionID2)) {
      return TR_SESS_ID_TO_PHASE[TradingSessionID2];
    }

    return 'Unknown phase';
  }

  static formatActionPanelTradingSession (items, type) {
    const offsetInMinutes = DateTime.local().offset;

    return items.map(item => {
      const starts = DateTime.fromFormat(item.TradSesOpenTime, 'yyyyLLdd-HH:mm:ss.SSS')
        .plus({minutes : offsetInMinutes})
        .toMillis();
      const ends = DateTime.fromFormat(item.TradSesEndTime, 'yyyyLLdd-HH:mm:ss.SSS')
        .plus({minutes : offsetInMinutes})
        .toMillis();

      const Price = get(item, 'Bid.Price', get(item, 'Offer.Price'));
      const OrderQty = get(item, 'Bid.OrderQty', get(item, 'Offer.OrderQty'));

      return {
        ...item,
        Price,
        OrderQty,
        session : {
          starts,
          ends,
          hasAsm  : item.hasAsm,
          session : GRID_TYPE_TO_SESSION_TAG[type](item),
          phase   : TradingSession.getPhaseName(item)
        },
        public : true
      };
    });
  }

  static getDirection ({Side}) {
    const asNumber = Number.parseInt(Side, 10);

    if (asNumber === 1) {
      return 'Buy';
    } else if (asNumber === 2) {
      return 'Sell';
    }

    return 'Unknown';
  }

  static getDescription (item) {
    return item.Symbol || item.SecurityID || '';
  }

  static getBlacklistedOrderIDs (tradingSessions) {
    const blacklistedSet = [];
    for (const sessionId in tradingSessions) {
      if (Object.prototype.hasOwnProperty.call(tradingSessions, sessionId)) {
        tradingSessions[sessionId]
          .filter(subSession => subSession.OrderIDBlacklist.length > 0)
          .map(subSession => blacklistedSet.push(...subSession.OrderIDBlacklist));
      }
    }

    return new Set(blacklistedSet);
  }

  static getUnconfirmedOrderIDs (tradingSessions) {
    const unconfirmedOrderSet = new Set();

    tradingSessions.forEach(sessions => unconfirmedOrderSet.add(coercer(sessions).reduce((acc, {UnconfirmedOrderIDs}) => [
      ...acc,
      ...UnconfirmedOrderIDs
    ], [])));

    return unconfirmedOrderSet;
  }

  static getSecurityIDs (tradingSessions) {
    const securityIds = [];
    tradingSessions
      .forEach(session => session.TradingSessionSubIDs
        .forEach(subSessionId => securityIds.push(subSessionId)));

    return new Set(securityIds);
  }

  static getMarketSegmentIDs (tradingSessions) {
    const marketSegmentIds = tradingSessions.map(session => session.MarketSegmentID);

    return new Set(marketSegmentIds);
  }

  static getMarketSegmentIDsInRunningSession (tradingSessions) {
    return new Set(coercer(tradingSessions).map(subSessions => {
      const segments = subSessions
        .filter(session => TradingSession.isOpen(session))
        .map(session => session.MarketSegmentID);

      return segments[0];
    }));
  }

  static getPrivateNegotiationSecurityIDs (tradingSessions) {
    const sessionSubIds = tradingSessions.map(pn => pn.TradingSessionSubID);

    return new Set(sessionSubIds);
  }

  static getClobSecurityIDs (tradingSessions) {
    const sessionSubIds = tradingSessions.map(clob => clob.TradingSessionSubID);

    return new Set(sessionSubIds);
  }

  static getTradingSessionByType (tradingSessions, type) {
    const sessionsResult = [];
    for (const sessionId in tradingSessions) {
      if (Object.prototype.hasOwnProperty.call(tradingSessions, sessionId)) {
        const protocolSessions = tradingSessions[sessionId]
          .filter(subSession => subSession.TradingSessionDesc === type);
        sessionsResult.push(...protocolSessions);
      }
    }

    return sessionsResult;
  }

  static getMatchingSessions (tradingSessions) {
    return TradingSession.getTradingSessionByType(tradingSessions, TRADING_SESSION_TYPE.MATCHING_SESSION); //
  }

  static getOLXMatchingSessions (tradingSessions) {
    return TradingSession.getTradingSessionByType(tradingSessions, TRADING_SESSION_TYPE.OLX);
  }

  static getPrivateNegotiationSessions (tradingSessions) {
    return TradingSession.getTradingSessionByType(tradingSessions, TRADING_SESSION_TYPE.PRIVATE_NEGOTIATION);
  }

  static getClobSessions (tradingSessions) {
    return TradingSession.getTradingSessionByType(tradingSessions, TRADING_SESSION_TYPE.CLOB);
  }
}

export default TradingSession;
