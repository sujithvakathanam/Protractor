import Fix from '@fenics/fenics-encoding';
import {generateClientOrderId} from './Util';

const {
  Message,
  OrdType,
  QuoteRespType : FixQuoteRespType,
  SecurityIDSource,
  Side : FixSide
} = Fix;

const defaultInternalPriceOverride = 100;

export class FixMessage {
  static buildNewOrderSingle ({RawOrderQty, Price, SecurityID, Side, TradingSessionID, NoTradingSessions}) {
    const payload = {
      SecurityID,
      OrderQty         : RawOrderQty,
      MsgType          : Message.NewOrderSingle,
      Side             : Side.toLowerCase().trim() === 'buy' ? FixSide.Buy : FixSide.Sell,
      ClOrdID          : generateClientOrderId(),
      SecurityIDSource : SecurityIDSource.ISIN,
      OrdType          : OrdType.Limit
    };

    if (Price) {
      payload.Price = Price;
    }

    if (TradingSessionID) {
      payload.TradingSessionID = TradingSessionID;
      payload.NoTradingSessions = NoTradingSessions;
    }

    return payload;
  }

  static buildAsmOrder (order, price, quantity, asmSide) {
    const aSide = {Side : asmSide};
    const {OrderQty, SecurityID, TradingSessionID} = order;
    const Side = typeof aSide.Side === 'string' ? aSide.Side : order.Side;

    const payload = {
      OrderQty,
      SecurityID,
      TrdSessLstGrp : [{
        TradingSessionID
      }],
      Side,
      Price            : price,
      SecurityIDSource : SecurityIDSource.ISIN,
      OrdType          : OrdType.Limit,
      RoutingInst      : 'H',
      MsgType          : Message.NewOrderSingle,
      ClOrdID          : generateClientOrderId()
    };

    if (typeof quantity === 'number') {
      payload.OrderQty = quantity;
    }

    return payload;
  }

  static buildOrderCancelReplace (order) {
    const {OrderID, Side, OrderQty, Price, SecurityID, RoutingInst} = order;

    const payload = {
      OrderID,
      OrderQty,
      Price,
      Side,
      SecurityID,
      RoutingInst,
      OrdType          : OrdType.Limit,
      MsgType          : Message.OrderCancelReplaceRequest,
      ClOrdID          : generateClientOrderId(),
      SecurityIDSource : SecurityIDSource.ISIN
    };

    if (order.TradingSessionID) {
      payload.TrdSessLstGrp = [{
        TradingSessionID : order.TradingSessionID
      }];

      payload.StrategyParameters = [];

      order.StrategyParameters.forEach(item => {
        if (item.StrategyParameterName === 'affirmed' && item.StrategyParameterValue === 'false') {
          item.StrategyParameterValue = 'true';
        }
        payload.StrategyParameters.push({
          StrategyParameterName  : item.StrategyParameterName,
          StrategyParameterValue : item.StrategyParameterValue
        });
      });
    }

    return payload;
  }

  static buildCancelOrder ({OrderID, Side, TradingSessionID, SecurityID}, hasTradingSession) {
    const payload = {
      OrderID,
      SecurityID,
      Side,
      OrigClOrdID      : OrderID,
      MsgType          : Message.OrderCancelRequest,
      ClOrdID          : generateClientOrderId(),
      SecurityIDSource : SecurityIDSource.ISIN
    };

    if (hasTradingSession) {
      payload.TrdSessLstGrp = [{
        TradingSessionID,
        TradingSessionSubID : SecurityID
      }];
    }

    return payload;
  }

  static buildNewClobOrder ({SecurityID}) {
    const payload = {
      MsgType          : Message.IOI,
      IOIID            : generateClientOrderId(),
      IOITransType     : 'N',
      SecurityID,
      SecurityIDSource : SecurityIDSource.ISIN
    };

    return payload;
  }

  static buildQuoteResponse ({OrderQty, QuoteID, QuoteRespType, Price}) {
    const payload = {
      MsgType : Message.QuoteResponse,
      QuoteRespType,
      OrderQty,
      QuoteID
    };

    if (Price) {
      payload.Price = Price;
    }

    return payload;
  }

  static buildQuoteResponseCancel ({OrderQty, QuoteID}) {
    return FixMessage.buildQuoteResponse({
      OrderQty,
      QuoteID,
      QuoteRespType : FixQuoteRespType.Pass
    });
  }

  static buildQuoteResponseAccept ({OrderQty, QuoteID, Price}) {
    return FixMessage.buildQuoteResponse({
      OrderQty,
      Price,
      QuoteID,
      QuoteRespType : FixQuoteRespType.HitLift
    });
  }

  static buildQuoteResponseAcceptOwnPrice ({OrderQty, QuoteID, Price}) {
    return FixMessage.buildQuoteResponse({
      OrderQty,
      Price,
      QuoteID,
      QuoteRespType : FixQuoteRespType.Counter
    });
  }

  static buildRequestForPosition () {
    return {
      MsgType    : Message.RequestForPositions,
      PosReqID   : generateClientOrderId(),
      PosReqType : 1
    };
  }

  static buildTradingSessionsRequest () {
    return {
      MsgType                 : Message.TradingSessionListRequest,
      TradSesReqID            : 'ts-id1',
      SubscriptionRequestType : 0
    };
  }

  static buildQuoteRequest () {
    return {
      MsgType    : Message.QuoteRequest,
      PosReqID   : generateClientOrderId(),
      PosReqType : 0
    };
  }

  static buildWeightedPriceRequest ({SecurityID}, {payload}, internalPriceOverride = defaultInternalPriceOverride) {
    const weightings = payload.weightings;

    return [{
      securityId : SecurityID,
      weightings,
      internalPriceOverride
    }];
  }

  // eslint-disable-next-line max-params
  static buildSessionTemplate (sector, rating, type, expectedOptions, expectedPhaseDefinitions) {
    const region = '';
    const payload = {
      type,
      rating,
      sector,
      phaseDefinitions         : expectedPhaseDefinitions,
      relevanceBandDefinitions : {
        relevanceBands : []
      },
      options              : expectedOptions,
      isDefaultForProtocol : false,
      region
    };

    return payload;
  }

  static buildSessionRequest (sector, delayInMs, rating, type) {
    const payload = {
      sector,
      rating,
      type,
      sessionId          : null,
      scheduleDefinition : {
        type       : 'ONETIME',
        definition : delayInMs
      }
    };

    return payload;
  }
}

export default FixMessage;
