import {ftransport, ftransportMiddlewares} from '@fenics/fenics-transport';
import Fix from '@fenics/fenics-encoding';
import flow from 'lodash/flow';
import {FixMessage} from './fixMessage';
import {OktaAuthentication} from '@fenics/fenics-test-core';

import {encodeURISpaces} from './Util';
import {FIX_COMMON_TAGS} from '../../constant/App';

// eslint-disable-next-line complexity
const removeEmpty = obj => Object.entries(obj).reduce((acc, [key, val]) => {
  if (val && typeof val === 'object' && !Array.isArray(val)) {
    acc[key] = removeEmpty(val);
  } else if (Array.isArray(val)) {
    acc[key] = val.map(item => removeEmpty(item));
  } else if (val !== '' && val !== undefined && val !== null) {
    acc[key] = val;
  }

  return acc;
}, {});

const removeFixCommonTags = decoded => {
  const asArray = Array.isArray(decoded) ? decoded : [decoded];

  /**
   * Can't use the object destructure + rest operator
   * to remove properties as it will throw a runtime
   * error. This needs to be investigates as there are
   * a set of ES7 features that do not seem to work in
   * web workers (spread operator, class properties)
   */
  return asArray.map(item => {
    const newItem = Object.assign({}, item);

    const OMIT_PROPS_WHITELIST = [
      'BeginString',
      'BodyLength',
      'MsgSeqNum',
      'SenderCompID',
      'SendingTime',
      'SenderSubID',
      'TargetCompID',
      'TargetSubID',
      'CheckSum'
    ];

    OMIT_PROPS_WHITELIST.forEach(propName => {
      delete newItem[propName];
    });

    return newItem;
  });
};

export class ApiClient {
  async init () {
    const configuration = this.context.getConfiguration();
    const apiUserConfig = this.context.getUserConfiguration(this.apiUser);

    const bearerTokenValue = await this.oktaSignIn(apiUserConfig.username, apiUserConfig.password);

    const fixMiddleware = ftransportMiddlewares.payloadFormatterMiddleware({
      encode : flow(removeEmpty, Fix.encode),
      decode : payload => {
        const decoded = Fix.decode(payload, {
          validateBodyLength : false,
          validateChecksum   : false
        });
        const messages = removeFixCommonTags(decoded);

        return messages;
      }
    });

    Fix.setCommonTags({
      Account      : apiUserConfig.oktaId,
      SenderCompID : FIX_COMMON_TAGS.senderCompId,
      SenderSubID  : apiUserConfig.oktaId,
      TargetCompID : FIX_COMMON_TAGS.targetCompId,
      TargetSubID  : FIX_COMMON_TAGS.targetSubId
    });

    Fix.setDictionary({
      5019  : 'TradingSessionID2',
      9303  : 'RoutingInst',
      10042 : 'PricingDuration',
      10043 : 'PrivateDuration',
      10044 : 'GroupDuration'
    });

    this.api = ftransport()
      .content('application/octet-stream')
      .accept('application/octet-stream')
      .middlewares([fixMiddleware])
      .url(configuration.apiUrl)
      .headers({
        'x-auth-userid'   : this.apiUser.oktaId,
        'x-auth-username' : this.apiUser.username,
        'x-auth-lei'      : this.apiUser.lei,
        'x-auth-espeedid' : this.apiUser.espeed,
        'x-auth-region'   : this.apiUser.region,
        'x-auth-location' : 'USA'
      })
      .auth(bearerTokenValue);

    this.adminApi = ftransport()
      .url(configuration.apiUrl)
      .content('application/jsonfix')
      .accept('application/jsonfix')
      .headers({
        'x-auth-userid'   : this.apiUser.oktaId,
        'x-auth-username' : this.apiUser.username,
        'x-auth-lei'      : this.apiUser.lei,
        'x-auth-espeedid' : this.apiUser.espeed,
        'x-auth-region'   : this.apiUser.region,
        'x-auth-location' : 'USA'
      })
      .auth(bearerTokenValue);

    this.isInitialized = true;
  }

  constructor (context, apiUser) {
    this.context = context;
    this.apiUser = apiUser;
    this.isInitialized = false;
  }

  async tradingSessions () {
    if (!this.isInitialized) {
      await this.init();
    }

    const request = FixMessage.buildTradingSessionsRequest();
    const positions = await this.api.url('/trader/trading-sessions')
      .body(request)
      .post()
      .json();

    return positions;
  }

  async requestForPosition () {
    if (!this.isInitialized) {
      await this.init();
    }

    const request = FixMessage.buildRequestForPosition();
    const positions = this.api.url('/trader/request-for-positions')
      .body(request)
      .post()
      .json();

    return positions;
  }

  async replaceOrder (order) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.api.url('/trader/orders/replace')
      .body(order)
      .post()
      .json();
  }

  async createOrders (orders) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.api.url('/trader/orders/new')
      .body(orders)
      .post()
      .json();
  }

  createClob (orders) {
    return this.api.url('/trader/start-clob')
      .body(orders)
      .post()
      .json();
  }

  async cancelOrder (order) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.api.url('/trader/orders/cancel')
      .body(order)
      .post()
      .json();
  }

  async scheduleSession (session) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.adminApi.url('/operator/session/new')
      .body(JSON.stringify(session))
      .post()
      .json();
  }

  async removeOrdersFromPortfolioByOperator (userOrderTobeRemoved) {
    if (!this.isInitialized) {
      await this.init();
    }
    const oktaIdOfUserOrderToBeRemoved = this.context.getUserConfiguration(userOrderTobeRemoved.apiUser).oktaId;
    this.context.getLogger().info('About to remove orders for ', userOrderTobeRemoved.apiUser);
    const request = {
      userId : oktaIdOfUserOrderToBeRemoved
    };

    return this.adminApi.url('/operator/user/remove-orders')
      .body(JSON.stringify(request))
      .post()
      .json();
  }

  async getSessionTemplate (uri) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.adminApi.url(`/operator/session-templates/${uri}`)
      .body()
      .get()
      .json();
  }

  async setSessionTemplate (request) {
    if (!this.isInitialized) {
      await this.init();
    }

    const uri = `SESSION_${request.rating}_${request.sector}`;
    request.region = this.apiUser.region;

    return this.adminApi.url(`/operator/session-templates/${uri}`)
      .body(JSON.stringify(request))
      .put()
      .json();
  }

  async getQuotes (quoteRequest) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.api.url('/trader/quotes')
      .body(quoteRequest)
      .post()
      .json();
  }

  async getWeightedPrice (weightedPriceRequest) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.adminApi.url('/operator/prices/weighted-price')
      .body(JSON.stringify(weightedPriceRequest))
      .post()
      .json();
  }

  async getWeightings (rating, {MarketSegmentID}) {
    if (!this.isInitialized) {
      await this.init();
    }

    return this.adminApi.url(`/operator/price-weightings/${rating}/${encodeURISpaces(MarketSegmentID)}`)
      .body()
      .get()
      .json();
  }

  async getTrades () {
    if (!this.isInitialized) {
      await this.init();
    }

    const request = FixMessage.buildRequestForPosition();
    const positions = this.api.url('/trader/trades')
      .body(request)
      .post()
      .json();

    return positions;
  }

  // eslint-disable-next-line class-methods-use-this
  async oktaSignIn (username, password) {
    const oktaAuth = new OktaAuthentication();
    const tokenValue = await oktaAuth.authenticate(username, password);

    return `Bearer ${tokenValue.token.value}`;
  }
}

