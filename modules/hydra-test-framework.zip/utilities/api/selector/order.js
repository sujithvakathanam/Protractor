import Fix from '@fenics/fenics-encoding';
import find from 'lodash/find';
import get from 'lodash/get';
import map from 'lodash/map';
import keyBy from 'lodash/keyBy';
import groupBy from 'lodash/groupBy';
import filter from 'lodash/filter';
import difference from 'lodash/difference';
import reduce from 'lodash/reduce';
import {TradingSession} from '../TradingSession';
import {OrderService} from '../orderService';

const {
  Side : FixSide
} = Fix;

export const matchingSessionCompareFn = (allTradingSessions, item) => find(allTradingSessions, ({MarketSegmentID}) => {
  const hasSecurityID = MarketSegmentID === item.MarketSegmentID;

  return hasSecurityID;
});

export const pnSessionCompareFn = (allTradingSessions, item) => find(allTradingSessions, ({TradingSessionSubID}) => {
  const hasSecurityID = TradingSessionSubID === item.SecurityID;

  return hasSecurityID;
});

const RoutingInst = {
  Book   : 'B',
  Hidden : 'H'
};

export const formatActionPanelItems = ({
  advertisements,
  tradingSessions,
  marketData,
  orders
}) => {
  // eslint-disable-next-line complexity, max-statements
  const collection = reduce(tradingSessions, (acc, session) => {
    const {TradingSessionID, TradingSessionSubIDs, OrderIDBlacklist} = session;
    const advertisement = get(advertisements, TradingSessionID, {});

    const ordersForSession = filter(orders, ({SecurityID}) => TradingSessionSubIDs.includes(SecurityID));
    const orderIdsInSession = map(ordersForSession, ({OrderID}) => OrderID);
    const byVenue = groupBy(ordersForSession, 'RoutingInst');
    const litOrdersBySide = keyBy(byVenue[RoutingInst.Book], 'Side');
    const darkOrdersBySide = keyBy(byVenue[RoutingInst.Hidden], 'Side');

    if (difference(orderIdsInSession, OrderIDBlacklist).length > 0) {
      let Bid = {};
      let Offer = {};
      let AsmBid = {};
      let AsmOffer = {};

      if (litOrdersBySide[FixSide.Buy]) {
        Bid = litOrdersBySide[FixSide.Buy];
      }

      if (litOrdersBySide[FixSide.Sell]) {
        Offer = litOrdersBySide[FixSide.Sell];
      }

      if (darkOrdersBySide[FixSide.Buy]) {
        AsmBid = darkOrdersBySide[FixSide.Buy];
      }

      if (darkOrdersBySide[FixSide.Sell]) {
        AsmOffer = darkOrdersBySide[FixSide.Sell];
      }

      let countdown = {};
      let quotes = {};

      if (session.TradSesOpenTime && session.TradSesEndTime) {
        countdown = TradingSession.getPanelTag(session);
      }

      if (marketData && marketData[TradingSessionID]) {
        quotes = marketData[TradingSessionID];
      }

      const Description = TradingSession.getDescription(Object.keys(Bid).length ? Bid : Offer);
      const Direction = TradingSession.getDirection(Object.keys(Bid).length ? Bid : Offer);

      acc.push({
        ...session,
        AsmBid,
        AsmOffer,
        Bid,
        Description,
        Direction,
        Offer,
        advertisement,
        countdown,
        quotes
      });
    }

    return acc;
  }, []);

  return collection;
};

export const formatPanelItems = collection => collection.map(item => {
  const Description = TradingSession.getDescription(item);
  const Direction = TradingSession.getDirection(item);

  return {
    ...item,
    Description,
    Direction
  };
});

export const formatPosition = ({SettlPrice, PositionQty, Text : OrderID, ...rest}) => {
  const [{LongQty, ShortQty}] = PositionQty;
  const OrderQty = ShortQty || LongQty;
  const Side = OrderService.getPositionSide({PositionQty});

  return {
    ...rest,
    Side,
    OrderQty,
    OrderID,
    Price             : SettlPrice,
    TradingSessionID2 : 0
  };
};
