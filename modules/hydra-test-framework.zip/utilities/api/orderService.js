import {coercer} from './Util';
import Fix from '@fenics/fenics-encoding';
import {TRADING_SESSION_PHASE} from '../../constant/TradingSession';

const {
  Side : FixSide
} = Fix;

export class OrderService {
  static getPositionSide ({PositionQty}) {
    const [{LongQty, ShortQty}] = PositionQty;
    const Side = LongQty && !ShortQty ? FixSide.Buy : FixSide.Sell;

    return Side;
  }

  static getOrdersByMarketSegmentID (orders, marketSegmentIds) {
    return coercer(orders).filter(({MarketSegmentID}) => marketSegmentIds.has(MarketSegmentID));
  }

  static getPortfolioPanelOrders ({
    allOrders,
    blacklistedOrderIDs,
    clobSecurityIDs,
    marketSegmentIdsInSession,
    privateNegotiationSecurityIDs
  }) {
    return coercer(allOrders)
      .filter(({MarketSegmentID, OrderID, SecurityID}) => {
        const isNotPartOfRunningSession = !marketSegmentIdsInSession.has(MarketSegmentID);
        const isBlacklisted = blacklistedOrderIDs.has(OrderID);
        const isPartOfPN = privateNegotiationSecurityIDs.has(SecurityID);
        const isPartOfCLOB = clobSecurityIDs.has(SecurityID);

        if (isBlacklisted) {
          return true;
        }

        return !isPartOfCLOB && !isPartOfPN && isNotPartOfRunningSession;
      })
      .map(item => ({
        ...item,

        // @TODO use some backend data for this flag
        canStartCLOB : true
      }));
  }

  static getSessionPanelOrders ({
    ordersForMarketSegmentIds,
    matchingSessionSecurityIds,
    blacklistedOrderIDs,
    marketSegmentIdsInSession
  }) {
    return coercer(ordersForMarketSegmentIds)
      .filter(({SecurityID, OrderID, MarketSegmentID, TradingSessionID2}) => {
        const isCountDownPhase = TradingSessionID2 === TRADING_SESSION_PHASE.MS_COUNTDOWN;
        const hasNoCounterInterest = !matchingSessionSecurityIds.has(SecurityID);
        const hasMarketSegmentIDinRunningSession = marketSegmentIdsInSession.has(MarketSegmentID);
        const isNotBlacklisted = !blacklistedOrderIDs.has(OrderID);

        return hasNoCounterInterest && isNotBlacklisted && hasMarketSegmentIDinRunningSession && isCountDownPhase;
      });
  }

  static getActionPanelMatchingSessionOrders ({
    ordersForMarketSegmentIds,
    matchingSessionSecurityIds,
    marketSegmentIdsInSession,
    blacklistedOrderIDs
  }) {
    return coercer(ordersForMarketSegmentIds)
      .filter(({MarketSegmentID, SecurityID, OrderID, TradingSessionID2}) => {
        const isCountDownPhase = TradingSessionID2 === TRADING_SESSION_PHASE.MS_AFFIRMATION;
        const isPartOfRunningSession = marketSegmentIdsInSession.has(MarketSegmentID);
        const hasCounterInterest = matchingSessionSecurityIds.has(SecurityID);
        const isNotBlacklisted = !blacklistedOrderIDs.has(OrderID);

        return isPartOfRunningSession && hasCounterInterest && isNotBlacklisted && isCountDownPhase;
      });
  }

  static getActionPanelPNOrders ({
    allOrders,
    privateNegotiationSecurityIDs,
    blacklistedOrderIDs
  }) {
    return coercer(allOrders)
      .filter(({OrderID, SecurityID}) => {
        const hasPN = privateNegotiationSecurityIDs.has(SecurityID);
        const isNotBlacklisted = !blacklistedOrderIDs.has(OrderID);

        return hasPN && isNotBlacklisted;
      });
  }

  static getActionPanelCLOBOrders ({
    allClobOrders,
    clobSecurityIDs,
    blacklistedOrderIDs
  }) {
    return coercer(allClobOrders)
      .filter(({OrderID, SecurityID}) => {
        const hasCLOB = clobSecurityIDs.has(SecurityID);
        const isNotBlacklisted = !blacklistedOrderIDs.has(OrderID);

        return hasCLOB && isNotBlacklisted;
      });
  }

  static getOrderQty (order) {
    const [{LongQty, ShortQty}] = order.PositionQty.filter(({PosType}) => PosType === 'TOT');

    return LongQty || ShortQty;
  }

  static orderWasSuccessful ({MsgType, OrdRejReason}) {
    if (OrdRejReason) {
      throw new Error(`OrdRejReason: ${OrdRejReason}`);
    }

    return MsgType === '8';
  }
}

export default OrderService;
