import {join} from 'path';
import {frameworkConfig} from '../../config/framework.config';

class TempBoot {
  constructor () {
    this.cdScript = frameworkConfig.clearDownScript;
  }

  get clearDownScript () {
    return require.resolve(join('./../../', this.cdScript));
  }
}

export default new TempBoot();
