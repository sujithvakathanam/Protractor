/* eslint-disable no-await-in-loop */
import {MODULE_TITLES} from '../constant/App';
import Alerts from '../pages/Alerts';
import {HydraLauncher} from '../pages/launchers/hydraLauncher';
import FenicsCredit from '../pages/FenicsCredit';
import LoginPage from '../pages/LoginPage';
import Page from '../pages/Page';
import FenicsOperator from '../pages/FenicsOperator';

const increments = {
  MIN_INCREMENT : 499999,
  MAX_INCREMENT : 1000000
};

class TestCommons extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Page object vars.
    this.loginPage = new LoginPage(context);
    this.hydraLauncher = new HydraLauncher(context);
    this.hydraPageModel = new FenicsCredit(context);
    this.hydraOperatorPageModel = new FenicsOperator(context);
    this.alerts = new Alerts(context);
  }

  async loginAsTrader (firstRun, username) {
    const user = this.context.getUserConfiguration(username);
    if (firstRun) {
      const loginPageTitle = MODULE_TITLES.loginPageTitle;
      const hydraClientTitle = MODULE_TITLES.hydraClientTitle;
      const launchbarTitle = MODULE_TITLES.launchbarTitle;
      const pageTitle = MODULE_TITLES.hydraPageTitle;

      await this.browser.waitUntil(
        () => super.hasTabOpen(loginPageTitle)
        , this.configuration.longTimeout
        , `Timed out after ${this.configuration.longTimeout} seconds, ${loginPageTitle} did not open properly.`
      );

      await this.loginPage.enterUsername(user.username);
      await this.browser.pause(this.configuration.shortTimeout);
      await this.loginPage.clickNext();
      await this.loginPage.waitForPasswordPageLoad(this.configuration.shortTimeout);
      await this.loginPage.enterPassword(user.password);
      await this.loginPage.clickSignIn();

      await this.browser.waitUntil(
        () => super.hasTabOpen(MODULE_TITLES.launchbarTitle)
        , this.configuration.longTimeout
        , `Timed out after ${this.configuration.longTimeout} seconds, ${MODULE_TITLES.launchbarTitle} did not open properly.`
      );

      await this.hydraLauncher.launchFromLaunchbar(true, hydraClientTitle, launchbarTitle, pageTitle);
      //TODO - Will enable the below code once it is fixed in the TRADER APP
      //await this.hydraPageModel.clickMaximiseWindow();
    }

    return false;
  }

  async loginAsOperator (firstRun, username) {
    const user = this.context.getUserConfiguration(username);
    if (firstRun) {
      const loginPageTitle = MODULE_TITLES.loginPageTitle;
      const hydraClientTitle = MODULE_TITLES.hydraOperatorTitle;
      const launchbarTitle = MODULE_TITLES.launchbarTitle;
      const pageTitle = MODULE_TITLES.hydraOperatorPageTitle;

      await this.browser.waitUntil(
        () => super.hasTabOpen(loginPageTitle)
        , this.configuration.longTimeout
        , `Timed out after ${this.configuration.longTimeout} seconds, ${loginPageTitle} did not open properly.`
      );

      await this.loginPage.enterUsername(user.username);
      await this.loginPage.clickNext();
      await this.loginPage.waitForPasswordPageLoad(this.configuration.shortTimeout);
      await this.loginPage.enterPassword(user.password);
      await this.loginPage.clickSignIn();

      await this.browser.waitUntil(
        () => super.hasTabOpen(MODULE_TITLES.launchbarTitle)
        , this.configuration.longTimeout
        , `Timed out after ${this.configuration.longTimeout} seconds, ${MODULE_TITLES.launchbarTitle} did not open properly.`
      );

      await this.hydraLauncher.launchFromLaunchbar(true, hydraClientTitle, launchbarTitle, pageTitle);
      await this.hydraOperatorPageModel.clickMaximiseWindow();

      return true;
    }

    return false;
  }

  async deletePortfolio (strategy, retryCount = 1) {
    let localCount = retryCount;
    const allPortfolioOrders = await strategy.getPortfolio().getAllOrders();

    for (const order of allPortfolioOrders) {
      await strategy.getPortfolio()
        .getOrderByDescription(order.Description)
        .delete();
    }
    try {
      this.browser.waitUntil(
        () => strategy.getPortfolio().isEmpty()
        , this.configuration.shortTimeout
        , `Timed out after ${this.configuration.shortTimeout} seconds, portfolio panel is not empty from test clean up.`
      );
    } catch (err) {
      if (localCount < this.configuration.cleanUpRetry) {
        this.logger.warn(err);
        localCount = retryCount + 1;
        await this.deletePortfolio(strategy, localCount);
      }
    }
  }

  async handlePopUp () {
    for (let retryCount = 0; retryCount < this.configuration.cleanUpRetry; retryCount += 1) {
      try {
        const alertMessage = await this.alerts.getPopUpAlertMessage();
        await this.alerts.clickPopUpAlertButton('OK, I GET IT');
        this.logger.warn(`Pop-up "${alertMessage.AlertType}" alert dismissed with message: "${alertMessage.AlertText}".`);
      } catch (err) {
        this.logger.warn(err);
      }
    }
  }

  async cleanUpTest (allApiStrategies) {
    await this.handlePopUp();
    for (const strategy of allApiStrategies) {
      await this.browser.pause(this.configuration.shortTimeout);
      let allActionOrders = await strategy.getActionPanel().getAllOrders();
      for (const order of allActionOrders) {
        try {
          await strategy.getActionPanel()
            .getOrderByDescription(order.Description)
            .delete();
        } catch (err) {
          this.logger.warn(err);
        }
        try {
          await this.browser.waitUntil(
            () => strategy.getActionPanel().isEmpty()
            , this.configuration.longTimeout
            , `Timed out after ${this.configuration.longTimeout} seconds, action panel is not empty from test clean up.`
          );
        } catch (err) {
          this.logger.warn(err);
        }
        allActionOrders = await strategy.getActionPanel().getAllOrders();
      }

      await this.deletePortfolio(strategy);
    }
  }

  formatSizeToMillion (size) {
    const isBelowMinIncrement = Math.abs(size) > increments.MIN_INCREMENT;
    const mathBelowMinIncrement = () => Math.sign(size) * (Math.abs(size) / increments.MAX_INCREMENT).toFixed(1);
    const mathAboveMinIncrement = () => Math.sign(size) * Math.abs(size);

    return isBelowMinIncrement ? `${mathBelowMinIncrement()}M` : `${mathAboveMinIncrement()}M`;
  }
}

export default TestCommons;
