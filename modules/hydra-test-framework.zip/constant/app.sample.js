const APP_DETAILS = {
  windowTitle      : 'MyFenicsApp',
  launchBarAppName : 'Fenics App'
};

const ELEMENTS = {
  aPage : {
    anElement : {
      selector    : () => '.foo.bar',
      description : () => 'some element'
    },
    anElementWithParam : {
      selector    : baz => `.foo.bar#${baz}`,
      description : baz => `some element with a parameterised selector ${baz}`
    }
  }
};

export {
  APP_DETAILS,
  ELEMENTS
};
