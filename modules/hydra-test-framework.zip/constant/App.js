const FIX_COMMON_TAGS = {
  senderCompId : 'Fenics',
  targetCompId : 'BGC',
  targetSubId  : ''
};

const suffix = process.env.TESTABLE_ITERATION_UID ? ` ${process.env.TESTABLE_ITERATION_UID}` : '';

const MODULE_TITLES = {
  hydraClientTitle       : 'CreditMatch DeltaX',
  hydraOperatorTitle     : 'CreditMatch DeltaX HQ',
  launchbarTitle         : 'Fenics Launchbar' + suffix,
  hydraPageTitle         : 'CreditMatch DeltaX' + suffix,
  hydraOperatorPageTitle : 'CreditMatch DeltaXHQ' + suffix,
  loginPageTitle         : 'Fenics Login' + suffix
};

export {
  FIX_COMMON_TAGS,
  MODULE_TITLES
};
