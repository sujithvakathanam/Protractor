import OrdStatus from '@fenics/fenics-encoding';

export const OPT_ATTRIBUTE = {
  IN_COMPETITION     : 't',
  NOT_IN_COMPETITION : 'f'
};

export const INVALID_ORDER_STATUS = [
  OrdStatus.Rejected
];

export const SIZE_MULTIPLIER = 1000;
