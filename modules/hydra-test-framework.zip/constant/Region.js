const REGION = {
  US : {
    COMMON_NAME : 'US',
    DX_NAME     : 'AMRS'
  },
  EU : {
    COMMON_NAME : 'EU',
    DX_NAME     : 'EMEA'
  },
  AU : {
    COMMON_NAME : 'AU',
    DX_NAME     : 'ANZ'
  },
  ASIA : {
    COMMON_NAME : 'ASIA',
    DX_NAME     : 'ASIA'
  }
};

const INVESTMENT_RATING = {
  IG : 'IG',
  HY : 'HY'
};

const TICK_CONFIGURATION = {
  [REGION.US.COMMON_NAME] : {
    [INVESTMENT_RATING.HY] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.03125,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 5,
      ASM_MIN_PRICE_TICKS                    : 0.03125,
      ASM_ROUND_TO_DECIMAL_POINT             : 5,
      VWAP_MIN_PRICE_TICKS                   : 0.03125,
      VWAP_ROUND_TO_DECIMAL_POINT            : 5
    },
    [INVESTMENT_RATING.IG] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.5,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 2,
      ASM_MIN_PRICE_TICKS                    : 0.5,
      ASM_ROUND_TO_DECIMAL_POINT             : 2,
      VWAP_MIN_PRICE_TICKS                   : 0.5,
      VWAP_ROUND_TO_DECIMAL_POINT            : 2
    }
  },
  [REGION.EU.COMMON_NAME] : {
    [INVESTMENT_RATING.HY] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.03125,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 5,
      ASM_MIN_PRICE_TICKS                    : 0.03125,
      ASM_ROUND_TO_DECIMAL_POINT             : 5,
      VWAP_MIN_PRICE_TICKS                   : 0.0625,
      VWAP_ROUND_TO_DECIMAL_POINT            : 4
    },
    [INVESTMENT_RATING.IG] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.5,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 2,
      ASM_MIN_PRICE_TICKS                    : 0.5,
      ASM_ROUND_TO_DECIMAL_POINT             : 2,
      VWAP_MIN_PRICE_TICKS                   : 0.5,
      VWAP_ROUND_TO_DECIMAL_POINT            : 2
    }
  },
  [REGION.ASIA.COMMON_NAME] : {
    [INVESTMENT_RATING.HY] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.0625,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 4,
      ASM_MIN_PRICE_TICKS                    : 0.0625,
      ASM_ROUND_TO_DECIMAL_POINT             : 4,
      VWAP_MIN_PRICE_TICKS                   : 0.03125,
      VWAP_ROUND_TO_DECIMAL_POINT            : 5
    },
    [INVESTMENT_RATING.IG] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.5,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 2,
      ASM_MIN_PRICE_TICKS                    : 0.5,
      ASM_ROUND_TO_DECIMAL_POINT             : 2,
      VWAP_MIN_PRICE_TICKS                   : 0.5,
      VWAP_ROUND_TO_DECIMAL_POINT            : 2
    }
  },
  [REGION.AU.COMMON_NAME] : {
    [INVESTMENT_RATING.HY] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.03125,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 5,
      ASM_MIN_PRICE_TICKS                    : 0.03125,
      ASM_ROUND_TO_DECIMAL_POINT             : 2,
      VWAP_MIN_PRICE_TICKS                   : 0.25,
      VWAP_ROUND_TO_DECIMAL_POINT            : 2
    },
    [INVESTMENT_RATING.IG] : {
      PRICE_INCREMENT_MIN_PRICE_TICKS        : 0.5,
      PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT : 2,
      ASM_MIN_PRICE_TICKS                    : 0.5,
      ASM_ROUND_TO_DECIMAL_POINT             : 2,
      VWAP_MIN_PRICE_TICKS                   : 0.25,
      VWAP_ROUND_TO_DECIMAL_POINT            : 2
    }
  }
};

export {
  TICK_CONFIGURATION,
  REGION,
  INVESTMENT_RATING
};
