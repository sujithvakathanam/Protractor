export const TRADED_DIRECTION = {
  BOUGHT : 'BOUGHT',
  SOLD   : 'SOLD'
};
