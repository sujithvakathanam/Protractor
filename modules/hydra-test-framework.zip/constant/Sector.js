export const Sector = {
  ENERGY               : 'Energy',
  BASICMATERIALS       : 'Basic Materials',
  COMMUNICATIONS       : 'Communications',
  CONSUMER_CYCLICAL    : 'Consumer,Cyclical',
  CONSUMER_NONCYCLICAL : 'Consumer,Non-cyclical',
  DIVERSIFIED          : 'Diversified',
  FINANCIAL            : 'Financial',
  FUNDS                : 'Funds',
  GOVERNMENT           : 'Government',
  INDUSTRIAL           : 'Industrial',
  TECHNOLOGY           : 'Technology',
  UTILITIES            : 'Utilities'
};
