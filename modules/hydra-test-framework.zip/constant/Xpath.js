export const ACTIVE_MODAL = 'div[@role="dialog" and not(contains(@style, "none"))]';
