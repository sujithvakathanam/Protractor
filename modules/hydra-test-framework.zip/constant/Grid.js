import {TRADING_SESSION_TYPE} from './TradingSession';

export const GRID_TYPE_TO_SESSION_TAG = {
  [TRADING_SESSION_TYPE.MATCHING_SESSION]    : item => item.MarketSegmentID,
  [TRADING_SESSION_TYPE.PRIVATE_NEGOTIATION] : () => 'PN',
  [TRADING_SESSION_TYPE.CLOB]                : () => 'CLOB'
};

export const PANEL_TYPE = {
  session   : 'session',
  action    : 'action',
  portfolio : 'portfolio',
  trades    : 'trades'
};

export const SESSION_TAB_TITLE = {
  PORTFOLIO : 'Portfolio',
  MY_TRADES : 'Trades',
  SESSION   : 'Session',
  OLX       : 'OLX'
};
