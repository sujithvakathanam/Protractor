const download = require('download-file');

const url = 'https://nexus.fenicsone.com/repository/software/com/selenium/chromedriver/2.34/chromedriver-2.34-x64.exe';

const options = {
  filename : 'chromedriver.exe'
};

download(url, options, err => {
  if (err) {
    throw err;
  }
  // eslint-disable-next-line no-console
  console.log('Chromedriver exe has been downloaded in your project root directory');
});
