// eslint-disable-next-line no-undef
// eslint-disable-next-line no-console

const {spawnSync} = require('child_process');
const {exec} = require('child_process');

const TARGET_ENV = process.env.TARGET_ENV ? process.env.TARGET_ENV : 'uat';
const CONFIG_URL = process.env.CONFIG_URL || `https://fenics-api.${TARGET_ENV}.fenicsone.com/v1/openfin-manifest?openFinApplication=fenics%2Ffenics-shell-app`;

exports.config = {
  specs : [
    'test/spec/**/*.js'
  ],
  suites : {
    smoke : [
      'test/spec/AMRS/11-session-cash-smoke.js',
      'test/spec/AMRS/12-session-spread-smoke.js'
    ],
    regression : [
     // 'test/spec/ASIA/03-session-spread-smoke.js'
      //'test/spec/ASIA/04-session-cash-smoke.js',
     'test/spec/EMEA/03-session-spread-smoke.js'
     //'test/spec/EMEA/04-session-cash-smoke.js',
     //'test/spec/AMRS/2-session-cash.js'
     //'test/spec/AMRS/3-session-spread.js'
     //'test/spec/AMRS/stress-test.js',
      //'test/spec/AMRS/stress-test-HY-Energy-100.js'
    ]
  },
  exclude : [
    'test/spec/AMRS/13-privateNegotiation-cash-smoke.js',
    'test/spec/AMRS/14-privateNegotiation-spread-smoke.js',
    'test/spec/ASIA/01-privateNegotiation-cash-smoke.js',
    'test/spec/ASIA/02-privateNegotiation-spread-smoke.js',
    'test/spec/EMEA/01-privateNegotiation-cash-smoke.js',
    'test/spec/EMEA/02-privateNegotiation-spread-smoke.js',
    'test/spec/AMRS/stress-test.js',
    'test/spec/AMRS/stress-test-HY-Energy-100.js',
    'test/spec/AMRS/10-operator-features.js',
    'test/spec/AMRS/4-privateNegotiation-cash.js',
    'test/spec/AMRS/5-privateNegotiation-spread.js',
    'test/spec/AMRS/1-login-features.js',
    'test/spec/AMRS/6-clob-cash.js',
    'test/spec/AMRS/7-clob-spread.js',
    'test/spec/AMRS/8-portfolioUpload-cash.js',
    'test/spec/AMRS/9-portfolioUpload-spread.js'
  ],

  capabilities : [
    {
      browserName   : 'chrome',
      chromeOptions : {
        extensions : [],
        binary     : process.env.CONFIG_URL ? 'RunTestableOpenFin.bat' : 'RunOpenFin.bat',
        args       : [
          `--config=${CONFIG_URL}`,
          '--allow-insecure-localhost',
          '--allow-running-insecure-content',
          '--disable-web-security',
          '--noerrdialogs',
          '--v=1',
          '--ignore-certificate-errors',
          '--remember-cert-error-decisions',
          '--disk-cache-size=1'
        ]
      }
    }
  ],
  maxInstances   : 1,
  sync           : false,
  host           : 'localhost',
  port           : 9515,
  path           : '/',
  loglevel       : 'silent',
  coloredLogs    : true,
  framework      : 'mocha',
  waitforTimeout : 20000,
  mochaOpts      : {
    ui        : 'bdd',
    compilers : ['js:babel-register'],
    require   : ['isomorphic-fetch', 'jsdom-global/register'],
    timeout   : 500000
  },

  reporters : ['allure', 'spec', 'teamcity'],

  reporterOptions : {
    captureStandardOutput : true,
    flowId                : true,
    message               : '[title]',
    allure                : {
      disableMochaHooks                    : true,
      disableWebdriverScreenshotsReporting : false
    }
  },

  onPrepare : () => {
    if (!process.env.CONFIG_URL) {
      spawnSync(`${process.env.INIT_CWD}/TerminateOpenfin.bat`);
      spawnSync(`${process.env.INIT_CWD}/TerminateChromedriver.bat`);
      exec('chromedriver.exe');

      console.log(`The target environment is : ${TARGET_ENV}`);
    }
  },

  beforeTest : () => {
    console.log('**************** Test has Started **************** ');
  },

  afterTest : () => {
    const name = `ERROR-chrome-${Date.now()}`;
    browser.saveScreenshot(`./errorShots/${name}.png`);
    console.log('**************** Test has Finished **************** ');
  },

  onComplete : () => {
    if (!process.env.CONFIG_URL) {
      //spawnSync(`${process.env.INIT_CWD}/TerminateOpenfin.bat`);
      spawnSync(`${process.env.INIT_CWD}/TerminateChromedriver.bat`);
    }
  }
};


