export const usersConfig = {
  users : [
    {
      oktaId   : 'INSERT OKTA ID HERE.',
      username : 'INSERT USERNAME HERE.',
      password : 'INSERT PASSWORD HERE.',
      lei      : 'INSERT LEI HERE.',
      espeed   : 'INSERT ESPEED HERE.'
    }
  ]
};
