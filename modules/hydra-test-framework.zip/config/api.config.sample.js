export const apiConfig = {
  apiUrl : 'INSERT STANDALONE IP:PORT OR CNAME HERE.'
};
