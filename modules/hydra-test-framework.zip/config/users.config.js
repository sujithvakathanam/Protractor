import {REGION} from '../constant/Region';

export const usersConfig = {
  users : [
    {
      oktaId   : '00u2mjw5tn0GTng9T0i7',
      username : 'sujith.vakathanam.auto1@testing.fenicstools.com',
      password : 'b5LzN7l6WcM3t2R4',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u2mjw1j3WEal7i20i7',
      username : 'sujith.vakathanam.auto2@testing.fenicstools.com',
      password : 'PZb4cFhnukk6CKyD',
      lei      : '773',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u2mjwbdgXnnfNKd0i7',
      username : 'sujith.vakathanam.auto3@testing.fenicstools.com',
      password : '67Ip4p2YgK0FyjQL',
      lei      : '775',
      espeed   : 'fencrt03',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u2mjwc58ZLcmtlR0i7',
      username : 'sujith.vakathanam.auto4@testing.fenicstools.com',
      password : '4vyQCa8rzAd9OsfF',
      lei      : '14684',
      espeed   : 'ejou1020',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u2mjwfvoV6r86Vd0i7',
      username : 'sujith.vakathanam.auto5@testing.fenicstools.com',
      password : 'l632yoJ4xhvjHdSm',
      lei      : '19154',
      espeed   : 'jsorb0a4',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u2mjvs3kXYH7N0T0i7',
      username : 'sujith.vakathanam.auto6@testing.fenicstools.com',
      password : 'ufv6F8VD6K8dVpvd',
      lei      : '26138',
      espeed   : 'tped6801',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37mwnquriTZuLi0i7',
      username : 'manjit.bharaj.auto7@testing.fenicstools.com',
      password : 't6fKwIwBUPEdyitX',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37mx9zwIHHw30E0i7',
      username : 'manjit.bharaj.auto8@testing.fenicstools.com',
      password : 'VQoOUbM4GsybAECR',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cisdeDkFlcSw0i7',
      username : 'manjit.bharaj.auto9@testing.fenicstools.com',
      password : 'VlK3tXXi7nbPIMWb',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cka3t9CssC0D0i7',
      username : 'manjit.bharaj.auto10@testing.fenicstools.com',
      password : 'XuMVgylVBy5J6t4u',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37ckja3wFlLYMS0i7',
      username : 'manjit.bharaj.auto11@testing.fenicstools.com',
      password : 'S6XDwidC7U4RpR1s',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cjsojFbKHFVS0i7',
      username : 'manjit.bharaj.auto12@testing.fenicstools.com',
      password : 'EcNhMrD3Qxo4PF30',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cka7yVeSjm6x0i7',
      username : 'manjit.bharaj.auto13@testing.fenicstools.com',
      password : 'KOqLLu8TXN0qUJaH',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cluev8pbOWgd0i7',
      username : 'manjit.bharaj.auto14@testing.fenicstools.com',
      password : 'agaFZgq3RLx729MI',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cmp8v3MYYWvl0i7',
      username : 'manjit.bharaj.auto15@testing.fenicstools.com',
      password : 'RdJhhg8Lt05HeGUd',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cmh3gdmF1nRI0i7',
      username : 'manjit.bharaj.auto16@testing.fenicstools.com',
      password : 'dpL1Nsm8a8JczOXk',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37co9aiKHEQzhS0i7',
      username : 'manjit.bharaj.auto17@testing.fenicstools.com',
      password : 'WQl0AQM5BBB6jEwo',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cmxyfKlBUlvs0i7',
      username : 'manjit.bharaj.auto18@testing.fenicstools.com',
      password : 'PFDPzi87zimbl0MJ',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37cp6nc5qKFCF40i7',
      username : 'manjit.bharaj.auto19@testing.fenicstools.com',
      password : '924NDhUZ3DkObyx8',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u37co6n1Z9NSyCZ0i7',
      username : 'manjit.bharaj.auto20@testing.fenicstools.com',
      password : 'PICea5bJ8aWrPk8t',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u38d4zujAWX9XoB0i7',
      username : 'manjit.bharaj.auto21@testing.fenicstools.com',
      password : '8jMOMQbJEYXLyJzx',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u38d4zvovZrzi5H0i7',
      username : 'manjit.bharaj.auto22@testing.fenicstools.com',
      password : 'S7HwPls4wTvxytzm',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u38d725odIFpac80i7',
      username : 'manjit.bharaj.auto23@testing.fenicstools.com',
      password : 'DhhYugYRFwa7aivr',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u38d4eje7nkXHUa0i7',
      username : 'manjit.bharaj.auto24@testing.fenicstools.com',
      password : 'uB70jOUv5zkOOUCs',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u3aghkkweomZUJW0i7',
      username : 'saurav.santosh.auto1.US@testing.fenicstools.com',
      password : '3TQxz1UTnWK6t2m1',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    },
    {
      oktaId   : '00u32ymfrfK7GeF5n0i7',
      username : 'sujith.vakathanam.auto7@testing.fenicstools.com',
      password : 'Password1',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u37j0h4jlHbx4PK0i7',
      username : 'sujith.vakathanam.auto17@testing.fenicstools.com',
      password : 'F9xWkoi7ykRsw020',
      lei      : '2',
      espeed   : 'afina522',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u37j0kswshJlrq40i7',
      username : 'sujith.vakathanam.auto18@testing.fenicstools.com',
      password : '4n8LoEIxf0M3OEaI',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u3cy4d9o6wLiO2f0i7',
      username : 'sujith.vakathanam.auto19@testing.fenicstools.com',
      password : '6Ltx9ZSCc8GhrtEX',
      lei      : '14850',
      espeed   : 'akau3m4a',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u3ah8pyprSYaOlG0i7',
      username : 'saurav.santosh.qa.auto1.emea@testing.fenicstools.com',
      password : 'rFZbPkJUxC7VuO93',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u3bu39eeFtE35fq0i7',
      username : 'saurav.santosh.qa.auto11.emea@testing.fenicstools.com',
      password : 'ys7a7v5FgWUBx5by',
      lei      : '26138',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u32yo5xi4ZlhdNq0i7',
      username : 'sujith.vakathanam.auto9@testing.fenicstools.com',
      password : 'smSz46lkX498Lgfh',
      lei      : '2',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.ASIA.DX_NAME
    },
    {
      oktaId   : '00u3bu6j843SNacZk0i7',
      username : 'saurav.santosh.qa.auto12.emea@testing.fenicstools.com',
      password : 'jVLJHRec8ArOBqu9',
      lei      : '19154',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.EU.DX_NAME
    },
    {
      oktaId   : '00u32ynwkcNlPNVja0i7',
      username : 'sujith.vakathanam.auto10@testing.fenicstools.com',
      password : 'xHLuKgA8Pfv66Itv',
      lei      : '286',
      espeed   : 'thig4b5c',
      type     : 'trader',
      region   : REGION.ASIA.DX_NAME
    },
    {
      oktaId   : '00u37j0g3b57A55sK0i7',
      username : 'sujith.vakathanam.auto15@testing.fenicstools.com',
      password : '0oHxZM7T5aoz6zHc',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.ASIA.DX_NAME
    },
    {
      oktaId   : '00u37j0korONXxpOl0i7',
      username : 'sujith.vakathanam.auto16@testing.fenicstools.com',
      password : 'ti8bHf2LKTDFqK9X',
      lei      : '773',
      espeed   : 'fencrt02',
      type     : 'trader',
      region   : REGION.ASIA.DX_NAME
    },
    {
      oktaId   : '00u37j0247eK6NPxW0i7',
      username : 'sujith.vakathanam.auto13@testing.fenicstools.com',
      password : 'U8aUUcOKhdH6fhpO',
      lei      : '771',
      espeed   : 'fencrt01',
      type     : 'trader',
      region   : REGION.US.DX_NAME
    }
  ]
};
