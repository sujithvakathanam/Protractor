# hydra-test-framework
End-to-end test automation framework for Hydra - Delta X.

## How it works
The configured users in `config/api.config.js` and `config/framework.config.js` interact with Hydra - Delta X.

One performs actions from the UI using [Webdriver.io](http://v4.webdriver.io/). The other sends FIX messages using the [fenics-transport](https://github.fenicsone.com/fenics/fenics-transport) library. To avoid authentication issues, it bypasses the AWS API Gateway by sending the requests directly to the 
[hydra-order-edge-standalone](https://github.fenicsone.com/fenics/hydra-order-edge-standalone) instance hosted in AWS.

## Prereq
1. hydra-test-framework:
    - `config/api.conig.js` - Set the `baseUrl` to the correct private IP http://10.251.56.66:8080 (API Gateway is bypassed).
    - `config/framework.config.js` - Set the UI user `username` and `password` variables to the desired user (This should be set to the first user configured in `config/api.config.js`).
    - Ensure that the target test pack to be executed is set in `config/wdio.config.js` under `specs: [...]`. 
    
2. fenics-dev-server (for local Hydra - Delta X only):
    - `index.js` - Add the openfin runtime version as below
    e.g. `openFinManifest.runtime.version = '9.61.33.22';`
    
    - Ensure this `src/override/bootstrap.json` file is added to the project.
    `bootstrap.json`:
    ```
    {
        "apiBaseUrl": "http://localhost:8989/api",
        "appOpenFinManifestUrl": "http://localhost:8989/fenicsone.fenics-launchbar.manifest.json",
        "streaming": {
            "default": {
                "wsUrl": "a1ue0co22dsw9x.iot.eu-west-1.amazonaws.com",
                "idpPoolId": "eu-west-1:6b98c777-569c-45f9-93ea-0cf3dab1d6f7"
            }
        }
    }
    ```
    
3. Environment variable `FENICS_DEBUG` should be set to `FENICS_DEBUG=0` if not running locally, otherwise it should be set to `FENICS_DEBUG=1`.

4. `chromedriver.exe` v2.34 has been downloaded and is in the root of the `hydra-test-framework`. 
    You can copy `chromedriver.exe` v2.34 from `\\BS-DEV-76406\shared`.

## Usage
1. Ensure that the Hydra application **is not running** and local cache is empty (Run this batch script: `TerminateOpenfin.bat`).
2. Selenium works with OpenFin if version >= 9.61.33.*. This can be overridden with [fenics-dev-server](https://github.fenicsone.com/fenics/fenics-dev-server).
3. Launch chromedriver.exe from `hydra-test-framework` root directory.
4. Start the `fenics-dev-server` using`npm install  & npm start` (OPTIONAL).
5. Install project dependencies using `npm install` or ``npm i`.
6. Run the test pack using `npm test`.

## Allure Reporting

1. `wdio-allure-reporter` should be part of project dependency `package.json`
2. Install Allure commandline tool to open and view test results `npm install -g allure-commandline`
3. To view the report, enter `allure open` in your command line or make this step as a part of your npm scripts

