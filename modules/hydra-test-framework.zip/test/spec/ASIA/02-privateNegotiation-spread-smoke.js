import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import TestCommons from '../../../utilities/TestCommons';
import FenicsCredit from '../../../pages/FenicsCredit';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {expect} from 'chai';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {SIZE_MULTIPLIER} from '../../../constant/Order';

describe('Private Negotiation Spread Smoke Tests for ASIA region', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;

  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto9@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto10@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto15@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  // eslint-disable-next-line max-len
  it('PNS-073 - ASIA region-ASM gets recalculated during Private Phase after a trade is executed and also gets recalculated when there is an Improved price compared to resting order', async () => {
    const securityId = 'US001055AQ51';
    const securityDescription = 'AFL 2 7/8 10/15/26';
    let orderMid = 262;
    const spread = 4;
    const size = 3000000;
    const sizeTwo = 2500000;
    const sizeDiff = 500;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.ASIA.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    allStrategies = [hydraPageModel, hydraApiClientUserTwo, hydraApiClientUserThree];

    // eslint-disable-next-line no-unneeded-ternary
    firstRun = firstRun === true ? true : true;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto9@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, sizeDiff);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price}  for 0.5M.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.50;
    const userThreeImprovedPrice = (parseFloat(asmPrice) + parseFloat(priceDiff)).toFixed(2);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeImprovedPrice);
    logger.info(`User 3 improves his Offer price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    let recalculatedAsmPrice = ((parseFloat(userOneOrder.Price) + parseFloat(userThreeImprovedPrice)) / 2).toFixed(2);
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(sizeDiff.toString());

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price).toFixed(1);
    logger.info('Expected Trade Price for User2 is', expectedTradePriceForUser2);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePriceForUser2))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders for User2`
    );

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price).toFixed(1))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal((sizeDiff * SIZE_MULTIPLIER).toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    logger.info('hydraPageModel UI user is about to check the portfolio');
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal((sizeTwo / SIZE_MULTIPLIER).toString());

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(sizeTwo);

    logger.info('About to check HydraApiClientUserTwos portfolio');
    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    logger.info('About to check hydraApiClientUserThree portfolio');
    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });
});
