/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateAsmPrice, getOrderMid} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {Sector} from '../../../constant/Sector';
import {TRADING_PROTOCOL} from '../../../constant/Protocol';
import {calculateVWAP} from '../../../utilities/vwapCalculator';
import {TRADED_DIRECTION} from '../../../constant/TradedDirection';
import {SIZE_MULTIPLIER} from '../../../constant/Order';
import {OPTIONS, PHASE_DEFINITIONS, TYPE} from '../../../constant/TradingSession';

describe('Matching Session Smoke tests for ASIA region for Spread', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let allApiStrategies = null;
  let allStrategies = null;
  let sessionStrategy = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto9@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto10@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto15@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto16@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    sessionStrategy = new FixSessionStrategy(context, 'sujith.vakathanam.auto10@testing.fenicstools.com');

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('MSS-008 - ASIA- HYD-582-LimitPrice-Off- User1,User3 at Buy Side, User2,User4 at Sell side- All users accept ASM price -Trade between User1 and User2 at VWAP satifying the price followed by time logic ', async () => {
    const securityId = 'US822582BX94';
    const securityDescription = 'RDSALN 2 1/2 09/12/26';
    const industrySector = Sector.ENERGY;
    let orderMid = 100.5;
    const spread = 3;
    const size = 5000000;
    const userOneOrderSize = 1000000;
    const userTwoOrderSize = 2000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.ASIA.IG;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    // eslint-disable-next-line no-unneeded-ternary
    firstRun = firstRun === true ? true : true;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    allStrategies = [hydraPageModel, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto9@testing.fenicstools.com');

    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, userOneOrderSize, 'HY', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, userTwoOrderSize, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty}, with limit price of ${userFourOrder.Price}  and direction of ${userFourOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(String(parseFloat(asmPrice).toFixed(2))).to.equal(String(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}`);

    const priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 (Winner) affirms their ASM price first followed by User4 at Sell side');

    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 (Winner) affirms their ASM price (Best price) at Buy side ');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User4 at ${userFourOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userFourOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice)
      , userOneOrderSize
      , parseFloat(asmPrice)
      , userTwoOrderSize
      , region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);
    logger.info('Expected Trade Price based on VWAP calculation is', expectedTradePrice);

    expect(tradedPrice).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    expectedTradePrice = Number.isInteger(expectedTradePrice) ? parseFloat(expectedTradePrice).toFixed(1) : expectedTradePrice;
    await browser.waitUntil(
      () => hydraApiClient.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePrice))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders.`
    );

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePrice));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(parseFloat(expectedTradePrice).toFixed(2)));
    expect(trades[0].Size).to.equal(userTwoOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.SOLD);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);
    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('OLXS-003 - Limit Price -ON-Tolerance band error thrown if the Limit price entered is outside 10% of WEP, User rejects the tolerance band warning and accept ASM-User should get traded  ', async () => {
    // MinPiece = 2k, Min Increment = 1k,Currency = USD - Please check for Amended and Minimum size leg along with Traded Price in GMO for below ISIN
    const securityId = 'US02005NBC39';
    const securityDescription = 'ALLY 4 5/8 05/19/22';
    const industrySector = Sector.FINANCIAL;
    let orderMid = 100.5;
    const spread = 150;
    const size = 1000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.ASIA.IG;
    const type = TYPE.OLX;

    const sessionConfiguration = {
      sector : industrySector,
      rating,
      type
    };

    OPTIONS.maxSizeCleanup = 5000000;
    OPTIONS.maxSizeAffirmation = 15000000;
    OPTIONS.minSize = 1000;
    OPTIONS.isLimitPricingEnabled = true;
    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto9@testing.fenicstools.com');

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    logger.info('OrderMid is', orderMid);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'HY', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, TYPE.OLX)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating, false, TYPE.OLX);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, TYPE.OLX)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    const asmPrice = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(String(parseFloat(asmPrice).toFixed(2))).to.equal(String(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}`);

    await hydraPageModel.getSessionPanel(rating, true, TYPE.OLX)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .affirmOrder();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    await browser.pause(configuration.veryShortTimeout);
    const toleranceBandRejectionWarningPrompt = await hydraPageModel.getSessionPanel(rating, false, type)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getToleranceBandRejectionWarningText();
    expect(toleranceBandRejectionWarningPrompt).to.equal('You priced outside the tolerance level either reject or confirm the order!');
    logger.info(`User 1 presented with warning as: '${toleranceBandRejectionWarningPrompt}'.`);

    await hydraPageModel.getSessionPanel(rating, false, type)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .clickToleranceBandWarningRejectBtn();
    logger.info(`User1 at ${userOneOrder.Side} side rejected their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    await hydraPageModel.getSessionPanel(rating, false, type)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptAsm();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = asmPrice;

    await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their asm price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true, type);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice),
      size, parseFloat(asmPrice), size, region
    );
    logger.info('Expected Trade Price is', expectedTradePrice);
    expect(String(parseFloat(tradedPrice))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(userOneOrder.OrderQty));
    logger.info('User1 traded with size and price correctly');

    expectedTradePrice = Number.isInteger(parseFloat(expectedTradePrice)) ? parseFloat(expectedTradePrice).toFixed(1) : parseFloat(expectedTradePrice);
    await browser.waitUntil(
      () => hydraApiClient.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePrice))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders.`
    );

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePrice));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(trades[0].Size).to.equal(size.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });
});
