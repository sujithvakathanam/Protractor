/* eslint-disable no-unused-expressions,max-len,max-lines,no-unused-vars,max-statements */

import {expect} from 'chai';
import {apiConfig} from '../../../config/api.config';
import config from '../../../config/framework.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FenicsCredit} from '../../../pages/FenicsCredit';
import {FenicsOperator} from "../../../pages/FenicsOperator";
import {HydraLauncher} from '../../../pages/launchers/hydraLauncher';
import LoginPage from '../../../pages/LoginPage';
import Bootstrap from '../../../utilities/framework/bootstrap';
import {shellExec} from '../../../utilities/framework/shellExec';
import {login, loginAsOperator, cleanUpTest} from '../../../utilities/TestCommons';
import FenicsLogger from '@fenics/fenics-logging';
import {quickUpload} from './9-portfolioUpload-spread';

describe('Private negotiation tests - Spread Bonds', () => {
  let hydraPageModel = null;
  let hydraOperatorPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;
  let loginUser = null;
  let hydraLauncher = null;
  let firstRun = true;
  let logger = null;

  before(() => {
    loginUser = new LoginPage();
    hydraPageModel = new FenicsCredit();
    hydraOperatorPageModel = new FenicsOperator();
    hydraApiClientUserOne = new FixHydraStrategy(apiConfig.users[0]);
    hydraApiClientUserTwo = new FixHydraStrategy(apiConfig.users[1]);
    hydraApiClientUserThree = new FixHydraStrategy(apiConfig.users[2]);
    hydraApiClientUserFour = new FixHydraStrategy(apiConfig.users[3]);
    hydraApiClientUserFive = new FixHydraStrategy(apiConfig.users[4]);
    hydraApiClientUserSix = new FixHydraStrategy(apiConfig.users[5]);
    hydraApiClientUserSeven = new FixHydraStrategy(apiConfig.users[6]);
    hydraApiClientUserEight = new FixHydraStrategy(apiConfig.users[7]);
    hydraApiClientUserNine = new FixHydraStrategy(apiConfig.users[8]);
    hydraApiClientUserTen = new FixHydraStrategy(apiConfig.users[9]);
    hydraApiClient = hydraApiClientUserTwo;
    hydraLauncher = new HydraLauncher();
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];
    logger = new FenicsLogger();

    browser.timeouts('implicit', config.shortTimeout);
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('OP-001 - Operator to create the session template successfully', async () => {
    const investmentRating = 'Investment Grade';
    const type = 'PN';
    const sector = 'Funds';
    const inCompetitionVisible = 'No';
    const pricingDuration = 5;
    const privateDuration = 3;
    const groupDuration = 2;
    const pricingGlowVisible = 'No';
    const privateGlowVisible = 'No';
    const groupGlowVisible = 'No';

    firstRun = await loginAsOperator(loginUser, hydraLauncher,  hydraOperatorPageModel, true);

    await hydraOperatorPageModel.getConfiguration().clickConfiguration();
    await hydraOperatorPageModel.getConfiguration()
      .marketEdit(investmentRating, sector, inCompetitionVisible, pricingDuration, privateDuration, groupDuration, pricingGlowVisible, privateGlowVisible, groupGlowVisible);

    const actualInvestmentRating = await hydraOperatorPageModel.getConfiguration().getSummaryInvestmentRating();
    expect(actualInvestmentRating).to.equal('IG');

    const actualType = await hydraOperatorPageModel.getConfiguration().getSummaryType();
    expect(actualType).to.equal(type);

    const actualSector = await hydraOperatorPageModel.getConfiguration().getSummarySector();
    expect(actualSector).to.equal(sector.toUpperCase());

    const expectedPricingDuration = 'PRICING - ' + pricingDuration + ' - GLOW: ' + pricingGlowVisible.toUpperCase();
    const actualPricingDuration = await hydraOperatorPageModel.getConfiguration().getSummaryPricing();
    expect(actualPricingDuration).to.equal(expectedPricingDuration);

    const expectedPrivateDuration = 'PRIVATE - ' + privateDuration + ' - GLOW: ' + privateGlowVisible.toUpperCase();
    const actualPrivateDuration = await hydraOperatorPageModel.getConfiguration().getSummaryPrivate();
    expect(actualPrivateDuration).to.equal(expectedPrivateDuration);

    const expectedGroupDuration = 'GROUP - ' + groupDuration + ' - GLOW: ' + groupGlowVisible.toUpperCase();
    const actualGroupDuration = await hydraOperatorPageModel.getConfiguration().getSummaryGroup();
    expect(actualGroupDuration).to.equal(expectedGroupDuration);

    const expectedInCompetitionVisible = 'IN COMPETITION VISIBLE: ' + inCompetitionVisible.toUpperCase();
    const actualInCompetitionVisible = await hydraOperatorPageModel.getConfiguration().getSummaryInCompetitionVisible();
    expect(actualInCompetitionVisible).to.equal(expectedInCompetitionVisible);

    await hydraOperatorPageModel.getConfiguration().refreshPage();
    await hydraOperatorPageModel.getConfiguration()
      .marketEdit(investmentRating, sector, 'Yes', 1, 1, 1, 'Yes', 'Yes', 'Yes');
  });

  //TODO - To hover over the market
  it('OP-002 - Test to verify the created session template in markets pop over summary screen ', async () => {
    const investmentRating = 'Investment Grade';
    const rating = 'IG';
    const type = 'PN';
    const sector = 'Funds';
    const inCompetitionVisible = 'Yes';
    const pricingDuration = 4;
    const privateDuration = 2;
    const groupDuration = 2;
    const pricingGlowVisible = 'Yes';
    const privateGlowVisible = 'No';
    const groupGlowVisible = 'Yes';
    const market = 'IG PN Funds';

    firstRun = await loginAsOperator(loginUser, hydraLauncher,  hydraOperatorPageModel, true);

    await hydraOperatorPageModel.getConfiguration().clickConfiguration();
    await hydraOperatorPageModel.getConfiguration()
      .marketEdit(investmentRating, sector, inCompetitionVisible, pricingDuration, privateDuration, groupDuration, pricingGlowVisible, privateGlowVisible, groupGlowVisible);

    //TODO -To hover over the market

    const actualInvestmentRating = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryInvestmentRating(market);
    expect(actualInvestmentRating).to.equal(rating);

    const actualType = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryType(market);
    expect(actualType).to.equal(type);

    const actualSector = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummarySector(market);
    expect(actualSector).to.equal(sector.toUpperCase());

    const expectedPricingDuration = 'PricingPage - ' + pricingDuration + ' - GLOW: ' + pricingGlowVisible;
    const actualPricingDuration = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryPricing(market);
    expect(actualPricingDuration).to.equal(expectedPricingDuration);

    const expectedPrivateDuration = 'Private - ' + privateDuration + ' - GLOW: ' + privateGlowVisible;
    const actualPrivateDuration = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryPrivate(market);
    expect(actualPrivateDuration).to.equal(expectedPrivateDuration);

    const expectedGroupDuration = 'Group - ' + groupDuration + ' - GLOW: ' + groupGlowVisible;
    const actualGroupDuration = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryGroup(market);
    expect(actualGroupDuration).to.equal(expectedGroupDuration);

    const expectedInCompetitionVisible = 'In Competition visible: ' + inCompetitionVisible.toUpperCase();
    const actualInCompetitionVisible = await hydraOperatorPageModel.getConfiguration().getMarketsPopoverSummaryInCompetitionVisible(market);
    expect(actualInCompetitionVisible).to.equal(expectedInCompetitionVisible);

    await hydraOperatorPageModel.getConfiguration().refreshPage();
    await hydraOperatorPageModel.getConfiguration()
      .marketEdit(investmentRating, sector, 'Yes', 1, 1, 1, 'Yes', 'Yes', 'Yes');
  });

  //TODO - To call the hydra spread or cash test and then do the assertion
  it('OP-003 - Private Negotiation show the status of PN', async () => {
    const securityDescription = 'DUK 7 3/4 03/01/31';
    const expectedLogEntries = [
      {
        ACTION: 'Session ended',
        BUY: '',
        PRICE: '',
        SELL: '' },
      {
        ACTION: 'Trade',
        BUY: '1.0',
        PRICE: '30.5',
        SELL: '' },
      {
        ACTION: 'Trade',
        BUY: '',
        PRICE: '30.5',
        SELL: '1.0' },
      {
        ACTION: 'Phase ended',
        BUY: '',
        PRICE: '',
        SELL: '' },
      {
        ACTION: 'Added order',
        BUY: '',
        PRICE: '30.5',
        SELL: '1.0' },
      {
        ACTION: 'Updated order',
        BUY: '1.0',
        PRICE: '30.5',
        SELL: '' },
      {
        ACTION: 'Added order',
        BUY: '1.0',
        PRICE: '30.5',
        SELL: '' },
      {
        ACTION: 'Counter-interest found',
        BUY: '',
        PRICE: '',
        SELL: '' },
      {
        ACTION: 'Phase started',
        BUY: '',
        PRICE: '',
        SELL: '' } ];

    firstRun = await loginAsOperator(loginUser, hydraLauncher,  hydraOperatorPageModel, true);

    await hydraOperatorPageModel.getPrivateNegotiation().clickPrivateNegotiation();
    const logEntries = await hydraOperatorPageModel.getPrivateNegotiation().getPrivateNegotiationLogs(securityDescription);
    for (let i=0; i<logEntries.length; i++) {
      expect(logEntries[i].ACTION).to.equal(expectedLogEntries[i].ACTION);
      expect(logEntries[i].BUY).to.equal(expectedLogEntries[i].BUY);
      expect(logEntries[i].PRICE).to.equal(expectedLogEntries[i].PRICE);
      expect(logEntries[i].SELL).to.equal(expectedLogEntries[i].SELL);
    }
  });

  //TODO - To call the hydra spread or cash test and then do the assertion
  it('OP-004 - System Activity screen -Test to assert the logs created after Quick Upload and after the PN protocol', async () => {
    const protocol = 'PORTFOLIO';
    const phase = 'Upload';
    const action = 'Added Interest';
    const securityId = 'US158525AT25';
    const securityDescription = 'UGPABZ 5 1/4 10/06/26';
    const buy = 5.0;

    browser.call(() => {
      return quickUpload;
      });

    firstRun = await loginAsOperator(loginUser, hydraLauncher,  hydraOperatorPageModel, true);

    await hydraOperatorPageModel.getSystemActivityLog().clickSystemActivityLog();
    const logEntries = await hydraOperatorPageModel.getSystemActivityLog().getSystemActivityLogsForISIN(securityId);
    console.log('log entries is ',logEntries);
  })
});
