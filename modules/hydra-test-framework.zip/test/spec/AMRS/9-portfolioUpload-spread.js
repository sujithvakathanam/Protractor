/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateMid, calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';

describe('Private negotiation tests - Spread Bonds', () => {
  // Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'qa.1');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'qa.2');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'qa.3');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'qa.4');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('PUS-001 - Upload file with duplicate ISIN in Same direction -Original Order to be replaced', async () => {
    const securityId = 'US594918BX11';
    const securityDescription = 'MSFT 2 7/8 02/06/24';
    const orderMid = 155;
    const spread = 3;
    const size = 1000000;
    const sizeToBeReplaced = 500000;

    const securityIdTwo = 'US23355LAD82';
    const securityDescriptionTwo = 'DXC 4 3/4 04/15/27';
    const orderMidTwo = 55;
    const spreadTwo = 2;
    const sizeTwo = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;


    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, sizeToBeReplaced, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, size, rating, region),
      getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[0].OrderQty} and direction of ${userOneOrder[0].Side} side.`);
    logger.info(`User 1 added bond ${securityDescriptionTwo} with size of ${userOneOrder[1].OrderQty} and direction of ${userOneOrder[1].Side} side.`);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[2].OrderQty} and direction of ${userOneOrder[2].Side} side.`);

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('1.0');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(1);

    const userTwoOrder = [getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region),
      getNewOrder(securityIdTwo, 'sell', spreadTwo, orderMidTwo, sizeTwo, rating, region)];
    await hydraApiClient.addOrders(userTwoOrder);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder[0].OrderQty} and direction of ${userTwoOrder[0].Side} side.`);
    logger.info(`User 2 added bond ${securityDescriptionTwo} with size of ${userTwoOrder[1].OrderQty} and direction of ${userTwoOrder[0].Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      let validateResult = await strategy.getActionPanel()
        .getOrderByDescription(securityDescriptionTwo)
        .validateForSession();
      expect(validateResult).to.be.true;

      validateResult = await strategy.getActionPanel()
        .getOrderByDescription(securityDescription)
        .validateForSession();
      expect(validateResult).to.be.true;
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('1.0');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescriptionTwo} from portfolio.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescriptionTwo} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PUS-002 - Upload file with duplicate ISIN in Opposite direction- second order is to be rejected during upload', async () => {
    const securityId = 'US90351DAF42';
    const securityDescription = 'UBS 4 1/8 04/15/26';
    const orderMid = 323;
    const spread = 0;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;
    const sizeToBeReplaced = 500000;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, sizeToBeReplaced, rating, region),
      getNewOrder(securityId, 'sell', spread, orderMid, size,rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[0].OrderQty} and direction of ${userOneOrder[0].Side} side.`);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[1].OrderQty} and direction of ${userOneOrder[1].Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const portfolioQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(portfolioQuantity).to.equal('1.0');

    const portfolioDirection = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getDirection();
    expect(portfolioDirection).to.equal('SELL');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PUS-003 - Scenario to test Mass Delete functionality', async () => {
    const securityId = 'US744320BA94';
    const securityDescription = 'PRU 3.935 12/07/49';
    const orderMid = 155;
    const spread = 0;
    const size = 1000000;

    const securityIdTwo = 'US594918AH79';
    const securityDescriptionTwo = 'MSFT 3 10/01/20';
    const orderMidTwo = 55;
    const spreadTwo = 0;
    const sizeTwo = 1000000;

    const securityIdThree = 'US00828ECZ07';
    const securityDescriptionThree = 'AFDB 2 5/8 03/22/21';
    const orderMidThree = 555;
    const spreadThree = 0;
    const sizeThree = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, sizeTwo, rating, region),
      getNewOrder(securityIdThree, 'sell', spreadThree, orderMidThree, sizeThree, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescriptionTwo} from portfolio.`);

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(0);
    logger.info(`Bond ${securityDescriptionTwo} with size of ${sizeTwo} is deleted successfully from Portfolio panel.`);

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion.');
  });

  it('PUS-004 - Scenario to test the Size increments by 100k for file upload', async () => {
    const securityId = 'US06048WWX46';
    const securityDescription = 'BAC 5.8 06/13/28';
    const orderMid = 155;
    const spread = 0;
    const size = 3465000;

    const securityIdTwo = 'US126410LM99';
    const securityDescriptionTwo = 'CSX 6.251 01/15/23';
    const orderMidTwo = 55;
    const spreadTwo = 0;
    const sizeTwo = 9650000;

    const securityIdThree = 'US36966TKA96';
    const securityDescriptionThree = 'GE 4 11/15/28';
    const orderMidThree = 555;
    const spreadThree = 0;
    const sizeThree = 2895000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, sizeTwo, rating, region),
      getNewOrder(securityIdThree, 'sell', spreadThree, orderMidThree, sizeThree, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('3.4');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .getSize(true);
    expect(remainingQuantity).to.equal('9.6');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionThree);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionThree)
      .getSize(true);
    expect(remainingQuantity).to.equal('2.8');

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion.');
  });

  it('PUS-005 - Scenario to test the Size increments by 100k for Quick upload', async (quickUpload) =>{
    const securityId = 'US158525AT25';
    const securityDescription = 'IP 7.2 11/01/26';
    const orderMid = 155;
    const spread = 0;
    const size = 5.2;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);

    await hydraPageModel.addOrdersByQuickUpload(userOneOrder.SecurityID);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .setDirection('Buy');

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .setSize(userOneOrder.OrderQty);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, 5200000, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('5.2');

    portfolioBondCount = await hydraApiClient
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(5200000);

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion for User 1.');

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info('User 2 deletes bond from portfolio.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty for User 2.');
  });

});
