'use strict';

/* eslint-disable no-unused-expressions */

import Bootstrap from '../utilities/framework/bootstrap';
import config from '../config/framework.config';
import {expect} from 'chai';
import LoginUser from '../pages/LoginPage';
import {hasTabOpen} from './../utilities/webdriverHelper/tabsHelper';

describe('Testing the login component - from loading to successful login', function loginTest () {
  let client = null;
  let loginUser = null;

  this.timeout(config.longTimeout);

  before(done => {
    client = Bootstrap.init(done);
    global.client = client;
    loginUser = new LoginUser(client);
  });

  it('Should load fenics-login page', async () => {
    expect(client).to.exist;
    await client.waitUntil(() => hasTabOpen(client, 'Fenics - fenicsone-login'));
  });

  it('If no user name and click on next, error message should be displayed', async () => {
    const userName = await loginUser.txtboxUsername.getValue();

    expect(userName).to.be.empty;

    await loginUser.clickNext();

    const errorMessageContent = await loginUser.errorMessage.getText();

    expect(errorMessageContent).to.have.string('error');
    expect(errorMessageContent).to.have.string('This is a required field');
  });

  it('Should set a username', async () => {
    await client.refresh();

    await loginUser.waitForLoginPageLoad();

    const initUserName = await loginUser.txtboxUsername.getValue();

    expect(initUserName).to.be.empty;

    const userName = config.username;
    await loginUser.enterUsername(userName);
    const inputUserName = await loginUser.txtboxUsername.getValue();

    expect(inputUserName).to.equal(userName);
  });

  it('should show error message with blank password', async ()=>{
    await loginUser.clickNext();
    await loginUser.waitForPasswordPageLoad();

    await loginUser.enterPassword('');

    await loginUser.clickSignIn();

    // Wait for the response to come back
    await loginUser.waitForLoginFailMessage();
    
    const errorMessageContent = await loginUser.signInErrorMessage.getText();

    expect(errorMessageContent).to.have.string('We found some errors. Please review the form and make corrections.');
  })

  it('Should show a password field - enter wrong password', async () => {
    await loginUser.waitForPasswordPageLoad();

    const password = 'wrong password';

    await loginUser.enterPassword(password);

    const passwordFieldValue = await loginUser.txtboxPassword.getValue();

    expect(passwordFieldValue).to.be.equal(password);
  });

  it('On enter - should show a Sign in failed message', async () => {
    await loginUser.clickSignIn();

    // Wait for the response to come back
    await loginUser.waitForLoginFailMessage();

    const errorMessageContent = await loginUser.signInErrorMessage.getText();

    expect(errorMessageContent).to.have.string('Sign in failed!');
  });

  it('Should show a password field - enter good password', async () => {
    const password = config.password;
    await loginUser.enterPassword(password);

    await loginUser.clickSignIn();
  });

  it('Should open launchbar after successful password', async () => {
    await client.waitUntil(() => hasTabOpen(client, 'Fenics - fenics-launchbar'));
  });

  /*
   * This test scenario should not test anything else
   * The launchbar will be tested in an other file
   */
});
