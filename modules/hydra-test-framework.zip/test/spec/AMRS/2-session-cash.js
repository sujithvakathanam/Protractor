/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateMid, calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {Sector} from '../../../constant/Sector';
import {TRADING_PROTOCOL} from '../../../constant/Protocol';
import {calculateVWAP} from '../../../utilities/vwapCalculator';
import {TRADED_DIRECTION} from '../../../constant/TradedDirection';
import {SIZE_MULTIPLIER} from '../../../constant/Order';
import {OPTIONS, PHASE_DEFINITIONS, RATING} from '../../../constant/TradingSession';

describe('Matching Session tests', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  // eslint-disable-next-line no-unused-vars
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;
  let sessionStrategy = null;

  // Test case vars.
  let firstRun = true;


  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'qa.1');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'qa.2');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'qa.3');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'qa.4');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    sessionStrategy = new FixSessionStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('MS-001 - Trade gets executed when both users affirm the same Limit Price at same Size', async () => {
    const securityId = 'US71647NAP42';
    const securityDescription = 'PETBRA 8 3/8 05/23/21';
    const industrySector = Sector.ENERGY;
    let orderMid = 100.18750;
    const spread = 0;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} , limit Price of ${userTwoOrder.Price} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} , limit Price of ${userOneOrder.Price} and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel().getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    logger.info('Count of Orders in Session panel is ', countOfOrdersInSessionPanel);

    const sessionPanel = hydraPageModel.getSessionPanel();
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, session panel has no orders.`
    );

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userTwoOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} , limit Price of ${userThreeOrder.Price} and direction of ${userThreeOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel().hasOrders()
      , configuration.longTimeout
      , 'Timed out after \' + configuration.longTimeout + \' seconds, session panel has no orders.'
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getSessionPanel()
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .affirmOrder();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = userTwoOrder.Price;
    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${userTwoOrder.Price} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 (Winner) affirm their Limit price first followed by User3');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their Limit price at ${userThreeOrder.Price} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true);

    const tradePanel = await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);

    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userOneOrder.Price)));
    expect(tradeSize).to.equal(String(userOneOrder.OrderQty));

    let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? expectedTradePriceForUser2.toFixed(1) : expectedTradePriceForUser2;
    logger.info('Expected TradedPrice for User2', expectedTradePriceForUser2);

    await browser.waitUntil(
      () => hydraApiClient.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePriceForUser2))
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, Trade panel has no orders for User2.`
    );

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
    expect(trades[0].Size).to.equal(size.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-002 - Trade gets executed when both users affirm their Limit Price such that orders get crossed- Fully Filled for both users ', async () => {
    const securityId = 'US65504LAF40';
    const securityDescription = 'NE 4 5/8 03/01/21';
    const industrySector = Sector.ENERGY;
    let orderMid = 90.5;
    const spread = 6;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'IG', region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'IG', region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'IG', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel();
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getSessionPanel()
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .affirmOrder();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = userTwoOrder.Price;

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 affirms their Limit price first followed by User3');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their Limit price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true);

    const tradePanel = await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);

    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    logger.info(`Expected Trade Price is ${expectedTradePrice}`);
    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(userOneOrder.OrderQty));

    expectedTradePrice = Number.isInteger(expectedTradePrice) ? String(parseFloat(expectedTradePrice).toFixed(1)) : String(expectedTradePrice);
    await browser.waitUntil(
      () => hydraApiClient.getTradesPanel(securityDescription)
        .hasTrades(expectedTradePrice)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders for User2`
    );

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(expectedTradePrice);

    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(trades[0].Size).to.equal(size.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-003 - Trade gets executed when User1 affirm their ASM Price, User2 affirm Limit price-Partial fill for User1 ', async () => {
    const securityId = 'US12654TAA88';
    const securityDescription = 'CNXMPF 6 1/2 03/15/26';
    const industrySector = Sector.ENERGY;
    const spread = 2;
    const size = 5000000;
    const sizeTwo = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    const expectedPortfolioBondCount = 1;
    const expectedRemainingQuantity = '4000';
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, 'IG', region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, 'IG', region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptAsm();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price of ${asmPrice} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = userTwoOrder.Price;
    logger.info(`User2 about to affirm their limit price as ${priceToAffirm} `);
    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    await hydraPageModel.getTrades(rating);
    await browser.pause(configuration.veryShortTimeout);
    const tradePanel = await hydraPageModel.getTrades();
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(userTwoOrder.Price),
      sizeTwo, parseFloat(asmPrice), size, region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);
    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(Math.abs(sizeTwo / SIZE_MULTIPLIER)));

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();

    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePrice));
    expect(trades[0].Size).to.equal(sizeTwo.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(expectedPortfolioBondCount);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(expectedRemainingQuantity);

    await hydraPageModel.getPortfolio(true)
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('MS-004 - Trade gets executed when both users affirm their ASM Price-Partial fill for User1 ', async () => {
    const securityId = 'XS0982711714';
    const securityDescription = 'PETBRA 4 3/4 01/14/25';
    const industrySector = Sector.ENERGY;
    const spread = 3;
    const size = 5000000;
    const sizeTwo = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    const expectedPortfolioBondCount = 1;
    const expectedRemainingQuantity = '4000';
    const expectedSizeInCleanupPhaseForUserOne = '4000';
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, session panel has no orders.`
    );
    logger.info('Session Panel does have orders');

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptAsm();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = asmPrice;
    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userTwoOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades();
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice),
      sizeTwo, parseFloat(asmPrice), size, region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(Math.abs(sizeTwo / SIZE_MULTIPLIER)));

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePrice));

    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePrice));
    expect(trades[0].Size).to.equal(sizeTwo.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(expectedPortfolioBondCount);
    logger.info('PortfolioBondCount matches the ExpectedPortfolioBondCount');

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(expectedRemainingQuantity);

    await hydraPageModel.getPortfolio(true)
      .getOrderByDescription(securityDescription)
      .delete(true);
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, Portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('MS-005 - Test to check if Order moves to Action panel and get traded only when there is CounterInterest during Countdown phase, Orders without CounterInterest is to drop back to Portfolio ', async () => {
    const securityId = 'US67059TAF21';
    const securityDescription = 'NSUS 6 06/01/26';

    const securityIdOfUserOneOrderTwo = 'USC0455LAA82';
    const securityDescriptionOfUserOneOrderTwo = 'ATHCN 9 7/8 02/24/22';

    const industrySector = Sector.ENERGY;
    const spread = 3;
    const size = 5000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    const expectedPortfolioBondCount = 1;
    const expectedRemainingQuantity = '5000';
    const orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.getPortfolio(true);

    const userOneOrderTwo = getNewOrder(securityIdOfUserOneOrderTwo, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder, userOneOrderTwo]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);
    logger.info(`User 1 added bond ${securityDescriptionOfUserOneOrderTwo} with size of ${userOneOrderTwo.OrderQty}, with limit price of ${userOneOrderTwo.Price}  and direction of ${userOneOrderTwo.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescriptionOfUserOneOrderTwo);
    expect(portfolioBondCount).to.equal(expectedPortfolioBondCount);
    logger.info(`userOneOrderTwo with security description as ${securityDescriptionOfUserOneOrderTwo} dropped to Portfolio panel as there is no Counter Interest`);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionOfUserOneOrderTwo)
      .getSize(true);
    expect(remainingQuantity).to.equal(expectedRemainingQuantity);
    logger.info(`userOneOrderTwo with security description as ${securityDescriptionOfUserOneOrderTwo} dropped to Portfolio panel with remaining quantity as ${expectedRemainingQuantity}`);

    const asmPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptAsm();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = asmPrice;
    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userTwoOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice),
      size, parseFloat(asmPrice), size, region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);
    expect(parseFloat(tradedPrice)).to.equal(expectedTradePrice);
    expect(tradeSize).to.equal(String(Math.abs(size / 1000)));

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();

    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePrice));
    expect(trades[0].Size).to.equal(size.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionOfUserOneOrderTwo)
      .delete(true);
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);
    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('MS-006 - HYD-584- Multi user-Trade gets executed at VWAP with tbe Best Bid,Best Bid Size, Best Offer, BestOffer Size', async () => {
    const securityId = 'USY59515AA72';
    const securityDescription = 'MEDCIJ 8 1/2 08/17/22';
    const industrySector = Sector.ENERGY;
    const expectedPortfolioBondCount = 1;
    const expectedRemainingQuantity = 5000000;
    let orderMid = 100.5;
    const spread = 6;
    const size = 5000000;
    const userOneOrderSize = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, userOneOrderSize, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    let priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    priceToAffirm = userOneOrder.Price;
    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);
    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades();
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    const expectedTradePrice = calculateVWAP(
      parseFloat(userOneOrder.Price)
      , userOneOrderSize
      , parseFloat(asmPrice)
      , size
      , region
    );
    logger.info(`ExpectedTradePrice based on calculated VWAP is ${expectedTradePrice}`);

    expect(String(tradedPrice)).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(userOneOrderSize / SIZE_MULTIPLIER));

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(parseFloat(expectedTradePrice)));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(parseFloat(expectedTradePrice).toFixed(2)));
    expect(trades[0].Size).to.equal(userOneOrderSize.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.SOLD);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getPortfolio(true);
    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    const portfolioBondCount = await hydraApiClientUserThree
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(expectedPortfolioBondCount);

    const remainingQuantity = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(expectedRemainingQuantity);
    logger.info(`User 3 with size of ${userThreeOrder.OrderQty} drops to Portfolio `);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-007 - HYD-472-Test to check Price followed by time logic- User1 ,User3 at Buy Side, User2 at Sell side- All users affirm their ASM price- Trade between User1 & User2 followed by trade between User3 &  User2 ', async () => {
    const securityId = 'USG5222MAC94';
    const securityDescription = 'KCADEU 9 5/8 04/01/23';
    const industrySector = Sector.ENERGY;
    const spread = 6;
    const size = 5000000;
    const userOneOrderSize = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, userOneOrderSize, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    const priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 affirm the ASM price first followed by User3');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice)
      , userOneOrderSize
      , parseFloat(asmPrice)
      , size
      , region
    );
    expectedTradePrice = Number.isInteger(expectedTradePrice) ? expectedTradePrice.toFixed(1) : expectedTradePrice;

    expect(tradedPrice).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(userOneOrderSize / SIZE_MULTIPLIER));

    let trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(trades[0].Size).to.equal(userTwoOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.SOLD);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(trades[0].Size).to.equal((userThreeOrder.RawOrderQty - userOneOrder.RawOrderQty).toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-008 - HYD-582- User1,User3 at Buy Side, User2,User4 at Sell side- All users accept ASM price except User1 at limit price-Trade between User1 and User2 at VWAP satifying the price followed by time logic ', async () => {
    const securityId = 'US12654TAA88';
    const securityDescription = 'CNXMPF 6 1/2 03/15/26';
    const industrySector = Sector.ENERGY;
    let orderMid = 100;
    const spread = 2;
    const size = 5000000;
    const userOneOrderSize = 1000000;
    const userTwoOrderSize = 2000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, userOneOrderSize, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel();
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, userTwoOrderSize, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty}, with limit price of ${userFourOrder.Price}  and direction of ${userFourOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel().hasOrders()
      , configuration.longTimeout
      , 'Timed out after \' + configuration.longTimeout + \' seconds, session panel has no orders.'
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    let priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 (Winner) affirms their ASM price first followed by User4 at Sell side');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User4 at ${userFourOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userFourOrder.OrderQty}`);

    priceToAffirm = userOneOrder.Price;
    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 (Winner) affirms their Limit price (Best price) at Buy side ');

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradePanel = hydraPageModel.getTrades(true);

    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(userOneOrder.Price)
      , userOneOrderSize
      , parseFloat(asmPrice)
      , userTwoOrderSize
      , region
    );
    logger.info('ExpectedTradePrice is', expectedTradePrice);
    expect(tradedPrice).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    expectedTradePrice = Number.isInteger(parseFloat(expectedTradePrice)) ? parseFloat(expectedTradePrice).toFixed(1) : parseFloat(expectedTradePrice);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePrice));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(parseFloat(expectedTradePrice).toFixed(2)));
    expect(trades[0].Size).to.equal(userOneOrderSize.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.SOLD);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-009 - HYD-537- User2,User3 at Buy Side, User1 at Sell side- All users accept ASM price except User2 at limit price-Trade between User1 and User2, Cleanup phase with residual size for User1', async () => {
    const securityId = 'US66978CAB81';
    const securityDescription = 'NOGLN 8 07/25/22';
    const industrySector = Sector.ENERGY;
    let orderMid = 100.5;
    const spread = 1;
    const size = 5000000;
    const userOneOrderSize = 2000000;
    const userTwoOrderSize = 1000000;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Calculated ASM/ Weighted price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    orderMid = parseInt(calculatedAsmPrice, 10);
    logger.info(`Calculated ASM /Weighted  price ${orderMid} is used as OrderMid`);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, userOneOrderSize, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, userTwoOrderSize, 'IG', region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    let priceToAffirm = asmPrice;
    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 (Winner) affirms their ASM price first followed by User4 at Sell side');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    priceToAffirm = userTwoOrder.Price;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${userTwoOrder.Price} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 (Winner) affirms their Limit price (Best price) at Buy side ');

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(userTwoOrder.Price)
      , userTwoOrderSize
      , parseFloat(asmPrice)
      , userOneOrderSize
      , region
    );
    expectedTradePrice = Number.isInteger(expectedTradePrice) ? expectedTradePrice.toFixed(1) : parseFloat(expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(userTwoOrderSize / SIZE_MULTIPLIER));

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePrice));
    expect(trades[0].Size).to.equal(userTwoOrderSize.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    await hydraPageModel.getPortfolio(true);
    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-011 - HYD-538 - User1 with residual size in Cleanup phase cancel his order at Traded Level price-Test to check if Order drops back to Portfolio ', async () => {
    const securityId = 'USU2937LAE49';
    const securityDescription = 'EPENEG 9 3/8 05/01/24';
    const industrySector = Sector.ENERGY;
    let orderMid = 100.5;
    const spread = 4;
    const size = 5000000;
    const userOneOrderSize = 2000000;
    const userTwoOrderSize = 1000000;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, userOneOrderSize, rating, region);
    await hydraPageModel.getPortfolio(true);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, userTwoOrderSize, 'IG', region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    let priceToAffirm = asmPrice;
    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 (Winner) affirms their ASM price first followed by User4 at Sell side');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.RawOrderQty}`);

    priceToAffirm = userTwoOrder.Price;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${userTwoOrder.Price} for size of ${userTwoOrder.RawOrderQty}`);
    logger.info('User2 (Winner) affirms their Limit price (Best price) at Buy side ');

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase`);

    const tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(userTwoOrder.Price)
      , userTwoOrderSize
      , parseFloat(asmPrice)
      , userOneOrderSize
      , region
    );
    expectedTradePrice = Number.isInteger(expectedTradePrice) ? expectedTradePrice.toFixed(1) : parseFloat(expectedTradePrice);
    logger.info('Expected Trade price is', expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(Math.abs(userTwoOrderSize / SIZE_MULTIPLIER)));
    logger.info('TradedPrice and Traded size matches for User1');

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .cancelTradedLevelPrice();
    logger.info(`User 1 with remaining size of ${sizeInCleanupPhaseForUserOne} and direction of ${userOneOrder.Side} cancels his Order at TradedLevel`);

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User 1 with remaining size of ${sizeInCleanupPhaseForUserOne} and direction of ${userOneOrder.Side} side dropped to Portfolio Panel after Cancellation`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    await hydraPageModel.getPortfolio(true);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-012 - HYD-537- Test to check if Fully Filled User1 can again trade at Traded Level and remaining size gets updated for User1  ', async () => {
    const securityId = 'XS1501167164';
    const securityDescription = 'TOTAL 2.708 PERP';
    const industrySector = Sector.ENERGY;
    const spread = 3;
    const size = 5000000;
    const userOneOrderSize = 1000000;
    const userOneTradedLevelDirection = 'Buy';
    const userOneTradedLevelSize = '3000';
    const userThreeOrderSize = 4000000;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, userThreeOrderSize, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, userOneOrderSize, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    const priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    const tradingSessionId = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getTradingSessionId();

    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 affirm the ASM price first followed by User3');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    let hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    let tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    let tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice)
      , userOneOrderSize
      , parseFloat(asmPrice)
      , size
      , region
    );
    expectedTradePrice = Number.isInteger(expectedTradePrice) ? expectedTradePrice.toFixed(1) : parseFloat(expectedTradePrice);
    logger.info('Expected Trade price is', expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(userOneOrderSize / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    const tradedLevelPrice = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getTradedLevelPrice(String(expectedTradePrice));
    expect(String(parseFloat(tradedLevelPrice))).to.equal(String(parseFloat(expectedTradePrice)));
    logger.info('TradedLevelPrice is', tradedLevelPrice);

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptTradedLevelPrice(userOneTradedLevelSize, userOneTradedLevelDirection);
    logger.info(`User1 accepts Traded Level Price of ${tradedLevelPrice} with Direction of ${userOneTradedLevelDirection} and size at ${userOneTradedLevelSize}`);

    const tradedLevelOrderForUserTwo = {
      SecurityID        : securityId,
      Side              : 'sell',
      RawOrderQty       : 2000000,
      Price             : tradedLevelPrice,
      TradingSessionID  : tradingSessionId,
      NoTradingSessions : '1'
    };

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .createTradedLevelOrder([tradedLevelOrderForUserTwo]);
    logger.info(`User2 accepts Traded Level Price of ${tradedLevelPrice} with Direction of ${tradedLevelOrderForUserTwo.Side} and size at ${tradedLevelOrderForUserTwo.RawOrderQty}`);

    await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);
    tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(tradedLevelOrderForUserTwo.RawOrderQty / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase after User1 traded with User2 at Traded Level`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-013 -HYD-537- Test to check the Time Priority -if Partially Filled User1 can again trade at Traded Level satisfying time priority ', async () => {
    const securityId = 'US12532MAA18';
    const securityDescription = 'CGGFP 9 05/01/23';
    const industrySector = Sector.ENERGY;
    const spread = 6;
    const size = 5000000;
    const userThreeOrderSize = 1000000;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, userThreeOrderSize, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, userThreeOrderSize, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'IG', region);
    await hydraPageModel.getPortfolio(true);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);
    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel();
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    const priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    const tradingSessionId = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getTradingSessionId();

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);
    logger.info('User3 affirm the ASM price first followed by User1');

    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating, true)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase after User1 traded with User2 `);

    let tradePanel = hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    let hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    let tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    let tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice)
      , userThreeOrderSize
      , parseFloat(asmPrice)
      , size
      , region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String((size - userThreeOrderSize) / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);

    await browser.pause(configuration.veryShortTimeout);
    const tradedLevelPrice = await hydraPageModel.getSessionPanel(true)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getTradedLevelPrice();
    expect(String(parseFloat(tradedLevelPrice))).to.equal(String(parseFloat(expectedTradePrice)));

    const tradedLevelOrderForUserThree = {
      SecurityID        : securityId,
      Side              : 'buy',
      RawOrderQty       : 1000000,
      Price             : tradedLevelPrice,
      TradingSessionID  : tradingSessionId,
      NoTradingSessions : '1'
    };
    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .createTradedLevelOrder([tradedLevelOrderForUserThree]);
    logger.info(`User3 accepts Traded Level Price of ${tradedLevelPrice} with Direction of ${tradedLevelOrderForUserThree.Side} and size at ${tradedLevelOrderForUserThree.RawOrderQty}`);

    const tradedLevelOrderForUserTwo = {
      SecurityID        : securityId,
      Side              : 'sell',
      RawOrderQty       : 1000000,
      Price             : tradedLevelPrice,
      TradingSessionID  : tradingSessionId,
      NoTradingSessions : '1'
    };

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .createTradedLevelOrder([tradedLevelOrderForUserTwo]);
    logger.info(`User2 accepts Traded Level Price of ${tradedLevelPrice} with Direction of ${tradedLevelOrderForUserTwo.Side} and size at ${tradedLevelOrderForUserTwo.RawOrderQty}`);

    tradePanel = await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);
    await tradePanel.handleMinimised();
    hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(tradedLevelOrderForUserTwo.RawOrderQty / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-014 -HYD-538 - User1 with residual size in Cleanup phase cancel his order at Traded Level price- Changes his direction and Trades again at TradedLevel price ', async () => {
    const securityId = 'US48244LAA61';
    const securityDescription = 'KCADEU 7 1/4 05/15/21';
    const industrySector = Sector.ENERGY;
    let orderMid = 100.5;
    const spread = 8;
    const size = 5000000;
    const userOneOrderSize = 2000000;
    const userTwoOrderSize = 1000000;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    const userOneTradedLevelEnteredSize = 2000;
    const userOneTradedLevelChangedDirection = 'Buy';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, userOneOrderSize, rating, region);
    await hydraPageModel.getPortfolio(true);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, userTwoOrderSize, 'IG', region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    const tradingSessionId = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getTradingSessionId();

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptAsm();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 (Winner) affirms their ASM price at Sell side');

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(asmPrice);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${asmPrice} for size of ${userThreeOrder.OrderQty}`);

    const priceToAffirm = userTwoOrder.Price;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${userTwoOrder.Price} for size of ${userTwoOrder.OrderQty}`);
    logger.info('User2 (Winner) affirms their Limit price (Best price) at Buy side ');

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} during Cleanup phase`);

    let tradePanel = await hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    let hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    let tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    let tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = calculateVWAP(
      parseFloat(userTwoOrder.Price)
      , userTwoOrderSize
      , parseFloat(asmPrice)
      , userOneOrderSize
      , region
    );
    expectedTradePrice = parseFloat(expectedTradePrice);

    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(String(userTwoOrderSize / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .cancelTradedLevelPrice();
    logger.info(`User 1 with remaining size of ${sizeInCleanupPhaseForUserOne} and direction of ${userOneOrder.Side} cancels his Order at TradedLevel`);

    await hydraPageModel.getPortfolio(true);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User 1 with remaining size of ${sizeInCleanupPhaseForUserOne} and direction of ${userOneOrder.Side} side dropped to Portfolio Panel after Cancellation`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    const tradedLevelPrice = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getTradedLevelPrice();
    expect(String(parseFloat(tradedLevelPrice))).to.equal(String(parseFloat(expectedTradePrice)));

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptTradedLevelPrice(userOneTradedLevelEnteredSize, userOneTradedLevelChangedDirection);
    logger.info(`User 1 accepts Traded Level price with size of ${userOneTradedLevelEnteredSize} and changed direction to be ${userOneTradedLevelChangedDirection}`);

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .hasSize()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Session panel has no remaining size for User1.`
    );

    sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(String(userOneTradedLevelEnteredSize));
    logger.info(`User 1 has remaining size of ${sizeInCleanupPhaseForUserOne} in changed direction with ${userOneTradedLevelChangedDirection} side `);

    const tradedLevelOrderForUserTwo = {
      SecurityID        : securityId,
      Side              : 'sell',
      RawOrderQty       : 1000000,
      Price             : tradedLevelPrice,
      TradingSessionID  : tradingSessionId,
      NoTradingSessions : '1'
    };

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .createTradedLevelOrder([tradedLevelOrderForUserTwo]);
    logger.info(`User 2 accepts Traded Level Price of ${tradedLevelPrice} with Direction of ${tradedLevelOrderForUserTwo.Side} and size at ${tradedLevelOrderForUserTwo.RawOrderQty}`);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .hasSize(true)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Session panel has no remaining size for User1.`
    );

    sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(String(userOneTradedLevelEnteredSize - tradedLevelOrderForUserTwo.RawOrderQty / SIZE_MULTIPLIER));
    logger.info(`User 1 has remaining size of ${sizeInCleanupPhaseForUserOne} in changed direction with ${userOneTradedLevelChangedDirection} side after the trade `);

    await hydraPageModel.getTrades(true);
    await browser.pause(configuration.veryShortTimeout);
    tradePanel = await hydraPageModel.getTrades();
    hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(tradedLevelPrice)));
    expect(tradeSize).to.equal(String(tradedLevelOrderForUserTwo.RawOrderQty / SIZE_MULTIPLIER));
    logger.info('User 1 traded price and traded size matches the expected');

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    await hydraPageModel.getPortfolio(true);
    await browser.pause(configuration.veryShortTimeout);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(String(userOneTradedLevelEnteredSize - tradedLevelOrderForUserTwo.RawOrderQty / SIZE_MULTIPLIER));
    logger.info(`User 1 with remaining size of ${sizeInCleanupPhaseForUserOne} and direction of ${userOneTradedLevelChangedDirection} side dropped to Portfolio Panel after End of Session`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete(true);
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('MS-015 - User subscription-User subscribed to a sector and no orders in portfolio- User should be able to view and trade in cleanup', async () => {
    const securityId = 'US71647NAP42';
    const securityDescription = 'PETBRA 8 3/8 05/23/21';
    const industrySector = Sector.ENERGY;
    const spread = 6;
    const size = 5000000;
    const userThreeOrderSize = 1000000;
    const userOneTradedLevelEnteredSize = '4000';
    const userOneTradedLevelDirection = 'buy';
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, userThreeOrderSize, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, userThreeOrderSize, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    logger.info('User 1 did not add any orders to his Portfolio');
    await hydraPageModel.setUserSubscriptionRating(RATING.HIGH_YIELD);
    await hydraPageModel.setUserSubscriptionSector(industrySector);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    const priceToAffirm = asmPrice;
    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    const tradingSessionId = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getTradingSessionId();
    logger.info('TradingSessionId for this session', tradingSessionId);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    const expectedSessionPhasePlaceholderText = 'Waiting for the next phase to start';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .hasSessionPlaceHolderText()
      , configuration.veryShortTimeout
      , `Timed out after ${configuration.veryShortTimeout} seconds, Session panel has no waiting orders.`
    );

    const sessionPlaceHolderText = await hydraPageModel.getSessionPanel(rating)
      .getSessionPlaceHolderText();
    expect(sessionPlaceHolderText).to.equal(expectedSessionPhasePlaceholderText);
    logger.info(`User1 is shown with message as : ${sessionPlaceHolderText}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(true)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradedLevelPrice = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getTradedLevelPrice();
    logger.info('TradedLevelPrice is', tradedLevelPrice);

    await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptTradedLevelPrice(userOneTradedLevelEnteredSize, userOneTradedLevelDirection);
    logger.info(`User 1 accepts Traded Level price with size of ${userOneTradedLevelEnteredSize} and changed direction to be ${userOneTradedLevelDirection}`);


    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = await hydraPageModel.getTrades(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);


    expect(String(parseFloat(tradedPrice))).to.equal(String(parseFloat(tradedLevelPrice)));
    expect(tradeSize).to.equal(String(userOneTradedLevelEnteredSize));

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });
});
