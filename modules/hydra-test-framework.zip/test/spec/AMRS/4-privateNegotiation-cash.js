/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';

describe('Private negotiation tests - Cash Bonds', () => {
  // Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'manjit.bharaj.auto7@testing.fenicstools.com');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'manjit.bharaj.auto8@testing.fenicstools.com');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'manjit.bharaj.auto9@testing.fenicstools.com');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'manjit.bharaj.auto10@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('PN-003 - Spread 8 - ASM accepted by user1 but not by User 2 and if the Orders move back to Portfolio when PN session ends', async () => {
    const securityId = 'US92241TAM45';
    const securityDescription = 'VEDLN 6 1/8 08/09/24';
    let orderMid = 88;
    const spread = 8;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('HY');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('HY');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(userOneOrder.OrderQty);
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.false;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 2 portfolio panel is now empty.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-004 - Spread 2 - Scenario to test that User 1 accepts the price of User 2 during Private phase', async () => {
    const securityId = 'US92241TAG76';
    const securityDescription = 'VEDLN 8 1/4 06/07/21';
    let orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('HY');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('HY');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true);
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price}@${userTwoOrder.OrderQty}.`);

    await browser.pause(configuration.shortTimeout);
    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(String(userTwoOrder.RawOrderQty));
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 2 portfolio panel is now empty.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-005 - Spread 2 - User 1 accepts the price of User 2 But with lesser size during Private phase', async () => {
    const securityId = 'XS1648248455';
    const securityDescription = 'SHAEGZ 4.55 07/26/20';
    let orderMid = 80.25;
    const spread = 2;
    const size = 1000000;
    const acceptedSize = 500;
    const expectedQty = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [undefined];
    let actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for UserThree with ${userThreeOrder.Side} side is ${actualMarketDepth}.`);
    logger.info('User3 does not view the Market Depth in Action panel as he uploaded the order during Private phase');

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userTwoOrder.Price)), true, acceptedSize);
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price} at size of ${acceptedSize}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for UserThree with ${userThreeOrder.Side} side is ${actualMarketDepth}.`);
    logger.info('User3 does not view the Market Depth in Action panel as he uploaded the order during Private phase');

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(parseFloat(tradeSize)).to.equal(acceptedSize);

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(String(expectedQty));
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isActionEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isActionEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(parseFloat(remainingQuantity)).to.equal(acceptedSize);
    logger.info(`User 1 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(expectedQty);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PN-006 - Spread 2 - User 2 accepts the price of User 1 during Private phase', async () => {
    const securityId = 'XS1648248455';
    const securityDescription = 'SHAEGZ 4.55 07/26/20';
    let orderMid = 76.50;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(parseFloat(userTwoOrder.Price), true);
    logger.info(`User 1 hits user 2 bid for bond ${securityDescription} at ${userTwoOrder.Price}@${userTwoOrder.OrderQty}.`);

    await browser.pause(configuration.shortTimeout);
    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(String(Math.abs(userTwoOrder.OrderQty)));

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(String(userTwoOrder.RawOrderQty));
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-007 - Spread 2 - User 2 accepts the price of User 1 But with lesser size during Private phase', async () => {
    const securityId = 'US456837AF06';
    const securityDescription = 'INTNED 6 1/2 PERP';
    let orderMid = 66;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(parseFloat(userTwoOrder.Price), true, '500');
    logger.info(`User 1 hits user 2 bid for bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');
    logger.info(`User 1 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    const expectedQty = 500000;
    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(expectedQty);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-008 - Spread 2 - Scenario to test that ASM accepted by both users during Group Phase', async () => {
    const securityId = 'US00489LAA17';
    const securityDescription = 'ACRISU 7 11/15/25';
    let orderMid = 88;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(Math.abs(userOneOrder.OrderQty));
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, size);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(asmPrice);
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(String(userTwoOrder.RawOrderQty));
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  describe('PN-009 - Scenario to test that User2 and User3 are in competition and User1 / User3 can trade at Group Phase', () => {
    it('PN-009.001 - User 1 perspective / Buyer perspective', async () => {
      const securityId = 'CH0367013981';
      const securityDescription = 'BCG 2 PERP';
      let orderMid = 164.25;
      const spread = 4;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraApiClient.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );

      let weightings = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('HY');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('HY');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.veryShortTimeout);
      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userOneOrder.Price
        , userTwoOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      asmPrice = parseFloat(asmPrice);
      expect(asmPrice).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(asmPrice).to.equal(String(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(Math.abs(userOneOrder.OrderQty));
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(asmPrice);
      expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

      const expectedTradePriceForUser2 = parseFloat(asmPrice);
      const trades = await hydraApiClient
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser2));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal(String(userTwoOrder.RawOrderQty));
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClient.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PN-009.002 - User 2 perspective / Seller perspective Winner of pricing', async () => {
      const securityId = 'US90320MAA36';
      const securityDescription = 'UPCB 5 3/8 01/15/25';
      let orderMid = 99.25;
      const spread = 6;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraPageModel.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );

      let weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userTwoOrder.Price
        , userOneOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(asmPrice).to.equal(String(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 3 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      let tradePanel = hydraPageModel.getTrades();
      let hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 2 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      tradePanel = hydraPageModel.getTrades();
      hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 2 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      const isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');
    });

    it('PN-009.003 - User 3 perspective / Seller perspective Loser of pricing', async () => {
      const securityId = 'US892231AA90';
      const securityDescription = 'TSQ 6 1/2 04/01/23';
      let orderMid = 92.50;
      const spread = 4;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraApiClient.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      let weightings = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('HY');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('HY');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(asmPrice).to.equal('');
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [undefined];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [undefined];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userTwoOrder.Price
        , userOneOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('1000');
      logger.info(`User 3 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      let tradePanel = hydraPageModel.getTrades();
      let hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 3 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      tradePanel = hydraPageModel.getTrades();
      hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 3 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info('User 3 portfolio panel is now empty.');

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info('User 3 portfolio panel is now empty.');

      expect(tradedPrice).to.equal(asmPrice);
      expect(tradeSize).to.equal('1000');

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClient.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now not empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now not empty.');
    });
  });

  it('PN-010 - Spread 8 - User1 and User2 accept ASM price at lesser quantity during private phase.', async () => {
    const securityId = 'US06675QAB95';
    const securityDescription = 'BOAD 5 07/27/27';
    let orderMid = 97.50;
    const spread = 8;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await browser.pause(configuration.veryShortTimeout);
    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('500');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice} for 500000.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, size);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice} for ${userTwoOrder.OrderQty}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(asmPrice);
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');
    logger.info(`User 1 remaining portfolio quantity for bond ${securityDescription} is ${remainingQuantity}.`);

    const expectedQty = 500000;
    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(expectedQty);
    logger.info(`User 2 remaining portfolio quantity for bond ${securityDescription} is ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-011 - Spread 2 - User1 and User2 amend the Size during PricingPage phase and then accept ASM price with Amended quantity during private phase', async () => {
    const securityId = 'US87724LAA35';
    const securityDescription = 'TMHC 5 7/8 04/15/23';
    let orderMid = 355.75;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 1500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setSize('1500');
    logger.info(`User 1 amends size of bond ${securityDescription} to ${sizeTwo}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('1500');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${sizeTwo}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, sizeTwo);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${sizeTwo}.`);

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(asmPrice);
    expect(tradeSize).to.equal('1500');

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(parseFloat(trades[0].Price)).to.equal(expectedTradePriceForUser2);
    expect(trades[0].Size).to.equal('1500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-012 - Spread 2 - User1 ignores during PricingPage Phase and Order moving back to Portfolio', async () => {
    const securityId = 'US81211KAK60';
    const securityDescription = 'SEE 6 7/8 07/15/33';
    let orderMid = 255;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession();
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-014 - Assert the prompt: Cannot Ignore during Private Phase', async () => {
    const securityId = 'US466023AB45';
    const securityDescription = 'BANORT 9 1/4 10/14/20';
    let orderMid = 155;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    const notificationAlertPrompt = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getNotificationAlertBodyText();
    expect(notificationAlertPrompt).to.equal('Cannot cancel order during Private phase if best order');
    logger.info(`User 1 presented with alert: '${notificationAlertPrompt}'.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const isIgnoreButtonEnabled = false;
    let validateIgnoreButton = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession(isIgnoreButtonEnabled);
    expect(validateIgnoreButton).to.be.false;
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    validateIgnoreButton = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession(isIgnoreButtonEnabled);
    expect(validateIgnoreButton).to.be.true;
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  // Test fails due to HYD-1241
  it('PN-019 - Scenario to test submitted price is Crossable and gets traded at Mathematical midpoint price-Fully Fill', async () => {
    const securityId = 'USU71663AC99';
    const securityDescription = 'PETM 8 7/8 06/01/25';
    let orderMid = 100;
    const spread = 8;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradedPrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    logger.info('Expected Traded price before appying rounding', expectedTradedPrice);

    expectedTradedPrice = roundToTick(expectedTradedPrice, region.PRICE_INCREMENT_MIN_PRICE_TICKS, region.PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT);
    logger.info('Expected Traded price after appying rounding', expectedTradedPrice);

    expect(String(parseFloat(tradedPrice))).to.equal(String(expectedTradedPrice));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradedPrice));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradedPrice));
    expect(trades[0].Size).to.equal(String(userTwoOrder.RawOrderQty));
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  // Manual Test available for this
  it.skip('PN-021- Test to check the Glow Functionality', async () => {
    /*
     * 1. Login to Hydra application
     * 2. User1 uploads a ISIN with Buy Side and size of 1m
     * 3. User2 uploads a ISIN with Sell Side and size of 1m
     * 4. Both User1 and User2 sharpen their prices to be 100
     * 4. Expected Result:
     * ASM price should glow as trade got executed at the ASM price(100) for both the users
     * Trade should get executed at ASM price and available in My Trades panel for both users
     */
  });

  // Manual Test available for this
  it.skip('PN-022 - Test to check the Yellow Flash Functionality', async () => {
    /*
     * 1. Login to Hydra application
     * 2. User1 uploads a ISIN with Buy Side and size of 1m
     * 3. User2 uploads a ISIN with Sell Side and size of 1m
     * 4. ASM is displayed during Private phase
     * 5. User2 then improves the Offer price
     * 6. ASM should then be amended
     * 4. Expected Result:
     * ASM should flash yellow and should get amended to new price
     */
  });

  // Manual Test available for this
  it.skip('PN-023 - Public Toggle On/Off functionality', async () => {
    /*
     * Public Toggle is ON Functionality
     * 1. During PricingPage or Private or Group phase, ensure that both the Users ( User1 and User2)
     * set the Public Toggle as ON
     * 2. When the PN ends assuming there is no action during PN phase, when order moves back to Portfolio
     * CLOB should get started
     *
     * Public Toggle is OFF Functionality
     * 1. During PricingPage or Private or Group phase, ensure that both the Users ( User1 and User2)
     * set the Public Toggle as Off . It is off by default
     * 2. When the PN ends assuming there is no action during PN phase, when order moves back to Portfolio
     * CLOB should Not get started
     */
  });

  it('PN-025 - ASM gets recalculated when StandbyUser with Lit Bid price crosses current ASM during Group Phase, check inverted order on price crossing ASM', async () => {
    const securityId = 'USU63127AC54';
    const securityDescription = 'NMG 14 04/25/24';
    let orderMid = 118.75;
    const spread = 3;
    const size = 3000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userTwoOrder.Price)), true, 500);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.25;
    const userThreeImprovedPrice = roundToTick(parseFloat(asmPrice) + parseFloat(priceDiff), region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeImprovedPrice);
    logger.info(`User 3 improves his Bid price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    let recalculatedAsmPrice = ((parseFloat(userThreeImprovedPrice) + parseFloat(userTwoOrder.Price)) / 2).toFixed(2);
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('PN-026 - ASM recalculation when StandbyUser amends the price to equal the Current ASM during Group Phase', () => {
    it('PN-026.001 - ASM gets recalculated When Lit Order(Lit Bid price) equals current ASM during Group Phase, check inverted order on price crossing ASM', async () => {
      const securityId = 'US398905AL33';
      const securityDescription = 'GPI 5 1/4 12/15/23';
      let orderMid = 93.25;
      const spread = 4;
      const spreadTwo = 3;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      let weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spreadTwo, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings();

      weightedPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userOneOrder.Price
        , userTwoOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptSellSideOrder(String(userTwoOrder.Price), true, 500);
      logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

      await browser.pause(configuration.veryShortTimeout);
      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(asmPrice);
      logger.info(`User 3 set his Bid price of bond ${securityDescription} to ${asmPrice}.`);

      let recalculatedAsmPrice = ((parseFloat(asmPrice) + parseFloat(userTwoOrder.Price)) / 2).toFixed(2);
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

      await browser.pause(configuration.shortTimeout);
      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(userTwoOrder.Price));
      expect(tradeSize).to.equal('500');

      const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser2));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('500000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PN-026.002 - ASM gets recalculated When Lit Order(Lit Offer price) equals current ASM during Group Phase-Standby user trying to improve in Private phase ', async () => {
      const securityId = 'US640204AB95';
      const securityDescription = 'NMG 7 1/8 06/01/28';
      let orderMid = 320;
      const spread = 5;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      let weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);

      weightedPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userTwoOrder.Price
        , userThreeOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(asmPrice);
      logger.info(`User 1 set his Offer price of bond ${securityDescription} to ${asmPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let recalculatedAsmPrice = ((parseFloat(asmPrice) + parseFloat(userThreeOrder.Price)) / 2).toFixed(2);
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User1 improves his price will be :${recalculatedAsmPrice}`);

      await browser.pause(configuration.shortTimeout);
      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  it('PN-028 - ASM does not get recalculated When Lit Order(Lit Bid price) do not cross ASM during Group Phase, check inverted order on price crossing ASM', async () => {
    const securityId = 'US04021LAA89';
    const securityDescription = 'PETM 7 1/8 03/15/23';
    let orderMid = 127;
    const spread = 8;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3  set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(userThreeOrder.Price), true, 500);
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price} for 0.5M.`);

    await browser.pause(configuration.veryShortTimeout);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.5;
    let user2ImprovedPrice = parseFloat(asmPrice) - parseFloat(priceDiff);
    user2ImprovedPrice = roundToTick(user2ImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`User 2 improves his Bid price of bond ${securityDescription} to ${user2ImprovedPrice}.`);

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(user2ImprovedPrice);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    logger.info(`Expected asmPrice for UI user after User2 improves his Bid price will be :${calculatedAsmPrice}`);
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(userThreeOrder.Price));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price).toFixed(2);
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PN-029 - ASM Blanks out when it is fully filled for one of the users (1 sided interest) during Group Phase', async () => {
    const securityId = 'US90470TAA60';
    const securityDescription = 'UNIFIN 7 1/4 09/27/23';
    let orderMid = 262;
    const spread = 4;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', 2, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`asmPrice displayed in the UI -based on the Weighted Average ASM calculation method is :${asmPrice}`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userThreeOrder.Price)), true, '500');
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price} for 0.5M.`);

    await browser.pause(configuration.veryShortTimeout);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    logger.info(`Actual ASM after the trade execution and after there is only one side is :${asmPrice}`);
    expect(asmPrice).to.equal('');

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userThreeOrder.Price)));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-030 - ASM Does Not recalculate when Lit Order cancelled by one of the user and there is no improvement of Price', async () => {
    const securityId = 'XS0737513738';
    const securityDescription = 'IBRD 0 1/2 02/24/22';
    let orderMid = 320;
    const spread = 5;
    const size = 1000000;
    const sizeTwo = 5000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 1, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(parseFloat(remainingQuantity)).to.equal(1000);

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-031 - ASM recalculates in Group phase when there are 2 sided interest after ASM blanked out during Private Phase', async () => {
    const securityId = 'USU63127AC54';
    const securityDescription = 'NMG 14 04/25/24';
    let orderMid = 262;
    const spread = 8;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(parseFloat(actualMarketDepth.length)).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userThreeOrder.Price)), true, 500);
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price} for 0.5M.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect('').to.equal(asmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let recalculatedAsmPrice = (parseFloat(userTwoOrder.Price) + parseFloat(userOneOrder.Price)) / 2;
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`Expected ASM in Group phase based on Best Bid / Offer after recalculation when it is 2 sided :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userThreeOrder.Price)));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price).toFixed(2);
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  describe('PN-051 - Trade execution when StandbyUser amends price to equal the best resting lit bid', () => {
    it('PN-051.001 - StandbyUser amends price to equal the best resting lit bid during Private phase - Trade execution', async () => {
      const securityId = 'USU85887AA26';
      const securityDescription = 'STER 8 1/8 11/01/21';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'HY';

      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const userOneImprovedPrice = userThreeOrder.Price;

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(parseFloat(userThreeOrder.Price)));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PN-051.002 - StandbyUser amends price to equal the best resting lit bid during Group phase - Trade execution', async () => {
      const securityId = 'CH0286864027';
      const securityDescription = 'UBS 6 7/8 PERP';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const userOneImprovedPrice = userThreeOrder.Price;

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.pause(configuration.shortTimeout);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(parseFloat(userThreeOrder.Price)));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  describe('PN-054 - Trade execution when StandbyUser amends offer price to cross the best resting lit bid', () => {
    // Failing due to HYD-1241
    it('PN-054.001 - StandbyUser amends Offer price to cross the best resting lit bid during Private phase - Trade execution at mathematical midpoint', async () => {
      const securityId = 'XS1199688109';
      const securityDescription = 'BACR 0 04/27/20';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      let userOneImprovedPrice = parseFloat(userThreeOrder.Price) - parseFloat(1.0);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradePrice = (parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2;
      expect(parseFloat(tradedPrice)).to.equal(expectedTradePrice);
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser3 = expectedTradePrice;
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PN-054.002 - StandbyUser amends Offer price to cross the best resting lit bid during Group phase - Trade execution', async () => {
      const securityId = 'XS0869252816';
      const securityDescription = 'WSTP 0 12/27/27';
      let orderMid = 175;
      const spread = 8;
      const size = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let userOneImprovedPrice = parseFloat(userThreeOrder.Price) - parseFloat(1.0);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(parseFloat(userThreeOrder.Price)));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser3 = userThreeOrder.Price;
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  it('PN-055 - StandbyUser amends Offer price to cross the best resting lit bid during Private phase  - Trade execution at mathematical midpoint with StandbyUser(Fully filled) and PN continues with other users', async () => {
    const securityId = 'XS0868458653';
    const securityDescription = 'TITIM 4 01/21/20';
    let orderMid = 175;
    const spread = 5;
    const size = 5000000;
    const sizeTwo = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    let userOneImprovedPrice = parseFloat(userThreeOrder.Price) - parseFloat(1.0);
    userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneImprovedPrice);
    logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    const expectedTradePrice = (parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2;
    expect(parseFloat(tradedPrice)).to.equal(expectedTradePrice);
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser3 = expectedTradePrice;
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('PN-056 - Sweep logic functionality when Active user in PN amend their price to cross best resting price -Basic Inverted Order', () => {
    it('PN-056.001 - Active user in PN amend Bid price to cross the best resting lit Offer during Private phase - Trade execution at best resting lit Offer with ASM to be blank in Private and PN continues with Active User vs Standby User in Group phase', async () => {
      const securityId = 'US62886EAJ73';
      const securityDescription = 'NCR 5 07/15/22';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 5000000;
      const sizeThree = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await browser.pause(configuration.shortTimeout);
      let userOneImprovedPrice = parseFloat(userTwoOrder.Price) + parseFloat(1.0);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
      expect(tradeSize).to.equal('5000');

      const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('5000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as User1 is now Single Sided.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.pause(configuration.shortTimeout);
      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PN-056.002 - Active user in PN amend Bid price to cross the best resting lit Offer during Group phase - Trade execution at best resting lit Offer and PN continues with Active User vs Standby User in Group phase', async () => {
      const securityId = 'XS1205619288';
      const securityDescription = 'BHCCN 4 1/2 05/15/23';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 5000000;
      const sizeThree = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.shortTimeout);
      let userOneImprovedPrice = parseFloat(userTwoOrder.Price) + parseFloat(1.0);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
      expect(tradeSize).to.equal('5000');

      const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('5000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      let recalculatedAsmPrice = ((parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2).toFixed(2);
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.pause(configuration.shortTimeout);
      await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  describe('PN-057 - Sweep logic functionality when Active user in PN amend their price to cross the best resting price', () => {
    it('PN-057.001 - Active user in PN amend Bid price to cross the best resting lit Offer during Private phase - Trade execution-Sweep between ASM order and best resting lit Offer', async () => {
      const securityId = 'US92241TAM45';
      const securityDescription = 'VEDLN 6 1/8 08/09/24';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 3000000;
      const sizeThree = 5000000;
      const sizeFour = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, sizeFour);
      logger.info(`User2 accepts ASM price of ${asmPrice} at ${sizeFour}`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = roundToTick(parseFloat(userTwoOrder.Price) + parseFloat(1.0), region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      await browser.pause(configuration.shortTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const expectedTradedPrice = [parseFloat(userTwoOrder.Price), parseFloat(asmPrice)];
      const expectedTradedSize = ['1000', '2000'];
      const countOfTrades = await browser.waitUntil(() => tradePanel
        .getOrderRowCount(securityDescription));
      expect(countOfTrades).to.equal(expectedTradedSize.length);
      logger.info('Count of Trades occured is', countOfTrades);
      await browser.pause(configuration.shortTimeout);
      for (let sizeCount = 0; sizeCount < expectedTradedSize.length; sizeCount += 1) {
        const tradedPrice = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getPrice();
        logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

        const tradeSize = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getSize();
        logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

        expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrice);
        expect(tradeSize).to.be.oneOf(expectedTradedSize);
      }

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.pause(configuration.shortTimeout);
      await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PN-057.002 - Active user in PN amend Bid price to cross the best resting lit Offer during Group phase - Trade execution - Sweep between ASM order and best resting lit Offer', async () => {
      const securityId = 'DE000A2AAPF1';
      const securityDescription = 'TKAGR 2 3/4 03/08/21';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 3000000;
      const sizeThree = 5000000;
      const sizeFour = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, sizeFour);
      logger.info(`User2 accepts ASM price of ${asmPrice} at ${sizeFour}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const priceDiff = 1.0;
      let userOneImprovedPrice = parseFloat(userTwoOrder.Price) + parseFloat(priceDiff);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const expectedTradedPrice = [parseFloat(userTwoOrder.Price), parseFloat(asmPrice)];
      const expectedTradedSize = ['1000', '2000'];
      const countOfTrades = await browser.waitUntil(() => tradePanel
        .getOrderRowCount(securityDescription));
      expect(countOfTrades).to.equal(expectedTradedSize.length);
      logger.info('Count of Trades occured is', countOfTrades);
      await browser.pause(configuration.shortTimeout);
      for (let sizeCount = 0; sizeCount < expectedTradedSize.length; sizeCount += 1) {
        const rowTradedPrice = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getPrice();
        logger.info(`User 1 traded bond ${securityDescription} with price of ${rowTradedPrice}.`);

        const tradeSize = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getSize();
        logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

        expect(parseFloat(rowTradedPrice)).to.be.oneOf(expectedTradedPrice);
        expect(tradeSize).to.be.oneOf(expectedTradedSize);
      }

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  describe('PN-058 - Active user in PN amend Offer price to cross the best resting lit Bid- Sweep between Best resting Bid and StandbyUser', () => {
    it('PN-058.001 - Active user in PN amend Offer price to cross the best resting lit Bid during Private phase - Trade execution- Sweep between best resting lit Bid and StandbyUser  ', async () => {
      const securityId = 'US06747NQ983';
      const securityDescription = 'BACR Float 11/29/22';
      let orderMid = 175;
      const spread = 5;
      const size = 2000000;
      const sizeTwo = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      let userOneImprovedPrice = parseFloat(userThreeOrder.Price);
      userOneImprovedPrice = roundToTick(userOneImprovedPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button "Yes"');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrices = [parseFloat(userOneImprovedPrice), parseFloat(userTwoOrder.Price)];
      expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.equal('1000');

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as all users are fully filled`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PN-058.002 - Active user in PN amend Offer price to cross the best resting lit Bid during Group phase - Trade execution- Sweep between best resting lit Bid and StandbyUser  ', async () => {
      const securityId = 'USU74902AG90';
      const securityDescription = 'QWECOM 7 5/8 08/03/21';
      let orderMid = 175;
      const spread = 5;
      const size = 2000000;
      const sizeTwo = 1000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = roundToTick(parseFloat(userThreeOrder.Price), region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrices = [parseFloat(userOneImprovedPrice), parseFloat(userTwoOrder.Price)];
      expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.equal('1000');

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as all users are fully filled`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  it('PN-060 - Active user in PN delete their Bid order during Group phase - ASM should not get recalculated when the next best bid do not cross ASM', async () => {
    const securityId = 'US55448QAQ91';
    const securityDescription = 'CLI 4 1/2 04/18/22';
    let orderMid = 175;
    const spread = 6;
    const size = 10000000;
    const sizeTwo = 5000000;
    const sizeThree = 3000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 2, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .deleteForSession();
    logger.info(`User 1 clicks the delete button for bond ${securityDescription}.`);
    await browser.pause(configuration.shortTimeout);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-061 - Test to check the Price followed by time logic when there is matched price  ', async () => {
    const securityId = 'US421924BN03';
    const securityDescription = 'EHC 5 1/8 03/15/23';
    let orderMid = 175;
    const spread = 0;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(false);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal('1000');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    const portfolioBondCount = await hydraApiClientUserThree
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(size);
    logger.info(`User 3 did not trade with bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PN-062 - Standby user in PN delete their Bid order during Private phase - ', async () => {
    const securityId = 'US80874YAM21';
    const securityDescription = 'SGMS 6 1/4 09/01/20';
    let orderMid = 100;
    const spread = 2;
    const size = 10000000;
    const sizeTwo = 500000;
    const sizeThree = 3000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userThreeOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .deleteForSession();
    logger.info(`User 1 clicks the delete button for bond ${securityDescription}.`);
    logger.info('On clicking the delete button - Order moves back to Portfolio for User1');
    await browser.pause(configuration.shortTimeout);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  it('PN-063 - Active participant in Private phase fully filled, PN should continue in Group phase with Single Sided participants ', async () => {
    const securityId = 'USG7223AAC02';
    const securityDescription = 'PRETSL Float 12/22/36';
    let orderMid = 118.75;
    const spread = 8;
    const size = 3000000;
    const sizeTwo = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userTwoOrder.Price)), true, 500);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice} as it is Single Sided.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice} as it is Single Sided.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.pause(configuration.shortTimeout);
    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('PN-066- Scenarios to test Price followed by Time logic with multiple users', () => {
    it('PN-066.001 -HYD-241 Scenario 2- Trade execution when there are Matched and Crossed orders for multi users- Price followed by time logic', async () => {
      const securityId = 'US389375AK26';
      const securityDescription = 'GTN 5 1/8 10/15/24';
      let orderMid = 175;
      const spread = 4;
      const size = 1000000;
      const sizeTwo = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);

      const weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      const userTwoOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserFour.addOrders([userFourOrder]);
      logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

      const userFiveOrder = getNewOrder(securityId, 'sell', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserFive.addOrders([userFiveOrder]);
      logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

      const userSixOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserSix.addOrders([userSixOrder]);
      logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      userFourOrder.Price = userOneOrder.Price - 1;
      await hydraApiClientUserFour.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFourOrder.Price);
      logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserFive.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFiveOrder.Price);
      logger.info(`User 5 set Offer price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserSix.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userSixOrder.Price);
      logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userFiveOrder.Price)];
      actualMarketDepth = await hydraApiClientUserFive.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userFiveOrder.Side} side is ${actualMarketDepth}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrice = userOneOrder.Price;

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradedPrice));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser2 = ((parseFloat(userTwoOrder.Price) + parseFloat(userFourOrder.Price)) / 2).toFixed(2);
      let trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(trades[0].Price).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const expectedTradePriceForUser4 = ((parseFloat(userTwoOrder.Price) + parseFloat(userFourOrder.Price)) / 2).toFixed(2);
      trades = await hydraApiClientUserFour
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(trades[0].Price).to.equal(String(expectedTradePriceForUser4));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Portfolio panel has no orders.`
      );

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      await hydraApiClientUserFive.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 5 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserFive.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 5 portfolio panel is now empty.');

      await hydraApiClientUserSix.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 6 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserSix.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 6 portfolio panel is now empty.');
    });

    it('PN-066.002 -HYD-241 Scenario 3- Trade execution when there are Matched and Crossed orders for multi users- Price followed by time logic', async () => {
      const securityId = 'USU63127AC54';
      const securityDescription = 'NMG 14 04/25/24';
      let orderMid = 175;
      const spread = 4;
      const size = 1000000;
      const sizeTwo = 2000000;
      const rating = 'HY';
      const region = TICK_CONFIGURATION.US.HY;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);

      const weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings();
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, sizeTwo, rating, region);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      const userTwoOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserFour.addOrders([userFourOrder]);
      logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

      const userFiveOrder = getNewOrder(securityId, 'sell', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserFive.addOrders([userFiveOrder]);
      logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

      const userSixOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserSix.addOrders([userSixOrder]);
      logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      userFourOrder.Price = userOneOrder.Price - 1;
      await hydraApiClientUserFour.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFourOrder.Price);
      logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

      await hydraApiClientUserFive.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFiveOrder.Price);
      logger.info(`User 5 set Offer price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserSix.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userSixOrder.Price);
      logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userSixOrder.Price)];
      actualMarketDepth = await hydraApiClientUserSix.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userSixOrder.Side} side is ${actualMarketDepth}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPriceForUser1 = parseFloat(userOneOrder.Price);

      expect(tradedPrice).to.equal(String(expectedTradedPriceForUser1));
      expect(tradeSize).to.equal('2000');

      const expectedTradePriceForUser5 = parseFloat(userOneOrder.Price);
      let trades = await hydraApiClientUserFive
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(parseFloat(trades[0].Price)).to.equal(expectedTradePriceForUser5);
      expect(trades[0].Size).to.equal('2000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const expectedTradePriceForUser2 = (parseFloat(userTwoOrder.Price) + parseFloat(userFourOrder.Price)) / 2;
      trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(parseFloat(trades[0].Price)).to.equal(expectedTradePriceForUser2);
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const expectedTradePriceForUser4 = (parseFloat(userTwoOrder.Price) + parseFloat(userFourOrder.Price)) / 2;
      trades = await hydraApiClientUserFour
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(parseFloat(trades[0].Price)).to.equal(expectedTradePriceForUser4);
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Portfolio panel is empty.`
      );

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      await hydraApiClientUserSix.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 6 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserSix.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 6 portfolio panel is now empty.');
    });
  });

  // Failing due to HYD-1241
  it('PN-067 - Test to check if Inverted order gets traded automatically for the second time at end of pricing phase  ', async () => {
    const securityId = 'US421924BN03';
    const securityDescription = 'EHC 5 1/8 03/15/23';
    let orderMid = 175;
    const spread = 4;
    const userTwoOrderSpread = spread + 1;
    const userThreeOrderSpread = spread + 2;
    const size = 1000000;
    const largeSize = 10000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', userTwoOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', userTwoOrderSpread, orderMid, size, 'IG', region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', userThreeOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, largeSize, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    userFourOrder.Price = String(parseFloat(userOneOrder.Price) + 2.0);
    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userFourOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);

    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userFourOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradedPrice1 = ((parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrice2 = ((parseFloat(userOneOrder.Price) + parseFloat(userThreeOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrices = [expectedTradedPrice1, expectedTradedPrice2];
    const expectedTradedSize = ['1000'];
    const tradePanel = hydraPageModel.getTrades();
    const countOfTrades = await browser.waitUntil(() => tradePanel
      .getOrderRowCount(securityDescription));
    expect(countOfTrades).to.equal(expectedTradedPrices.length);
    for (let priceCount = 0; priceCount < expectedTradedPrices.length; priceCount += 1) {
      const tradedPrice = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, priceCount + 1)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, priceCount + 1)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.be.oneOf(expectedTradedSize);
    }

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserFour.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 4 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserFour.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 4 portfolio panel is now empty.');
  });

  // Failing due to HYD-1241
  it('PN-068 - Test to check if Inverted order & Matched order gets traded satisfying the price followed by time logic  ', async () => {
    const securityId = 'IT0005291163';
    const securityDescription = 'WINTRE 5 01/20/26';
    let orderMid = 175;
    const spread = 8;
    const userTwoOrderSpread = 9;
    const userThreeOrderSpread = 10;
    const userFourOrderSpread = 11;
    const userFiveOrderSpread = 12;
    const userSixOrderSpread = 9;
    const size = 1000000;
    const sizeTwo = 3000000;
    const sizeThree = 2000000;
    const sizeFour = 10000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', userThreeOrderSpread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'buy', userFourOrderSpread, orderMid, sizeThree, 'IG', region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userFiveOrder = getNewOrder(securityId, 'buy', userFiveOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserFive.addOrders([userFiveOrder]);
    logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeFour);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userSixOrder = getNewOrder(securityId, 'sell', userSixOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserSix.addOrders([userSixOrder]);
    logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserSix.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSixOrder.Price);
    logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

    userThreeOrder.Price = String(parseFloat(userOneOrder.Price));
    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Bid price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    await hydraApiClientUserFive.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFiveOrder.Price);
    logger.info(`User 5 set Bid price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);

    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradedPrice1ForUser1 = ((parseFloat(userOneOrder.Price) + parseFloat(userFiveOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrice2ForUser1 = ((parseFloat(userOneOrder.Price) + parseFloat(userFourOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrice3ForUser1 = parseFloat(userOneOrder.Price).toFixed(2);
    const expectedTradedPricesForUser1 = [expectedTradedPrice1ForUser1, expectedTradedPrice2ForUser1, expectedTradedPrice3ForUser1];
    const expectedTradedSizeForUser1 = ['1M', '2M', '3M'];
    const tradePanel = hydraPageModel.getTrades();
    const countOfTrades = await browser.waitUntil(() => tradePanel
      .getOrderRowCount(securityDescription));
    expect(countOfTrades).to.equal(expectedTradedPricesForUser1.length);
    for (let priceCount = 0; priceCount < expectedTradedPricesForUser1.length; priceCount += 1) {
      const tradedPrice = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, priceCount + 1)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, priceCount + 1)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.be.oneOf(expectedTradedPricesForUser1);
      expect(tradeSize).to.be.oneOf(expectedTradedSizeForUser1);
    }

    const expectedTradePriceForUser5 = ((parseFloat(userFiveOrder.Price) + parseFloat(userOneOrder.Price)) / 2).toFixed(2);
    let trades = await hydraApiClientUserFive
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser5));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser5));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser4 = ((parseFloat(userFourOrder.Price) + parseFloat(userOneOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFour
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser4));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser4));
    expect(trades[0].Size).to.equal('2000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser3 = ((parseFloat(userThreeOrder.Price) + parseFloat(userOneOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('3000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserSix.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 6 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  // Failing due to HYD-1241
  it('PN-069 - Multiple Users -10 users- test to check the Price followed by time logic in both Buy and Sell side ', async () => {
    const securityId = 'US09258BAC90';
    const securityDescription = 'BLKCQP 6 1/2 03/20/21';
    let orderMid = 175;
    const spread = 8;
    const userTwoOrderSpread = 9;
    const userThreeOrderSpread = 10;
    const userFourOrderSpread = 11;
    const userFiveOrderSpread = 12;
    const userSixOrderSpread = 7;
    const userSevenOrderSpread = 6;
    const userEightOrderSpread = 5;
    const userNineOrderSpread = 4;
    const userTenOrderSpread = 3;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix,
      hydraApiClientUserSeven, hydraApiClientUserEight, hydraApiClientUserNine, hydraApiClientUserTen];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', userThreeOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'buy', userFourOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userFiveOrder = getNewOrder(securityId, 'buy', userFiveOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserFive.addOrders([userFiveOrder]);
    logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

    const userTenOrder = getNewOrder(securityId, 'buy', userTenOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserTen.addOrders([userTenOrder]);
    logger.info(`User 10 added bond ${securityDescription} with size of ${userTenOrder.OrderQty} and direction of ${userTenOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userSixOrder = getNewOrder(securityId, 'sell', userSixOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserSix.addOrders([userSixOrder]);
    logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

    const userSevenOrder = getNewOrder(securityId, 'sell', userSevenOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserSeven.addOrders([userSevenOrder]);
    logger.info(`User 7 added bond ${securityDescription} with size of ${userSevenOrder.OrderQty} and direction of ${userSevenOrder.Side} side.`);

    const userEightOrder = getNewOrder(securityId, 'sell', userEightOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserEight.addOrders([userEightOrder]);
    logger.info(`User 8 added bond ${securityDescription} with size of ${userEightOrder.OrderQty} and direction of ${userEightOrder.Side} side.`);

    const userNineOrder = getNewOrder(securityId, 'sell', userNineOrderSpread, orderMid, size, 'IG', region);
    await hydraApiClientUserNine.addOrders([userNineOrder]);
    logger.info(`User 9 added bond ${securityDescription} with size of ${userNineOrder.OrderQty} and direction of ${userNineOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    userThreeOrder.Price = String(parseFloat(userOneOrder.Price));
    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Bid price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    await hydraApiClientUserFive.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFiveOrder.Price);
    logger.info(`User 5 set Bid price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

    await hydraApiClientUserTen.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTenOrder.Price);
    logger.info(`User 10 set Bid price of bond ${securityDescription} to ${userTenOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserSix.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSixOrder.Price);
    logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

    await hydraApiClientUserSeven.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSevenOrder.Price);
    logger.info(`User 7 set Offer price of bond ${securityDescription} to ${userSevenOrder.Price}.`);

    await hydraApiClientUserEight.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userEightOrder.Price);
    logger.info(`User 8 set Offer price of bond ${securityDescription} to ${userEightOrder.Price}.`);

    await hydraApiClientUserNine.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userNineOrder.Price);
    logger.info(`User 9 set Offer price of bond ${securityDescription} to ${userNineOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [userTwoOrder.Price];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [userOneOrder.Price];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradePriceForUser3 = ((parseFloat(userThreeOrder.Price) + parseFloat(userNineOrder.Price)) / 2).toFixed(2);
    let trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser9 = ((parseFloat(userThreeOrder.Price) + parseFloat(userNineOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserNine
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser9));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 9 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 9 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 9 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser4 = ((parseFloat(userFourOrder.Price) + parseFloat(userEightOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFour
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser4));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser8 = ((parseFloat(userFourOrder.Price) + parseFloat(userEightOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserEight
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser8));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 8 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 8 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 8 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser5 = ((parseFloat(userFiveOrder.Price) + parseFloat(userSevenOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFive
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser5));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser7 = ((parseFloat(userFiveOrder.Price) + parseFloat(userSevenOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserSeven
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser7));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 7 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 7 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 7 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser10 = ((parseFloat(userTenOrder.Price) + parseFloat(userSixOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserTen
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser10));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 10 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 10 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 10 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser6 = ((parseFloat(userTenOrder.Price) + parseFloat(userSixOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserSix
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser6));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 6 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 6 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 6 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(String(userTwoOrder.Price), true, '0.5');
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(userTwoOrder.Price));
    expect(tradeSize).to.equal('0.5M');

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  // Failing due to HYD-1241
  it('PN-070 - HYD-457-StandbyUser amends Offer price to cross the best resting lit bid during Private phase  - Trade execution at mathematical midpoint with StandbyUser(Fully filled) and PN become Single Sided', async () => {
    const securityId = 'FR0013210754';
    const securityDescription = 'HSBC 0 10/15/19';
    let orderMid = 175;
    const spread = 5;
    const size = 10000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [String(parseFloat(userThreeOrder.Price).toFixed(2))];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [String(parseFloat(userTwoOrder.Price).toFixed(2))];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    const userOneImprovedPrice = roundToTick(parseFloat(userThreeOrder.Price) - parseFloat(1.0), region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneImprovedPrice);
    logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    const expectedTradePrice = ((parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2).toFixed(2);
    expect(tradedPrice).to.equal(expectedTradePrice);
    expect(tradeSize).to.equal('10M');

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth} for User1.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth} for User1.`);

    const asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice} for User1.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth} for User2.`);

    // User2 in the UI will see the Offer price as blank though the backend returns the Offer price
    expectedMarketDepth = [userTwoOrder.Price];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth} for User2.`);

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.verylongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is empty.`
    );

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  // Test fails due to HYD-257
  it('PN-071 - HYD-257 -To test if multiple price levels in Group Phase are supported', async () => {
    const securityId = 'US44965TAA51';
    const securityDescription = 'AER 0 12/21/65';
    let orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const tradedQuantity = 0.5;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [String(parseFloat(userOneOrder.Price).toFixed(2))];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [String(parseFloat(userTwoOrder.Price).toFixed(2))];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(userTwoOrder.Price, true, tradedQuantity);
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price}@${tradedQuantity}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(userTwoOrder.Price);
    expect(tradeSize).to.equal('0.5M');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price).toFixed(2);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraApiClient
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const expectedQty = 500000;
    let remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(expectedQty);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    // Test fails due to HYD-257- Multiple price levels in Group phase are not accepted
    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('0.5');
    logger.info(`User 1 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });
});
