/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {Sector} from '../../../constant/Sector';
import {TRADING_PROTOCOL} from '../../../constant/Protocol';
import {log} from 'testable-utils';
import {MODULE_TITLES} from '../../../constant/App';
import {OPTIONS, PHASE_DEFINITIONS} from "../../../constant/TradingSession";

describe('Matching Session Stress tests', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let sessionStrategy = null;
  let orderRemoverStrategy = null;
  let allTraders = null;
  let sellers = null;
  let buyers = null;
  let affirmers = null;
  let uiTrader = null;
  let apiSessionCreator = null;
  let apiOrderRemover = null;

  // Test case vars.
  let firstRun = true;

  const securityDescription = 'ALTMES 7 7/8 12/15/24';
  const industrySector = Sector.ENERGY;
  const spread = 1;
  const size = 5000000;
  const rating = 'HY';
  const region = TICK_CONFIGURATION.US.HY;
  const orderMid = 100.5;

  const sessionConfiguration = {
    sector : industrySector,
    rating
  };

  const testIterations = 1;

  const genOrders = buyOrSell => [
    {order       : getNewOrder('CA15713JAA21', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CEUCN 6 3/8 10/21/24'},
    {order       : getNewOrder('NO0010607682', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NJGANO Float 09/30/28'},
    {order       : getNewOrder('NO0010649221', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SOLGAS 5.32 12/30/27'},
    {order       : getNewOrder('US018760AB41', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VOSTOK 7 05/04/20'},
    {order       : getNewOrder('US021332AF81', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ALTMES 7 7/8 12/15/24'},
    {order       : getNewOrder('US02564PAA66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AMWOOD 9 09/15/22'},
    {order       : getNewOrder('US02753GAA76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AMID 8 1/2 12/15/21'},
    {order       : getNewOrder('US095796AA63', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BLURAC 6 1/8 11/15/22'},
    {order       : getNewOrder('US12532MAA18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CGGFP 9 05/01/23'},
    {order       : getNewOrder('US12654TAA88', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CNXMPF 6 1/2 03/15/26'},
    {order       : getNewOrder('US13123XAZ50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CPE 6 3/8 07/01/26'},
    {order       : getNewOrder('US17302XAJ54', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CITPET 6 1/4 08/15/22'},
    {order       : getNewOrder('US198280AH20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CPGX 5.8 06/01/45'},
    {order       : getNewOrder('US205677AB38', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CRK 9 3/4 08/15/26'},
    {order       : getNewOrder('US23311RAH93', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DCP 5.85 05/21/43'},
    {order       : getNewOrder('US23311VAD91', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DCP 3 7/8 03/15/23'},
    {order       : getNewOrder('US247916AM12', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DNR 7 3/4 02/15/24'},
    {order       : getNewOrder('US25271CAN20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DO 4 7/8 11/01/43'},
    {order       : getNewOrder('US268787AD07', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'EPENEG 6 3/8 06/15/23'},
    {order       : getNewOrder('US27890GAB68', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MR 8 7/8 07/15/23'},
    {order       : getNewOrder('US29273VAC46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ET 7 1/2 10/15/20'},
    {order       : getNewOrder('US29273VAF76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ET 5 1/2 06/01/27'},
    {order       : getNewOrder('US293561BW52', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ENRNQ 6.95 07/15/28'},
    {order       : getNewOrder('US37185LAH50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GEL 6 3/4 08/01/22'},
    {order       : getNewOrder('US37185LAJ17', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GEL 6 1/2 10/01/25'},
    {order       : getNewOrder('US428337AA70', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HCR 9 1/2 08/01/26'},
    {order       : getNewOrder('US462044AG36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'IO 9 1/8 12/15/21'},
    {order       : getNewOrder('US48253LAA44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KLXE 11 1/2 11/01/25'},
    {order       : getNewOrder('US48667QAP00', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KZOKZ 5 3/4 04/19/47'},
    {order       : getNewOrder('US516806AD89', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LPI 5 5/8 01/15/22'},
    {order       : getNewOrder('US626717AD43', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MUR 4 06/01/22'},
    {order       : getNewOrder('US62704PAF09', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MURREN 11 1/4 04/15/21'},
    {order       : getNewOrder('US65504LAF40', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 4 5/8 03/01/21'},
    {order       : getNewOrder('US65504LAK35', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 5 1/4 03/15/42'},
    {order       : getNewOrder('US66978CAB81', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NOGLN 8 07/25/22'},
    {order       : getNewOrder('US67059TAF21', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NSUS 6 06/01/26'},
    {order       : getNewOrder('US674215AK41', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'OAS 6 1/4 05/01/26'},
    {order       : getNewOrder('US69318UAB17', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PBFX 6 7/8 05/15/23'},
    {order       : getNewOrder('US69419WAA71', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PACD 11 04/01/24'},
    {order       : getNewOrder('US699320AH03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VIICN 6 7/8 06/30/23'},
    {order       : getNewOrder('US71647NAP42', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PETBRA 8 3/8 05/23/21'},
    {order       : getNewOrder('US71647NAV10', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PETBRA 5.299 01/27/25'},
    {order       : getNewOrder('US71647NBD03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PETBRA 6.9 03/19/49'},
    {order       : getNewOrder('US723664AB43', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PESX 6 1/8 03/15/22'},
    {order       : getNewOrder('US740212AK19', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PDCN 7 3/4 12/15/23'},
    {order       : getNewOrder('US76716XAB82', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIOOIL 9 3/4 01/06/27'},
    {order       : getNewOrder('US79970YAD76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SNEC 6 1/8 01/15/23'},
    {order       : getNewOrder('US80007PAU30', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SD 8 3/4 06/01/20'},
    {order       : getNewOrder('US87612BAY83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NGLS 6 3/4 03/15/24'},
    {order       : getNewOrder('US893817AA41', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 7.45 04/15/27'},
    {order       : getNewOrder('US89385AAA34', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 5 3/8 05/15/23'},
    {order       : getNewOrder('US91889DAB29', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VAL 4 1/2 10/01/24'},
    {order       : getNewOrder('US91889DAE67', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VAL 7 3/4 02/01/26'},
    {order       : getNewOrder('US966387AH55', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'WLL 5 3/4 03/15/21'},
    {order       : getNewOrder('US98212BAE39', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'WPX 5 1/4 09/15/24'},
    {order       : getNewOrder('US984245AP50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'YPFDAR 16 1/2 05/09/22'},
    {order       : getNewOrder('USC0455LAA82', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ATHCN 9 7/8 02/24/22'},
    {order       : getNewOrder('USC71968AA67', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PKICN 6 04/01/26'},
    {order       : getNewOrder('USC71968AB41', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PKICN 5 7/8 07/15/27'},
    {order       : getNewOrder('USG90073AD26', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 7 1/4 11/01/25'},
    {order       : getNewOrder('USL9412AAA53', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'UGPABZ 5 1/4 10/06/26'},
    {order       : getNewOrder('USN6945AAK36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PETBRA 5.999 01/27/28'},
    {order       : getNewOrder('USP989MJBN03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'YPFDAR 7 12/15/47'},
    {order       : getNewOrder('USU1303AAD82', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CRC 8 12/15/22'},
    {order       : getNewOrder('USU16450AY12', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHK 8 03/15/26'},
    {order       : getNewOrder('USU2100LAA36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CEIX 11 11/15/25'},
    {order       : getNewOrder('USU2481AAD01', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DNR 9 05/15/21'},
    {order       : getNewOrder('USU2937LAE49', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'EPENEG 9 3/8 05/01/24'},
    {order       : getNewOrder('USU3025AAA70', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'XOG 7 3/8 05/15/24'},
    {order       : getNewOrder('USU34550AE00', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FELP 11 1/2 04/01/23'},
    {order       : getNewOrder('USU43279AF26', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HILCRP 5 12/01/24'},
    {order       : getNewOrder('USU43279AH81', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HILCRP 6 1/4 11/01/28'},
    {order       : getNewOrder('USU5742YAA20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MDR 10 5/8 05/01/24'},
    {order       : getNewOrder('USU65365AF24', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NGL 7 1/2 04/15/26'},
    {order       : getNewOrder('USU7024PAC24', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PARSLY 6 1/4 06/01/24'},
    {order       : getNewOrder('USU7024PAG38', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PARSLY 5 5/8 10/15/27'},
    {order       : getNewOrder('USU8302LAB46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TEP 5 1/2 09/15/24'},
    {order       : getNewOrder('XS0201817292', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MAXLTD 5.7 04/02/24'},
    {order       : getNewOrder('XS0925015074', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KZOKZ 4.4 04/30/23'},
    {order       : getNewOrder('XS1093755194', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SEVENE 10 1/4 10/11/21'},
    {order       : getNewOrder('XS1729059862', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RAFHEI 6 3/8 12/01/22'},
    {order       : getNewOrder('XS1816296062', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ENGPRO 4 1/2 05/04/24'}
  ];

  function getOrders (orders) {
    const ordersArray = orders.map(value => value.order);

    return ordersArray;
  }

  async function getOrdersToAffirm (orders) {
    let affirmArray = orders.filter(order => order.affirmOrder === true);

    for (let index = 0; index < affirmArray.length; index += 1) {
      const asmPrice = await allTraders[0].getActionPanel()
        .getFirstOrderByDescription(affirmArray[index].description)
        .getAsmPrice();

      affirmArray[index].price = asmPrice;
      log.info(`getting price for security: ${affirmArray[index].description} price: ${asmPrice}`);
    }

    affirmArray = affirmArray.filter(order => parseFloat(order.price) !== 0);
    log.info('Total number of orders to be affirmed after ignoring orders with ASM price as zero is ', affirmArray.length);

    return affirmArray;
  }

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    configuration = context.getConfiguration();
    log.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // User setup
    uiTrader = 'sujith.vakathanam.auto1@testing.fenicstools.com';
    apiSessionCreator = 'sujith.vakathanam.auto3@testing.fenicstools.com';
    apiOrderRemover = 'sujith.vakathanam.auto13@testing.fenicstools.com';

    // Api Users
    const hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    const hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    const hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    const hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    const hydraApiClientUserSeven = new FixHydraStrategy(context, 'manjit.bharaj.auto7@testing.fenicstools.com');
    const hydraApiClientUserEight = new FixHydraStrategy(context, 'manjit.bharaj.auto8@testing.fenicstools.com');
    const hydraApiClientUserNine = new FixHydraStrategy(context, 'manjit.bharaj.auto9@testing.fenicstools.com');
    const hydraApiClientUserTen = new FixHydraStrategy(context, 'manjit.bharaj.auto10@testing.fenicstools.com');
    const hydraApiClientUserEleven = new FixHydraStrategy(context, 'manjit.bharaj.auto11@testing.fenicstools.com');
    const hydraApiClientUserTwelve = new FixHydraStrategy(context, 'manjit.bharaj.auto12@testing.fenicstools.com');
    const hydraApiClientUserThirteen = new FixHydraStrategy(context, 'manjit.bharaj.auto13@testing.fenicstools.com');
    const hydraApiClientUserFourteen = new FixHydraStrategy(context, 'manjit.bharaj.auto14@testing.fenicstools.com');
    const hydraApiClientUserFifteen = new FixHydraStrategy(context, 'manjit.bharaj.auto15@testing.fenicstools.com');
    const hydraApiClientUserSixteen = new FixHydraStrategy(context, 'manjit.bharaj.auto16@testing.fenicstools.com');
    const hydraApiClientUserSeventeen = new FixHydraStrategy(context, 'manjit.bharaj.auto17@testing.fenicstools.com');
    const hydraApiClientUserEighteen = new FixHydraStrategy(context, 'manjit.bharaj.auto18@testing.fenicstools.com');
    const hydraApiClientUserNineteen = new FixHydraStrategy(context, 'manjit.bharaj.auto19@testing.fenicstools.com');
    const hydraApiClientUserTwenty = new FixHydraStrategy(context, 'manjit.bharaj.auto20@testing.fenicstools.com');
    const hydraApiClientUserTwentyOne = new FixHydraStrategy(context, 'manjit.bharaj.auto21@testing.fenicstools.com');

    buyers = [hydraApiClientUserTwo,
      hydraApiClientUserFour,
      hydraApiClientUserSix,
      hydraApiClientUserEight,
      hydraApiClientUserTen,
      hydraApiClientUserTwelve,
      hydraApiClientUserFourteen,
      hydraApiClientUserSixteen,
      hydraApiClientUserEighteen,
      hydraApiClientUserTwenty];

    sellers = [
      hydraApiClientUserFive,
      hydraApiClientUserSeven,
      hydraApiClientUserNine,
      hydraApiClientUserEleven,
      hydraApiClientUserThirteen,
      hydraApiClientUserFifteen,
      hydraApiClientUserSeventeen,
      hydraApiClientUserNineteen,
      hydraApiClientUserTwentyOne
    ];

    allTraders = buyers.concat(sellers);

    // Matchers will load a limited set of isins and trade them
    affirmers = allTraders;
    sessionStrategy = new FixSessionStrategy(context, apiSessionCreator);
    orderRemoverStrategy = new FixHydraStrategy(context, apiOrderRemover);

    expect(browser).to.exist;
  });

  after(() => {
    // ShellExec(TempBoot.clearDownScript);
  });

  for (let executionNumber = 1; executionNumber <= testIterations; executionNumber += 1) {
    describe(`Execution number ${executionNumber}`, () => {
      it('UI User logs in', async () => {
        log.info('Running 100 isin tests');
        log.info('MODULE_TITLES.loginPageTitle is set as ', MODULE_TITLES.loginPageTitle);
        log.info('MODULE_TITLES.launchbarTitle is set as ', MODULE_TITLES.launchbarTitle);
        log.info('MODULE_TITLES.hydraPageTitle is set as ', MODULE_TITLES.hydraPageTitle);
        log.info('MODULE_TITLES.hydraOperatorPageTitle is set as ', MODULE_TITLES.hydraOperatorPageTitle);
        firstRun = await testCommons.loginAsTrader(firstRun, uiTrader);
      });

      it('API and UI Users remove ISINs', async () => {
        log.info('Removing UI user orders');
        const hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
        await orderRemoverStrategy.removeOrders(hydraApiClientUserOne);

        log.info('Removing API user orders');
        for (const trader of allTraders) {
          await orderRemoverStrategy.removeOrders(trader);
        }
        log.info('All user orders removed');
      });

      it('API Users load ISINs', async () => {
        log.info('Buyers adding orders');
        const myBuyOrders = getOrders(genOrders('buy'));
        const buyersAddOrders = buyers.map(buyer => {
          log.info(`${buyer.getApiUser()} adding orders`);

          return buyer.addOrders(myBuyOrders);
        });
        await Promise.all(buyersAddOrders);
        log.info('Buyers completed adding orders');

        log.info('Sellers adding orders');
        const mySellOrders = getOrders(genOrders('sell'));
        const sellersAddOrders = sellers.map(seller => {
          log.info(`${seller.getApiUser()} adding orders`);

          return seller.addOrders(mySellOrders);
        });
        await Promise.all(sellersAddOrders);
        log.info('Sellers completed adding orders');
      });

      it('UI user loads ISINs', async () => {
        const mySellOrders = getOrders(genOrders('sell'));
        await hydraPageModel.addOrders(mySellOrders);

        await browser.waitUntil(
          () => hydraPageModel.getPortfolio()
            .hasOrders()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, Portfolio panel do not not have orders for User1`
        );

        await browser.pause(configuration.shortTimeout);
        let countOfOrdersInPortfolioPanel = await hydraPageModel.getPortfolio().getPanelHeaderCount();
        countOfOrdersInPortfolioPanel = countOfOrdersInPortfolioPanel.slice(1, -1);
        log.info('Count of Orders in Portfolio panel is ', countOfOrdersInPortfolioPanel);
      });

      it('Operator starts session', async () => {
        OPTIONS.isLimitPricingEnabled = false;
        await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);
        await sessionStrategy.createSession(sessionConfiguration);
      });

      // Enhance to check each user goes to confirmation phase.
      it('Waiting for COUNTDOWN phase', async () => {
        const expectedPhase = 'Countdown';

        await browser.waitUntil(
          () => hydraPageModel.getSessionPanel()
            .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
            .isCurrentPhase(expectedPhase)
          , configuration.mediumTimeout
          , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
        );
        log.info(`${expectedPhase} phase has started.`);

        let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel().getPanelHeaderCount();
        countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
        log.info('Count of Orders in Session panel is ', countOfOrdersInSessionPanel);
      });

      it('Waiting for AFFIRMATION phase', async () => {
        // Check that the UI user is in AFFIRMATION PHASE
        const expectedPhase = 'Affirmation';
        await browser.waitUntil(
          () => hydraPageModel.getSessionPanel()
            .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
            .isCurrentPhase(expectedPhase)
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
        );
        log.info(`${expectedPhase} phase has started.`);

        let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel().getPanelHeaderCount();
        countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
        log.info('Count of Orders in Session panel during Affirmation phase is ', countOfOrdersInSessionPanel);
      });

      // Multiple traders need to affirm orders
      it('Traders Affirm orders', async () => {
        const affirmOrdersArray = await getOrdersToAffirm(genOrders('buy'));
        log.info('Total no of affirmers is', affirmers.length);

        // UI User only
        await hydraPageModel.getSessionPanel()
          .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
          .affirmAllOrders();
        log.info('UI user has affirmed all orders');

        const affirmedOrders = affirmers.map(trader => affirmOrdersArray.map(order => {
          log.info(`trader: ${trader.apiUser} about to affirm: ${order.description} at price: ${order.price}`);

          return trader.getActionPanel()
            .getFirstOrderByDescription(order.description)
            .affirmOrder(order.price);
        }));

        await Promise.all(affirmedOrders);
      });

      it('Wait for CLEAN UP phase', async () => {
        const expectedPhase = 'MY CLEAN UP';

        await browser.waitUntil(
          () => hydraPageModel.getSessionPanel()
            .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
            .isCurrentPhase(expectedPhase)
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, phase is not ${expectedPhase}.`
        );
        log.info(`${expectedPhase} phase has started.`);

        let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel().getPanelHeaderCount();
        countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
        log.info(`Count of Orders in Session panel during ${expectedPhase}is `, countOfOrdersInSessionPanel);
      });

      it('Waiting for all traders action panels to be emptied', async () => {
        await hydraPageModel.getSessionPanel(rating, true);
        await browser.pause(configuration.veryShortTimeout);
        const expectedPhase = 'Cleanup';
        await browser.waitUntil(
          () => hydraPageModel.getSessionPanel()
            .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
            .isPhaseEnded(expectedPhase)
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
        );
        log.info(`${expectedPhase} phase has Ended.`);
      });

      it('API and UI Users remove ISINs', async () => {
        log.info('Removing UI user orders');
        const hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
        await orderRemoverStrategy.removeOrders(hydraApiClientUserOne);

        log.info('Removing API user orders');
        for (const trader of allTraders) {
          await orderRemoverStrategy.removeOrders(trader);
        }
        log.info('All user orders removed');
      });
    });
  }
});

