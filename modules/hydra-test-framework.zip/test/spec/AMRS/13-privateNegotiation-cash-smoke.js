/* eslint-disable max-statements,max-lines,complexity */
import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import TestCommons from '../../../utilities/TestCommons';
import FenicsCredit from '../../../pages/FenicsCredit';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {expect} from 'chai';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {SIZE_MULTIPLIER} from '../../../constant/Order';

describe('Private Negotiation Cash Smoke Tests for AMRS region', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;


  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');

    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('PN-001 - Order gets executed automatically when the size and price matches in private phase', async () => {
    const securityId = 'JP358580A922';
    const securityDescription = 'TOKELP 2.205 02/27/29';
    const orderMid = 100.5;
    const spread = 0;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(false);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(orderMid);
    expect(tradeSize).to.equal(userOneOrder.OrderQty.toString());

    const expectedTradePriceForUser2 = parseFloat(orderMid);
    logger.info('Expected Trade Price for User1', expectedTradePriceForUser2);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(userOneOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-002 - Spread 2 - ASM accepted by both users during Private Phase (Same Size, agreed on Asm Price)', async () => {
    const securityId = 'XS1684387456';
    const securityDescription = 'IQV 2 7/8 09/15/25';
    let orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice).toFixed(2);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice).toFixed(2);
    expect(asmPrice).to.equal(calculatedAsmPrice);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(userOneOrder.OrderQty);
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, userTwoOrder.size);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
    expect(tradeSize).to.equal(userOneOrder.OrderQty.toString());

    const expectedTradePriceForUser2 = parseFloat(asmPrice).toFixed(2);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal(userOneOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-020 - Scenario to test submitted price is Crossable and gets traded at Mathematical midpoint price-Partial Fill', async () => {
    const securityId = 'AU3CB0214534';
    const securityDescription = 'MGRAU 5 3/4 09/18/20';
    const orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid + spread, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'sell', 0, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    expectedTradePrice = parseFloat(expectedTradePrice);
    expect(tradedPrice).to.equal(String(expectedTradePrice));
    expect(tradeSize).to.equal(userTwoOrder.OrderQty.toString());

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePrice));
    expect(trades[0].Size).to.equal(userTwoOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(userTwoOrder.OrderQty.toString());

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-024 - ASM gets recalculated during Private Phase after a trade is executed and also gets recalculated when there is an Improved price compared to resting order', async () => {
    const securityId = 'CH0367013981';
    const securityDescription = 'BCG 2 PERP';
    let orderMid = 262;
    const spread = 3;
    const size = 3000000;
    const sizeTwo = 2500000;
    const sizeDiff = 500;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings();
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings();

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices();

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, sizeDiff);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price}  for 0.5M.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.50;
    const userThreeImprovedPrice = parseFloat(asmPrice) - parseFloat(priceDiff);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeImprovedPrice);
    logger.info(`User 3 improves his Offer price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    let recalculatedAsmPrice = (parseFloat(userOneOrder.Price) + parseFloat(userThreeImprovedPrice)) / 2;
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(sizeDiff.toString());

    let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? parseFloat(expectedTradePriceForUser2).toFixed(1) : expectedTradePriceForUser2;
    logger.info('Expected Trade Price for User2 is', expectedTradePriceForUser2);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePriceForUser2))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders for User2`
    );

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    let actualTradePriceForUser2 = parseFloat(trades[0].Price);
    actualTradePriceForUser2 = Number.isInteger(actualTradePriceForUser2) ? parseFloat(actualTradePriceForUser2).toFixed(1) : actualTradePriceForUser2;
    expect(String(actualTradePriceForUser2)).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal((sizeDiff * SIZE_MULTIPLIER).toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal((sizeTwo / SIZE_MULTIPLIER).toString());

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(sizeTwo);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PN-027 - ASM get recalculated when StandbyUser with Lit Offer price crosses current ASM during Group Phase, check inverted order on price crossing ASM', async () => {
    const securityId = 'US761519BD88';
    const securityDescription = 'REV 5 3/4 02/15/21';
    let orderMid = 175;
    const spread = 5;
    const size = 1000000;
    const sizeTwo = 500;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [String(parseFloat(userOneOrder.Price).toFixed(2))];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [String(parseFloat(userTwoOrder.Price).toFixed(2))];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(String(parseFloat(userTwoOrder.Price)), true, sizeTwo);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal(String(parseFloat(calculatedAsmPrice)));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.25;
    const userThreeImprovedPrice = roundToTick(parseFloat(asmPrice) - parseFloat(priceDiff), region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`User 3 improves his Offer price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeImprovedPrice);
    logger.info(`User 3 improves his Offer price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    let recalculatedAsmPrice = ((parseFloat(userThreeImprovedPrice) + parseFloat(userOneOrder.Price)) / 2).toFixed(2);
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(sizeTwo.toString());

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    logger.info('ExpectedTradePrice for User2 is', expectedTradePriceForUser2);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal((sizeTwo * SIZE_MULTIPLIER).toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PN-050 - To test that Trade does not split when seller crosses 2 buyers', async () => {
    const securityId = 'XS1982707413';
    const securityDescription = 'KFW 1.7 04/16/20';
    let orderMid = 262;
    const spread = 4;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG', region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', 2, orderMid, size, 'IG', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    const expectedTradedPrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    await browser.pause(configuration.shortTimeout);

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);
    expect(tradedPrice).to.equal(String(parseFloat(expectedTradedPrice)));
    expect(tradeSize).to.equal(Math.abs(userOneOrder.OrderQty).toString());

    let expectedTradePriceForUser2 = parseFloat(expectedTradedPrice);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? parseFloat(expectedTradePriceForUser2).toFixed(1) : expectedTradePriceForUser2;
    logger.info('ExpectedTradePrice for User2 is ', expectedTradePriceForUser2);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePriceForUser2))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders for User2`
    );
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
    expect(trades[0].Size).to.equal(userTwoOrder.RawOrderQty.toString());
    expect(trades[0].Direction).to.equal(userTwoOrder.TradedSide);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const remainingQuantity = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });
});
