/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateMid, calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';

describe('Private negotiation tests - Spread Bonds', () => {
  // Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'manjit.bharaj.auto7@testing.fenicstools.com');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'manjit.bharaj.auto8@testing.fenicstools.com');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'manjit.bharaj.auto9@testing.fenicstools.com');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'manjit.bharaj.auto10@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('PNS-003 - Spread 8 - ASM accepted by user1 but not by User 2 and if the Orders move back to Portfolio when PN session ends', async () => {
    const securityId = 'US49456BAH42';
    const securityDescription = 'KMI 5.55 06/01/45';
    let orderMid = 88;
    const spread = 8;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);

    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('1000');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.false;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 2 portfolio panel is now empty.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-004 - Spread 2 - Scenario to test that User 1 accepts the price of User 2 during Private phase', async () => {
    const securityId = 'US68389XBQ79';
    const securityDescription = 'ORCL 4 11/15/47';
    let orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice).toFixed(2);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice).toFixed(2);

    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true);
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price}@${userTwoOrder.OrderQty}.`);

    await browser.pause(configuration.shortTimeout);
    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);
    expect(tradedPrice).to.equal(String(parseFloat(userTwoOrder.Price)));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? expectedTradePriceForUser2.toFixed(1) : expectedTradePriceForUser2;
    logger.info('Expected Trade price for User2 is', expectedTradePriceForUser2);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 2 portfolio panel is now empty.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-005 - Spread 2 - User 1 accepts the price of User 2 But with lesser size during Private phase', async () => {
    const securityId = 'US69403WAE75';
    const securityDescription = 'PACBEA 5.578 07/15/51';
    let orderMid = 80.25;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice).toFixed(2);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice).toFixed(2);

    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [undefined];
    let actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for UserThree with ${userThreeOrder.Side} side is ${actualMarketDepth}.`);
    logger.info('User3 does not view the Market Depth in Action panel as he uploaded the order during Private phase');

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, '1000');
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price}@0.5M.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for UserThree with ${userThreeOrder.Side} side is ${actualMarketDepth}.`);
    logger.info('User3 does not view the Market Depth in Action panel as he uploaded the order during Private phase');

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? expectedTradePriceForUser2.toFixed(1) : expectedTradePriceForUser2;
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(parseFloat(trades[0].Price)).to.equal(parseFloat(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isActionEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isActionEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');
    logger.info(`User 1 traded bond ${securityDescription} with residual size of ${remainingQuantity}.`);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PNS-006 - Spread 2 - User 2 accepts the price of User 1 during Private phase', async () => {
    const securityId = 'US059165EE64';
    const securityDescription = 'EXC 2.8 08/15/22';
    let orderMid = 76.50;
    const spread = 2;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice).toFixed(2);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice).toFixed(2);

    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(parseFloat(userTwoOrder.Price), true);
    logger.info(`User 1 hits user 2 bid for bond ${securityDescription} at ${userTwoOrder.Price}@${userTwoOrder.OrderQty}.`);

    await browser.pause(configuration.shortTimeout);
    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('1000');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-007 - Spread 2 - User 2 accepts the price of User 1 But with lesser size during Private phase', async () => {
    const securityId = 'US88032XAQ79';
    const securityDescription = 'TENCNT 4.525 04/11/49';
    let orderMid = 66;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userTwoOrder.Price
      , userOneOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(parseFloat(userTwoOrder.Price), true, '500');
    logger.info(`User 1 hits user 2 bid for bond ${securityDescription} at ${userTwoOrder.Price} for ${sizeTwo}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');
    logger.info(`User 1 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(sizeTwo);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-008 - Spread 2 - Scenario to test that ASM accepted by both users during Group Phase', async () => {
    const securityId = 'US00828ECZ07';
    const securityDescription = 'AFDB 2 5/8 03/22/21';
    let orderMid = 88;
    const spread = 2;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('1000');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, size);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
    expect(tradeSize).to.equal('1000');

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  describe('PNS-009 - Scenario to test that User2 and User3 are in competition and User1 / User3 can trade at Group Phase', () => {
    it('PNS-009.001 - User 1 perspective / Buyer perspective', async () => {
      const securityId = 'US059438AH41';
      const securityDescription = 'JPM 7 5/8 10/15/26';
      let orderMid = 164.25;
      const spread = 4;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraApiClient.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );

      let weightings = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.veryShortTimeout);
      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userOneOrder.Price
        , userTwoOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      asmPrice = parseFloat(asmPrice);

      expect(asmPrice).to.equal(parseFloat(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('1000');
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userOneOrder.OrderQty}.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser2 = parseFloat(asmPrice);
      const trades = await hydraApiClient
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClient.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PNS-009.002 - User 2 perspective / Seller perspective Winner of pricing', async () => {
      const securityId = 'US949746SF91';
      const securityDescription = 'WFC Float 08/10/21';
      let orderMid = 99.25;
      const spread = 2;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraPageModel.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );

      let weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userTwoOrder.Price
        , userOneOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 3 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      let tradePanel = hydraPageModel.getTrades();
      let hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 2 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      tradePanel = hydraPageModel.getTrades();
      hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 2 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      const isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');
    });

    it('PNS-009.003 - User 3 perspective / Seller perspective Loser of pricing', async () => {
      const securityId = 'AU3CB0223816';
      const securityDescription = 'ASIA 3 3/4 03/12/25';
      let orderMid = 392.50;
      const spread = 4;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);

      await browser.waitUntil(
        () => hydraApiClient.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
      );

      let weightings = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClient.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userOneOrder]);
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no orders.`
      );
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const validateResult = await strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession();
        expect(validateResult).to.be.true;
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(asmPrice).to.equal('');
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [undefined];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [undefined];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      weightedPrice = await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      let calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userThreeOrder.Price
        , userOneOrder.Price
        , region
      );
      calculatedAsmPrice = parseFloat(calculatedAsmPrice);
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(calculatedAsmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('1000');
      logger.info(`User 3 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      let tradePanel = hydraPageModel.getTrades();
      let hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.false;
      logger.info(`User 3 bond ${securityDescription} has traded is ${hasTraded}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, size);
      logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userThreeOrder.OrderQty}.`);

      tradePanel = hydraPageModel.getTrades();
      hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 3 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info('User 3 portfolio panel is now empty.');

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info('User 3 portfolio panel is now empty.');

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
      expect(tradeSize).to.equal('1000');

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClient.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now not empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now not empty.');
    });
  });

  it('PNS-010 - Spread 2 - User1 and User2 accept ASM price at lesser quantity during private phase.', async () => {
    const securityId = 'DE000DK97VR4';
    const securityDescription = 'DEKA Float 08/16/23';
    let orderMid = 255;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await browser.pause(configuration.veryShortTimeout);
    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('500');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice} for ${sizeTwo}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, size);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice}@${userTwoOrder.OrderQty}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');
    logger.info(`User 1 remaining portfolio quantity for bond ${securityDescription} is ${remainingQuantity}.`);

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(sizeTwo);
    logger.info(`User 2 remaining portfolio quantity for bond ${securityDescription} is ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-011 - Spread 2 - User1 and User2 amend the Size during PricingPage phase and then accept ASM price with Amended quantity during private phase', async () => {
    const securityId = 'FR0010208694';
    const securityDescription = 'CFF Float 06/30/20';
    let orderMid = 355;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 1500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);
    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setSize('1500');
    logger.info(`User 1 amends size of bond ${securityDescription} to ${sizeTwo}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    const asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm('1500');
    logger.info(`User 1 accepts the ASM of bond ${securityDescription} at ${asmPrice} for ${sizeTwo}.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptAsm(asmPrice, sizeTwo);
    logger.info(`User 2 accepts the ASM of bond ${securityDescription} at ${asmPrice} for ${sizeTwo}.`);


    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(asmPrice));
    expect(tradeSize).to.equal('1500');

    const expectedTradePriceForUser2 = parseFloat(asmPrice);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('1500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-012 - Spread 2 - User1 ignores during PricingPage Phase and Order moving back to Portfolio', async () => {
    const securityId = 'US55336VAJ98';
    const securityDescription = 'MPLX 4 7/8 06/01/25';
    let orderMid = 455;
    const spread = 2;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession();
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-014 - Cannot Cancel or Ignore during Private Phase', async () => {
    const securityId = 'XS1396270677';
    const securityDescription = 'IFC 0 04/25/46';
    const orderMid = 66;
    const spread = 2;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    const notificationAlertPrompt = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getNotificationAlertBodyText();
    expect(notificationAlertPrompt).to.equal('Cannot cancel order during Private phase if best order');
    logger.info(`User 1 presented with alert: '${notificationAlertPrompt}'.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const isIgnoreButtonEnabled = false;
    let validateIgnoreButton = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession(isIgnoreButtonEnabled);
    expect(validateIgnoreButton).to.be.false;
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    validateIgnoreButton = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .ignoreForSession(isIgnoreButtonEnabled);
    expect(validateIgnoreButton).to.be.true;
    logger.info(`User 1 clicks the ignore button for bond ${securityDescription}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-019 - Scenario to test submitted price is Crossable and gets traded at Mathematical midpoint price-Full Fill', async () => {
    const securityId = 'AT000B112941';
    const securityDescription = 'OBERBK Float 02/25/22';
    const orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(true);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradedPrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    expectedTradedPrice = Number.isInteger(expectedTradedPrice) ? parseFloat(expectedTradedPrice).toFixed(1) : expectedTradedPrice;
    logger.info('ExpectedTradedPrice is ', expectedTradedPrice);
    expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradedPrice));
    expect(tradeSize).to.equal('1000');

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradedPrice));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradedPrice)));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );

    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  // Manual Test available for this
  it.skip('PNS-021 - Test to check the Glow Functionality', async () => {
    /*
     * 1. Login to Hydra application
     * 2. User1 uploads a ISIN with Buy Side and size of 1m
     * 3. User2 uploads a ISIN with Sell Side and size of 1m
     * 4. Both User1 and User2 sharpen their prices to be 100
     * 4. Expected Result:
     * ASM price should glow as trade got executed at the ASM price(100) for both the users
     * Trade should get executed at ASM price and available in My Trades panel for both users
     */
  });

  // Manual Test available for this
  it.skip('PNS-022 - Test to check the Yellow Flash Functionality', async () => {
    /*
     * 1. Login to Hydra application
     * 2. User1 uploads a ISIN with Buy Side and size of 1m
     * 3. User2 uploads a ISIN with Sell Side and size of 1m
     * 4. ASM is displayed during Private phase
     * 5. User2 then improves the Offer price
     * 6. ASM should then be amended
     * 4. Expected Result:
     * ASM should flash yellow and should get amended to new price
     */
  });

  // Manual Test available for this
  it.skip('PNS-023 - Public Toggle On/Off functionality', async () => {
    /*
     * Public Toggle is ON Functionality
     * 1. During PricingPage or Private or Group phase, ensure that both the Users ( User1 and User2)
     * set the Public Toggle as ON
     * 2. When the PN ends assuming there is no action during PN phase, when order moves back to Portfolio
     * CLOB should get started
     *
     * Public Toggle is OFF Functionality
     * 1. During PricingPage or Private or Group phase, ensure that both the Users ( User1 and User2)
     * set the Public Toggle as Off . It is off by default
     * 2. When the PN ends assuming there is no action during PN phase, when order moves back to Portfolio
     * CLOB should Not get started
     */
  });

  it('PNS-025 - ASM gets recalculated When StandbyUser with Lit Bid price crosses current ASM during Group Phase, check inverted order on price crossing ASM', async () => {
    const securityId = 'US57385LAB45';
    const securityDescription = 'MRVL 4 7/8 06/22/28';
    let orderMid = 118.75;
    const spread = 3;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(calculatedAsmPrice)).to.equal(parseFloat(asmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, 500);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price}  for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? parseFloat(expectedTradePriceForUser2).toFixed(1) : expectedTradePriceForUser2;

    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.5;
    const userThreeImprovedPrice = parseFloat(asmPrice) - parseFloat(priceDiff);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeImprovedPrice);
    logger.info(`User 3 improves his Bid price of bond ${securityDescription} to ${userThreeImprovedPrice}.`);

    let recalculatedAsmPrice = (parseFloat(userThreeImprovedPrice) + parseFloat(userTwoOrder.Price)) / 2;
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
    logger.info(`RecalculatedAsmPrice after User3 improves his Bid price will be :${recalculatedAsmPrice}`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('PNS-026 - ASM recalculation when StandbyUser amends the price to equal the Current ASM ', () => {
    it('PNS-026.001 - ASM gets recalculated When Lit Order(Lit Bid price) equals current ASM during Group Phase, check inverted order on price crossing ASM', async () => {
      const securityId = 'XS1178242506';
      const securityDescription = 'JPM 1 3/4 01/30/30';
      let orderMid = 93.25;
      const spread = 4;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      let weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');

      weightedPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');

      const calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userOneOrder.Price
        , userTwoOrder.Price
        , region
      );
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, 500);
      logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price}  for 0.5M.`);

      await browser.pause(configuration.mediumTimeout);

      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();

      expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      logger.info(`User3 set their price as ${asmPrice}`);
      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(asmPrice);
      logger.info(`User 3 set his Bid price of bond ${securityDescription} to ${asmPrice}.`);

      let recalculatedAsmPrice = (parseFloat(asmPrice) + parseFloat(userTwoOrder.Price)) / 2;
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

      await browser.pause(configuration.shortTimeout);
      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
      expect(tradeSize).to.equal('500');

      const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('500000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PNS-026.002 - ASM gets recalculated When Lit Order(Lit Offer price) equals current ASM during Group Phase-Standby user trying to improve in Private phase ', async () => {
      const securityId = 'XS1225626461';
      const securityDescription = 'SMINLN 1 1/4 04/28/23';
      let orderMid = 320;
      const spread = 6;
      const spreadTwo = 2;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', spreadTwo, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      let weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', spreadTwo, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      weightings = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');

      weightedPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');

      const calculatedAsmPrice = calculateAsmPrice(
        weightings.payload.weightings
        , weightedPrice.prices
        , userTwoOrder.Price
        , userThreeOrder.Price
        , region
      );
      logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

      let asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(calculatedAsmPrice)).to.equal(parseFloat(asmPrice));
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(asmPrice);
      logger.info(`User 1 set his Offer price of bond ${securityDescription} to ${asmPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let recalculatedAsmPrice = (parseFloat(asmPrice) + parseFloat(userThreeOrder.Price)) / 2;
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User1 improves his price will be :${recalculatedAsmPrice}`);

      await browser.pause(configuration.shortTimeout);
      asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

      asmPrice = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.longTimeout
          , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getActionPanel().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  it('PNS-028 - ASM does not get recalculated When Lit Order(Lit Bid price) do not cross ASM during Group Phase, check inverted order on price crossing ASM', async () => {
    const securityId = 'US29250NAR61';
    const securityDescription = 'ENBCN 3.7 07/15/27';
    let orderMid = 327;
    const spread = 8;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userThreeOrder.Price), true, 500);
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price}  for 0.5M.`);

    await browser.pause(configuration.veryShortTimeout);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const priceDiff = 0.5;
    let userTwoImprovedPrice = parseFloat(asmPrice) + parseFloat(priceDiff);
    userTwoImprovedPrice = roundToTick(userTwoImprovedPrice, region.PRICE_INCREMENT_MIN_PRICE_TICKS, region.PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT);

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoImprovedPrice);
    logger.info(`User 2 improves his Bid price of bond ${securityDescription} to ${userTwoImprovedPrice}.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 3 at ${asmPrice}.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 2 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
    expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PNS-029 - ASM Blanks out when it is fully filled for one of the users (1 sided interest) during Group Phase', async () => {
    const securityId = 'US260003AG33';
    const securityDescription = 'DOV 6.6 03/15/38';
    let orderMid = 262;
    const spread = 4;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', 2, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userThreeOrder.Price), true, 500);
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price}  for 0.5M.`);

    await browser.pause(configuration.veryShortTimeout);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice} as it is Single Sided.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
    expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-030 - ASM Does Not recalculate when Lit Order cancelled by one of the user and there is no improvement of Price', async () => {
    const securityId = 'US268317AP93';
    const securityDescription = 'EDF 4 3/4 10/13/35';
    let orderMid = 320;
    const spread = 2;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 1, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(calculatedAsmPrice)).to.equal(parseFloat(asmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('1000');

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-031 - ASM recalculates in Group phase when there are 2 sided interest after ASM blanked out during Private Phase', async () => {
    const securityId = 'US302491AR62';
    const securityDescription = 'FMC 3.95 02/01/22';
    let orderMid = 262;
    const spread = 4;
    const size = 1000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Loser) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    weightings = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userThreeOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(asmPrice)).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userThreeOrder.Price), true, 500);
    logger.info(`User 1 accepts User 3 counterInterest of bond ${securityDescription} at ${userThreeOrder.Price} for 0.5M.`);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect('').to.equal(asmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let recalculatedAsmPrice = (parseFloat(userTwoOrder.Price) + parseFloat(userOneOrder.Price)) / 2;
    recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);

    await browser.pause(configuration.shortTimeout);
    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
    expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('500');

    remainingQuantity = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(size);

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  describe('PNS-051 - Trade execution when StandbyUser amends price to equal the best resting lit bid', () => {
    it('PNS-051.001 - StandbyUser amends price to equal the best resting lit bid during Private phase - Trade execution', async () => {
      const securityId = 'US281020AL15';
      const securityDescription = 'EIX 2.4 09/15/22';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const userOneImprovedPrice = parseFloat(userThreeOrder.Price);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
      expect(tradeSize).to.equal('1000');

      let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
      expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PNS-051.002 - StandbyUser amends price to equal the best resting lit bid during Group phase - Trade execution', async () => {
      const securityId = 'US281020AL15';
      const securityDescription = 'EIX 2.4 09/15/22';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const userOneImprovedPrice = parseFloat(userThreeOrder.Price).toFixed(2);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.pause(configuration.shortTimeout);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
      expect(tradeSize).to.equal('1000');

      let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
      expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  describe('PNS-054 - Trade execution when StandbyUser amends offer price to cross the best resting lit bid', () => {
    it('PNS-054.001 - StandbyUser amends Offer price to cross the best resting lit bid during Private phase - Trade execution at mathematical midpoint', async () => {
      const securityId = 'US281020AL15';
      const securityDescription = 'EIX 2.4 09/15/22';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const userOneImprovedPrice = (parseFloat(userThreeOrder.Price) + parseFloat(1.0)).toFixed(2);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.mediumTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradePrice = calculateMid(parseFloat(userOneImprovedPrice), parseFloat(userThreeOrder.Price));
      logger.info('Expected Trade price for User1 is ', expectedTradePrice);
      expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradePrice));
      expect(tradeSize).to.equal('1000');

      let expectedTradePriceForUser3 = parseFloat(expectedTradePrice);
      expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
      logger.info('Expected Trade price for User3 is ', expectedTradePriceForUser3);
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });

    it('PNS-054.002 - StandbyUser amends Offer price to cross the best resting lit bid during Group phase - Trade execution', async () => {
      const securityId = 'US565849AL02';
      const securityDescription = 'MRO 3.85 06/01/25';
      let orderMid = 175;
      const spread = 5;
      const size = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices();
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const userOneImprovedPrice = parseFloat(userThreeOrder.Price) + parseFloat(1.0);
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
      );
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userThreeOrder.Price));
      expect(tradeSize).to.equal('1000');

      let expectedTradePriceForUser3 = parseFloat(userThreeOrder.Price);
      expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
      const trades = await hydraApiClientUserThree
        .getTradesPanel(securityDescription)
        .getTrades(String(expectedTradePriceForUser3));
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');
    });
  });

  it('PNS-055 - StandbyUser amends Offer price to cross the best resting lit bid during Private phase  - Trade execution at mathematical midpoint with StandbyUser(Fully filled) and PN continues with other users', async () => {
    const securityId = 'US29379VBU61';
    const securityDescription = 'EPD 4.8 02/01/49';
    let orderMid = 175;
    const spread = 5;
    const size = 5000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    const userOneImprovedPrice = parseFloat(userThreeOrder.Price) + parseFloat(1.0);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneImprovedPrice);
    logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    const expectedTradePrice = calculateMid(parseFloat(userOneImprovedPrice), parseFloat(userThreeOrder.Price));
    logger.info('Expected Trade price for User1 is ', expectedTradePrice);
    expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradePrice));
    expect(tradeSize).to.equal('500');

    let expectedTradePriceForUser3 = parseFloat(expectedTradePrice);
    expectedTradePriceForUser3 = Number.isInteger(expectedTradePriceForUser3) ? parseFloat(expectedTradePriceForUser3).toFixed(1) : expectedTradePriceForUser3;
    logger.info('Expected Trade price for User3 is ', expectedTradePriceForUser3);
    const trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser3));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser3)));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('HYD-319 - PNS-056 - Sweep logic functionality when Active user in PN amend their price to cross best resting price -Basic Inverted Order', () => {
    it('PNS-056.001 - Active user in PN amend Bid price to cross the best resting lit Offer during Private phase - Trade execution at best resting lit Offer with ASM to be blank in Private and PN continues with Active User vs Standby User in Group phase', async () => {
      const securityId = 'US428236BM44';
      const securityDescription = 'HPQ 4.3 06/01/21';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 5000000;
      const sizeThree = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = parseFloat(userTwoOrder.Price) - parseFloat(1.0);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
      expect(tradeSize).to.equal('5000');

      let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? parseFloat(expectedTradePriceForUser2).toFixed(1) : expectedTradePriceForUser2;
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
      expect(trades[0].Size).to.equal('5000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as User1 is now Single Sided.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.pause(configuration.shortTimeout);
      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PNS-056.002 - Active user in PN amend Bid price to cross the best resting lit Offer during Group phase - Trade execution at best resting lit Offer and PN continues with Active User vs Standby User in Group phase', async () => {
      const securityId = 'US26874RAJ77';
      const securityDescription = 'ENIIM 4 1/4 05/09/29';
      let orderMid = 175;
      const spread = 7.5;
      const size = 10000000;
      const sizeTwo = 5000000;
      const sizeThree = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = parseFloat(userTwoOrder.Price) - parseFloat(1.0);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
      expect(tradeSize).to.equal('5000');

      let expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
      expectedTradePriceForUser2 = Number.isInteger(expectedTradePriceForUser2) ? parseFloat(expectedTradePriceForUser2).toFixed(1) : expectedTradePriceForUser2;
      const trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
      expect(trades[0].Size).to.equal('5000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      let recalculatedAsmPrice = (parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2;
      recalculatedAsmPrice = roundToTick(recalculatedAsmPrice, region.ASM_MIN_PRICE_TICKS, region.ASM_ROUND_TO_DECIMAL_POINT);
      logger.info(`RecalculatedAsmPrice after User3 improves his price will be :${recalculatedAsmPrice}`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect(parseFloat(asmPrice)).to.equal(parseFloat(recalculatedAsmPrice));
      logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  describe('PNS-057 - Sweep logic functionality when Active user in PN amend their price to cross the best resting price', () => {
    it('PNS-057.001 - Active user in PN amend Bid price to cross the best resting lit Offer during Private phase - Trade execution -Sweep between ASM order and best resting lit Offer', async () => {
      const securityId = 'US674599CM50';
      const securityDescription = 'OXY 3 02/15/27';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 3000000;
      const sizeThree = 5000000;
      const sizeFour = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, sizeFour);
      logger.info(`User2 accepts ASM price of ${asmPrice} at ${sizeFour}`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = parseFloat(userTwoOrder.Price) - parseFloat(1.0);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const expectedTradedPrice = [parseFloat(userTwoOrder.Price), parseFloat(asmPrice)];
      const expectedTradedSize = ['1000', '2000'];
      const countOfTrades = await browser.waitUntil(() => tradePanel
        .getOrderRowCount(securityDescription));
      logger.info('Count of Trades occured is', countOfTrades);
      expect(countOfTrades).to.equal(expectedTradedSize.length);
      await browser.pause(configuration.shortTimeout);
      for (let sizeCount = 0; sizeCount < expectedTradedSize.length; sizeCount += 1) {
        const tradedPrice = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getPrice();
        logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

        const tradeSize = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getSize();
        logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

        expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrice);
        expect(tradeSize).to.be.oneOf(expectedTradedSize);
      }

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PNS-057.002 - Active user in PN amend Bid price to cross the best resting lit Offer during Group phase - Trade execution - Sweep between ASM order and best resting lit Offer', async () => {
      const securityId = 'US887315BM03';
      const securityDescription = 'TWX 6.95 01/15/28';
      let orderMid = 175;
      const spread = 5;
      const size = 10000000;
      const sizeTwo = 3000000;
      const sizeThree = 5000000;
      const sizeFour = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeThree, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmPrice, sizeFour);
      logger.info(`User2 accepts ASM price of ${asmPrice} at ${sizeFour}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const userOneImprovedPrice = parseFloat(userTwoOrder.Price) - parseFloat(1.0);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Bid price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const expectedTradedPrice = [parseFloat(userTwoOrder.Price), parseFloat(asmPrice)];
      const expectedTradedSize = ['1000', '2000'];
      const countOfTrades = await browser.waitUntil(() => tradePanel
        .getOrderRowCount(securityDescription));
      logger.info('Count of trades occured is', countOfTrades);
      expect(countOfTrades).to.equal(expectedTradedSize.length);
      await browser.pause(configuration.shortTimeout);
      for (let sizeCount = 0; sizeCount < expectedTradedSize.length; sizeCount += 1) {
        const tradedPrice = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getPrice();
        logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

        const tradeSize = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, sizeCount + 1)
          .getSize();
        logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

        expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrice);
        expect(tradeSize).to.be.oneOf(expectedTradedSize);
      }

      expectedMarketDepth = [parseFloat(userOneImprovedPrice)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

      await browser.pause(configuration.shortTimeout);
      expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      actualMarketDepth = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraPageModel.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  describe('PNS-058 - Active user in PN amend Offer price to cross the best resting lit Bid- Sweep between Best resting Bid and StandbyUser', () => {
    it('PNS-058.001 - Active user in PN amend Offer price to cross the best resting lit Bid during Private phase - Trade execution- Sweep between best resting lit Bid and StandbyUser  ', async () => {
      const securityId = 'US797440BH66';
      const securityDescription = 'SRE 6 06/01/26';
      let orderMid = 175;
      const spread = 5;
      const size = 2000000;
      const sizeTwo = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      const userOneImprovedPrice = parseFloat(userThreeOrder.Price).toFixed(2);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrices = [parseFloat(userOneImprovedPrice), parseFloat(userTwoOrder.Price)];
      expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.equal('1000');

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as all users are fully filled`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });

    it('PNS-058.002 - Active user in PN amend Offer price to cross the best resting lit Bid during Group phase - Trade execution- Sweep between best resting lit Bid and StandbyUser  ', async () => {
      const securityId = 'US20825CAQ78';
      const securityDescription = 'COP 6 1/2 02/01/39';
      let orderMid = 175;
      const spread = 6;
      const size = 2000000;
      const sizeTwo = 1000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);

      const weightings = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings(rating);
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices(rating);
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userTwoOrder = getNewOrder(securityId, 'buy', 2, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraPageModel.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 (Winner) set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
        expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await browser.pause(configuration.shortTimeout);

      const userOneImprovedPrice = parseFloat(userThreeOrder.Price);
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneImprovedPrice);
      logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

      await browser.waitUntil(
        () => hydraPageModel.getAlerts().isPopUpAlertPresent()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, Pop up alert message is not present`
      );
      const alertMessage = await hydraPageModel.getAlerts().getPopUpAlertMessage();
      logger.info(`User 1 presented with alert: '${alertMessage.AlertText}'.`);

      await hydraPageModel.getAlerts().clickPopUpAlertButton('Yes');
      logger.info('Clicked alert button \'Yes');

      await browser.pause(configuration.shortTimeout);
      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await browser.waitUntil(
        () => tradePanel
          .getOrderByDescription(securityDescription)
          .isTraded()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
      );
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrices = [parseFloat(userOneImprovedPrice), parseFloat(userTwoOrder.Price)];
      expect(parseFloat(tradedPrice)).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.equal('1000');

      const asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('').to.equal(asmPrice);
      logger.info(`Actual and expected ASM are equal at ${asmPrice} as all users are fully filled`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserTwo.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 2 portfolio panel is now empty.');

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserOne.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 1 portfolio panel is now empty.');
    });
  });

  it('PNS-060 - Active user in PN delete their Bid order during Group phase - ASM should not get recalculated when the next best bid do not cross ASM', async () => {
    const securityId = 'US20825CAQ78';
    const securityDescription = 'COP 6 1/2 02/01/39';
    let orderMid = 175;
    const spread = 8;
    const size = 10000000;
    const sizeTwo = 3000000;
    const sizeThree = 5000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeThree, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(calculatedAsmPrice)).to.equal(parseFloat(asmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .deleteForSession();
    logger.info(`User 1 clicks the delete button for bond ${securityDescription}.`);
    await browser.pause(configuration.shortTimeout);

    asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);
    expect(asmPrice).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-061 - Test to check the Price followed by time logic when there is matched price  ', async () => {
    const securityId = 'US68389XBQ79';
    const securityDescription = 'ORCL 4 11/15/47';
    let orderMid = 175;
    const spread = 0;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const tradePanel = hydraPageModel.getTrades();
    await tradePanel.handleMinimised(false);
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('1000');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades(expectedTradePriceForUser2);
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    const portfolioBondCount = await hydraApiClientUserThree
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal(size);
    logger.info(`User 3 did not trade with bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('PNS-062 - Standby user in PN delete their Bid order during Private phase - ', async () => {
    const securityId = 'US023551AJ38';
    const securityDescription = 'HES 7.3 08/15/31';
    let orderMid = 175;
    const spread = 3;
    const size = 10000000;
    const sizeTwo = 3000000;
    const sizeThree = 5000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeThree, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userThreeOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice);

    expect(asmPrice).to.equal(parseFloat(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .deleteForSession();
    logger.info(`User 1 clicks the delete button for bond ${securityDescription}.`);
    logger.info('On clicking the delete button - Order moves back to Portfolio for User1');
    await browser.pause(configuration.shortTimeout);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PNS-063 - Active participant in Private phase fully filled, PN should continue in Group phase with Single Sided participants ', async () => {
    const securityId = 'US29379VBU61';
    const securityDescription = 'EPD 4.8 02/01/49';
    let orderMid = 118.75;
    const spread = 3;
    const size = 3000000;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    let weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeTwo, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread - 1, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Loser) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);

    weightedPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();

    expect(parseFloat(calculatedAsmPrice)).to.equal(parseFloat(asmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(parseFloat(userTwoOrder.Price), true, 500);
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(parseFloat(tradedPrice)).to.equal(parseFloat(userTwoOrder.Price));
    expect(tradeSize).to.equal('500');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price);
    const trades = await hydraApiClientUserTwo
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice} as it is Single Sided.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal for User 1 at ${asmPrice} as it is Single Sided.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  describe('PNS-066 - Scenarios to test Price followed by Time logic with multiple users', () => {
    it('PNS-066.001 -HYD-241 Scenario 2- Trade execution when there are Matched and Crossed orders for multi users- Price followed by time logic', async () => {
      const securityId = 'US718549AE82';
      const securityDescription = 'PSXP 4.9 10/01/46';
      let orderMid = 175;
      const spread = 4;
      const size = 1000000;
      const sizeTwo = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);

      const weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      const userTwoOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserFour.addOrders([userFourOrder]);
      logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

      const userFiveOrder = getNewOrder(securityId, 'sell', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserFive.addOrders([userFiveOrder]);
      logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

      const userSixOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserSix.addOrders([userSixOrder]);
      logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      userFourOrder.Price = userOneOrder.Price - 1;
      await hydraApiClientUserFour.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFourOrder.Price);
      logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserFive.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFiveOrder.Price);
      logger.info(`User 5 set Offer price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserSix.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userSixOrder.Price);
      logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(String(parseFloat(actualMarketDepth[depthCount]))).to.equal(String(parseFloat(expectedMarketDepth[depthCount])));
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userFourOrder.Price)];
      actualMarketDepth = await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(String(parseFloat(actualMarketDepth[depthCount]))).to.equal(String(parseFloat(expectedMarketDepth[depthCount])));
      }
      logger.info(`Market depth for ${userFourOrder.Side} side is ${actualMarketDepth}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPrice = userOneOrder.Price;

      expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradedPrice));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser2 = userTwoOrder.Price;
      let trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser2)));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const expectedTradePriceForUser5 = userOneOrder.Price;
      trades = await hydraApiClientUserFive
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePriceForUser5)));
      expect(trades[0].Size).to.equal('2000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Portfolio panel is empty.`
      );

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      await hydraApiClientUserFour.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 4 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserFour.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 4 portfolio panel is now empty.');

      await hydraApiClientUserSix.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 6 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserSix.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 6 portfolio panel is now empty.');
    });

    it('PNS-066.002 -HYD-241 Scenario 3- Trade execution when there are Matched and Crossed orders for multi users- Price followed by time logic', async () => {
      const securityId = 'US136385AX99';
      const securityDescription = 'CNQCN 3.85 06/01/27';
      let orderMid = 175;
      const spread = 4;
      const size = 1000000;
      const sizeTwo = 2000000;
      const rating = 'IG';
      const region = TICK_CONFIGURATION.US.IG;

      allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
      firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
      await testCommons.cleanUpTest(allApiStrategies);

      let userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);

      const weightings = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightings('IG');
      logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

      const weightedPrice = await hydraApiClientUserOne.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getWeightedAsmPrices('IG');
      logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

      orderMid = getOrderMid(weightedPrice.prices);

      userOneOrder = getNewOrder(securityId, 'buy', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserOne.addOrders([userOneOrder]);
      logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

      const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

      const userTwoOrder = getNewOrder(securityId, 'buy', 0, orderMid, size, rating, region);
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

      const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
      await hydraApiClientUserFour.addOrders([userFourOrder]);
      logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

      const userFiveOrder = getNewOrder(securityId, 'sell', 0, orderMid, sizeTwo, rating, region);
      await hydraApiClientUserFive.addOrders([userFiveOrder]);
      logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

      const userSixOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
      await hydraApiClientUserSix.addOrders([userSixOrder]);
      logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

      await browser.waitUntil(
        () => hydraPageModel.getActionPanel().hasOrders()
        , configuration.mediumTimeout
        , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
      );

      await hydraApiClientUserTwo.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userTwoOrder.Price);
      logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

      await hydraApiClientUserThree.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userThreeOrder.Price);
      logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

      userFourOrder.Price = userOneOrder.Price - 1;
      await hydraApiClientUserFour.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFourOrder.Price);
      logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

      await hydraApiClientUserFive.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userFiveOrder.Price);
      logger.info(`User 5 set Offer price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        await browser.waitUntil(
          () => strategy.getActionPanel()
            .getOrderByDescription(securityDescription)
            .validateForSession()
          , configuration.shortTimeout
          , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
        );
      }
      logger.info('Validated session for all users.');

      let expectedPhase = 'PRICING';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      await hydraApiClientUserSix.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userSixOrder.Price);
      logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

      await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setPrice(userOneOrder.Price);
      logger.info(`User 1 set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

      expectedPhase = 'PRIVATE';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
      let actualMarketDepth = await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

      expectedMarketDepth = [parseFloat(userSixOrder.Price)];
      actualMarketDepth = await hydraApiClientUserOne.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();
      expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
      for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
        expect(parseFloat(actualMarketDepth[depthCount])).to.equal(expectedMarketDepth[depthCount]);
      }
      logger.info(`Market depth for ${userSixOrder.Side} side is ${actualMarketDepth}.`);

      const tradePanel = hydraPageModel.getTrades();
      const hasTraded = await tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded();
      expect(hasTraded).to.be.true;
      logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      const expectedTradedPriceForUser1 = userOneOrder.Price;
      expect(parseFloat(tradedPrice)).to.equal(parseFloat(expectedTradedPriceForUser1));
      expect(tradeSize).to.equal('1000');

      const expectedTradePriceForUser5 = userOneOrder.Price;
      let trades = await hydraApiClientUserFive
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(parseFloat(trades[0].Price)).to.equal(parseFloat(expectedTradePriceForUser5));
      expect(trades[0].Size).to.equal('2000000');
      expect(trades[0].Direction).to.equal('SOLD');
      logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      const expectedTradePriceForUser2 = userTwoOrder.Price;
      trades = await hydraApiClientUserTwo
        .getTradesPanel(securityDescription)
        .getTrades();
      expect(parseFloat(trades[0].Price)).to.equal(parseFloat(expectedTradePriceForUser2));
      expect(trades[0].Size).to.equal('1000000');
      expect(trades[0].Direction).to.equal('BOUGHT');
      logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
      logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

      expectedPhase = 'GROUP';
      await browser.waitUntil(
        () => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .isCurrentPhase(expectedPhase)
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
      );
      logger.info(`${expectedPhase} phase has started.`);

      for (const strategy of allStrategies) {
        const isEmpty = await browser.waitUntil(
          () => strategy.getActionPanel().isEmpty()
          , configuration.veryLongTimeout
          , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
        );
        expect(isEmpty).to.be.true;
      }
      logger.info('Action panel is now empty for all users.');

      await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().hasOrders()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, Portfolio panel is empty.`
      );

      await hydraApiClientUserThree.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

      let isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserThree.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;
      logger.info('User 3 portfolio panel is now empty.');

      await hydraApiClientUserSix.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      logger.info(`User 6 deletes bond ${securityDescription} from portfolio.`);

      isPortfolioEmpty = await browser.waitUntil(
        () => hydraApiClientUserSix.getPortfolio().isEmpty()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
      );
      expect(isPortfolioEmpty).to.be.true;

      logger.info('User 6 portfolio panel is now empty.');
    });
  });

  // Test fails due to hyd-1241
  it('PNS-067 - Test to check if Inverted order gets traded automatically for the second time at end of pricing phase  ', async () => {
    const securityId = 'US743263AE50';
    const securityDescription = 'DUK 7 3/4 03/01/31';
    let orderMid = 175;
    const spread = 3;
    const userTwoOrderSpread = spread + 1;
    const userThreeOrderSpread = spread + 2;
    const size = 1000000;
    const sizeTwo = 10000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', userTwoOrderSpread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'sell', userThreeOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, sizeTwo, 'IG', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Bid price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Offer price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    userFourOrder.Price = String(parseFloat(userOneOrder.Price) - 2.0);
    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Offer price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(String(parseFloat(actualMarketDepth[depthCount]))).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userFourOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);

    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]));
      expectedMarketDepth[depthCount] = String(parseFloat(expectedMarketDepth[depthCount]));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userFourOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradedPrice1 = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    const expectedTradedPrice2 = (parseFloat(userOneOrder.Price) + parseFloat(userThreeOrder.Price)) / 2;
    const expectedTradedPrices = [expectedTradedPrice1, expectedTradedPrice2];
    const expectedTradedSize = ['1000'];
    const tradePanel = hydraPageModel.getTrades();
    const countOfTrades = await browser.waitUntil(() => tradePanel
      .getOrderRowCount(securityDescription));
    expect(countOfTrades).to.equal(expectedTradedPrices.length);
    for (let tradeCount = 0; tradeCount < expectedTradedPrices.length; tradeCount += 1) {
      const tradedPrice = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, tradeCount + 1)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, tradeCount + 1)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.be.oneOf(expectedTradedPrices);
      expect(tradeSize).to.be.oneOf(expectedTradedSize);
    }

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserFour.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 4 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserFour.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 4 portfolio panel is now empty.');
  });

  // Test fails due to hyd-1241
  it('PNS-068 - Test to check if Inverted order & Matched order gets traded satisfying the price followed by time logic  ', async () => {
    const securityId = 'US12673PAE51';
    const securityDescription = 'CA 4 1/2 08/15/23';
    let orderMid = 175;
    const spread = 8;
    const userTwoOrderSpread = 9;
    const userThreeOrderSpread = 10;
    const userFourOrderSpread = 11;
    const userFiveOrderSpread = 12;
    const userSixOrderSpread = 9;
    const size = 1000000;
    const sizeTwo = 3000000;
    const sizeThree = 2000000;
    const sizeFour = 10000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', userThreeOrderSpread, orderMid, sizeTwo, 'HY', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'buy', userFourOrderSpread, orderMid, sizeThree, 'HY', region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userFiveOrder = getNewOrder(securityId, 'buy', userFiveOrderSpread, orderMid, size, 'HY', region);
    await hydraApiClientUserFive.addOrders([userFiveOrder]);
    logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, sizeFour, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userSixOrder = getNewOrder(securityId, 'sell', userSixOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserSix.addOrders([userSixOrder]);
    logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserSix.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSixOrder.Price);
    logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

    userThreeOrder.Price = String(parseFloat(userOneOrder.Price));
    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Bid price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    await hydraApiClientUserFive.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFiveOrder.Price);
    logger.info(`User 5 set Bid price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Winner) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userOneOrder.Price)];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);

    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]));
      expect(String(parseFloat(actualMarketDepth[depthCount]))).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradedPrice1ForUser1 = ((parseFloat(userOneOrder.Price) + parseFloat(userFiveOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrice2ForUser1 = ((parseFloat(userOneOrder.Price) + parseFloat(userFourOrder.Price)) / 2).toFixed(2);
    const expectedTradedPrice3ForUser1 = parseFloat(userOneOrder.Price).toFixed(2);
    const expectedTradedPricesForUser1 = [expectedTradedPrice1ForUser1, expectedTradedPrice2ForUser1, expectedTradedPrice3ForUser1];
    const expectedTradedSizeForUser1 = ['1M', '2M', '3M'];
    const tradePanel = hydraPageModel.getTrades();
    const countOfTrades = await browser.waitUntil(() => tradePanel
      .getOrderRowCount(securityDescription));
    expect(countOfTrades).to.equal(expectedTradedPricesForUser1.length);
    for (let tradeCount = 0; tradeCount < expectedTradedPricesForUser1.length; tradeCount += 1) {
      const tradedPrice = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, tradeCount + 1)
        .getPrice();
      logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

      const tradeSize = await tradePanel
        .getOrderByRowIdAndDescription(securityDescription, tradeCount + 1)
        .getSize();
      logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

      expect(tradedPrice).to.be.oneOf(expectedTradedPricesForUser1);
      expect(tradeSize).to.be.oneOf(expectedTradedSizeForUser1);
    }

    const expectedTradePriceForUser5 = (parseFloat(userFiveOrder.Price) + parseFloat(userOneOrder.Price)) / 2;
    let trades = await hydraApiClientUserFive
      .getTradesPanel(securityDescription)
      .getTrades(expectedTradePriceForUser5);
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser5));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser4 = ((parseFloat(userFourOrder.Price) + parseFloat(userOneOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFour
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser4));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser4));
    expect(trades[0].Size).to.equal('2000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser3 = (parseFloat(userThreeOrder.Price) + parseFloat(userOneOrder.Price)) / 2;
    trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades(expectedTradePriceForUser3);
    expect(String(parseFloat(trades[0].Price))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('3000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is empty.`
    );

    await hydraApiClientUserOne.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserOne.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserSix.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 6 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserSix.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 6 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  // Test fails due to hyd-1241
  it('PNS-069 - Multiple Users -10 users- test to check the Price followed by time logic in both Buy and Sell side ', async () => {
    const securityId = 'US744320BA94';
    const securityDescription = 'PRU 3.935 12/07/49';
    let orderMid = 175;
    const spread = 8;
    const userTwoOrderSpread = 9;
    const userThreeOrderSpread = 10;
    const userFourOrderSpread = 11;
    const userFiveOrderSpread = 12;
    const userSixOrderSpread = 7;
    const userSevenOrderSpread = 6;
    const userEightOrderSpread = 5;
    const userNineOrderSpread = 4;
    const userTenOrderSpread = 3;
    const size = 1000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree, hydraApiClientUserFour, hydraApiClientUserFive, hydraApiClientUserSix,
      hydraApiClientUserSeven, hydraApiClientUserEight, hydraApiClientUserNine, hydraApiClientUserTen];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', userTwoOrderSpread, orderMid, size, rating, region);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', userThreeOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty} and direction of ${userThreeOrder.Side} side.`);

    const userFourOrder = getNewOrder(securityId, 'buy', userFourOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserFour.addOrders([userFourOrder]);
    logger.info(`User 4 added bond ${securityDescription} with size of ${userFourOrder.OrderQty} and direction of ${userFourOrder.Side} side.`);

    const userFiveOrder = getNewOrder(securityId, 'buy', userFiveOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserFive.addOrders([userFiveOrder]);
    logger.info(`User 5 added bond ${securityDescription} with size of ${userFiveOrder.OrderQty} and direction of ${userFiveOrder.Side} side.`);

    const userTenOrder = getNewOrder(securityId, 'buy', userTenOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserTen.addOrders([userTenOrder]);
    logger.info(`User 10 added bond ${securityDescription} with size of ${userTenOrder.OrderQty} and direction of ${userTenOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userSixOrder = getNewOrder(securityId, 'sell', userSixOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserSix.addOrders([userSixOrder]);
    logger.info(`User 6 added bond ${securityDescription} with size of ${userSixOrder.OrderQty} and direction of ${userSixOrder.Side} side.`);

    const userSevenOrder = getNewOrder(securityId, 'sell', userSevenOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserSeven.addOrders([userSevenOrder]);
    logger.info(`User 7 added bond ${securityDescription} with size of ${userSevenOrder.OrderQty} and direction of ${userSevenOrder.Side} side.`);

    const userEightOrder = getNewOrder(securityId, 'sell', userEightOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserEight.addOrders([userEightOrder]);
    logger.info(`User 8 added bond ${securityDescription} with size of ${userEightOrder.OrderQty} and direction of ${userEightOrder.Side} side.`);

    const userNineOrder = getNewOrder(securityId, 'sell', userNineOrderSpread, orderMid, size, rating, region);
    await hydraApiClientUserNine.addOrders([userNineOrder]);
    logger.info(`User 9 added bond ${securityDescription} with size of ${userNineOrder.OrderQty} and direction of ${userNineOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set Bid price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    userThreeOrder.Price = String(parseFloat(userOneOrder.Price));
    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    await hydraApiClientUserFour.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFourOrder.Price);
    logger.info(`User 4 set Bid price of bond ${securityDescription} to ${userFourOrder.Price}.`);

    await hydraApiClientUserFive.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userFiveOrder.Price);
    logger.info(`User 5 set Bid price of bond ${securityDescription} to ${userFiveOrder.Price}.`);

    await hydraApiClientUserTen.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTenOrder.Price);
    logger.info(`User 10 set Bid price of bond ${securityDescription} to ${userTenOrder.Price}.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    await hydraApiClientUserSix.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSixOrder.Price);
    logger.info(`User 6 set Offer price of bond ${securityDescription} to ${userSixOrder.Price}.`);

    await hydraApiClientUserSeven.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userSevenOrder.Price);
    logger.info(`User 7 set Offer price of bond ${securityDescription} to ${userSevenOrder.Price}.`);

    await hydraApiClientUserEight.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userEightOrder.Price);
    logger.info(`User 8 set Offer price of bond ${securityDescription} to ${userEightOrder.Price}.`);

    await hydraApiClientUserNine.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userNineOrder.Price);
    logger.info(`User 9 set Offer price of bond ${securityDescription} to ${userNineOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [userTwoOrder.Price];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [userOneOrder.Price];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = String(parseFloat(actualMarketDepth[depthCount]).toFixed(2));
      expect(actualMarketDepth[depthCount]).to.equal(String(expectedMarketDepth[depthCount]));
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    const expectedTradePriceForUser3 = ((parseFloat(userThreeOrder.Price) + parseFloat(userNineOrder.Price)) / 2).toFixed(2);
    let trades = await hydraApiClientUserThree
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser3));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 3 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 3 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser9 = ((parseFloat(userThreeOrder.Price) + parseFloat(userNineOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserNine
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser9));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 9 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 9 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 9 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser4 = ((parseFloat(userFourOrder.Price) + parseFloat(userEightOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFour
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser4));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 4 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 4 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser8 = ((parseFloat(userFourOrder.Price) + parseFloat(userEightOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserEight
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser8));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 8 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 8 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 8 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser5 = ((parseFloat(userFiveOrder.Price) + parseFloat(userSevenOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserFive
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser5));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 5 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 5 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser7 = ((parseFloat(userFiveOrder.Price) + parseFloat(userSevenOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserSeven
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser7));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 7 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 7 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 7 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser10 = ((parseFloat(userTenOrder.Price) + parseFloat(userSixOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserTen
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser10));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('BOUGHT');
    logger.info(`User 10 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 10 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 10 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    const expectedTradePriceForUser6 = ((parseFloat(userTenOrder.Price) + parseFloat(userSixOrder.Price)) / 2).toFixed(2);
    trades = await hydraApiClientUserSix
      .getTradesPanel(securityDescription)
      .getTrades();
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser6));
    expect(trades[0].Size).to.equal('1000000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 6 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 6 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 6 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptBuySideOrder(String(userTwoOrder.Price), true, '0.5');
    logger.info(`User 1 accepts User 2 counterInterest of bond ${securityDescription} at ${userTwoOrder.Price} for 0.5M.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(String(userTwoOrder.Price));
    expect(tradeSize).to.equal('0.5M');

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  it('PNS-070 - HYD-457-StandbyUser amends Offer price to cross the best resting lit bid during Private phase  - Trade execution at mathematical midpoint with StandbyUser(Fully filled) and PN become Single Sided', async () => {
    const securityId = 'US69403WAE75';
    const securityDescription = 'PACBEA 5.578 07/15/51';
    let orderMid = 175;
    const spread = 5;
    const size = 10000000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);

    const weightings = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', 2, orderMid, size, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${size} and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, action panel has no orders.`
    );

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 (Winner) set Offer price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userThreeOrder.Price);
    logger.info(`User 3 (Winner) set Bid price of bond ${securityDescription} to ${userThreeOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 (Loser) set Offer price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let expectedMarketDepth = [parseFloat(userThreeOrder.Price)];
    let actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    const userOneImprovedPrice = parseFloat(userThreeOrder.Price) + parseFloat(1.0);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneImprovedPrice);
    logger.info(`User 1 improves his Offer price of bond ${securityDescription} to ${userOneImprovedPrice}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, trade did not occur for bond ${securityDescription}`
    );
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);

    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    const expectedTradePrice = (parseFloat(userOneImprovedPrice) + parseFloat(userThreeOrder.Price)) / 2;
    expect(parseFloat(tradedPrice)).to.equal(expectedTradePrice);
    expect(tradeSize).to.equal('10000');

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth} for User1.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth} for User1.`);

    const asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(asmPrice).to.equal('');
    logger.info(`Actual and expected ASM are equal at ${asmPrice} for User1.`);

    expectedMarketDepth = [undefined];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userThreeOrder.Side} side is ${actualMarketDepth} for User2.`);

    // User2 in the UI will see the Offer price as blank though the backend returns the Offer price
    expectedMarketDepth = [parseFloat(userTwoOrder.Price)];
    actualMarketDepth = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      actualMarketDepth[depthCount] = parseFloat(actualMarketDepth[depthCount]);
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth} for User2.`);

    for (const strategy of allApiStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.veryLongTimeout
        , `Timed out after ${configuration.veryLongTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    await hydraApiClientUserTwo.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');
  });

  // Test fails due to HYD-257
  it('PNS-071 - HYD-257 -To test if multiple price levels in Group Phase are supported', async () => {
    const securityId = 'US68389XBQ79';
    const securityDescription = 'ORCL 4 11/15/47';
    let orderMid = 100;
    const spread = 2;
    const size = 1000000;
    const tradedQuantity = 0.5;
    const sizeTwo = 500000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    let userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${size} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraPageModel.addOrders([userOneOrder]);
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${size} and direction of ${userOneOrder.Side} side.`);

    await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userTwoOrder.Price);
    logger.info(`User 2 set price of bond ${securityDescription} to ${userTwoOrder.Price}.`);

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    let expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .setPrice(userOneOrder.Price);
    logger.info(`User 1 set price of bond ${securityDescription} to ${userOneOrder.Price}.`);

    expectedPhase = 'PRIVATE';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightings('IG');
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    weightedPrice = await hydraApiClient.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices('IG');
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    let calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , userOneOrder.Price
      , userTwoOrder.Price
      , region
    );
    calculatedAsmPrice = parseFloat(calculatedAsmPrice).toFixed(2);
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    let asmPrice = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    asmPrice = parseFloat(asmPrice).toFixed(2);

    expect(asmPrice).to.equal(calculatedAsmPrice);
    logger.info(`Actual and expected ASM are equal at ${asmPrice}.`);

    let expectedMarketDepth = [userOneOrder.Price];
    let actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getBuySideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userOneOrder.Side} side is ${actualMarketDepth}.`);

    expectedMarketDepth = [userTwoOrder.Price];
    actualMarketDepth = await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getSellSideOrderValues();
    expect(actualMarketDepth.length).to.equal(expectedMarketDepth.length);
    for (let depthCount = 0; depthCount < expectedMarketDepth.length; depthCount += 1) {
      expect(actualMarketDepth[depthCount]).to.equal(expectedMarketDepth[depthCount]);
    }
    logger.info(`Market depth for ${userTwoOrder.Side} side is ${actualMarketDepth}.`);

    expectedPhase = 'GROUP';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    await hydraPageModel.getActionPanel()
      .getOrderByDescription(securityDescription)
      .acceptSellSideOrder(userTwoOrder.Price, true, tradedQuantity);
    logger.info(`User 1 lifts user 2 offer for bond ${securityDescription} at ${userTwoOrder.Price}@${tradedQuantity}.`);

    const tradePanel = hydraPageModel.getTrades();
    const hasTraded = await tradePanel
      .getOrderByDescription(securityDescription)
      .isTraded();
    expect(hasTraded).to.be.true;
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    expect(tradedPrice).to.equal(userTwoOrder.Price);
    expect(tradeSize).to.equal('0.5M');

    const expectedTradePriceForUser2 = parseFloat(userTwoOrder.Price).toFixed(2);
    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePriceForUser2));
    expect(String(parseFloat(trades[0].Price).toFixed(2))).to.equal(String(expectedTradePriceForUser2));
    expect(trades[0].Size).to.equal('500000');
    expect(trades[0].Direction).to.equal('SOLD');
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}.`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Size}`);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${trades[0].Direction}`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    const portfolioBondCount = await hydraApiClient
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize();
    expect(remainingQuantity).to.equal(sizeTwo);
    logger.info(`User 2 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    // Test fails due to HYD-257- Multiple price levels in Group phase are not accepted
    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('0.5');
    logger.info(`User 1 traded bond ${securityDescription} with size of ${remainingQuantity}.`);

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 2 deletes bond ${securityDescription} from portfolio.`);

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });
});
