/* eslint-disable no-unused-expressions */

import {expect} from 'chai';
import config from '../../../config/framework.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FenicsCredit} from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {HydraLauncher} from '../../../pages/launchers/hydraLauncher';
import Bootstrap from '../../../utilities/framework/bootstrap';
import LoginPage from '../../../pages/LoginPage';
import {shellExec} from '../../../utilities/framework/shellExec';
import {login,cleanUpTest} from '../../../utilities/TestCommons';
import {apiConfig} from "../../../config/api.config";

describe('Test CLOB protocol with 2 users', function testScenario () {
  let client = null;
  let loginUser = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let allApiStrategies = null;
  let allStrategies = null;
  let hydraLauncher = null;
  let firstRun = true;

  /*
   * Mocha timeout
   * prevents from using arrow function in describe() args
   */
  this.timeout(config.veryLongTimeout);

  before(done => {
    client = Bootstrap.init();
    loginUser = new LoginPage(client);
    hydraPageModel = new FenicsCredit(client);
    hydraApiClientUserOne = new FixHydraStrategy(client,apiConfig.users[0]);
    hydraApiClientUserTwo = new FixHydraStrategy(client,apiConfig.users[1]);
    hydraApiClientUserThree = new FixHydraStrategy(client,apiConfig.users[2]);
    hydraApiClientUserFour = new FixHydraStrategy(client,apiConfig.users[3]);
    hydraApiClient = hydraApiClientUserTwo;
    hydraLauncher = new HydraLauncher(client);
    allApiStrategies = [hydraApiClientUserOne,hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    done();
  });

  after(done => {
    client.end();
    shellExec(Bootstrap.clearDownScript);
    done();
  });

  describe('Tests to check the Spread Functionality for CLOB protocol', function testScenarioForSpread (){
    it('CLS-001 - With counter interest - Spread = 0 - Accept ASM', async () => {
      const securityId = 'US02364WBE49';
      const securityDescription = 'AMXLMM 4 3/8 07/16/42';
      const orderMid = 338.5;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraPageModel.addOrders([order]);
      await client.waitUntil(() => hydraPageModel.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .startClob();

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1',order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(orderMid,size);

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const isEmpty = await client.waitUntil(() => strategy.getPortfolio().isEmpty()
          ,config.veryShortTimeout
          ,'Timed out after ' + config.veryShortTimeout + ' seconds, portfolio panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      expect(tradedPrice).to.equal('338.50');
      expect('1M').to.equal(tradeSize);
    });

    it('CLS-002 - With counter interest - Spread = 0 - Accept ASM partial fill', async () => {
      const securityId = 'US69370NAB29';
      const securityDescription = 'PLBIIJ 4 1/4 05/05/25';
      const orderMid = 105.5;
      const spread = 0;
      const size = 1000000;
      const partialFillSize = 500000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraPageModel.addOrders([order]);
      await client.waitUntil(() => hydraPageModel.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .startClob();

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1',order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(orderMid,partialFillSize);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      expect(tradedPrice).to.equal('105.50');
      expect('0.5M').to.equal(tradeSize);

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;

      const remainingQuantity = await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getSize(true);
      expect('0.5').to.equal(remainingQuantity);

      await hydraPageModel.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();
      isPortfolioEmpty = await client.waitUntil(() => hydraPageModel.getPortfolio().isEmpty()
        ,config.mediumTimeout
        ,'Timed out after ' + config.mediumTimeout + ' seconds, portfolio panel is not empty.');
      expect(isPortfolioEmpty).to.be.true;
    });

    it('CLS-003 - With counter interest - Spread = 0 - counter interest same direction and cancel', async () => {
      const securityId = 'US035242AF31';
      const securityDescription = 'ABIBB 0 02/01/19';
      const orderMid = 25.5;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob();
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('0.5','25.5');

      await client.waitUntil(() => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .hasSellOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no sell orders.');

      const expectedVals = ['25.50'];
      const actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
          expect(actualVals[i]).to.equal(expectedVals[i]);

          await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .cancelSellSideOrder(expectedVals[i],true);
      }

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      let isPortfolioEmpty = await hydraPageModel.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;

      isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.false;

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;
    });

    it('CLS-004 - With counter interest in opposite direction after expressing interest in same direction previously', async () => {
      const securityId = 'US037833BW97';
      const securityDescription = 'AAPL 4 1/2 02/23/36';
      const orderMid = 739;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder(0.5,order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasSellOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.veryShortTimeout + ' seconds, action panel has no sell orders.');

      const expectedVals = ['739.00'];
      const actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);

        await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .cancelSellSideOrder(expectedVals[i],true);
      }

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder(0.5,order.Price);

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.veryShortTimeout + ' seconds, trade panel has no orders.');

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.false;

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();

      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      const remainingQuantity = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getSize(true);

      expect(tradedPrice).to.equal('739.00');
      expect('0.5M').to.equal(tradeSize);
      expect(500000).to.equal(remainingQuantity);

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      isPortfolioEmpty = await client.waitUntil( () => hydraApiClient.getPortfolio().isEmpty()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel is not empty.');
      expect(isPortfolioEmpty).to.be.true;
    });

    //Test fails due to the Inverted order pop up message appearing when 32 is entered becos 32 crosses the ASM
    //Once the ASM updated logic is implemented, ASM will be blank for Single Sided CLOB,
    // Thereby inverted order message will not appear and test will pass
    it('CLS-005 - Top of the book functionality for Sell side', async () => {
      const securityId = 'US038222AH86';
      const securityDescription = 'AMAT 2 5/8 10/01/20';
      const orderMid = 31;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1','30');

      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasSellOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no sell orders.');

      await client.pause(config.veryShortTimeout);
      let expectedVals = ['31.00','30.00'];
      let actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);
      }

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1','32.0');

      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasSellOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no sell orders.');

      await client.pause(config.shortTimeout);
      expectedVals = ['32.00'];
      actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getSellSideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);
      }

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        , config.veryShortTimeout
        , 'Timed out after ' + config.veryShortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getPortfolio().isEmpty()
          , config.shortTimeout
          , 'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    });

    //Test fails due to the Inverted order pop up message appearing when 32 is entered becos 32 crosses the ASM
    //Once the ASM updated logic is implemented, ASM will be blank for Single Sided CLOB,
    // Thereby inverted order message will not appear and test will pass
    it('CLS-006 - Top of the book functionality for Buy side', async () => {
      const securityId = 'US059165EE64';
      const securityDescription = 'EXC 2.8 08/15/22';
      const orderMid = 31;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'buy', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('3','32.0');

      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no buy orders.');

      await client.pause(config.veryShortTimeout);
      let expectedVals = ['31.00','32.00'];
      let actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);
      }

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('3','30.0');

      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no buy orders.');

      await client.pause(config.shortTimeout);
      expectedVals = ['30.00'];
      actualVals = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getBuySideOrderValues();

      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);
      }

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        , config.veryShortTimeout
        , 'Timed out after ' + config.veryShortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getPortfolio().isEmpty()
          , config.shortTimeout
          , 'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    });

    it('CLS-007 - Accept the ASM price during CLOB session (Lit Order)', async () => {
      const securityId = 'US059438AH41';
      const securityDescription = 'JPM 7 5/8 10/15/26';
      const orderMid = 95.5;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'buy', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1',order.Price);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      for (const strategy of allStrategies) {
        // eslint-disable-next-line
        const isEmpty = await client.waitUntil(() => strategy.getPortfolio().isEmpty()
          ,config.veryShortTimeout
          ,'Timed out after ' + config.veryShortTimeout + ' seconds, portfolio panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      expect(tradedPrice).to.equal('95.50');
      expect('1M').to.equal(tradeSize);
    });

    it('CLS-008 - Accept the ASM price but with reduced size during CLOB session (Lit Order)', async () => {
      const securityId = 'US06048WWX46';
      const securityDescription = 'BAC 5.8 06/13/28';
      const orderMid = 842.5;
      const spread = 0;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('0.5',order.Price);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          ,config.longTimeout
          ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();
      expect(tradedPrice).to.equal('842.50');
      expect('0.5M').to.equal(tradeSize);

      let isPortfolioEmpty = await hydraPageModel.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;

      isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.false;

      const remainingQuantity = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getSize();
      expect(remainingQuantity).to.equal(500000);
    });

    it('CLS-009 - Inverted Order - Trades get executed at the ASM price though the Counterparty had offered to sell at Higher price than ASM (Lit Order-Negative test)', async () => {
      const securityId = 'US064159KU98';
      const securityDescription = 'BNS 0 01/08/21';
      const orderMid = 31;
      const spread = 2;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'buy', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.longTimeout
        ,'Timed out after ' + config.longTimeout + ' seconds, Action panel has no orders ');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('1.0',order.Price+spread);

      // Pop up warning as 'You're about to submit an order that will result in an execution. Do you wish to continue?'
      await client.pause(config.veryShortTimeout);
      hydraPageModel.getAlerts().clickPopUpAlertButton('Continue');

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          , config.longTimeout
          , 'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      expect(tradedPrice).to.equal('31.00');
      expect('1M').to.equal(tradeSize);

      for (const strategy of allStrategies) {
        const isPortfolioEmpty = await strategy.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      }
    });

    it('CLS-010 - Inverted Order - Trades get executed at the ASM price though the Counterparty had offered to buy at reduced price than ASM (Lit Order-Negative test)', async () => {
      const securityId = 'US126410LM99';
      const securityDescription = 'CSX 6.251 01/15/23';
      const orderMid = 31;
      const spread = 2;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);

      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.longTimeout
        ,'Timed out after ' + config.longTimeout + ' seconds, Action panel has no orders ');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('1.0',order.Price-spread);

      // Pop up warning as 'You're about to submit an order that will result in an execution. Do you wish to continue?'
      await client.pause(config.veryShortTimeout);
      hydraPageModel.getAlerts().clickPopUpAlertButton('Continue');

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
          , config.longTimeout
          , 'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, trade panel has no orders.');

      const tradedPrice = await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();
      const tradeSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      expect('1M').to.equal(tradeSize);
      expect(tradedPrice).to.equal('31.00');

      await client.pause(config.shortTimeout);
      for (const strategy of allStrategies) {
        const isPortfolioEmpty = await strategy.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      }
    });

    // This test fails because currently ASM gets recalculated though the Improved Bid price do not cross the ASM
    // Once the ASM updated logic is implemented,
    // ASM of 105.25 will remain static and ASM will not get recalculated with the Improved Bid price which do not cross the ASM
    // Order will then get traded at this ASM price of 105.25 and this test will Pass
    it('CLS-011 - ASM calculated with Best Bid/Offer, ASM do not recalculate when Improved Bid do not Cross the ASM, and Trades get executed at the ASM price', async () => {
      const securityId = 'US158525AT25';
      const securityDescription = 'IP 7.2 11/01/26';
      const orderMid = 102;
      const asmTradedPrice = 105.00;
      const spread = 3;
      const size = 3000000;
      const partialFillSize = 1500000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

      //ASM to be blank for Single Sided Clob- Offer : 103.50
      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

      //Upload Buy Side Order
      const buyOrder = getNewOrder(securityId, 'buy', spread, orderMid + spread, size);
      await hydraPageModel.addOrders([buyOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no order');

      // Best Bid/Offer: 106.50/103.50, ASM set as 105.00
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('2.0','106.50');
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order');

      // Improve Buy Side Lit Order price to 105.50 so that ASM is not recalculated as the ASM do not cross the ASM of 105.0
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('2.0','105.50');
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order');

      //Create Dark Order-Buy side ASM entry
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('2.0');

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmTradedPrice,partialFillSize);

      for (const strategy of allStrategies){
        const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders(), config.veryShortTimeout);

      const tradedPrice= await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();

      const tradedSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      //Assert executed trade at ASM price at reduced size
      expect(tradedPrice).to.equal(String(asmTradedPrice));
      expect(tradedSize).to.equal('1.5M');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;
    });

    describe('CLS-012 - Tests to check the impact on Dark Order when ASM gets changed',async () =>{
      it('CLS-012.001 - Dark Order ASM entry remain when ASM do not change', async () => {
        const securityId = 'US172967KG57';
        const securityDescription = 'C 3.7 01/12/26';
        const orderMid = 102;
        const spread = 3;
        const size = 3000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
        await hydraApiClient.addOrders([order]);
        await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

        //On launching Single Sided Clob-ASM to be blank
        await hydraApiClient.getPortfolio()
            .getOrderByDescription(securityDescription)
            .launchClob(order.Price);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setBuySideLitOrder('3.0','106.0')
        await client.waitUntil(() => hydraPageModel.getActionPanel()
                .getOrderByDescription(securityDescription)
                .hasBuyOrders()
            ,config.veryShortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order');

        //Best Bid/ Offer - 106/ 103.50 , ASM to be 104.75
        //Assert ASM to be 104.75
        let asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('104.75').to .equal(asmPrice);

        //Create Dark Order-Buy side ASM entry
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .acceptAsm('2.0');

        //Assert DarkOrder Buy side entry
        const expectedVals = ['106.00','2.0'];
        let actualVals = [];
        do {
          actualVals = await hydraPageModel.getActionPanel()
              .getOrderByDescription(securityDescription)
              .getBuySideOrderValues();
        } while(actualVals.length != expectedVals.length);
        expect(actualVals.length).to.equal(expectedVals.length);
        for (let i = 0; i < expectedVals.length; i++) {
          expect(actualVals[i]).to.equal(expectedVals[i]);
        }

        //Set Sell side Lit order (Worse price) such that it does not Cross the ASM of 104.75
        // ASM does not get recalculated and remain as 104.75
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setSellSideLitOrder('3.0','102.0')

        //Assert ASM does not get recalculated and still remain as 104.75
        asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('104.75').to .equal(asmPrice);

        //Create Dark Order -Sell side ASM entry
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .acceptAsm('1.5');

        //Assert Sell side Dark Order values
        const sellSideExpectedVals = ['1.5','103.50','102.00'];
        let sellSideActualVals = [];
        do{
          sellSideActualVals = await hydraPageModel.getActionPanel()
              .getOrderByDescription(securityDescription)
              .getSellSideOrderValues();
        }while(sellSideActualVals.length != sellSideExpectedVals.length);
        expect(sellSideActualVals.length).to.equal(sellSideExpectedVals.length);
        for (let i = 0; i < sellSideExpectedVals.length; i++) {
          expect(sellSideActualVals[i]).to.equal(sellSideExpectedVals[i]);
        }

        //DarkOrder Buy side entry to remain as it is a better price
        const buySideExpectedVals = ['106.00', '2.0'];
        let buySideActualVals = [];
        do {
          buySideActualVals= await hydraPageModel.getActionPanel()
              .getOrderByDescription(securityDescription)
              .getBuySideOrderValues();
        }while(buySideActualVals.length != buySideExpectedVals.length);
        expect(buySideActualVals.length).to.equal(buySideExpectedVals.length);
        for (let i = 0; i < buySideExpectedVals.length; i++) {
          expect(buySideActualVals[i]).to.equal(buySideExpectedVals[i]);
        }

        for (const strategy of allStrategies){
          const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
          expect(isEmpty).to.be.true;
        }

        await hydraApiClient.getPortfolio()
            .getOrderByDescription(securityDescription)
            .delete();

        let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      });

      // This test fails because on Setting Sell side Lit order (Improved price -105), Inverted Order pop up message appear incorrectly
      // Once the ASM recalculation and Inverted order logic is implemented,
      // Setting the Sell Side Lit order (Improved price -105) will not throw pop up message,
      // ASM will get recalculated ,Buy side Dark Order will get cancelled and the test will pass
      it('CLS-012.002 - Dark Order ASM entry cancels when ASM gets recalculated', async () => {
        const securityId = 'US172967KG57';
        const securityDescription = 'C 3.7 01/12/26';
        const orderMid = 102;
        const spread = 3;
        const size = 3000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
        await hydraApiClient.addOrders([order]);
        await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

        //On launching Single Sided Clob-ASM to be blank
        await hydraApiClient.getPortfolio()
            .getOrderByDescription(securityDescription)
            .launchClob(order.Price);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setBuySideLitOrder('3.0','106.0')
        await client.waitUntil(() => hydraPageModel.getActionPanel()
                .getOrderByDescription(securityDescription)
                .hasBuyOrders()
            ,config.veryShortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order');

        //Best Bid/ Offer - 106/ 103.50 , ASM to be 104.75
        //Assert ASM to be 104.75
        let asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('104.75').to .equal(asmPrice);

        //Create Dark Order-Buy side ASM entry
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .acceptAsm('2.0');

        //Assert DarkOrder Buy side entry
        const expectedVals = ['106.00','2.0'];
        let actualVals = [];
        do {
          actualVals = await hydraPageModel.getActionPanel()
              .getOrderByDescription(securityDescription)
              .getBuySideOrderValues();
        } while(actualVals.length != expectedVals.length);
        expect(actualVals.length).to.equal(expectedVals.length);
        for (let i = 0; i < expectedVals.length; i++) {
          expect(actualVals[i]).to.equal(expectedVals[i]);
        }

        //Set Sell side Lit order (Improved price-105) such that it Cross the ASM of 104.75
        // ASM get recalculated to be 105.50
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setSellSideLitOrder('3.0','105.0')

        await client.pause(config.shortTimeout);

        //Assert ASM get recalculated as 105.5
        asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('105.50').to .equal(asmPrice);

        //DarkOrder Buy side entry of 2M gets cancelled
        const buySideExpectedVals = ['106.00'];
        let buySideActualVals = [];
        do {
          buySideActualVals= await hydraPageModel.getActionPanel()
              .getOrderByDescription(securityDescription)
              .getBuySideOrderValues();
        }while(buySideActualVals.length != buySideExpectedVals.length);
        expect(buySideActualVals.length).to.equal(buySideExpectedVals.length);
        for (let i = 0; i < buySideExpectedVals.length; i++) {
          expect(buySideActualVals[i]).to.equal(buySideExpectedVals[i]);
        }

        for (const strategy of allStrategies){
          const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
          expect(isEmpty).to.be.true;
        }

        await hydraApiClient.getPortfolio()
            .getOrderByDescription(securityDescription)
            .delete();

        let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      });
    });

    it('CLS-013 - Two sided Clob- Trade at ASM price- DarkOrder Size reduces and order moving back to Portfolio ', async () => {
      const securityId = 'US1730T0KZ11';
      const securityDescription = 'C 0 11/09/30';
      const orderMid = 105.5;
      const asmTradedPrice = 108.25;
      const spread = 2;
      const size = 3000000;
      const partialFillSize = 1500000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('3.0','110.0')
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order ');

      // Best Bid/ Offer - 110/106.50, ASM is 108.25
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('108.25').to.equal(asmPrice);

      //Set Sell Side Lit order of 105.0 that does not cross the ASM and ASM remain as 108.25
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('3.0','105.0')
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasSellOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no SellSideLit Order');

      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('108.25').to.equal(asmPrice);

      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmTradedPrice,partialFillSize);

      //Dark order- created for size of 2.0M
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('2.0');

      const expectedVals = ['106.50','105.00'];
      let actualVals =[];
      do {
        actualVals = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getSellSideOrderValues();
      }while(actualVals.length != expectedVals.length);
      expect(actualVals.length).to.equal(expectedVals.length);
      for (let i = 0; i < expectedVals.length; i++) {
        expect(actualVals[i]).to.equal(expectedVals[i]);
      }

      //Assert Dark Order size reduced from 2.0M to 0.5M
      const buySideExpectedVals = ['110.00','0.5'];
      let buySideActualVals =[];
      do {
        buySideActualVals = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getBuySideOrderValues();
      }while(buySideActualVals.length != buySideExpectedVals.length);
      expect(buySideActualVals.length).to.equal(buySideExpectedVals.length);
      for (let i = 0; i < buySideExpectedVals.length; i++) {
        expect(buySideActualVals[i]).to.equal(buySideExpectedVals[i]);
      }

      for (const strategy of allStrategies){
        const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders(), config.veryShortTimeout);

      const tradedPrice= await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();

      const tradedSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      expect(tradedPrice).to.equal(String(asmTradedPrice));
      expect(tradedSize).to.equal('1.5M');

      //Assert Order moving back to Portfolio panel
      const portfolioSize = await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .getSize();
      expect(portfolioSize).to.equal(size);

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;
    });

    it('CLS-014 - Two sided Clob- Trade at ASM price at reduced size ', async () => {
      const securityId = 'US191219AV64';
      const securityDescription = 'KO 0 06/20/20';
      const orderMid = 105.5;
      const asmTradedPrice = 107.00;
      const spread = 2;
      const size = 3000000;
      const partialFillSize = 1500000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('3.0','107.5')
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no BuySideLit Order ');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setSellSideLitOrder('3.0','105.0')
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasSellOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no SellSideLit Order');

      // Best Bid/ Offer - 107.50/106.50, ASM to be 107.00
      let asmPrice = await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .getAsmPrice();
      expect('107.00').to.equal(asmPrice);

      //Dark order created for 1.5M by API user
      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmTradedPrice,partialFillSize);

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm('1.5');

      for (const strategy of allStrategies){
        const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders(), config.veryShortTimeout);

      const tradedPrice= await tradePanel
        .getOrderByDescription(securityDescription)
        .getPrice();

      const tradedSize = await tradePanel
        .getOrderByDescription(securityDescription)
        .getSize();

      expect(tradedPrice).to.equal('107.00');
      expect(tradedSize).to.equal('1.5M');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;
    });

    it('CLS-015 - Spread = 2 - Trade at Dark and Lit Order-Sweep functionality ', async () => {
      const securityId = 'US22532LAN47';
      const securityDescription = 'ACAFP 0 04/15/19';
      const orderMid = 105.5;
      const spread = 2;
      const size = 3000000;
      const partialFillSize = 1500000;
      const asmTradedPrice = 107;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
      await hydraApiClient.addOrders([order]);
      await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .launchClob(order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
        ,config.shortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no orders');

      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .setBuySideLitOrder('3.0','107.5')
      await client.waitUntil(() => hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .hasBuyOrders()
        ,config.veryShortTimeout
        ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Buy order.');

      //Dark Order created for size of 1.5M
      await hydraApiClient.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptAsm(asmTradedPrice,partialFillSize);

      //UI user accepts counter interest price (Lit Order)
      await hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .acceptPrice('2.0');

      for (const strategy of allStrategies){
        const isEmpty = await client.waitUntil(()=> strategy.getActionPanel().isEmpty(), config.longTimeout);
        expect(isEmpty).to.be.true;
      }

      const tradePanel = hydraPageModel.getTrades();
      await client.waitUntil(() => tradePanel.hasOrders(), config.longTimeout);

      let orderRowCount = await tradePanel
        .getOrderRowCount(securityDescription);

      let expectedTrades = [
        {Price: 107.00,Size : '1.5M'},
        {Price: 106.50,Size : '0.5M'}
      ];

      //Test will fail due to this issue - Issue:289
      //Assert trades are executed with sweep logic
      for(let rowId = 0; rowId < expectedTrades.length ; rowId++){
        let actualTrades = await tradePanel
          .getOrderByRowIdAndDescription(securityDescription, rowId+1)
          .getAllTrades();

        expect(actualTrades[0].Price).to.equal(expectedTrades[rowId].Price);
        expect(actualTrades[0].Size).to.equal(expectedTrades[rowId].Size);
      };

      await hydraApiClient.getPortfolio()
        .getOrderByDescription(securityDescription)
        .delete();

      let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
      expect(isPortfolioEmpty).to.be.true;
    });

    describe('CLS-016 -Tests to check the Igngore Functionality', async () =>{
      //Test fails due to HYD-102
      it('CLS-016.001 - Ignore Clob session by User who launches CLOB- Order moves back to portfolio ', async () => {
        const securityId = 'US225433AK71';
        const securityDescription = 'CS 3 1/8 12/10/20';
        const orderMid = 105.5;
        const spread = 2;
        const size = 3000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const order = getNewOrder(securityId, 'sell', spread, orderMid, size);
        await hydraPageModel.addOrders([order]);
        await client.waitUntil(()=> hydraPageModel.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

        await hydraPageModel.getPortfolio()
            .getOrderByDescription(securityDescription)
            .startClob();
        await hydraPageModel.getPortfolio()
            .getOrderByDescription(securityDescription)
            .setSellSideLitOrder('1.0',order.Price);

        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .ignoreForSession();

        await client.pause(config.veryShortTimeout);
        const portfolioSize = await hydraPageModel.getPortfolio()
            .getOrderByDescription(securityDescription)
            .getSize();
        expect(portfolioSize).to.equal(size);

        await hydraPageModel.getPortfolio()
            .getOrderByDescription(securityDescription)
            .delete();

        let isPortfolioEmpty = await hydraApiClient.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      });

      //Test fails due to HYD-102 - Ignore icon is not clickable by UI user
      it('CLS-016.002 - Ignore Clob session by User who joins the CLOB -Order do not move back to portfolio ', async () => {
        const securityId = 'US064159KU98';
        const securityDescription = 'BNS 0 01/08/21';
        const orderMid = 31;
        const spread = 2;
        const size = 1000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const order = getNewOrder(securityId, 'buy', spread, orderMid, size);
        await hydraApiClient.addOrders([order]);
        await client.waitUntil(() => hydraApiClient.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

        await hydraApiClient.getPortfolio()
            .getOrderByDescription(securityDescription)
            .launchClob(order.Price);

        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .ignoreForSession();

        await client.pause(config.veryShortTimeout);
        let isPortfolioEmpty = await hydraPageModel.getPortfolio().isEmpty();
        expect(isPortfolioEmpty).to.be.true;
      });

    });

    // -Manual test available for this.
    it.skip('CLS-017 - Test to check the GLOW functionality ', async () => {
      /*
      1. Login to Hydra application
      2. User1 uploads a ISIN with Buy Side and starts a CLOB
      3. User2 joins the CLOB and accept the ASM
      4. Expected Result:
         ASM price should glow as trade got executed at the ASM price for both the users
         Trade should get executed at ASM price and available in My Trades panel for both users
      */
    });

    // -Manual test available for this.
    it.skip('CLS-018 - Test to check the Yellow Flash Functionality ', async () => {
      /*
        1. Login to Hydra application
        2. User1 uploads a ISIN with Buy Side and starts a CLOB
        3. User2 joins the CLOB and sets the Offer price and Offer size
        4. ASM is displayed
        5. User2 then improves the Offer price
        6. ASM should then be amended
        4. Expected Result:
         ASM should flash yellow and should get amended to new price
      */
    });

    //TODO- write manual test for this.
    it.skip('CLS-019 - Test to check the Relevance band Functionality ', async () => {
    });

    //HYD-3 - ASM updated logic story -Yet to be implemented
    //Test fails becos when User3 sets the Offer price of 261.0, Order is getting rejected with OrdRejReason:99
    //Once ASM updated logic is implemented, When User3 set the Offer price of 261, ASM will not get recalculated and
    //ASM will remain as 261.50 and the Test will pass
    it('CLS-20 - ASM is calculated using best 2 sided Orders and calculated only once when the new Offer price do not cross the current ASM ',async() =>{
      const securityId = 'US96950FAF18';
      const securityDescription = 'WMB 6.3 04/15/40';
      const orderMid = 261.50
      const spread = 2;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'IG');
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      await client.waitUntil(() => hydraApiClientUserTwo.getPortfolio().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

      //On launching CLOB, ASM is to be Blank as it is single sided- User2 Offer price : 260.50
      await hydraApiClientUserTwo.getPortfolio()
          .getOrderByDescription(securityDescription)
          .launchClob(userTwoOrder.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

      // User1 set Bid Price as 262.50
      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid , size,'IG');
      await hydraPageModel.addOrders([userOneOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setBuySideLitOrder('0.5','262.5');

      //Best Bid/Offer - 262.50/ 260.50 , ASM is calculated as - 261.50
      await client.pause(config.veryShortTimeout);
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('261.50').to.equal(asmPrice)

      // User3 sets an Offer price of 261 (Improved price of 261) but it does not cross ASM of 261.50 and hence ASM is not recalculated
      const userThreeOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size,'IG');
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      await client.waitUntil(() => hydraApiClientUserThree.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserThree.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('261.0');

      await client.pause(config.veryShortTimeout);
      //Best Bid/Offer - 262.50/ 261 , Please note that since the offer price of 261 did not cross ASM,
      //ASM will not get recalculated and will remain as 261.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('261.50').to.equal(asmPrice);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
            ,config.longTimeout
            ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    });

    describe('Tests to check ASM impact when the new Price equals or crosses the current ASM ', async () => {
      //HYD-3 - ASM updated logic story -Yet to be implemented
      //Test fails becos when User3 sets the Offer price of 261.50, Order is getting rejected with OrdRejReason:99
      //Once ASM updated logic is implemented, When User3 set the Offer price of 261.50, ASM will get recalculated and Test will pass
      it('CLS-21.001 - ASM is calculated using best 2 sided Orders and gets recalculated when the new Offer Price equals the current ASM  ',async() =>{
        const securityId = 'XS0434449640';
        const securityDescription = 'HSBC 0 07/01/39';
        const orderMid = 261.50
        const spread = 2;
        const size = 1000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
        await hydraApiClientUserTwo.addOrders([userTwoOrder]);
        await client.waitUntil(() => hydraApiClientUserTwo.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

        //On launching CLOB, ASM is to be Blank as it is single sided- User2 Offer price : 260.50
        await hydraApiClientUserTwo.getPortfolio()
            .getOrderByDescription(securityDescription)
            .launchClob(userTwoOrder.Price);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

        // User1 set Bid Price as 262.50
        const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid , size,'IG');
        await hydraPageModel.addOrders([userOneOrder]);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
        console.log(userOneOrder.Price);
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setBuySideLitOrder('0.5',userOneOrder.Price);

        //Best Bid/Offer - 262.50/ 260.50 , ASM is calculated as - 261.50
        await client.pause(config.veryShortTimeout);
        let asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('261.50').to.equal(asmPrice)

        // User3 sets an Offer price of 261.50 so that this new Offer price is equal to the current ASM of 261.50
        const userThreeOrder = getNewOrder(securityId, 'sell', 1 , orderMid, size, 'IG');
        await hydraApiClientUserThree.addOrders([userThreeOrder]);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
        await hydraApiClientUserThree.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setPrice('261.50');

        await client.pause(config.veryShortTimeout);
        //Best Bid/Offer - 262.50/ 261.50 , ASM will get recalculated  as 262.00
        asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('262.00').to.equal(asmPrice);

        for (const strategy of allStrategies) {
          const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
              ,config.longTimeout
              ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
          expect(isEmpty).to.be.true;
        }
      });

      //HYD-3 - ASM updated logic story -Yet to be implemented
      //Test fails becos when User3 sets the Offer price of 261.75, inverted order pop up message is displayed and Order is then rejected by the server
      //Once ASM updated logic / Inverted order logic is implemented, When User3 set the Offer price of 261.75, there should not be inverted order warning message,
      // ASM will get recalculated as 262.00 and the Test will pass
      it('CLS-21.002 - ASM is calculated using best 2 sided Orders and gets recalculated when the new Offer Price crosses the current ASM  ',async() =>{
        const securityId = 'US416515BD59';
        const securityDescription = 'HIG 4.4 03/15/48';
        const orderMid = 261.50
        const spread = 2;
        const size = 1000000;

        firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
        await cleanUpTest(client,allApiStrategies);

        const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
        await hydraApiClientUserTwo.addOrders([userTwoOrder]);
        await client.waitUntil(() => hydraApiClientUserTwo.getPortfolio().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

        //On launching CLOB, ASM is to be Blank as it is single sided- User2 Offer price : 260.50
        await hydraApiClientUserTwo.getPortfolio()
            .getOrderByDescription(securityDescription)
            .launchClob(userTwoOrder.Price);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

        // User1 set Bid Price as 262.50
        const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid , size,'IG');
        await hydraPageModel.addOrders([userOneOrder]);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
        await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setBuySideLitOrder('0.5','262.50');

        //Best Bid/Offer - 262.50/ 260.50 , ASM is calculated as - 261.50
        await client.pause(config.veryShortTimeout);
        let asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('261.50').to.equal(asmPrice);

        // User3 sets an Offer price of 261.75 so that this new Offer price crosses current ASM of 261.50
        const userThreeOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size,'IG');
        await hydraApiClientUserThree.addOrders([userThreeOrder]);
        await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
            ,config.shortTimeout
            ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
        await hydraApiClientUserThree.getActionPanel()
            .getOrderByDescription(securityDescription)
            .setPrice('261.75');

        await client.pause(config.veryShortTimeout);
        //Best Bid/Offer - 262.50/ 261.75 , ASM will get recalculated  as 262.25
        asmPrice = await hydraPageModel.getActionPanel()
            .getOrderByDescription(securityDescription)
            .getAsmPrice();
        expect('262.25').to.equal(asmPrice);

        for (const strategy of allStrategies) {
          const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
              ,config.longTimeout
              ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
          expect(isEmpty).to.be.true;
        }
      });
    });

    //HYD-3 - ASM updated logic story -Yet to be implemented
    //Test fails becos when User3 sets an Offer price of 261 , ASM gets recalculated though it does not cross ASM
    //Once ASM updated logic / Inverted order logic is implemented, When User3 set the Offer price of 261, ASM will Not get recalculated
    //Once the Trade is executed , ASM will recalculate and the Test will pass
    it('CLS-22 - ASM is calculated using best 2 sided Orders and gets recalculated when there is a Trade ',async() =>{
      const securityId = 'US225433AR25';
      const securityDescription = 'CS 4.55 04/17/26';
      const orderMid = 261.50
      const spread = 2;
      const size = 3500000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      await client.waitUntil(() => hydraApiClientUserTwo.getPortfolio().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders for API user.');

      //On launching CLOB, ASM is to be Blank as it is single sided- User2 Offer price : 260.50
      await hydraApiClientUserTwo.getPortfolio()
          .getOrderByDescription(securityDescription)
          .launchClob(userTwoOrder.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, Action panel has no Sell order');

      const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid , size,'IG');
      await hydraPageModel.addOrders([userOneOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      // User1 set Bid Price as 262.50
      await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setBuySideLitOrder('3.5','262.5')

      //Best Bid/Offer - 262.50/ 260.50 , ASM is calculated as - 261.50
      await client.pause(config.veryShortTimeout);
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('261.50').to.equal(asmPrice)

      // User3 sets an Offer price of 261 (Improved price of 261) but it does not cross ASM of 261.50
      const userThreeOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size,'IG');
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserThree.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice(userThreeOrder.Price);

      await client.pause(config.veryShortTimeout);
      //Best Bid/Offer - 262.50/ 261 , Please note that since the offer price of 261 did not cross ASM,
      //ASM will not get recalculated and will remain as 261.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('261.50').to.equal(asmPrice);

      // User1 then accepts the Offer Price of User3
      await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .acceptSellSideOrder('261.00','3.0');

      await client.pause(config.veryShortTimeout);
      //Best Bid/Offer - 262.50/ 261 , Please note that since the order gets traded above
      //ASM will get recalculated and will recalculate as 261.75
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('261.75').to.equal(asmPrice);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
            ,config.longTimeout
            ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    });

    //HYD-3 - ASM updated logic story -Yet to be implemented
    //Test fails becos when User2 sets an Offer price of 337.50 , ASM gets recalculated though it does not cross ASM
    //Once ASM updated logic / Inverted order logic is implemented, When User2 set the Offer price of 337.50, ASM will Not get recalculated
    //When User3 set the Offer price of 338.50, ASM will get recalculated and the Test will pass
    it('CLS-23 - Two sided Clob-ASM is calculated using 2 sided orders when the clob is launched and ASM is also recalculated when the order cross the ASM', async() =>{
      const securityId = 'US56585AAS15';
      const securityDescription = 'MPC 3.8 04/01/28';
      const orderMid = 338.50;
      const spread = 4;
      const size = 1000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
      await hydraPageModel.addOrders([order]);
      await client.waitUntil(() => hydraPageModel.getPortfolio().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .startClob();

      //Two Sided CLOB- Bid /Offer :  340.5/336.50
      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .setBuyAndSellSideLitOrder( '2',order.Price + spread,'1',order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      //Best Bid / Offer 340.5 / 336.50, ASM is calculated as 338.50
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      // User2 sets an Offer price of 337.50 so that this new Offer price do not cross the ASM of 338.50
      const userTwoOrder = getNewOrder(securityId, 'sell', spread -2 , orderMid, size,'IG');
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserTwo.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('337.50');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 340.50 / 337.50, ASM is not recalculated and will remain as 338.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      // User3 sets an Offer price of 338.50 so that this new Offer price is equal to the current ASM of 338.50
      const userThreeOrder = getNewOrder(securityId, 'sell', spread -4 , orderMid, size,'IG');
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserThree.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('338.50');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 340.5 / 338.5, ASM is calculated as 339.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('339.50').to.equal(asmPrice);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
            ,config.longTimeout
            ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    })

    //HYD-3 - ASM updated logic story -Yet to be implemented
    //Test fails becos when User2 sets an Offer price of 337.0 , ASM gets recalculated though it does not cross ASM
    //Once ASM updated logic / Inverted order logic is implemented, When User2 set the Offer price of 337.0, ASM will Not get recalculated
    //When User3 set the Offer price of 338.75, ASM will get recalculated and the Test will pass
    it('CLS-24 - Two sided Clob- ASM is Not recalculated when the order do not cross the ASM but ASM is recalculated when Trade occurs ', async() =>{
      const securityId = 'US59217HBL06';
      const securityDescription = 'MET 0 09/19/19';
      const orderMid = 338.50;
      const spread = 4;
      const size = 3000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
      await hydraPageModel.addOrders([order]);
      await client.waitUntil(() => hydraPageModel.getPortfolio().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .startClob();

      //Two Sided CLOB- Bid /Offer :  340.5 /336.5
      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .setBuyAndSellSideLitOrder( '3',order.Price + spread,'3',order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      //Best Bid / Offer 340.5 / 336.50, ASM is calculated as 338.50
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      // User2 sets an Offer price of 337 so that this new Offer price do not cross the ASM of 338.50
      const userTwoOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size, 'IG');
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserTwo.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('337.0');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 340.50/336.50, ASM is not recalculated and will remain as 338.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      //User1 accepts the Offer price of User2
      await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .acceptSellSideOrder('337.0','2.0');
      //Best Bid / Offer 340.50 / 337.00, ASM is  recalculated as 338.75
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.75').to.equal(asmPrice);

      // User3 sets an Offer price of 338.75 so that this new Offer price is equal to the current ASM of 338.75
      //ASM should then get recalculated
      const userThreeOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size,'IG');
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserThree.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('338.75');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 340.5 / 338.75, ASM is calculated as 339.0
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('339.00').to.equal(asmPrice);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
            ,config.longTimeout
            ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    })

    //HYD-3 - ASM updated logic story -Yet to be implemented
    //Test fails becos when User2 sets an Offer price of 337 , ASM gets recalculated though it does not cross ASM
    //Once ASM updated logic / Inverted order logic is implemented, When User2 set the Offer price of 337.0, ASM will Not get recalculated
    //When User3 set the Bid price of 339, ASM will get recalculated and the Test will pass
    it('CLS-25 - Two sided Clob- When Trade occurs and there is only one side ASM is set as blank, ASM to get recalculated when there are two sides', async() =>{
      const securityId = 'US594457BT97';
      const securityDescription = 'DTE 5.7 03/15/33';
      const orderMid = 338.50;
      const spread = 4;
      const size = 3000000;

      firstRun = await login(loginUser,hydraLauncher,hydraPageModel,client,firstRun);
      await cleanUpTest(client,allApiStrategies);

      const order = getNewOrder(securityId, 'sell', spread, orderMid, size,'IG');
      await hydraPageModel.addOrders([order]);
      await client.waitUntil(() => hydraPageModel.getPortfolio().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, portfolio panel has no orders.');

      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .startClob();

      //Two Sided CLOB- Bid /Offer :  340.5/ 336.50
      await hydraPageModel.getPortfolio()
          .getOrderByDescription(securityDescription)
          .setBuyAndSellSideLitOrder( '3',order.Price + spread,'3',order.Price);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');

      //Best Bid / Offer 340.5 / 336.5, ASM is calculated as 338.50
      let asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      // User2 sets an Offer price of 337 so that this new Offer price do not cross the ASM of 338.50
      const userTwoOrder = getNewOrder(securityId, 'sell', spread -1 , orderMid, size,'IG');
      await hydraApiClientUserTwo.addOrders([userTwoOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserTwo.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('337.0');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 340.50 / 337, ASM is not recalculated and will remain as 338.50
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('338.50').to.equal(asmPrice);

      //User1 accepts the Offer price of User2
      //User2 gets fully filled
      await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .acceptSellSideOrder('337.00','3.0');

      await client.pause(config.veryShortTimeout);
      //Best Offer 336.50, ASM is set as blank as there is only one side now
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('').to.equal(asmPrice);

      //User3 sets Bid price of 339.00
      //ASM should then get recalculated as there are two sides now
      const userThreeOrder = getNewOrder(securityId, 'buy', spread -3 , orderMid, size,'IG');
      await hydraApiClientUserThree.addOrders([userThreeOrder]);
      await client.waitUntil(() => hydraPageModel.getActionPanel().hasOrders()
          ,config.shortTimeout
          ,'Timed out after ' + config.shortTimeout + ' seconds, action panel has no orders.');
      await hydraApiClientUserThree.getActionPanel()
          .getOrderByDescription(securityDescription)
          .setPrice('339.0');

      await client.pause(config.veryShortTimeout);
      //Best Bid / Offer 339.0 / 336.50, ASM is calculated as 337.75
      asmPrice = await hydraPageModel.getActionPanel()
          .getOrderByDescription(securityDescription)
          .getAsmPrice();
      expect('337.75').to.equal(asmPrice);

      for (const strategy of allStrategies) {
        const isEmpty = await client.waitUntil(() => strategy.getActionPanel().isEmpty()
            ,config.longTimeout
            ,'Timed out after ' + config.longTimeout + ' seconds, action panel is not empty.');
        expect(isEmpty).to.be.true;
      }
    })
  });
});
