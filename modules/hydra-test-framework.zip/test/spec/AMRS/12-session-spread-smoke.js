/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateAsmPrice, getOrderMid} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';
import {Sector} from '../../../constant/Sector';
import {TRADING_PROTOCOL} from '../../../constant/Protocol';
import {calculateVWAP} from '../../../utilities/vwapCalculator';
import {TRADED_DIRECTION} from '../../../constant/TradedDirection';
import {SIZE_MULTIPLIER} from '../../../constant/Order';
import {OPTIONS, PHASE_DEFINITIONS, TYPE} from '../../../constant/TradingSession';

describe('AMRS Region - Spread Matching Session tests', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;
  let sessionStrategy = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'sujith.vakathanam.auto7@testing.fenicstools.com');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'sujith.vakathanam.auto8@testing.fenicstools.com');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'manjit.bharaj.auto7@testing.fenicstools.com');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'manjit.bharaj.auto8@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    sessionStrategy = new FixSessionStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('MSS-010 - HYD-537- User1 ,User3 at Buy Side, User2 at Sell side- Test to check if User1 can trade with User2 at TradedLevel price during Cleanup phase', async () => {
    const securityId = 'US29379VBU61';
    const securityDescription = 'EPD 4.8 02/01/49';
    const industrySector = Sector.ENERGY;
    const spread = 6;
    const size = 4000000;
    const userTwoOrderSize = 10000000;
    const userOneTradedLevelEnteredSize = 3000;
    const userOneTradedLevelSize = 2000000;
    const userOneTradedLevelDirection = 'Buy';
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;
    const expectedSizeInCleanupPhaseForUserOne = '1000';
    let orderMid = 100.5;

    const sessionConfiguration = {
      sector : industrySector,
      rating
    };

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);
    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');

    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    let userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);

    await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const weightings = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    const weightedPrice = await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, userTwoOrderSize, rating, region);
    await hydraApiClientUserTwo.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraApiClientUserTwo.getActionPanel().hasOrders()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const asmPrice = await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    const priceToAffirm = asmPrice;

    await hydraApiClientUserOne.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User1 at ${userOneOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userOneOrder.OrderQty}`);
    logger.info('User1 affirm the ASM price first followed by User3');

    await hydraApiClientUserTwo.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    await hydraApiClientUserThree.getActionPanel()
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their ASM price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const expectedTradePrice = calculateVWAP(
      parseFloat(asmPrice)
      , size
      , parseFloat(asmPrice)
      , userTwoOrderSize
      , region
    );
    logger.info('ExpectedTradePrice is ', expectedTradePrice);

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);

    const tradedLevelPrice = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getTradedLevelPrice();
    expect(String(parseFloat(tradedLevelPrice))).to.equal(String(parseFloat(expectedTradePrice)));

    let tradePanel = hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    let hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    let tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    let tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);
    expect(tradedPrice).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(Math.abs(userOneOrder.OrderQty)));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);

    await hydraPageModel.getSessionPanel(rating, true)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .acceptTradedLevelPrice(userOneTradedLevelEnteredSize, userOneTradedLevelDirection);
    logger.info(`User1 accepts the TradedLevel price of ${tradedLevelPrice} with direction as ${userOneTradedLevelDirection} with size as ${userOneTradedLevelEnteredSize}`);

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(true)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .hasSize(true)
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Action panel has no remaining size for User1.`
    );

    const sizeInCleanupPhaseForUserOne = await hydraPageModel.getSessionPanel(rating)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .getSize(true, true);
    expect(sizeInCleanupPhaseForUserOne).to.equal(expectedSizeInCleanupPhaseForUserOne);
    logger.info(`User1 has remaining size of ${sizeInCleanupPhaseForUserOne} after trading at Traded Level during Cleanup phase`);

    tradePanel = hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);
    expect(tradedPrice).to.equal(String(parseFloat(tradedLevelPrice)));
    expect(tradeSize).to.equal(String(userOneTradedLevelSize / SIZE_MULTIPLIER));

    await hydraPageModel.getSessionPanel(rating, true);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel()
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserTwo.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });

  it('OLXS-001 - Limit price ON- Over-Under leg trade gets generated when both users affirm their Limit Price such that orders get crossed- Fully Filled for both users ', async () => {
    // MinPiece = 100k, Min Increment - 1k Currency = EUR - Please check for Amended and Minimum size leg along with Traded Price in GMO for below ISIN
    const securityId = 'XS1684785774';
    const securityDescription = 'LANSBK 0 1/2 09/19/22';
    const industrySector = Sector.FINANCIAL;
    let orderMid = 100.5;
    const spread = 3;
    const size = 95000;
    const rating = 'IG';
    const region = TICK_CONFIGURATION.US.IG;
    const type = TYPE.OLX;

    const sessionConfiguration = {
      sector : industrySector,
      rating,
      type
    };

    OPTIONS.maxSizeCleanup = 5000000;
    OPTIONS.maxSizeAffirmation = 15000000;
    OPTIONS.minSize = 1000;
    OPTIONS.isLimitPricingEnabled = true;
    await sessionStrategy.setSessionTemplate(sessionConfiguration, PHASE_DEFINITIONS, OPTIONS);

    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo, hydraApiClientUserThree];
    await testCommons.cleanUpTest(allApiStrategies);

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    let userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraApiClient.addOrders([userTwoOrder]);

    await browser.waitUntil(
      () => hydraApiClient.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    let weightings = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);
    logger.info(`Weightings for bond ${securityDescription} are: ${JSON.stringify(weightings.payload.weightings)}.`);

    let weightedPrice = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);
    logger.info(`Weighted prices for bond ${securityDescription} are: ${JSON.stringify(weightedPrice.prices)}.`);

    orderMid = getOrderMid(weightedPrice.prices);

    userTwoOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty}, with limit price of ${userTwoOrder.Price}  and direction of ${userTwoOrder.Side} side.`);

    const userThreeOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, 'HY', region);
    await hydraApiClientUserThree.addOrders([userThreeOrder]);
    logger.info(`User 3 added bond ${securityDescription} with size of ${userThreeOrder.OrderQty}, with limit price of ${userThreeOrder.Price}  and direction of ${userThreeOrder.Side} side.`);

    const userOneOrder = getNewOrder(securityId, 'sell', spread, orderMid, size, 'HY', region);
    await hydraPageModel.addOrders([userOneOrder]);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty}, with limit price of ${userOneOrder.Price}  and direction of ${userOneOrder.Side} side.`);

    await sessionStrategy.createSession(sessionConfiguration);

    let expectedPhase = 'Countdown';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, TYPE.OLX)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    const sessionPanel = hydraPageModel.getSessionPanel(rating, false, TYPE.OLX);
    await browser.waitUntil(
      () => sessionPanel.hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, session panel has no orders.`
    );

    expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, TYPE.OLX)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    weightings = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getWeightings(rating);

    weightedPrice = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getWeightedAsmPrices(rating);

    const calculatedAsmPrice = calculateAsmPrice(
      weightings.payload.weightings
      , weightedPrice.prices
      , 0
      , 0
      , region
      , true
    );
    logger.info(`Expected calculated ASM price for bond ${securityDescription} is ${calculatedAsmPrice}.`);

    const asmPrice = await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .getAsmPrice();
    expect(String(parseFloat(asmPrice).toFixed(2))).to.equal(String(calculatedAsmPrice));
    logger.info(`Actual and expected ASM are equal at ${asmPrice}`);

    await hydraPageModel.getSessionPanel(rating, true, TYPE.OLX)
      .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
      .affirmOrder();
    logger.info(`User1 at ${userOneOrder.Side} side affirms their Limit price at ${userOneOrder.Price} for size of ${userOneOrder.OrderQty}`);

    const priceToAffirm = userTwoOrder.Price;

    await hydraApiClient.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User2 at ${userTwoOrder.Side} side affirms their Limit price at ${priceToAffirm} for size of ${userTwoOrder.OrderQty}`);

    await hydraApiClientUserThree.getActionPanel(type)
      .getOrderByDescription(securityDescription)
      .affirmOrder(priceToAffirm);
    logger.info(`User3 at ${userThreeOrder.Side} side affirms their Limit price at ${priceToAffirm} for size of ${userThreeOrder.OrderQty}`);

    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is empty indicating there is no residual size in Portfolio during Cleanup phase');

    await hydraPageModel.getSessionPanel(rating, true, type);
    await browser.pause(configuration.veryShortTimeout);
    expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has Ended.`);

    const tradePanel = hydraPageModel.getTrades(true);
    await tradePanel.handleMinimised();
    const hasTraded = await browser.waitUntil(
      () => tradePanel
        .getOrderByDescription(securityDescription)
        .isTraded()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, trade panel has no orders.`
    );
    logger.info(`User 1 bond ${securityDescription} has traded is ${hasTraded}.`);

    const tradedPrice = await tradePanel
      .getOrderByDescription(securityDescription)
      .getPrice();
    logger.info(`User 1 traded bond ${securityDescription} with price of ${tradedPrice}.`);
    const tradeSize = await tradePanel
      .getOrderByDescription(securityDescription)
      .getSize();
    logger.info(`User 1 traded bond ${securityDescription} with size of ${tradeSize}.`);

    let expectedTradePrice = (parseFloat(userOneOrder.Price) + parseFloat(userTwoOrder.Price)) / 2;
    expectedTradePrice = Number.isInteger(expectedTradePrice) ? parseFloat(expectedTradePrice).toFixed(1) : parseFloat(expectedTradePrice);
    logger.info('Expected Trade Price is', expectedTradePrice);
    expect(String(parseFloat(tradedPrice))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(tradeSize).to.equal(String(userOneOrder.OrderQty));

    await browser.waitUntil(
      () => hydraApiClient.getTradesPanel(securityDescription)
        .hasTrades(String(expectedTradePrice))
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, Trade panel has no orders.`
    );

    const trades = await hydraApiClient
      .getTradesPanel(securityDescription)
      .getTrades(String(expectedTradePrice));
    expect(String(parseFloat(trades[0].Price))).to.equal(String(parseFloat(expectedTradePrice)));
    expect(trades[0].Size).to.equal(size.toString());
    expect(trades[0].Direction).to.equal(TRADED_DIRECTION.BOUGHT);
    logger.info(`User 2 traded bond ${securityDescription} with price of ${trades[0].Price}, with size of ${trades[0].Size} and Direction as ${trades[0].Direction} `);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 2 portfolio panel is now empty.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio(true).isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');

    await hydraApiClientUserThree.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 3 deletes bond ${securityDescription} from portfolio.`);

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClientUserThree.getPortfolio().isEmpty()
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 3 portfolio panel is now empty.');
  });
});
