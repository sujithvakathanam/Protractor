/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from '../../../config/api.config';
import {FixHydraStrategy} from '../../../lib/hydra/fixHydraStrategy';
import FenicsCredit from '../../../pages/FenicsCredit';
import {getNewOrder} from '../../../utilities/orderCreator';
import {calculateMid, calculateAsmPrice, getOrderMid, roundToTick} from '../../../utilities/asmCalculator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../../constant/Region';


describe('Portfolio Upload tests - Cash Bonds', () => {
  // Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  let hydraApiClient = null;
  let hydraApiClientUserOne = null;
  let hydraApiClientUserTwo = null;
  let hydraApiClientUserThree = null;
  let hydraApiClientUserFour = null;
  let hydraApiClientUserFive = null;
  let hydraApiClientUserSix = null;
  let hydraApiClientUserSeven = null;
  let hydraApiClientUserEight = null;
  let hydraApiClientUserNine = null;
  let hydraApiClientUserTen = null;
  let allApiStrategies = null;
  let allStrategies = null;

  // Test case vars.
  let firstRun = true;

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // Api setup.
    hydraApiClientUserOne = new FixHydraStrategy(context, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    hydraApiClientUserTwo = new FixHydraStrategy(context, 'sujith.vakathanam.auto2@testing.fenicstools.com');
    hydraApiClientUserThree = new FixHydraStrategy(context, 'sujith.vakathanam.auto3@testing.fenicstools.com');
    hydraApiClientUserFour = new FixHydraStrategy(context, 'sujith.vakathanam.auto4@testing.fenicstools.com');
    hydraApiClientUserFive = new FixHydraStrategy(context, 'sujith.vakathanam.auto5@testing.fenicstools.com');
    hydraApiClientUserSix = new FixHydraStrategy(context, 'sujith.vakathanam.auto6@testing.fenicstools.com');
    hydraApiClientUserSeven = new FixHydraStrategy(context, 'manjit.bharaj.auto7@testing.fenicstools.com');
    hydraApiClientUserEight = new FixHydraStrategy(context, 'manjit.bharaj.auto8@testing.fenicstools.com');
    hydraApiClientUserNine = new FixHydraStrategy(context, 'manjit.bharaj.auto9@testing.fenicstools.com');
    hydraApiClientUserTen = new FixHydraStrategy(context, 'manjit.bharaj.auto10@testing.fenicstools.com');
    hydraApiClient = hydraApiClientUserTwo;
    allApiStrategies = [hydraApiClientUserOne, hydraApiClientUserTwo];
    allStrategies = [hydraApiClient, hydraPageModel];

    expect(browser).to.exist;
  });

  after(async () => {
    await hydraPageModel.clickSignOut();
  });

  it('PU-001 - Upload file with duplicate ISIN in Same direction -Original Order to be replaced', async () => {
    const securityId = 'US126307AZ02';
    const securityDescription = 'CSCHLD 6 1/2 02/01/29';
    const orderMid = 155;
    const spread = 3;
    const size = 1000000;
    const sizeToBeReplaced = 500000;

    const securityIdTwo = 'US12674TAA43';
    const securityDescriptionTwo = 'CWCLN 6 7/8 09/15/27';
    const orderMidTwo = 55;
    const spreadTwo = 2;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, sizeToBeReplaced, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, size, rating, region),
      getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[0].OrderQty} and direction of ${userOneOrder[0].Side} side.`);
    logger.info(`User 1 added bond ${securityDescriptionTwo} with size of ${userOneOrder[1].OrderQty} and direction of ${userOneOrder[1].Side} side.`);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[2].OrderQty} and direction of ${userOneOrder[2].Side} side.`);

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('1000');

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(1);
    logger.info('Portfolio assertions are done');

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    await browser.pause(configuration.shortTimeout);
    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescriptionTwo} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PU-002 - Upload file with duplicate ISIN in Opposite direction- second order is to be rejected during upload', async () => {
    const securityId = 'US29271LAA26';
    const securityDescription = 'ENDP 5 3/4 01/15/22';
    const orderMid = 323;
    const spread = 0;
    const size = 1000000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;
    const sizeToBeReplaced = 500000;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, sizeToBeReplaced, rating, region),
      getNewOrder(securityId, 'sell', spread, orderMid, size, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[0].OrderQty} and direction of ${userOneOrder[0].Side} side.`);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder[1].OrderQty} and direction of ${userOneOrder[1].Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel has no orders.`
    );

    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    const portfolioQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(portfolioQuantity).to.equal('1000');

    const portfolioDirection = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getDirection();
    expect(portfolioDirection).to.equal('SELL');

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescription} from portfolio.`);

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getPortfolio().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('User 1 portfolio panel is now empty.');
  });

  it('PU-003 - Scenario to test Mass Delete functionality', async () => {
    const securityId = 'US73107GAA13';
    const orderMid = 155;
    const spread = 0;
    const size = 1000000;

    const securityIdTwo = 'US36160NZA08';
    const securityDescriptionTwo = 'SYF 2.35 10/25/19';
    const orderMidTwo = 55;
    const spreadTwo = 0;
    const sizeTwo = 1000000;

    const securityIdThree = 'US62704PAF09';
    const securityDescriptionThree = 'MURREN 11 1/4 04/15/21';
    const orderMidThree = 555;
    const spreadThree = 0;
    const sizeThree = 500000;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, sizeTwo, rating, region),
      getNewOrder(securityIdThree, 'sell', spreadThree, orderMidThree, sizeThree, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo)
      .delete();
    logger.info(`User 1 deletes bond ${securityDescriptionTwo} from portfolio.`);

    await browser.pause(configuration.shortTimeout);
    const portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(0);
    logger.info(`Bond ${securityDescriptionTwo} with size of ${sizeTwo} is deleted successfully from Portfolio panel.`);

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion.');
  });

  it('PU-004 - Scenario to test the Size increments by 100k for file upload', async () => {
    const securityId = 'USU7024PAG38';
    const securityDescription = 'PARSLY 5 5/8 10/15/27';
    const orderMid = 155;
    const spread = 0;
    const size = 3465000;

    const securityIdTwo = 'XS0266811388';
    const securityDescriptionTwo = 'CORIOL 0 06/25/38';
    const orderMidTwo = 55;
    const spreadTwo = 0;
    const sizeTwo = 9651000;

    const securityIdThree = 'XS1298711729';
    const securityDescriptionThree = 'TCELLT 5 3/4 10/15/25';
    const orderMidThree = 555;
    const spreadThree = 0;
    const sizeThree = 2895001;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = [getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region),
      getNewOrder(securityIdTwo, 'buy', spreadTwo, orderMidTwo, sizeTwo, rating, region),
      getNewOrder(securityIdThree, 'sell', spreadThree, orderMidThree, sizeThree, rating, region)];
    await hydraPageModel.addOrders(userOneOrder);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescriptionTwo);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionTwo, 'PN', true)
      .getSize(true);
    expect(remainingQuantity).to.equal('9651');
    logger.info(`${securityDescriptionTwo} got uploaded with correct size as ${remainingQuantity}`);

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription, 'PN', true)
      .getSize(true);
    expect(remainingQuantity).to.equal('3465');
    logger.info(`${securityDescription} got uploaded with correct size as ${remainingQuantity}`);

    portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCountInPortfolio(securityDescriptionThree);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescriptionThree, 'PN', true)
      .getSize(true);
    expect(remainingQuantity).to.equal('2895');

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    const isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion.');
  });

  it('PU-005 - Scenario to test the Size increments by 100k for Quick upload', async () => {
    const securityId = 'USU7024PAG38';
    const securityDescription = 'PARSLY 5 5/8 10/15/27';
    const orderMid = 155;
    const spread = 0;
    const size = 5.2;
    const rating = 'HY';
    const region = TICK_CONFIGURATION.US.HY;

    firstRun = await testCommons.loginAsTrader(firstRun, 'sujith.vakathanam.auto1@testing.fenicstools.com');
    await testCommons.cleanUpTest(allApiStrategies);

    const userOneOrder = getNewOrder(securityId, 'buy', spread, orderMid, size, rating, region);

    await hydraPageModel.addOrdersByQuickUpload(userOneOrder.SecurityID);
    await browser.waitUntil(
      () => hydraPageModel.getPortfolio().hasOrders()
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, portfolio panel has no orders.`
    );

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .setDirection('Buy');

    await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .setSize(userOneOrder.OrderQty);
    logger.info(`User 1 added bond ${securityDescription} with size of ${userOneOrder.OrderQty} and direction of ${userOneOrder.Side} side.`);

    const userTwoOrder = getNewOrder(securityId, 'sell', spread, orderMid, 5200000, rating, region);
    await hydraApiClient.addOrders([userTwoOrder]);
    logger.info(`User 2 added bond ${securityDescription} with size of ${userTwoOrder.OrderQty} and direction of ${userTwoOrder.Side} side.`);

    await browser.waitUntil(
      () => hydraPageModel.getActionPanel().hasOrders()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, action panel has no orders.`
    );

    for (const strategy of allStrategies) {
      // eslint-disable-next-line
      await browser.waitUntil(
        () => strategy.getActionPanel()
          .getOrderByDescription(securityDescription)
          .validateForSession()
        , configuration.shortTimeout
        , `Timed out after ${configuration.shortTimeout} seconds, could not validate session.`
      );
    }
    logger.info('Validated session for all users.');

    const expectedPhase = 'PRICING';
    await browser.waitUntil(
      () => hydraPageModel.getActionPanel()
        .getOrderByDescription(securityDescription)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    logger.info(`${expectedPhase} phase has started.`);

    for (const strategy of allStrategies) {
      const isEmpty = await browser.waitUntil(
        () => strategy.getActionPanel().isEmpty()
        , configuration.longTimeout
        , `Timed out after ${configuration.longTimeout} seconds, action panel is not empty.`
      );
      expect(isEmpty).to.be.true;
    }
    logger.info('Action panel is now empty for all users.');

    let portfolioBondCount = await hydraPageModel
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    let remainingQuantity = await hydraPageModel.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('5200');

    portfolioBondCount = await hydraApiClient
      .getPortfolio()
      .getOrderRowCount(securityDescription);
    expect(portfolioBondCount).to.equal(1);

    remainingQuantity = await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .getSize(true);
    expect(remainingQuantity).to.equal('5200');

    await hydraPageModel.getPortfolio()
      .selectAll()
      .delete(false);
    logger.info('User 1 deletes all bonds from portfolio.');

    let isPortfolioEmpty = await browser.waitUntil(
      () => hydraPageModel.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty after mass deletion for User 1.');

    await hydraApiClient.getPortfolio()
      .getOrderByDescription(securityDescription)
      .delete();
    logger.info('User 2 deletes bond from portfolio.');

    isPortfolioEmpty = await browser.waitUntil(
      () => hydraApiClient.getActionPanel().isEmpty()
      , configuration.shortTimeout
      , `Timed out after ${configuration.shortTimeout} seconds, portfolio panel is not empty.`
    );
    expect(isPortfolioEmpty).to.be.true;
    logger.info('Portfolio panel is now empty for User 2.');
  });
});
