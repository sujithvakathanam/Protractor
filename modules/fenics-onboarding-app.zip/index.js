'use strict';

const HttpStatus = require('http-status-codes');
const AWS = require('aws-sdk');
const {HubAndSpoke} = require('@bgc-devops/bgc-okta-client');
const {utils: lambdaUtil, LambdaProfiler} = require('@bgc-devops/lambda-util');
const assignApps = require('./assign-apps');
const {getDynamoTableName} = require('./utils');

const dynamoDB = new AWS.DynamoDB();
const hubAndSpoke = new HubAndSpoke();

const applicationName = process.env.application_name;
const environment = process.env.env_target;
const tableStack = process.env.table_stack;

async function invoke (logger, event) {
  logger.info({event}, 'Assigning apps to user.');

  const {body, pathParameters : {email}} = event;

  const oktaGroup = `fenics_${environment}_users`;

  try {
    const headers = {
      'Access-Control-Allow-Origin'      : '*',
      'Access-Control-Request-Headers'   : 'Content-Type',
      'Access-Control-Allow-Credentials' : true,
      'Access-Control-Allow-Methods'     : 'OPTIONS,PUT'
    };

    const oktaErrResp = await assignApps.ensureOktaGroupMembership({
      email,
      headers,
      hubAndSpoke,
      logger,
      oktaGroup
    });

    if (oktaErrResp) {
      return oktaErrResp;
    }

    const appUserTableName = getDynamoTableName({
      applicationName,
      environment,
      tableStack,
      tableName : 'application_user'
    });

    const userDataTableName = getDynamoTableName({
      applicationName,
      environment,
      tableStack,
      tableName : 'user_data'
    });

    const result = await assignApps.doOnboarding({
      appUserTableName,
      data : JSON.parse(body),
      dynamoDB,
      email,
      environment,
      headers,
      logger,
      userDataTableName
    });

    return result;
  } catch (err) {
    logger.error(err);

    return lambdaUtil.getLambdaErrorPayload(HttpStatus.INTERNAL_SERVER_ERROR);
  }
}

module.exports.handler = function handler (event, context) {
  const lambdaProfiler = new LambdaProfiler(event, context);

  return lambdaProfiler.invokeAsyncForApiGateway(invoke);
};
