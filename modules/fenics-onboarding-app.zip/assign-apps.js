'use strict';

const HttpStatus = require('http-status-codes');
const {utils : lambdaUtil} = require('@bgc-devops/lambda-util');
const {getUserData, updateUserApplications} = require('./dynamo-api');
const {customOnboarding} = require('./custom-onboarding');

const ensureOktaGroupMembership = async ({
  email,
  headers,
  hubAndSpoke,
  logger,
  oktaGroup
}) => {
  logger.info(`Ensuring membership of okta group ${oktaGroup} for ${email}.`);

  const user = await hubAndSpoke.getUserAndGroups(email);

  if (!user || !user.spoke) {
    logger.error(`Cannot find the user or spoke record for ${email}.`, user);

    return lambdaUtil.getLambdaErrorPayload(HttpStatus.BAD_REQUEST, headers);
  }

  const {spoke : {groups = []}} = user;

  if (groups.filter(group => group.name.indexOf(oktaGroup) >= 0).length === 0) {
    logger.info(`User does not exist in the okta group ${oktaGroup}. Will add them.`);

    try {
      const {group : {name, spoke : {name : spokeName}}} = await hubAndSpoke.addUserToGroup(email, oktaGroup);

      logger.info(`Added user ${email} to group ${name} (spoke: ${spokeName})`);
    } catch (err) {
      logger.error(err, `Error thrown while adding user to group. ${email} - ${oktaGroup}`);

      return lambdaUtil.getLambdaErrorPayload(HttpStatus.INTERNAL_SERVER_ERROR, headers);
    }
  }

  return null;
};

// eslint-disable-next-line complexity, max-statements
const doOnboarding = async ({
  appUserTableName,
  data,
  dynamoDB,
  email,
  environment,
  headers,
  logger,
  userDataTableName
}) => {
  logger.info('Adding user to applications', email, data);

  const {id, apps, appsInfo} = data;
  let user = null;

  try {
    user = await getUserData({
      dynamoDB,
      logger,
      id,
      userDataTableName
    });
  } catch (err) {
    logger.error(err, 'Error while getting user data from dynamodb');

    return lambdaUtil.getLambdaErrorPayload(HttpStatus.INTERNAL_SERVER_ERROR, headers);
  }

  const erroredApps = [];
  const customApps = Object.keys(customOnboarding);

  const customCalls = apps.filter(app => customApps.includes(app))
    .reduce((calls, app) => {
      logger.info(`Found custom onboarding function for ${app}`);
      const userProperties = appsInfo ? appsInfo[app] : null;
      const promise = customOnboarding[app]({
        environment,
        logger,
        user,
        userDataTableName,
        dynamoDB,
        userProperties
      }).catch(err => {
        logger.error(err, `An error occurred during custom onboarding for ${app}`);

        erroredApps.push(app);
      });

      return calls.concat(promise);
    }, []);

  await Promise.all(customCalls);
  const okApps = apps.filter(app => !erroredApps.includes(app));

  if (okApps.length) {
    try {
      await updateUserApplications({
        apps : okApps,
        appUserTableName,
        dynamoDB,
        logger,
        id
      });
    } catch (err) {
      logger.error(err, 'Error thrown while updating the apps table.', {data});

      return lambdaUtil.getLambdaErrorPayload(HttpStatus.INTERNAL_SERVER_ERROR, headers);
    }
  }

  const response = {
    apps : apps.map(app => ({
      app,
      success : okApps.includes(app)
    }))
  };

  return lambdaUtil.getLambdaJsonPayload(headers, response, HttpStatus.OK);
};

module.exports = {
  doOnboarding,
  ensureOktaGroupMembership
};
