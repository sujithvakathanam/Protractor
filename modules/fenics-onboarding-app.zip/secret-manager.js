const AWS = require('aws-sdk');
const {SECRET_ENV_KEY} = require('./constants');

let loadedSecrets = null;

const getSecretPath = id => {
  const key = SECRET_ENV_KEY[id];
  const path = process.env[key];

  if (!path) {
    throw new Error(`Missing AWS Param Store ID for ${id}, expected environment variable '${key}'`);
  }

  return path;
};

const getSecretsFromParamStore = async () => {
  const ssm = new AWS.SSM({region : 'eu-west-1'});
  const ids = Object.keys(SECRET_ENV_KEY);
  const secrets = {};

  const requests = ids.reduce((reqs, id) => {
    const path = getSecretPath(id);
    const request = ssm.getParameter({Name : path}).promise()
      .then(data => {
        secrets[id] = data.Parameter.Value;
      }, err => {
        throw err;
      });

    return reqs.concat(request);
  }, []);

  await Promise.all(requests);

  return secrets;
};

const getSharedSecrets = async () => {
  if (!loadedSecrets) {
    loadedSecrets = await getSecretsFromParamStore();
  }

  return loadedSecrets;
};

module.exports = {
  getSharedSecrets
};
