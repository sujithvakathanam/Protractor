const getDynamoTableName = ({
  applicationName,
  tableName,
  environment,
  tableStack,
  separator = '_'
}) => [
  applicationName,
  tableName,
  environment,
  tableStack
].filter(value => Boolean(value)).join(separator);

module.exports = {
  getDynamoTableName
};
