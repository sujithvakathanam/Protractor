const DYNAMODB_TYPES = {
  STRING : 'S',
  SET    : 'SS'
};

const getUserData = ({
  dynamoDB,
  id,
  logger,
  userDataTableName
}) => {
  logger.info(`Looking up user data for ${id}`);

  const queryParams = {
    TableName : userDataTableName,
    Key       : {
      id : {S : id}
    }
  };

  return new Promise((resolve, reject) => {
    dynamoDB.getItem(queryParams, (err, {Item}) => {
      if (err) {
        reject(err);
      }

      if (!Item) {
        reject(new Error(`Failed to retrieve user from the dynamo table. ${id}`));

        return;
      }

      const {
        name : {
          S : name
        },
        email : {
          S : email
        },
        lei : {
          S : lei
        },
        espeedId : {
          S : espeedId
        }
      } = Item;

      resolve({
        name,
        id,
        email,
        lei,
        espeedId
      });
    });
  });
};

function updateItem (dynamoDB, updateParams) {
  return new Promise((resolve, reject) => {
    dynamoDB.updateItem(updateParams, (err, data) => {
      if (err) {
        reject(err);
      }

      resolve(data);
    });
  });
}

const updateUserApplications = ({
  apps,
  appUserTableName,
  dynamoDB,
  id,
  logger
}) => {
  logger.info(`Updating item with new apps ${id} - ${JSON.stringify(apps)}`);

  const updateParams = {
    TableName : appUserTableName,
    Key       : {
      userId : {S : id}
    },
    UpdateExpression         : 'ADD #attrNames :n',
    ExpressionAttributeNames : {
      '#attrNames' : 'names'
    },
    ExpressionAttributeValues : {
      ':n' : {SS : apps}
    }
  };

  return updateItem(dynamoDB, updateParams);
};

const getDynamodbType = value => {
  if (Array.isArray(value)) {
    return DYNAMODB_TYPES.SET;
  }

  return DYNAMODB_TYPES.STRING;
};

const updateUser = ({
  userProperties,
  userDataTableName,
  dynamoDB,
  userId,
  logger
}) => {
  logger.info(`Updating item with new properties ${userId} - ${JSON.stringify(userProperties)}`);

  const propertyNames = Object.keys(userProperties);
  const updateExpression = `SET ${propertyNames.map(pName => `#${pName} = :${pName}`).join(', ')}`;
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};
  for (const propertyName of propertyNames) {
    const attributeName = `#${propertyName}`;
    const newPropertyName = `:${propertyName}`;
    expressionAttributeNames[attributeName] = propertyName;
    const fieldType = getDynamodbType(userProperties[propertyName]);
    expressionAttributeValues[newPropertyName] = {[fieldType] : userProperties[propertyName]};
  }

  const updateParams = {
    TableName : userDataTableName,
    Key       : {
      id : {S : userId}
    },
    UpdateExpression          : updateExpression,
    ExpressionAttributeNames  : expressionAttributeNames,
    ExpressionAttributeValues : expressionAttributeValues
  };

  return updateItem(dynamoDB, updateParams);
};

module.exports = {
  getUserData,
  updateUserApplications,
  updateUser
};
