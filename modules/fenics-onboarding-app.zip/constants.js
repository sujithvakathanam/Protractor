const APPS = {
  BLUECHIP_TRADER_APP   : 'bluechip/bluechip-trader-app',
  BLUECHIP_OPERATOR_APP : 'bluechip/bluechip-operator-app',
  HYDRA_TRADER_APP      : 'fenics/hydra-trader-app',
  HYDRA_OPERATOR_APP    : 'fenics/hydra-operator-app',
  NVM_VOLUME_MATCH_APP  : 'nvm/nvm-volume-match-app'
};

const BLUECHIP_ENVS = {
  dev  : 'https://go.dev.fenicsone.com',
  qa   : 'https://go.qa.fenicsone.com',
  uat  : 'https://go.uat.fenicsone.com',
  prod : 'https://go.fenicsone.com'
};

const BLUECHIP_PATH = '/BlueChip/http?action=newOnboardingUserAction';

const SECRET_ENV_KEY = {
  bluechip : 'bluechip_onboarding_api_secret'
};

module.exports = {
  APPS,
  BLUECHIP_ENVS,
  BLUECHIP_PATH,
  SECRET_ENV_KEY
};
