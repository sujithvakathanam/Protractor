const {updateUser} = require('./dynamo-api');

const ftransport = require('@fenics/fenics-transport').default;

const {getSharedSecrets} = require('./secret-manager');
const {APPS, BLUECHIP_ENVS, BLUECHIP_PATH} = require('./constants');

const onboardBluechipUser = async ({
  environment,
  logger,
  type,
  user
}) => {
  const hostname = BLUECHIP_ENVS[environment];
  const path = `${hostname}${BLUECHIP_PATH}`;

  const {bluechip : secret} = await getSharedSecrets();

  logger.info(`Making custom onboarding call to bluechip for user type ${type}.`, {
    path,
    user
  });

  const {response} = await ftransport(path)
    .auth(`Bearer ${secret}`)
    .json({
      userType   : type,
      oktaUserId : user.id,
      email      : user.email,
      firstName  : '',
      lastName   : '',
      espeedId   : user.espeedId,
      lei        : user.lei
    })
    .post()
    .json(json => {
      logger.info('Bluechip api call returned:', JSON.stringify(json));

      return json;
    })
    .catch(err => {
      logger.error(err, `Error onboarding bluechip ${type} with data: ${JSON.stringify(user)}`);

      throw err;
    });

  if (!response.length || response[0].responseStatus !== 'OK') {
    throw new Error(`Bluechip ${type} custom onboarding failed.`);
  }

  logger.info(`Bluechip ${type} custom onboarding call succeeded with OK status`);
};

const onboardBluechipTraderApp = ({
  environment,
  logger,
  user
}) => onboardBluechipUser({
  environment,
  logger,
  type : 'USER',
  user
});

const onboardBluechipOperatorApp = ({
  environment,
  logger,
  user
}) => onboardBluechipUser({
  environment,
  logger,
  type : 'ADMIN',
  user
});

const onboardHydraUser = async ({
  environment,
  logger,
  user,
  userDataTableName,
  dynamoDB,
  userProperties
}) => {
  if (userProperties) {
    const userId = user.id;
    logger.info(`Onboard hydra user ${userId} with properties ${JSON.stringify(userProperties)}`);
    try {
      await updateUser({
        userProperties,
        userDataTableName,
        dynamoDB,
        userId,
        logger
      });
    } catch (err) {
      logger.error(err, 'Error while updating user data in dynamoDB');
    }
  }
};

const onboardNvmUser = async ({
  logger,
  user,
  userDataTableName,
  dynamoDB,
  userProperties : {
    tradableCurrencyCodes = ['']
  }
}) => {
  const userId = user.id;
  logger.info(`Onboarding nvm user ${userId} with properties ${JSON.stringify(tradableCurrencyCodes)}`);
  try {
    await updateUser({
      userProperties : {
        tradableCurrencyCodes
      },
      userDataTableName,
      dynamoDB,
      userId,
      logger
    });
  } catch (err) {
    logger.error(err, 'Error while updating user data in dynamoDB');
  }
};

const customOnboarding = {
  [APPS.BLUECHIP_TRADER_APP]   : onboardBluechipTraderApp,
  [APPS.BLUECHIP_OPERATOR_APP] : onboardBluechipOperatorApp,
  [APPS.HYDRA_TRADER_APP]      : onboardHydraUser,
  [APPS.HYDRA_OPERATOR_APP]    : onboardHydraUser,
  [APPS.NVM_VOLUME_MATCH_APP]  : onboardNvmUser
};

module.exports = {
  customOnboarding
};
