# fenics-transport

> HTTP and WebSocket library for Fenics

## Table of Contents

* [Motivation](#motivation)
* [Installation](#installation)
* [Usage](#usage)
* [Api](#api)
* [Streaming](https://github.fenicsone.com/fenics/fenics-transport/blob/master/src/streaming/README.md)
* [Testing](#testing)

## Motivation

### Having to write a second callback to process a response body is tedious

```javascript
fetch('examples/example.json')
  .then(response => response.json())
  .then(json => {
    // Do stuff with the parsed json
  });
```

```javascript
// ftransport does it for you

// Use .res for the raw response, .text for raw text, .json for json, .blob for a blob ...
ftransport('examples/example.json')
  .get()
  .json(json => {
    // Do stuff with the parsed json
  })
```

### Manually checking and throwing every request error code is cumbersome

```javascript
// Fetch won’t reject on HTTP error status
fetch('http://some.url')
  .then(response => {
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Not found')
      } else if (response.status === 401) {
        throw new Error('Unauthorized')
      } else if (response.status === 418) {
        throw new Error('I\'m a teapot !')
      } else {
        throw new Error('Other error')
      }
    } else // ...
  })
  .then(data => /* ... */)
  .catch(error => { /* ... */ });
```

```javascript
// ftransport should throw when the response is not successful and contain helper methods to handle common codes
ftransport('http://some.url')
  .get()
  .notFound(error => { /* ... */ })
  .unauthorized(error => { /* ... */ })
  .error(420, error => { /* ... */ })
  .res(response => /* ... */)
  .catch(error => { /* uncaught errors */ });
```

### Sending a json object should be easy

```javascript
// With fetch you have to set the header, the method and the body manually
fetch('http://some.url', {
  method  : 'POST',
  headers : {
    'Content-Type' : 'application/json'
  },
  body : JSON.stringify({
    'hello' : 'world'
  })
}).then(response => /* ... */);
```

```javascript
// ftransport should allow you to have shorthands at your disposal
ftransport('http://some.url')
  .json({'hello' : 'world'})
  .post()
  .res(response => /* ... */);
```

### Configuration should not repeat

```javascript
// Stay immutable which means configure, store and reuse instances
const externalApi = ftransport()
  // Set the base url
  .url('http://external.api')
  // Authorization header
  .auth(`Bearer ${token}`)
  // Cors fetch options
  .options({
    credentials : 'include',
    mode        : 'cors'
  });

// Fetch a resource
externalApi
  .url('/resource/1')
  // Add a custom header for this request
  .headers({
    'If-Unmodified-Since' : 'Wed, 21 Oct 2015 07:28:00 GMT'
  })
  .get()
  .json(handleResource);

// Post a resource
externalApi
  .url('/resource')
  .json({
    'Shiny new' : 'resource object'
  })
  .post()
  .json(handleNewResourceResult);
```

**[⬆ back to top](#table-of-contents)**

## Installation

### Npm

```sh
npm i @fenics/fenics-transport
```

## Usage

**ftransport should be bundled using the UMD format (@`dist/bundle/transport.js`) alongside es2015 modules (@`dist/library.js`).**

## Import

```javascript
// es2015 modules
import ftransport from '@fenics/fenics-transport';

// commonjs
var ftransport = require('@fenics/fenics-transport').default;
```

**[⬆ back to top](#table-of-contents)**

## Code

```javascript
ftransport(url, options)
  /* The 'request' chain. */
  .[helper method(s)]()
    // [Optional]
    // A set of helper methods to set the default options, set accept header, change the current url ...
  .[body type]()
    // [Optional]
    // Serialize an object to json or FormData formats and sets the body & header field if needed
  .[http method]()
    // [Required, ends the request chain]
    // Performs the get/put/post/delete/patch request

  /* Fetch is called at this time. */
  /* The request is sent, and from this point on you can chain catchers and call a response type handler. */

  /* The "response" chain. */

  .[catcher(s)]()
    // [Optional]
    // You can chain error handlers here
  .[response type]()
    // [Required, ends the response chain]
    // Specify the data type you need, which will be parsed and handed to you

  /* From this point just return a standard Promise, so anybody can continue chaining actions afterwards. */

  .then(/* ... */)
  .catch(/* ... */);
```

**[⬆ back to top](#table-of-contents)**

<a name="api"></a>

## API

* [Helper Methods](#helper-methods)
* [Body Types](#body-types)
* [Http Methods](#http-methods)
* [Catchers](#catchers)
* [Response Types](#response-types)
* [Extras](#extras)

**[⬆ back to top](#table-of-contents)**

### ftransport(url: String = '', options: Object = {})

Creates a new FTransport object with an url and [vanilla fetch API options](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch)

<a name="helper-methods"></a>

## Helper Methods

* [url](#helper-methods--url)
* [query](#helper-methods--query)
* [options](#helper-methods--options)
* [headers](#helper-methods--headers)
* [accept](#helper-methods--accept)
* [content](#helper-methods--content)
* [auth](#helper-methods--auth)
* [catcher](#helper-methods--catcher)
* [defer](#helper-methods--defer)
* [resolve](#helper-methods--resolve)
* [defaults](#helper-methods--defaults)
* [errorType](#helper-methods--error-type)
* [polyfills](#helper-methods--polyfills)

**[⬆ back to top](#table-of-contents)**

*Helper methods are optional and can be chained.*

<a name="helper-methods--url"></a>

### url(url: String, replace: Boolean = false)

Appends or replaces the url.

```javascript
ftransport().url('...').get().json(/* ... */);

// Can be used to set a base url

// Subsequent request made using the 'externalApi' object will be prefixed with 'http://external.api/v1'
const entityApi = ftransport('http://external.api/v1/entity');

// CRUD apis
const entityId = await entityApi.json({key : 'value'}).post(({id}) => id);
const entity = await entityApi.url(`/${entityId}`).get().json();

await entityApi.url(`/${entityId}`).delete().res();

// Base url can be replaced if necessary
const rootOfApi = entityApi.url('http://external.api/v1', true);
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--query"></a>

### query(params: Object, replace: Boolean = false)

Converts a javascript object to query parameters, then append this query string to the current url.

```javascript
let api = ftransport('http://external.api');

api = api.query({param : 'value', paramTwo : 'valueTwo'});
// url is now http://external.api?param=Value&paramTwo=valueTwo

api = api.query({paramThree : 'valueThree', paramFour : [1, 2]});
// url is now http://external.api?param=Value&paramTwo=valueTwo&paramThree=valueThree&paramFour=1&paramFour=2
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--options"></a>

### options(options: Object, mixin: Boolean = true)

Sets the fetch options.

```javascript
ftransport('http://external.api/v1').options({credentials : 'same-origin'});
```

Because ftransport is immutable, you can store the object for later use.

```javascript
const corsFTransport = ftransport().options({
  credentials : 'include',
  mode        : 'cors'
});

corsFTransport.url('http://external.api/v1/pathOne').get();
corsFTransport.url('http://external.api/v1/pathTwo').get();
```

You can override instead of mixing in the existing options by passing a boolean flag.

```javascript
// By default options are mxed/merged in:

ftransport()
  .options({headers : {'Accept' : 'application/json'}})
  .options({encoding : 'same-origin', headers : {'X-Custom' : 'Header'}});

/*
  {
    headers : {
      'Accept'   : 'application/json',
      'X-Custom' : 'Header'
    },
    encoding : 'same-origin'
  }
*/

// With the flag, options are overridden:

ftransport()
  .options({headers : {'Accept' : 'application/json'}})
  .options({encoding : 'same-origin', headers : {'X-Custom' : 'Header'}}, false);

/*
  {
    headers : {
      'X-Custom' : 'Header'
    },
    encoding : 'same-origin'
  }
*/
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--headers"></a>

### headers(headerValues: Object)

Sets the request headers.

```javascript
ftransport()
  .headers({'Content-Type' : 'text/plain', 'Accept' : 'application/json'})
  .body('payload')
  .post()
  .json();
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--accept"></a>

### accept(headerValue: String)

Shortcut to set the 'Accept' header.

```javascript
ftransport().accept('application/json');
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--content"></a>

### content(headerValue: String)

Shortcut to set the 'Content-Type' header.

```javascript
ftransport().content('application/json');
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--auth"></a>

### auth(headerValue: String)

Shortcut to set the 'Authorization' header.

```javascript
ftransport().auth('Basic dsfsdRWEFSFD=');
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--catcher"></a>

### catcher(errorId: Number | String, catcher: Function(error, originalRequest) => any)

Adds a catcher which will be called on every subsequent request error.
Useful when you need to perform repetitive action on a specific error code.

```javascript
const api = ftransport()
  .catcher(404, error => applicationRouter.redirect('/path/not-found'))
  .catcher(500, error => notification.show('Internal Server Error'))
  .catcher('SyntaxError', error => logger('Bad json'));

// There is no need to catch 404 or 500 or the json parsing error, they are already taken care of.
api.url('http://external.api/get/resource')/get().json(/* ... */);

// But the default catchers can be overridden if needed.
api.url('http://external.api/get/resource').notFound(error => /* overrides the default 'redirect' catcher defined above */);
```

The original request is passed along with the error and can be used in order to retry or use to perform another request.

```javascript
const retryAuthOn401 = ftransport()
  .catcher(401, (error, request) => {
    // Renew auth token
    const token = await ftransprt('/authorize').get().text();

    storeToken(token);

    // Retry the original request with the new credentials
    return request.auth(token).get().unauthorized(err => { throw err; }).json();
  });

retryAuthOn401.url('/resource')
  .get()
  .json()         // < Will only be called for the original promise
  .then(callback); // < Will be called for the original OR the replayed promise result
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--defer"></a>

### defer(callback: Function(originalRequest, url: String, options: Object) => ftransport, clear: Boolean = false)

Defer ftransport methods that will be chained and called just before the request is performed. This comes in handy when there are options that are not known upfront, when instantiating ftransport.

```javascript
/**
 * In case you cannot retrieve the authorization token while configuring the ftransport
 * object tou can use .defer to postpone the call
 */
const apiInstance = ftransport('...')
  .defer((instance, url, options) => {
    if (/\/authorised-endpoint/.test(url)) {
      const {token} = options.authData;

      return instance.auth(token);
    }

    return instance;
  });

/* ... */

const token = await getToken(currentSession.user);

apiInstance
  .options({
    authData : {
      token
    }
  })
  .get()
  .res();
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--resolve"></a>

### resolve(doResolve: Function(chain, originalRequest) => chain | Promise, clear: Boolean = false)

Programs a resolver which will automatically be injected to perform response chain tasks.
This is useful when you need to perform repetitive actions on the ftransport response.

* The clear argument, if set to true, removes any previously defined resolvers.*

```javascript
// Response chain actions
const api = ftransport()
  .resolve(resolver =>
    resolver
      .perfs(response => /* monitor every request */)
      .json(response => /* parse and return json */)
  );

const jsonObj = await api.url('http://external.api/v1/resource').get();

// The above is equivalent to
ftransport()
  .url(http://external.api/v1/resource)
  .get()
  .perfs(response => /* monitor every request */)
  .json(response => response);
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--defaults"></a>

### defaults(options: Object, mixin: Boolean = false)

Sets default fetch options which will be used for every subsequent request.

```javascript
// Default options will be mixed in
ftransport().defaults({headers : {'Accept' : 'application/json'}});

// The fetch request is sent with both headers, the default defined above and the inline below
ftransport('http://external.api', {
  headers : {
    'X-Custom' : 'Header'
  }
}).get();
```

```javascript
// You can mix in with the existing options instead of overriding them by passing a boolean flag
ftransport().defaults({headers : {'Accept' : 'application/json'}});
ftransport().defaults({headers : {'X-Custom' : 'header'}, encoding : 'same-origin'}, true);

/*
  The new options are:

  {
    headers : {
      'Accept'   : 'application/json',
      'X-Custom' : 'Header'
    },
    encoding : 'same-origin'
  }
*/
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--error-type"></a>

### errorType(method: 'text' | 'json' = 'text')

Sets the method (text, json...) used to parse the data contained in the response body in case of an HTTP error.

Persists for every subsequent requests.

```javascript
ftransport().errorType('json');

ftransport('http://server/which/returns/an/error/with/a/json/body')
  .get()
  .res()
  .catch(error => {
    // error[errorType] (here, json) contains the parsed body
    console.log(error.json)
  });
```

**[⬆ back to helper methods](#helper-methods)**

<a name="helper-methods--polyfills"></a>

### polyfills(polyfills: Object)

Sets the non-global polyfills which will be used for every subsequent calls.

```javascript
import fetch from 'node-fetch';
import FormData from 'form-data';
import {URLSearchParams} from 'url';

ftransport().polyfills({
    fetch,
    FormData,
    URLSearchParams
});
```

**[⬆ back to helper methods](#helper-methods)**

<a name="body-types"></a>

## Body Types

* [body](#body-types--body)
* [json](#body-types--json)
* [formData](#body-types--form-data)
* [formUrl](#body-types--form-url)

> A body type is only needed when performing put/patch/post requests with a body.

<a name="body-types--body"></a>

### body(payload: any)

```javascript
ftransport('http://external.api')
  .body('hello')
  .put();
```

**[⬆ back to body types](#body-types)**

<a name="body-types--json"></a>

### json(payload: Object)

Sets the content type header, stringifies an object and sets the request body.

```javascript
const jsonObject = {
  a : 1,
  b : 2,
  c : 3
};

ftransport('http://external.api/v1/resource')
  .json(jsonObject)
  .post();

// Calling an 'http verb' method with the body as an argument is equivalent

ftransport('http://external.api/v1/resource')
  .post(jsonObject);
```

**[⬆ back to body types](#body-types)**

<a name="body-types--form-data"></a>

#### formData(formObject: Object)

Converts the javascript object to a FormData and sets the request body.

```javascript
const form = {
  hello : 'world',
  foo   : 'bar'
};

ftransport('http://external.api/v1/resource')
  .formData(form)
  .post();
```

**[⬆ back to body types](#body-types)**

<a name="body-types--form-url"></a>

#### formUrl(input: Object | String)

Converts the input parameter to an url encoded string and sets the content-type header and body.
If the input argument is already a string, skips the conversion part.

```javascript
const form = {
  a : 1,
  b : {
    c : 2
  }
};
const alreadyEncodedForm = 'a=1&b=%7B%22c%22%3A2%7D';

// Automatically sets the content-type header to 'application/x-www-form-urlencoded'
ftransport('http://external.api/v1/resource')
  .formUrl(form)
  .post();

ftransport('http://external.api/v1/resource')
  .formUrl(alreadyEncodedForm)
  .post();
```

**[⬆ back to body types](#body-types)**

**[⬆ back to top](#table-of-contents)**

<a name="http-methods"></a>

## HTTP Methods

### Required

> You can pass the fetch options here if you prefer.

### get(options = {})

Performs a get request.

```javascript
ftransport('http://some.api/v1')
  .get({credentials : 'same-origin'});
```

**[⬆ back to HTTP methods](#http-methods)**

### delete(options = {})

Performs a delete request.

```javascript
ftransport('http://some.api/v1')
  .delete({credentials : 'same-origin'});
```

**[⬆ back to HTTP methods](#http-methods)**

### put(body?, options = {})

Performs a put request.

```javascript
ftransport('http://some.api/v1')
  .json({...})
  .put();
```

**[⬆ back to HTTP methods](#http-methods)**

### patch(body?, options = {})

Performs a patch request.

```javascript
ftransport('http://some.api/v1')
  .json({...})
  .patch();
```

**[⬆ back to HTTP methods](#http-methods)**

### post(body?, options = {})

Performs a post request.

```javascript
ftransport('http://some.api/v1')
  .json({...})
  .post();
```

**[⬆ back to HTTP methods](#http-methods)**

### head(opts = {})

Performs a head request.

```javascript
ftransport('http://some.api/v1').head({credentials : 'same-origin'});
```

**[⬆ back to HTTP methods](#http-methods)**

### opts(options = {})

Performs an options request.

```javascript
ftransport('http://some.api/v1')
  .opts({credentials : 'same-origin'});
```

**[⬆ back to HTTP methods](#http-methods)**

<a name="catchers"></a>

## Catchers

> Catchers are optional, but if you do not provide them an error will still be thrown in case of an http error code received. Catchers can be chained.

* [badRequest](#catchers--bad-request)
* [unauthorized](#catchers--unauthorized)
* [forbidden](#catchers--forbidden)
* [notFound](#catchers--not-found)
* [timeout](#catchers--timeout)
* [internalError](#catchers--internal-error)
* [onAbort](#catchers--on-abort)
* [error](#catchers--error)

```javascript
ftransport('http://some.api')
  .get()
  .badRequest(err => console.log(err.status))
  .unauthorized(err => console.log(err.status))
  .forbidden(err => console.log(err.status))
  .notFound(err => console.log(err.status))
  .timeout(err => console.log(err.status))
  .internalError(err => console.log(err.status))
  .error(418, err => console.log(err.status))
  .res();
```

<a name="catchers--bad-request"></a>

### badRequest(callback)

Syntactic sugar for `error(400, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--unauthorized"></a>

#### unauthorized(callback)

Syntactic sugar for `error(401, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--forbidden"></a>

#### forbidden(callback)

Syntactic sugar for `error(403, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--not-found"></a>

#### notFound(callback)

Syntactic sugar for `error(404, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--timeout"></a>

#### timeout(callback)

Syntactic sugar for `error(418, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--internal-error"></a>

#### internalError(callback)

Syntactic sugar for `error(500, callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--on-abort"></a>

#### onAbort(callback)

Syntactic sugar for `error('AbortError', callback)`.

**[⬆ back to catchers](#catchers)**

<a name="catchers--error"></a>

#### error(errorId: Number | String, callback: (error, originalRequest) => any)

Catches a specific error given its code or name and perform the callback.

The original request is passed along the error and can be used in order to perform an additional request.

```javascript
ftransport('/resource')
  .get()
  .unauthorized(async (error, request) => {
    // Renew auth token
    const token = await ftransprt('/renew-token')
      .get()
      .text();

    storeToken(token);

    // Retry the original request with the new credentials
    return request.auth(token)
      .get()
      .unauthorized(err => {
        throw err;
      }).json();
  })
  .json()
  /*
   * The promise chain is preserved as expected '.then' will be
   * performed on the result of the original request or the replayed
   * one (if a 401 error was thrown)
   */
  .then(callback);
```

**[⬆ back to catchers](#catchers)**

<a name="response-types"></a>

## Response Types

### Required

> If an error is caught by catchers, the response type handler will not be called.

* [res](#response-types--res)
* [json](#response-types--json)
* [blob](#response-types--blob)
* [formData](#response-types--form-data)
* [arrayBuffer](#response-types--array-buffer)
* [text](#response-types--text)

All these methods accept an optional callback, and will return a Promise resolved with either the return value of the provided callback or the expected type.

```javascript
// Without a callback
ftransport('...')
  .get()
  .json()
  .then(json => /* json is the parsed json of the response body */);

// Without a callback using await
const json = await ftransport('...')
  .get()
  .json();

// With a callback the value returned is passed to the Promise
ftransport('...')
  .get()
  .json(() => 'Hello world!')
  .then(console.log); // Hello world!
```

<a name="response-types--res"></a>

### res(callback? Function(response: Response) => any): Promise<Response | any>

Raw Response handler.

```javascript
ftransport('http://some.api/v1')
  .get()
  .res(response => console.log(response.url));
```

**[⬆ back to response types](#response-types)**

<a name="response-types--json"></a>

#### json(callback? Function(response: Response) => any): Promise<Response | any>

Json handler.

```javascript
ftransport('http://some.api/v1')
  .get()
  .json(json => console.log(Object.keys(json)));
```

**[⬆ back to response types](#response-types)**

<a name="response-types--blob"></a>

#### blob(callback? Function(response: Blob) => any): Promise<Blob | any>

Blob handler.

```javascript
ftransport('http://some.api/v1')
  .get()
  .blob(blob => /* ... */);
```

**[⬆ back to response types](#response-types)**

<a name="response-types--form-data"></a>

#### formData(callback? Function(response: FormData ) => any): Promise<FormData  | any>

FormData handler.

```javascript
ftransport('http://some.api/v1')
  .get()
  .formData(formData => /* ... */);
```

**[⬆ back to response types](#response-types)**

<a name="response-types--array-buffer"></a>

#### arrayBuffer(callback? Function(response: ArrayBuffer) => any): Promise<ArrayBuffer | any>

ArrayBuffer handler.

```javascript
ftransport('http://some.api/v1').get().arrayBuffer(arrayBuffer => /* ... */);
```

**[⬆ back to response types](#response-types)**

<a name="response-types--text"></a>

#### text(callback? Function(response: String) => any): Promise<String | any>

Text handler.

```javascript
ftransport('http://some.api/v1')
  .get()
  .text(text => console.log(text));
```

**[⬆ back to response types](#response-types)**

<a name="extras"></a>

## Extras

*A set of extra features.*

* [Abortable requests](#extras--abortable-requests)
* [Performance API](#extras--performance-api)
* [Middlewares](#extras--middlewares)

<a name="extras--abortable-requests"></a>

### Abortable requests

*Your browser absolutely needs to support [AbortControllers](https://developer.mozilla.org/en-US/docs/Web/API/AbortController).*

```javascript
const [controller, api] = ftransport('http://some.api')
  .get()
  .onAbort(() => console.log('Aborted!'))
  .controller();

api.text(() => console.log('This should never be called'));
controller.abort();

// Or:

const controller = new AbortController();

ftransport('http://some.api')
  .signal(controller)
  .get()
  .onAbort(() => console.log('Aborted!'))
  .text(_ => console.log('This should never be called'));

controller.abort();
```

**[⬆ back to extras](#extras)**

### signal(controller: AbortController)

> Used at `request` time, like an helper.

Associates a custom controller with the request. Comes in useful when you need to use your own AbortController, otherwise ftransport will create a new controller itself

```javascript
const controller = new AbortController();

ftransport('url1')
  .signal(controller)
  .get()
  .json(response => /* ... */);

ftransport('url2')
  .signal(controller)
  .get()
  .json(response => /* ... */);

// Abort both requests
controller.abort();
```

**[⬆ back to extras](#extras)**

#### setTimeout(time: Number, controller?: AbortController)

> Used at `response` time.

Aborts the request after a fixed time. If you use a custom AbortController associated with the request, pass is as a second argument.

```javascript
// 1 second timeout
ftransport('...')
  .get()
  .setTimeout(1e3)
  .json(response => {
    // Will not be called in case of a timeout
  });
```

**[⬆ back to extras](#extras)**

#### controller()

> Used at `response` time

Returns the automatically generated AbortController alongside the current ftransport response as a pair.

```javascript
const [controller, instance] = ftransport('url')
  .get()
  .controller();

// Resume with the chain of calls
instance
  .onAbort(() => console.log('Request aborted'))
  .json(response => /* ... */)

// At a later point
controller.abort();
```

**[⬆ back to extras](#extras)**

#### onAbort(callback(error) => any)

> Used at `response` time like a catcher

Catches an AbortError and performs the callback.

**[⬆ back to extras](#extras)**

<a name="extras--performance-api"></a>

### Performance API

#### perfs(callback: Function(timings: PerformanceTimig): void)

Takes advantage of the Performance API ([browsers](https://developer.mozilla.org/en-US/docs/Web/API/Performance_API) & [node.js](https://nodejs.org/api/perf_hooks.html)) to expose timings related to the underlying request.

Browser timings are very accurate, node.js only contains raw measures.

```javascript
// Use perfs() before the response types (text, json, ...)
ftransport('http://some.api')
  .get()
  .perfs(timings => {
    // Will be called when the timings are ready.
    console.log(timings.startTime);
  })
  .res();
```

**[⬆ back to extras](#extras)**

<a name="extras--middlewares"></a>

### Middlewares

Middlewares are functions that can intercept requests before being processed by Fetch. ftransport  includes a helper to help replicate the [middleware](http://expressjs.com/en/guide/using-middleware.html) style.

#### Signature

Basically a middleware is a function having the following signature:

```javascript
const middleware = possibleOptions => next => (url, options) => {
  // Your logic here

  // Call the next middleware in the chain
  return next(url, options);
};
```

**[⬆ back to extras](#extras)**

<a name="middlewares"></a>

#### middlewares(middlewares, clear = false)

Add middlewares to intercept a request before being sent.

```javascript
const delayMiddleware = delay => next => (url, opts) => {
  return new Promise(res => setTimeout(() => res(next(url, opts)), delay))
};

// The request will be delayed by 1 second.
ftransport('http://some.api').middlewares([
  delayMiddleware(1e3)
]).get().res(_ => /* ... */);
```

ftransport comes with a suite of handful middlewares

* [cache](#middlewares--cache)
* [delay](#middlewares--delay)
* [log](#middlewares--log)
* [payloadFormatter](#middlewares--payload-formatter)
* [perf](middlewares--perf)
* [retry](#middlewares--retry)
* [shortCircuit](#middlewares--short-circuit)

<a name="middlewares--cache"></a>

#### `cache(throttleMs: Number)`

A simple implementation of throttling + caching middleware. It will cache responses for `throttleMs`. If any subsequent requests are made within the `throttleMs` interval, ftransport will serve the cached response instead of calling the API.

<a name="middlewares--delay"></a>

**[⬆ back to middlewares](#middlewares)**

#### `delay(forHowLong: Number)`

Will delay every API call with `forHowLong` ms.

**[⬆ back to middlewares](#middlewares)**

<a name="middlewares--log"></a>

#### `log`

Logs request data into the browser console.

**[⬆ back to middlewares](#middlewares)**

<a name="middlewares--payload-formatter"></a>

#### `payloadFormatter({encode: Function, decode: Function, bodyType: 'text' | 'json', shouldProcess: Function})`

Useful for custom encoding/decoding operations performed on the request and response payload.

```javascript
import Fix from '@fenics/fenics-encoding';
import {ftransport, ftransportMiddlewares} from '@fenics/fenics-transport';

const fixPayloadFormatterMiddleware = ftransportMiddlewares.payloadFormatterMiddleware({
  encode : Fix.encode,
  decode : payload => Fix.decode(payload, {
    validateBodyLength : false,
    validateChecksum   : false
  }),
  bodyType      : 'text',
  shouldProcess : ({options}) => {
    const hasContentTypeHeader = options.headers && Reflect.has(options.headers, 'Content-Type');

    return hasContentTypeHeader && options.headers['Content-Type'] === 'application/json';
  }
});

const apiBaseUrl = 'https://api-base.url';

const api = ftransport()
  .content('application/octet-stream')
  .accept('application/octet-stream')
  .middlewares([fixMiddleware])
  .url(apiBaseUrl);
```

**[⬆ back to middlewares](#middlewares)**

<a name="middlewares--perf"></a>

#### `perf(callback)`


Monitors roundtrip time for requests. `callback` will be passed an instance of [PerformanceMeasure](https://developer.mozilla.org/en-US/docs/Web/API/PerformanceMeasure), where `name` property will be the request url.

```javascript
import {ftransport, ftransportMiddlewares} from '@fenics/fenics-transport';

const perfMw = ftransportMiddlewares.perfMiddleware(measure => {
  const {duration, name} = measure;

  console.log(`Request with url ${name} took ${duration}ms`);
});

ftransport(url)
  .middlewares([perfMw])
  .get()
  .json();
```

**[⬆ back to middlewares](#middlewares)**

<a name="middlewares--retry"></a>

#### `retry({backoff, delay, errorCodes, maxAttempts})`

Middleware that will re-try to make the API call in case that the error code is whitelisted.

* `backoff` is a function that determines how often the retries are made. A default exponential implementation is provided.
* `delay` start point for delaying retry attempts. This will be used for the first retry attempt and then it should be increased, up to a capping value.
* `errorCodes` is an array of standard HTTP Response error codes.
* `maxAttempts` is set to Infinity by default.

All the parameters are optional and default are internally provided.

```javascript
const defaultBackoff = (delay, numberOfAttemptsMade) =>
  Math.min(delay * numberOfAttemptsMade, 1000);
```

**[⬆ back to middlewares](#middlewares)**

<a name="middlewares--short-circuit"></a>

#### `shortCircuit`

Middleware useful in development for using mock data instead of the actual API.

**[⬆ back to middlewares](#middlewares)**

#### An example

```javascript
import ftransport, {delay, cache, log, reconnect, shortCircuit} from '@fenics/fenics-transport';

const delayMiddleware = delay(1000);
const cacheMiddleware = cache(2000);
const retryMiddleware = reconnect({
  errorCodes  : [400, 404, 500, 503],
  maxAttempts : 10
});

const externalApi = ftransport('http://some.api').middlewares([
  delayMiddleware,
  cacheMiddleware,
  retryMiddleware,
  log(),
  shortCircuit()
]);

// Will wait for 1000ms, then it will try to call the API, but because of the
// shortCircuit middleware, that will never happen, instead mock data will be
// returned. It will log the request details into the console. For the following
// 2 calls, the response will be served from the cache. If the response has one
// of the statuses passed to retryMiddleware, it will retry to get the data.
externalApi('/somePath').get().json();
externalApi('/somePath').get().json();
externalApi('/somePath').get().json();
```

## Testing

`fenics-transport` exports an instance that uses `fenics-worker`'s web worker implementation. Due to this, the consumer packages of `fenics-transport` will have a few challenges:

* Because WebWorkers are heavily relying on browser API's that are not available in `node` environment where `mocha` unit tests run, unless [puppeteer](https://github.com/GoogleChrome/puppeteer) or a similar tools is used, when trying to run the tests, `mocha` will throw runtime errors like `MessagePort is not defined`. If you're not using the web-worker implementation, there is a quick workaround. But first, the explanation. `fenics-transport` distribution consists af one bundle. Even though you might not use the `fenicsTransportWorker` in your code, just by importing anything from `fenics-transport`, the runtime error will be thrown. The fix is illustrated below:

```javascript
// sample.js
import {ftransport} from '@fenics/fenics-transport';

// ... Module logic
```

```javascript
// sample.test.js
// various imports, but not the sources containing imports of '@fenics/fenics-transport'
global.MessagePort = () => null; // <-- Mock the MessagePort so that mocha doesn't throw an error

const sample = require('./sample'); // <-- this way we make sure global.MessagePorts has been defined before importing our module

describe('Sample', () => {
  // ...
});
```

> Even if you don't place your module's imports as the first thigs, they'll [get hoisted](http://exploringjs.com/es6/ch_modules.html#_imports-are-hoisted), so any code you lexically put before the import will actually happen after, that's why the need of using `require` instead.

## NOTE: This is just temporary until a proper solution is put in place.
