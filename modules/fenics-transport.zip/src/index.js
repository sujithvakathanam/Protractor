import ftransport, {
  middlewares as ftransportMiddlewares,
  HTTP_METHOD,
  HTTP_STATUS
} from './fetch';
import FStream, {
  CLOSE_EVENT_CODE,
  STREAM_EVENT
} from './streaming';

export {
  ftransport,
  ftransportMiddlewares,
  FStream,

  CLOSE_EVENT_CODE,
  HTTP_METHOD,
  HTTP_STATUS,
  STREAM_EVENT
};

export default ftransport;
