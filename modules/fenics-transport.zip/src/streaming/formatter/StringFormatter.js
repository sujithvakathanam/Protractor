import MessageFormatterBase from './MessageFormatterBase';

class StringFormatter extends MessageFormatterBase {
  toMessage = obj => obj.toString();

  fromMessage = message => message;
}

export default StringFormatter;
