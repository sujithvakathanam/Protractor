import MessageFormatterBase from './MessageFormatterBase';
import {TOPIC} from '../constant';

class JsonFormatter extends MessageFormatterBase {
  constructor () {
    super();

    this.requestMap = new Map();
    this.nextId = 0;
  }

  resetNextId = () => {
    this.nextId = 0;
  };

  pingRequest = () => ({
    topic   : TOPIC.PING,
    payload : {
      clientTimestamp : Number(new Date())
    }
  });

  handlePong = ({topic}) => topic === TOPIC.PONG;

  formatPong = ({topic, payload}) => ({
    topic,
    ...payload
  });

  toMessage = obj => JSON.stringify(obj);

  fromMessage = message => JSON.parse(message);

  trackRequest = (requestObject, handler) => {
    this.nextId += 1;

    requestObject.payload.id = this.nextId;

    this.requestMap.set(requestObject.payload.id, handler);

    return requestObject;
  };

  getHandlerForResponse = ({id}) => {
    if (!id) {
      return null;
    }

    const handler = this.requestMap.get(id);

    if (!handler) {
      return null;
    }

    this.requestMap.delete(id);

    return handler;
  };

  getPendingHandlerIds = () => this.requestMap.keys();

  getPingId = obj => {
    const {payload : {id}} = obj;

    return id;
  };

  onMessage = async (dispatch, message) => {
    const {topic, payload} = message;

    await dispatch(topic, payload);
  };
}

export default JsonFormatter;
