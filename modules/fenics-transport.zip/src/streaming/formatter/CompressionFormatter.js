import pako from 'pako';
import UTF8 from 'utf-8';
import JsonFormatter from './JsonFormatter';
import {TOPIC, ZLIB_BASE_64} from '../constant';
import getLogger from '../../logger';

class CompressionFormatter extends JsonFormatter {
  constructor () {
    super();

    this.logger = getLogger('CompressionFormatter');
  }

  toMessage = obj => {
    const {topic, payload} = obj;

    if (topic === TOPIC.PING) {
      return JSON.stringify({
        __compression : 'none',
        ...obj
      });
    }

    const json = JSON.stringify(payload);
    const decompressed = UTF8.setBytesFromString(json);
    const compressed = pako.deflate(decompressed);
    const base64 = Buffer.from(compressed).toString('base64');

    return JSON.stringify({
      __compression : ZLIB_BASE_64,
      payload       : base64,
      topic
    });
  }

  fromMessage = messageString => {
    try {
      const message = JSON.parse(messageString);
      const {__compression, topic, payload} = message;

      if (__compression === ZLIB_BASE_64) {
        const compressed = Buffer.from(payload, 'base64').toString('binary');
        const decompressed = pako.inflate(compressed);
        const str = UTF8.getStringFromBytes(decompressed);

        return {
          topic,
          payload : JSON.parse(str)
        };
      }

      return message;
    } catch (err) {
      this.logger.error(err);

      return {
        __decompressionError : err
      };
    }
  }
}

export default CompressionFormatter;
