/* eslint-disable class-methods-use-this */

class MessageFormatterBase {
  pingMessage = null;

  pingRequest = null;

  handlePing = null;

  handlePong = null;

  formatPong = item => item;

  resetNextId = () => null;

  toMessage () {
    throw new Error('toMessage not implemented');
  }

  fromMessage () {
    throw new Error('fromMessage not implemented');
  }

  trackRequest () {
    throw new Error('trackRequest not implemented');
  }

  getHandlerForResponse () {
    return null;
  }

  getPendingHandlerIds () {
    return null;
  }

  getPingId () {
    return null;
  }

  onMessage () {
    return null;
  }
}

export default MessageFormatterBase;
