const getTag = value => {
  if (value === null) {
    return '[object Undefined]';
  } else if (typeof value === 'undefined') {
    return '[object Undefined]';
  }

  return Object.prototype.toString.call(value);
};

const isFunction = value => {
  const tag = getTag(value);

  return (
    tag === '[object Function]'
    || tag === '[object AsyncFunction]'
    || tag === '[object GeneratorFunction]'
    || tag === '[object Proxy]'
  );
};

const isObject = obj => obj !== null && obj === Object(obj);

export {
  isFunction,
  isObject
};
