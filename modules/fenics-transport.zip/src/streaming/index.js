import {CLOSE_EVENT_CODE, STREAM_EVENT} from './constant';
import FStream from './FStream';

export {
  CLOSE_EVENT_CODE,
  STREAM_EVENT
};

export default FStream;
