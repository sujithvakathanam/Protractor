/* eslint-disable max-lines */

import FStreamEvent from './FStreamEvent';
import {CompressionFormatter, JsonFormatter, MessageFormatterBase, StringFormatter} from './formatter';
import {CLOSE_EVENT_CODE, STREAM_EVENT, WS_ERROR} from './constant';
import {isFunction, isObject} from './utils';
import ftransport, {middlewares, HTTP_ERROR_WILDCARD, HTTP_METHOD} from '../fetch';
import getLogger from '../logger';

const logger = getLogger('FStream');

const {retryMiddleware} = middlewares;

const BASE = 16;
const randUuid = Math.random()
  .toString(BASE)
  .substring(2);

const delay = amount => new Promise(resolve => setTimeout(resolve, amount));

const DEFAULT_OPTIONS = {
  applicationName : `application-name-${randUuid}`,
  backoff         : numberOfAttempts => {
    const MAX_POW = 6;
    const MS_IN_S = 1e3;
    const timeCap = Math.pow(2, Math.min(MAX_POW, numberOfAttempts - 1));

    return timeCap * MS_IN_S + Math.floor(Math.random() * MS_IN_S);
  },
  binaryType                 : 'blob',
  connectionTimeout          : 1e4,
  disconnectOnRequestTimeout : false,
  formatter                  : null,
  getTokenRequestPayload     : ({applicationName}) => ({
    group : applicationName
  }),
  getWebsocketToken            : ({ott}) => ott,
  getWebsocketUrl              : ({websocketUrl, websocketToken}) => `${websocketUrl}?ott=${websocketToken}`,
  pingInterval                 : 3e4,
  pingResponseTimeout          : 6e4,
  reconnectOnPingTimeout       : true,
  reconnectOnConnectionTimeout : true,
  requestTimeout               : null,
  tokenHttpMethod              : HTTP_METHOD.POST,
  tokenContentTypeHeader       : 'application/json',
  tokenAcceptHeader            : 'application/json',
  shouldReconnectOnClose       : ({code, wasClean}) => !wasClean || wasClean && code !== CLOSE_EVENT_CODE.NORMAL_CLOSURE
};

class FStream {
  static STREAM_EVENT = STREAM_EVENT;

  static CompressionFormatter = CompressionFormatter;

  static JsonFormatter = JsonFormatter;

  static MessageFormatterBase = MessageFormatterBase;

  static StringFormatter = StringFormatter;

  constructor (url, options = {}) {
    this.options = {
      ...DEFAULT_OPTIONS,
      ...options
    };

    this.url = url;
    this.socket = null;

    this.events = new FStreamEvent(this);

    this.attemptingConnect = false;
    this.tries = 0;
    this.aborted = false;
    this.closing = false;
    this.formatter = options.formatter;

    this.pingTimer = null;
    this.lastSentPing = null;
    this.lastReceivedPongId = 0;
    this.lastMessageTimestamp = 0;

    this.setUpTransport();
    this.attemptConnect();
  }

  setUpTransport = () => {
    const {tokenUrl, authHeader} = this.options;

    this.api = ftransport(tokenUrl)
      .auth(authHeader)
      .accept(this.options.tokenAcceptHeader)
      .content(this.options.tokenContentTypeHeader)
      .middlewares([retryMiddleware({
        errorCodes : [HTTP_ERROR_WILDCARD]
      })]);
  };

  // eslint-disable-next-line complexity, max-statements
  attemptConnect = async () => {
    this.raiseEvent(STREAM_EVENT.ATTEMPT_CONNECT);

    if (!this.attemptingConnect) {
      let delayAmount = 0;
      let websocketToken = null;

      this.attemptingConnect = true;

      if (this.tries > 0) {
        delayAmount = this.options.backoff(this.tries);

        this.raiseEvent(STREAM_EVENT.RETRY_CONNECT, this.tries);

        logger.info(`Trying again in ${delayAmount}ms`);
      } else {
        await this.raiseEvent(STREAM_EVENT.CONNECTING);
      }

      this.tries += 1;

      await delay(delayAmount);

      this.attemptingConnect = false;

      if (this.options.tokenUrl) {
        try {
          let response = null;

          logger.info('Fetching websocket token');

          const payload = this.options.getTokenRequestPayload(this.options);

          if (this.options.tokenHttpMethod === HTTP_METHOD.POST) {
            response = await this.api
              .json(payload)
              .post()
              .json();
          } else if (this.options.tokenHttpMethod === HTTP_METHOD.GET) {
            response = await this.api
              .get()
              .json();
          }

          websocketToken = this.options.getWebsocketToken(response);

          logger.info(`websocketToken = ${websocketToken}`);

          await this.start(websocketToken);
        } catch (error) {
          logger.error('Error while fetching the websocket token', error);

          await this.attemptConnect();
        }
      } else {
        this.attemptingConnect = false;

        await this.start();
      }
    }
  };

  abortConnect = () => {
    this.attemptingConnect = false;
    this.aborted = true;
  };

  start = websocketToken => {
    if (!this.formatter) {
      logger.info('No message formatter had been specifid, creating a JsonFormatter instance as formatter');

      this.formatter = new JsonFormatter();
    }

    if (!this.aborted) {
      const {binaryType} = this.options;
      const websocketUrl = this.options.getWebsocketUrl({
        websocketUrl : this.url,
        websocketToken
      });

      this.socket = new WebSocket(websocketUrl);
      this.socket.binaryType = binaryType;

      let connectionTimeout = null;

      if (this.options.connectionTimeout) {
        connectionTimeout = global.setTimeout(async () => {
          logger.error('Connection timeout exceeded');

          await this.raiseEvent(STREAM_EVENT.CONNECTION_TIMEOUT);

          if (this.options.reconnectOnConnectionTimeout) {
            const willRetryToReconnect = true;

            await this.raiseErrorEvent(willRetryToReconnect);
          }
        }, this.options.connectionTimeout);

        logger.info(`Setting connection timeout (${this.options.connectionTimeout}ms)`);
      }

      const clearConnectionTimeout = () => {
        if (connectionTimeout !== null) {
          logger.info('Clearing connection timeout');

          global.clearTimeout(connectionTimeout);

          connectionTimeout = null;
        }
      };

      this.socket.onopen = async () => {
        logger.info('Websocket::onopen');

        clearConnectionTimeout();

        this.tries = 0;

        await this.raiseEvent(STREAM_EVENT.CONNECTED);

        this.sendPingRequest();
      };

      this.socket.onclose = async error => {
        const {code, reason, wasClean} = error;

        logger.info(`Websocket::onclose {wasClean : ${wasClean.toString()}, code : ${code}}`);

        clearConnectionTimeout();
        this.clearPingTimers();
        this.formatter.resetNextId();
        const closeReason = {
          code,
          reason,
          wasClean
        };

        if (this.options.shouldReconnectOnClose(error)) {
          const willRetryToReconnect = true;
          await this.raiseErrorEvent(willRetryToReconnect, closeReason);
        } else {
          await this.raiseEvent(STREAM_EVENT.CLOSED, closeReason);

          this.socket = null;
        }
      };

      this.socket.onmessage = ({data}) => {
        this.lastMessageTimestamp = Number(new Date());

        this.dispatchMessage(data);
      };
    }
  };

  // eslint-disable-next-line complexity, max-statements
  dispatchMessage = async message => {
    const obj = this.formatter.fromMessage(message);

    let isHandled = false;
    let isPong = false;
    let pongId = 0;

    if (isObject(this.formatter.pingRequest) || isFunction(this.formatter.pingRequest)) {
      const pingId = this.formatter.getPingId(obj);
      const handler = isObject(obj) ? this.formatter.getHandlerForResponse({id : pingId}) : null;

      if (handler) {
        await Promise.resolve(handler.callback(obj));

        if (
          this.lastSentPing !== null
          && this.lastSentPing.obj !== null
          && this.formatter.getPingId(this.lastSentPing.obj) === this.lastReceivedPongId
        ) {
          this.lastSentPing.clearTimeout();
          this.lastSentPing = null;
          this.lastReceivedPongId = 0;

          isPong = true;
          pongId = this.formatter.getPingId(obj);
        }

        isHandled = true;
      }

      if (!isPong && this.lastSentPing !== null) {
        logger.info('Non-pong received during pong response period, extending delay...');

        this.startRequestTimeout(this.lastSentPing);
      }
    } else if (this.formatter.pingMessage) {
      if (isFunction(this.formatter.handlePong)) {
        isPong = await Promise.resolve(this.formatter.handlePong(obj));

        if (isPong) {
          isHandled = true;
        }
      } else {
        isPong = true;
      }

      if (this.lastSentPing) {
        if (isPong) {
          this.lastSentPing.clearTimeout();
          this.lastSentPing = null;
        } else {
          logger.info('Non-pong received during pong response period, extending delay...');

          this.startPingMessageTimeout(this.lastSentPing);
        }
      }
    }

    if (isPong) {
      this.raiseEvent(STREAM_EVENT.PONG, {
        messageTimestamp : this.lastMessageTimestamp,
        ...this.formatter.formatPong(obj)
      });

      if (pongId > 0) {
        logger.info(`< PONG [${pongId}]`);
      } else {
        logger.info('< PONG');
      }

      this.resetPingTimer();
    }

    if (!isHandled && isFunction(this.formatter.handlePing)) {
      const isPing = await Promise.resolve(this.formatter.handlePing(obj));

      if (isPing) {
        logger.info('Received PING message, handled');

        isHandled = true;
      }
    }

    if (!isHandled) {
      if (isFunction(this.formatter.onMessage)) {
        await this.formatter.onMessage(this.raiseEvent, obj);
      }

      await this.raiseEvent(STREAM_EVENT.MESSAGE, obj);
    }
  };

  clearSocket = reason => {
    if (this.lastSentPing) {
      this.lastSentPing.clearTimeout();
      this.lastSentPing = null;
    }

    this.lastReceivedPongId = 0;

    if (this.socket) {
      this.socket.onclose = () => logger.info('Closed old socket that had been cleared()');

      this.socket.onmessage = null;
      this.socket.onerror = error => logger.info('Error in old socket that had been cleared()', error);

      this.socket.close();
      this.socket = null;
    }

    this.raiseEvent(STREAM_EVENT.CLOSE, reason);
  };

  clearPingTimers = () => {
    logger.info('Clearing ping timers');

    if (this.pingTimer) {
      global.clearTimeout(this.pingTimer);

      this.pingTimer = null;
    }
  };

  resetPingTimer = () => {
    logger.info('Resetting ping timer');

    this.clearPingTimers();

    this.pingTimer = global.setTimeout(() => {
      this.sendPingRequest();
    }, this.options.pingInterval);

    logger.info(`Attempting ping in ${this.options.pingInterval}ms`);
  };

  // eslint-disable-next-line complexity
  sendPingRequest = () => {
    if (this.formatter) {
      if (isObject(this.formatter.pingRequest) || isFunction(this.formatter.pingRequest)) {
        const ping = isFunction(this.formatter.pingRequest) ? this.formatter.pingRequest() : {
          ...this.formatter.pingRequest
        };

        this.raiseEvent(STREAM_EVENT.PING, ping);

        this.lastSentPing = this.request({
          obj      : ping,
          callback : obj => {
            this.lastReceivedPongId = this.formatter.getPingId(obj);
          },
          errorCallback : error => {
            if (error.type === WS_ERROR.TIMEOUT) {
              if (this.options.reconnectOnPingTimeout) {
                logger.info('No ping response, trying to reconnect');

                const willRetryToReconnect = true;

                this.formatter.resetNextId();
                this.clearPingTimers();
                this.raiseErrorEvent(willRetryToReconnect, error);
              } else {
                logger.error('No ping response, handling as disconnected');
              }
            }
          },
          timeout             : this.options.pingResponseTimeout,
          disconnectOnTimeout : true
        });

        const pingId = this.formatter.getPingId(ping);

        logger.info(`> PING [${pingId}], requiring response in ${this.options.pingResponseTimeout}ms`);
      } else if (this.formatter.pingMessage) {
        this.lastSentPing = this.sendPingMessage(this.formatter.pingMessage, this.options.pingResponseTimeout);

        logger.info(`> PING, requiring response in ${this.options.pingResponseTimeout}ms`);
      } else {
        logger.info('No ping set up for message formatter, not performing ping');
      }
    } else {
      logger.info('Time for ping, but no formatter selected, not performing ping');
    }
  };

  sendPingMessage = (message, timeout = this.options.requestTimeout) => {
    const pingMessage = {
      obj                 : message,
      messageTimeoutTimer : null,
      messageTimeout      : timeout,
      clearTimeout () {
        if (this.messageTimeoutTimer) {
          global.clearTimeout(this.messageTimeoutTimer);

          this.messageTimeoutTimer = null;
        }
      }
    };

    this.send(message);

    if (pingMessage.messageTimeout > 0) {
      this.startPingMessageTimeout(pingMessage);
    }

    return pingMessage;
  };

  startPingMessageTimeout = pingMessage => {
    pingMessage.clearTimeout();
    pingMessage.messageTimeoutTimer = global.setTimeout(() => {
      if (this.options.reconnectOnPingTimeout) {
        const willRetryToReconnect = true;

        logger.error('Ping message timeout exceeded, trying to reconnect');

        this.raiseErrorEvent(willRetryToReconnect);
      } else {
        logger.error('Ping message timeout exceeded');
      }
    }, pingMessage.messageTimeout);
  };

  // eslint-disable-next-line max-params
  request = ({
    obj,
    callback,
    errorCallback,
    timeout : requestTimeout = this.options.requestTimeout,
    disconnectOnTimeout : requestDisconnectOnTimeout = this.options.disconnectOnRequestTimeout
  }) => {
    const request = {
      obj,
      requestTimeoutTimer : null,
      requestTimeout,
      requestDisconnectOnTimeout,
      clearTimeout () {
        if (this.requestTimeoutTimer) {
          global.clearTimeout(this.requestTimeoutTimer);

          this.requestTimeoutTimer = null;
        }
      }
    };

    this.formatter.trackRequest(obj, {
      callback (item) {
        request.clearTimeout();

        if (callback) {
          callback(item);
        }
      },
      errorCallback (err) {
        if (errorCallback) {
          errorCallback(err);
        }
      }
    });

    this.send(obj);

    if (request.requestTimeout > 0) {
      this.startRequestTimeout(request);
    }

    return request;
  };

  startRequestTimeout = request => {
    const requestId = this.formatter.getPingId(request.obj);

    request.clearTimeout();

    request.requestTimeoutTimer = global.setTimeout(async () => {
      logger.error(`Timeout exceeded [${requestId}]`);

      await this.dispatchErrorMessage(requestId, {type : WS_ERROR.TIMEOUT});

      if (!request.requestDisconnectOnTimeout) {
        const willRetryToReconnect = true;

        await this.raiseErrorEvent(willRetryToReconnect);
      }
    }, request.requestTimeout);
  };

  dispatchErrorMessage = async (id, error) => {
    if (isFunction(this.formatter.getHandlerForResponse)) {
      const handler = this.formatter.getHandlerForResponse({id});

      if (handler) {
        await Promise.resolve(handler.errorCallback(error));
      }
    }
  };

  raiseErrorEvent = async (willRetry, error = {}) => {
    await this.raiseEvent(STREAM_EVENT.ERROR, {
      willRetry,
      ...error
    });

    this.clearSocket(error);

    if (isFunction(this.formatter.getPendingHandlerIds)) {
      const pendingRequestIds = this.formatter.getPendingHandlerIds();

      if (Array.isArray(pendingRequestIds)) {
        const allPendingRequestPromises = pendingRequestIds.map(requestId => this.dispatchErrorMessage(requestId, {
          type : WS_ERROR.DISCONNECT
        }));

        await Promise.all(allPendingRequestPromises);
      }
    }

    if (willRetry) {
      await this.attemptConnect();
    }
  };

  abort = () => {
    if (this.socket) {
      logger.warn('abort() called on a live socket, performing forceful shutdown. Did you mean to call close()?');

      this.clearPingTimers();

      if (this.lastSentPing) {
        this.lastSentPing.clearTimeout();
        this.lastSentPing = null;
      }
      this.lastReceivedPongId = 0;
      this.socket.onclose = null;
      this.socket.onmessage = null;
      this.socket.onerror = null;
      this.socket.close();
      this.socket = null;
    }

    this.abortConnect();

    this.raiseEvent(STREAM_EVENT.ABORT);
  };

  close = async () => {
    this.raiseEvent(STREAM_EVENT.CLOSE);

    if (this.socket) {
      this.closing = true;
      this.socket.close();
    } else {
      this.abortConnect();
      this.clearPingTimers();

      const willRetryToReconnect = false;

      await this.raiseErrorEvent(willRetryToReconnect);
    }
  };

  raiseEvent = async (event, ...args) => {
    await this.events.trigger(event, ...args);
  };

  send = data => {
    if (this.socket) {
      const message = this.formatter.toMessage(data);

      this.socket.send(message);
    }
  };

  on = (type, handler) => {
    this.events.on(type, handler);
  };

  off = (type, handler) => {
    this.events.off(type, handler);
  };
}

export default FStream;
