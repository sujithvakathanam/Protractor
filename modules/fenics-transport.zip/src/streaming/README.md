# Streaming

> Small abstraction on top of the [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API)

## Table of contents
- [Motivation](#motivation)
- [Installation](#installation)
- [Usage and examples](#usage-and-examples)
- [API](#api)

## Motivation

The [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API) is pretty simple and straightforward to use, however it has a few downsides and things that need to be implemented over and over again. This library provides a protocol and API that sits on top of native WebSockets.

This library is supposedto address and facilitate of few of these. Its main features are:

#### Auto-reconnection support

Unless instructed otherwise a disconnected client will try to reconnect forever, until the server is available again. Please see the available reconnection options [here]();

#### Disconnection detection

A heartbeat mechanism is implemented at library level, allowing both the server and the client to know when the other one is not responding anymore.

#### PubSub mechanism

The library implements a small publisher-subscriber mechanism that enables the consumer to subscribe to designated topics. This eliminates the need of listening to `onmessage` event and branch the logic based on a criteria.

## Installation

```bash
npm i --save @fenics/fenics-transport
```

## Usage and examples

You can either import the `FStream` from the library bundle, or import just the streaming bundle on demand. The following 2 are equivalent.

```javascript
// Import from the library bundle
import {FStream} from '@fenics/fenics-transport';

// Import on demand
import FStream from '@fenics/fenics-transport/build/streaming';
```

Here's an example of subscribing to a custom topic.
```javascript
import FStream from '@fenics/fenics-transport/build/streaming';

const websocketUrl = 'wss://websocket.url';

const socket = new FStream(websocketsUrl);

socket.on(FStream.STREAM_EVENT.CONNECTED, () => {
  console.log('Socket connection opened');
});
```

### Fenics platform integration

This library is also used on Fenics platform for connecting to WS API Gateways on AWS. [Insert here a description about the architecture of the platform]. 

Creating a websocket connection happens in 2 steps on the Fenics platform:
1. An HTTP request is made for fetching a websocket token.
2. The websocket token is used when opening the real websocket connection.

#### Example

```javascript
import FStream from '@fenics/fenics-transport/build/streaming';

const websocketUrl = 'wss://websocket.url';
const tokenUrl = 'https://token.url';
const authHeader = 'Bearer ...';
const applicationName = 'applicationName';

const socket = new FStream(websocketsUrl, {
  applicationName,
  authHeader,
  tokenUrl
});

socket.on(FStream.STREAM_EVENT.CONNECTED, () => {
  console.log('Socket connection opened');
});
```

The library has a builtin retry mechanism for the HTTP request for fetching the websocket token. The websocket connection will not be opened until a valid websocket token is received.

## API

`FStream` is exported as a class, you must get an instance before calling any of the api methods.

#### `new FStream(websocketUrl: String, options: Object): FStream`

Returns a new instance of the `FStream`. Most of the options have default values. For how to override them, see the table below with all the possible options accepted.

| Name | Description | Type | Default value | Required |
|------|-------------|------|---------------|----------|
| **applicationName** | Application name used as value for `group` used in the json payload of the HTTP request for fetching the websocket token | `String` | `application-name-${randUuid}` | If used by `getTokenRequestPayload` |
| **authHeader** | Authorization header needed for the HTTP request made for fetching the websocket token | `String` | `-` | `true` |
| **backoff** | Function that determines the amount of time between reconnect attempts. Will receive the current number of attempts made so far as the only argument. By default has an capped exponential implementation. | `Function` | See default value [below](#default-backoff) | `false` |
| **binaryType** | The type of binary data being transmitted by the connection. For details read [here](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/binaryType) | `String` | `'blob'` | `false` |
| **connectionTimeout** | Amount of time before the client decides the connection has timed out | `Number` | `10000ms` | `false` |
| **disconnectOnRequestTimeout** | Wheather or not the library should disconnect when a request times out | `Boolean` | `false` | `false` |
| **formatter** | Allows setting the websocket frames formatter | `MessageFormatterBase` | `JsonFormatter` | `false` |
| **getTokenRequestPayload** | Function that returns the json payload for the websocket token HTTP request. It will have all the options passed to the constructor as the only argument | `Function` | `({applicationName}) => ({group : applicationName})` | `false` |
| **getWebsocketToken** | Function that extracts the websocket token from the HTTP response received when fetching the websocket token | `Function` | `({ott}) => ott` | `false` |
| **getWebsocketUrl** | Function used to build the final websocket url (including the websocket token). Will receive the `websocketUrl` and `websocketToken` as parameter passed under the same property names in an object. | `Function` | `({websocketUrl, websocketToken}) => '${websocketUrl}?ott=${websocketToken}'` | `false` |
| **pingInterval** | Amount of time in `milliseconds` between 2 consecutive ping requests sent by the library | `Number` | `10000ms` | `false` |
| **pingResponseTimeout** | Amount of time in `milliseconds` for ping request timeout. If the timeout is exceeded, it will be treated as disconnect | `Number` | `60000ms` | `false` |
| **reconnectOnPingTimeout** | Controls if the library will try to reconnect after a ping timeout was exceeded. | `Boolean` | `true` | `false` |
| **reconnectOnConnectionTimeout** | Controls if the library will try to reconnect after a connection timeout was exceeded | `Boolean` | `true` | `false` |
| **requestTimeout** | Default websocket request timeout | `Number` | `-` | `false` |
| **tokenHttpMethod** | HTTP Method used on the request for fetching the websocket token | <code>GET&vert;POST</code> | `POST` | `false` |
| **tokenContentTypeHeader** | `Content-Type` header for websocket token request | `String` | `application/json` | `false` |
| **tokenAcceptHeder** | `Accept` header for websocket token request | `String` | `application/json` | `false` |
| **shouldReconnectOnClose** | Function that allows the client to configure when and if the library must perform a reconnect when the websocket connection is closed. Function will received 2 parameters: [code](https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent) and [wasClean](https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent) | `Function => Boolean` | <code>!wasClean &vert;&vert; wasClean && code !== 1000</code> | `false` |

#### Default backoff
```javascript
const backoff = numberOfAttempts => {
  const MAX_POW = 6;
  const MS_IN_S = 1000;
  const timeCap = Math.pow(2, Math.min(MAX_POW, numberOfAttempts - 1));

  return timeCap * MS_IN_S + Math.floor(Math.random() * MS_IN_S);
};
```

#### `on(topicName: String, handler: Function): void`

Registers a new `handler` for the topic with `topicName`. Whenever a message is received having a topic `topicName`, the handler will be called with the data.

```javascript
socket.on(FStream.STREAM_EVENT.CONNECTED, () => {
  console.log('Socket connection opened');
});
```

#### `off(topicName: String, handler: Function): void`

Pair method of [Fstream.on](#ontopicname-string-handler-function-void). Will remove the handler from the list of handlers for `topicName`.

```javascript
const handler = () => {
  console.log('Socket connection opened');
};

socket.on(FStream.STREAM_EVENT.CONNECTED, handler);

// ... later in the code
socket.off(FStream.STREAM_EVENT.CONNECTED, handler);
```

#### `send(data: any): void`

Sends the `data` on the websocket connection.

#### `close(): void`

Closes the websocket connection.
