class FStreamEvents {
  constructor (context) {
    this.events = {};
    this.context = context;
  }

  getHandlersFor = type => {
    if (!Reflect.has(this.events, type)) {
      this.events[type] = [];
    }

    return this.events[type];
  };

  on = (type, handler) => {
    const handlers = this.getHandlersFor(type);

    handlers.push(handler);
  };

  off = (type, handler) => {
    if (handler === null) {
      delete this.events[type];
    } else {
      const handlers = this.getHandlersFor(type);

      this.events[type] = handlers.filter(hndl => hndl !== handler);
    }
  };

  trigger = async (type, ...args) => {
    const handlers = this.getHandlersFor(type).slice();

    // eslint-disable-next-line no-unused-vars
    for (const handler of handlers) {
      // eslint-disable-next-line no-await-in-loop
      const result = await new Promise((resolve, reject) => {
        try {
          let isAsync = false;

          this.context.async = () => {
            isAsync = true;

            return (continueLoop = true) => {
              resolve(continueLoop);
            };
          };

          Promise.resolve(handler.call(this.context, ...args)).then(handlerResult => {
            delete this.context.async;

            if (!isAsync) {
              resolve(handlerResult);
            }
          });
        } catch (ex) {
          reject(ex);
        }
      });

      if (typeof result !== 'undefined' && !result) {
        break;
      }
    }
  };
}

export default FStreamEvents;
