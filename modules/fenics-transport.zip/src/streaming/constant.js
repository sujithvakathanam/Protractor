const STREAM_EVENT = {
  ABORT              : 'abort',
  ATTEMPT_CONNECT    : 'attemptConnect',
  CLOSE              : 'close',
  CLOSED             : 'closed',
  CONNECTED          : 'connected',
  CONNECTING         : 'connecting',
  CONNECTION_TIMEOUT : 'connectionTimeout',
  ERROR              : 'error',
  MESSAGE            : 'message',
  PING               : 'ping',
  PONG               : 'pong',
  RETRY_CONNECT      : 'retryConnect'
};

const TOPIC = {
  PING : '/fenics/ping',
  PONG : '/fenics/pong'
};

const WS_ERROR = {
  NONE       : 0,
  DISCONNECT : 1,
  TIMEOUT    : 2
};

const ZLIB_BASE_64 = 'zlib/base64';

const CLOSE_EVENT_CODE = {
  NORMAL_CLOSURE             : 1000,
  GOING_AWAY                 : 1001,
  PROTOCOL_ERROR             : 1002,
  UNSUPPORTED_DATA           : 1003,
  ON_STATUS_RECEIVED         : 1004,
  ABNORMAL_CLOSURE           : 1006,
  INVALID_FRAME_PAYLOAD_DATA : 1007,
  POLICY_VIOLATION           : 1008,
  MESSAGE_TOO_BIG            : 1009,
  MISSING_EXTENSION          : 1010,
  INTERNAL_ERROR             : 1011,
  SERVICE_RESTART            : 1012,
  TRY_AGAIN_LATER            : 1013,
  BAD_GATEWAY                : 1014,
  TLS_HANDSHAKE              : 1015
};

export {
  CLOSE_EVENT_CODE,
  STREAM_EVENT,
  TOPIC,
  WS_ERROR,
  ZLIB_BASE_64
};
