const GROUP_OF_TWO_SLICE = -2;
const GROUP_OF_THREE_SLICE = -3;

const getNowFormatted = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}`.slice(GROUP_OF_TWO_SLICE);
  const day = `0${now.getDate()}`.slice(GROUP_OF_TWO_SLICE);
  const hours = `0${now.getHours()}`.slice(GROUP_OF_TWO_SLICE);
  const minutes = `0${now.getMinutes()}`.slice(GROUP_OF_TWO_SLICE);
  const seconds = `0${now.getSeconds()}`.slice(GROUP_OF_TWO_SLICE);
  const milliseconds = `00${now.getMilliseconds()}`.slice(GROUP_OF_THREE_SLICE);

  return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
};

const buildPrefix = context => {
  const date = getNowFormatted();

  return `[${date}][${context}]`;
};

const getLogger = context => ({
  info : (...args) => {
    const prefix = buildPrefix(context);

    global.console.log(...[prefix, ...args]);
  },
  warn : (...args) => {
    const prefix = buildPrefix(context);

    global.console.warn(...[prefix, ...args]);
  },
  error : (...args) => {
    const prefix = buildPrefix(context);

    global.console.error(...[prefix, ...args]);
  }
});

export default getLogger;
