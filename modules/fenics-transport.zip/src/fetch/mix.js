// eslint-disable-next-line complexity
const mix = (one, two, mergeArrays = false) => {
  if (!one || !two || typeof one !== 'object' || typeof two !== 'object') {
    return one;
  }

  const clone = {...one};

  // eslint-disable-next-line no-unused-vars
  for (const prop in two) {
    if (Reflect.has(two, prop)) {
      if (two[prop] instanceof Array && one[prop] instanceof Array) {
        clone[prop] = mergeArrays ? [...one[prop], ...two[prop]] : two[prop];
      } else if (typeof two[prop] === 'object' && typeof one[prop] === 'object') {
        clone[prop] = mix(one[prop], two[prop], mergeArrays);
      } else {
        clone[prop] = two[prop];
      }
    }
  }

  return clone;
};

export default mix;
