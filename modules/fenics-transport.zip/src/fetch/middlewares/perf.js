const perfMiddleware = (callback = () => null) => {
  const onFinally = url => {
    performance.mark(`${url}-end`);
    performance.measure(url, `${url}-start`, `${url}-end`);

    const [measure] = performance.getEntriesByName(url);

    callback(measure);

    performance.clearMarks(url);
    performance.clearMeasures(url);
  };

  return next => (url, options) => {
    performance.mark(`${url}-start`);

    return next(url, options)
      .then(response => {
        onFinally(url);

        return response;
      })
      .catch(error => {
        onFinally(url);

        throw error;
      });
  };
};

export default perfMiddleware;
