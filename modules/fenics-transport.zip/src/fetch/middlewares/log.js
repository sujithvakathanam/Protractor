import getLogger from '../../logger';

const logger = getLogger('logMiddleware');

const logMiddleware = () => next => (url, options) => {
  logger.info(`${options.method}@${url}`);

  return next(url, options);
};

export default logMiddleware;
