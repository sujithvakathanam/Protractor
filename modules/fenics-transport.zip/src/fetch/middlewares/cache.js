const cacheMiddleware = (throttle = 0) => {
  const cache = new Map();
  const inflight = new Map();
  const throttling = new Set();

  // eslint-disable-next-line complexity
  return next => (url, options) => {
    const key = `${options.method}@${url}`;

    if (!options.noCache && throttling.has(key)) {
      /**
       * If the cache contains a previous response and we are throttling,
       * serve it and bypass the chain.
       */
      if (cache.has(key)) {
        return Promise.resolve(cache.get(key).clone());
      } else if (inflight.has(key)) {
        // If the request in already in-flight, wait until it is resolved
        return new Promise(resolve => {
          inflight.get(key).push(resolve);
        });
      }
    }

    // Init the pending promises
    if (!inflight.has(key)) {
      inflight.set(key, []);
    }

    // If we are not throttling, activate the throttle for X milliseconds
    if (throttle && !throttling.has(key)) {
      throttling.add(key);

      setTimeout(() => {
        throttling.delete(key);
      }, throttle);
    }

    return next(url, options)
      .then(response => {
        // Add a clone of the response to the cache
        cache.set(key, response.clone());

        // Resolve pending promises
        inflight.get(key).forEach(resolve => resolve(response.clone()));

        // Remove inflight pending promises
        inflight.delete(key);

        // Return the original response
        return response;
      })
      .catch(error => {
        // Reject pending promises
        inflight.get(key).forEach(([, reject]) => reject(error));

        // Remove inflight pending promises
        inflight.delete(key);

        throw error;
      });
  };
};

export default cacheMiddleware;
