const PREFIX = 'API::';

const ACTION_TYPE = {
  REQUEST          : `${PREFIX}REQUEST`,
  RESPONSE_SUCCESS : `${PREFIX}RESPONSE_SUCCESS`,
  RESPONSE_ERROR   : `${PREFIX}RESPONSE_ERROR`
};

const REQUEST_STATUS = {
  IN_PROGRESS : `${PREFIX}REQUEST_IN_PROGRESS`,
  SUCCEDED    : `${PREFIX}REQUEST_SUCCEDED`,
  FAILED      : `${PREFIX}REQUEST_FAILED`
};

const HEADER_TO_METHOD = {
  'application/octet-stream' : 'text',
  'application/json'         : 'json',
  'application/jsonfix'      : 'json'
};

const buildTrackerKey = (url, method) => `${method}:${url}`;

const getResponseStatus = response => (
  response.ok ? REQUEST_STATUS.SUCCEDED : REQUEST_STATUS.FAILED
);

const getActionType = response => (
  response.ok ? ACTION_TYPE.RESPONSE_SUCCESS : ACTION_TYPE.RESPONSE_ERROR
);

const reduxMiddleware = ({decode, dispatch}) => {
  const tracker = new Map();

  return next => (url, options) => {
    const {body, headers, method} = options;
    const trackerKey = buildTrackerKey(url, method);

    tracker.set(trackerKey, REQUEST_STATUS.IN_PROGRESS);

    dispatch({
      type : ACTION_TYPE.REQUEST,
      meta : {
        method,
        url
      },
      payload : body
    });

    const onSucceed = async response => {
      tracker.set(trackerKey, getResponseStatus(response));
      const ftMethod = HEADER_TO_METHOD[headers['Content-Type']];

      const res = await response.clone()[ftMethod]();
      let payload = {};

      if (typeof res === 'string' && res.length) {
        payload = decode(res, {
          validateBodyLength : false,
          validateChecksum   : false
        });
      } else if (typeof res === 'object') {
        payload = res;
      }

      dispatch({
        type : getActionType(response),
        meta : {
          method,
          url
        },
        payload
      });

      return Promise.resolve(response);
    };

    const onError = failure => {
      tracker.set(trackerKey, REQUEST_STATUS.FAILED);

      dispatch({
        type : ACTION_TYPE.RESPONSE_ERROR,
        meta : {
          method,
          url
        },
        payload : failure
      });

      return Promise.reject(failure);
    };

    return next(url, options)
      .then(onSucceed)
      .catch(onError);
  };
};

export default reduxMiddleware;
