const DEFAULTS = {
  DELAY : 1000
};

const delayMiddleware = (delay = DEFAULTS.DELAY) => next => (url, options) => new Promise(resolve => {
  global.setTimeout(() => resolve(next(url, options)), delay);
});

export default delayMiddleware;
