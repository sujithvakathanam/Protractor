const shortCircuitMiddleware = () => () => (url, options) => {
  const response = new Response();

  response.text = () => Promise.resolve(`${options.method}@${url}`);
  response.json = () => Promise.resolve({
    url,
    method : options.method
  });

  return Promise.resolve(response);
};

export default shortCircuitMiddleware;
