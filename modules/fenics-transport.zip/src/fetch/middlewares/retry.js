import {HTTP_ERROR_WILDCARD} from '../constant';

const DEFAULTS = {
  DELAY         : 100,
  MAX_ATTEMPTS  : Number.POSITIVE_INFINITY,
  ERROR_CODES   : [],
  BACKOFF_DELAY : 1000
};

const defaultBackoff = (delay, numberOfAttemptsMade) => Math.min(delay * numberOfAttemptsMade, DEFAULTS.BACKOFF_DELAY);

const retryMiddleware = ({
  backoff = defaultBackoff,
  delay = DEFAULTS.DELAY,
  errorCodes = DEFAULTS.ERROR_CODES,
  maxAttempts = DEFAULTS.MAX_ATTEMPTS
} = {}) => {
  const tracker = new Map();

  errorCodes.map(code => tracker.set(code, new Map()));

  return next => (url, options) => {
    // eslint-disable-next-line complexity
    const checkStatus = response => {
      if (tracker.has(response.status) || tracker.has(HTTP_ERROR_WILDCARD)) {
        if (!response.ok) {
          const requestKey = `${options.method}@${url}`;
          const numberOfAttemptsMade = tracker.get(response.status).get(requestKey) || 0;

          tracker.get(response.status).set(requestKey, numberOfAttemptsMade + 1);

          if (numberOfAttemptsMade >= maxAttempts) {
            return response;
          }

          // We need to recurse until we have a correct response and chain the checks
          return new Promise(resolve => {
            const nextCallIn = backoff(delay, numberOfAttemptsMade);

            setTimeout(() => {
              resolve(next(url, options));
            }, nextCallIn);
          }).then(checkStatus);
        }

        // If ok - reset the map and return the response
        tracker.set(response.status, new Map());

        return Promise.resolve(response);
      }

      return response;
    };

    // Willingly omitted .catch which prevents handling network errors and should throw
    return next(url, options).then(checkStatus);
  };
};

export default retryMiddleware;
