const payloadFormatter = ({
  encode = false,
  decode = false,
  bodyType = 'text',
  shouldProcess = () => true
} = {}) => {
  if (typeof encode !== 'function' || typeof decode !== 'function') {
    throw new Error('Encode and decode must be functions');
  }

  return next => async (url, options) => {
    const params = {
      options,
      url
    };

    if (shouldProcess(params)) {
      const body = await Promise.resolve(encode(options.body));
      const newOptions = {
        ...options,
        body
      };

      return next(url, newOptions)
        .then(async result => {
          if (result.ok) {
            const response = new Response();
            const payload = await result[bodyType]();
            const asJson = await Promise.resolve(payload ? decode(payload) : []);

            response.json = () => Promise.resolve(asJson);

            return response;
          }

          throw new Error(result.status);
        })
        .catch(error => {
          throw error;
        });
    }

    return next(url, options);
  };
};

export default payloadFormatter;
