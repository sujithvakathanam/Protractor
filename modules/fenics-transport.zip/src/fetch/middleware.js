const middlewareHelper = middlewares => fetchFunction => {
  if (middlewares.length === 0) {
    return fetchFunction;
  } else if (middlewares.length === 1) {
    return middlewares[0](fetchFunction);
  }

  return middlewares.reduceRight((acc, curr, idx) => (
    idx === middlewares.length - 2 ? curr(acc(fetchFunction)) : curr(acc)
  ));
};

export default middlewareHelper;
