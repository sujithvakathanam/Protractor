/* eslint no-magic-numbers : off */

import configuration from './configuration';
import mix from './mix';
import perfs from './perfs';
import middlewareHelper from './middleware';
import {HTTP_STATUS} from './constant';

const resolver = ftransport => {
  const {
    baseOptions     : options,
    baseUrl         : url,
    middlewareChain : middlewares,
    catchers,
    resolvers
  } = ftransport;

  const finalOptions = mix(configuration.defaults, options);
  const fetchController = configuration.polyfill('AbortController', false, true);

  if (!finalOptions.signal && fetchController) {
    finalOptions.signal = fetchController.signal;
  }

  const fetchRequest = middlewareHelper(middlewares)(configuration.polyfill('fetch'))(url, finalOptions);

  const throwingPromise = fetchRequest.then(response => {
    if (!response.ok) {
      const errorPropertyName = configuration.errorType || 'text';

      return response[errorPropertyName]().then(message => {
        const error = new Error(message);

        error[errorPropertyName] = message;
        error.status = response.status;
        error.response = response;

        throw error;
      });
    }

    return response;
  });

  const doCatch = promise => promise.catch(error => {
    if (catchers.has(error.status)) {
      return catchers.get(error.status)(error, ftransport);
    } else if (catchers.has(error.name)) {
      return catchers.get(error.name)(error, ftransport);
    }

    throw error;
  });

  const bodyParser = bodyType => callback => {
    if (bodyType) {
      return doCatch(throwingPromise
        .then(response => {
          if (response) {
            return response[bodyType]();
          }

          return response;
        })
        .then(response => {
          if (response && callback) {
            return callback(response);
          }

          return response;
        }));
    }

    return doCatch(throwingPromise.then(response => {
      if (response && callback) {
        return callback(response);
      }

      return response;
    }));
  };

  const responseChain = {
    /**
     * Retrieves the raw result as a promise.
     */
    res : bodyParser(null),

    /**
     * Retrieves the result as a parsed JSON object.
     */
    json : bodyParser('json'),

    /**
     * Retrieves the result as a Blob object.
     */
    blob : bodyParser('blob'),

    /**
     * Retrieves the result as a FormData object.
     */
    formData : bodyParser('formData'),

    /**
     * Retrieves the result as an ArrayBuffer object.
     */
    arrayBuffer : bodyParser('arrayBuffer'),

    /**
     * Retrieves the result as a string.
     */
    text : bodyParser('text'),

    /**
     * Performs a callback on the API performance timings of the request.
     *
     * Warning: Still experimental on browsers and node.js
     */
    perfs : callback => {
      fetchRequest.then(res => perfs.observe(res.url, callback));

      return responseChain;
    },

    /**
     * Aborts the request after a fixed time.
     *
     * @param time Time in milliseconds
     * @param controller A custom controller
     */
    setTimeout : (time, controller = fetchController) => {
      setTimeout(() => controller.abort(), time);

      return responseChain;
    },

    /**
     * Returns the automatically generated AbortController alongside the current ftransport response as a pair.
     */
    controller : () => [fetchController, responseChain],

    /**
     * Catches an http response with a specific error code or name and performs a callback.
     */
    error (errorId, callback) {
      catchers.set(errorId, callback);

      return responseChain;
    },

    /**
     * Catches a bad request (http code 400) and performs a callback.
     */
    badRequest : callback => responseChain.error(HTTP_STATUS.BAD_REQUEST, callback),

    /**
     * Catches an unauthorized request (http code 401) and performs a callback.
     */
    unauthorized : callback => responseChain.error(HTTP_STATUS.UNAUTHORIZED, callback),

    /**
     * Catches a forbidden request (http code 403) and performs a callback.
     */
    forbidden : callback => responseChain.error(HTTP_STATUS.FORBIDDEN, callback),

    /**
     * Catches a 'not found' request (http code 404) and performs a callback.
     */
    notFound : callback => responseChain.error(HTTP_STATUS.NOT_FOUND, callback),

    /**
     * Catches a timeout (http code 408) and performs a callback.
     */
    timeout : callback => responseChain.error(HTTP_STATUS.REQUEST_TIMEOUT, callback),

    /**
     * Catches an internal server error (http code 500) and performs a callback.
     */
    internalError : callback => responseChain.error(HTTP_STATUS.INTERNAL_SERVER_ERROR, callback),

    /**
     * Catches an AbortError and performs a callback.
     */
    onAbort : callback => responseChain.error('AbortError', callback)
  };

  return resolvers.reduce((chain, item) => item(chain, ftransport), responseChain);
};

export default resolver;
