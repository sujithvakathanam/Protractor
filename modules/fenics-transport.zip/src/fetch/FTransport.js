/* eslint no-underscore-dangle : off */

import mix from './mix';
import configuration from './configuration';
import resolver from './resolver';
import {appendQueryParams, convertFormData, convertFormUrl} from './helpers';
import {HTTP_METHOD} from './constant';

const methodSymbol = Symbol('method');

/**
 * The FTransport class used to perform easy fetch requests.
 *
 * Immutability : almost every method of this class return a fresh FTransport object.
 */
class FTransport {
  constructor ({
    url,
    options,
    catchers = new Map(),
    resolvers = [],
    middlewares = [],
    deferredChain = []
  }) {
    this.baseUrl = url;
    this.baseOptions = options;
    this.catchers = catchers;
    this.resolvers = resolvers;
    this.middlewareChain = middlewares;
    this.deferredChain = deferredChain;
  }

  static factory (url = '', options = {}) {
    return new FTransport({
      url,
      options
    });
  }

  selfFactory ({
    url = this.baseUrl,
    options = this.baseOptions,
    catchers = this.catchers,
    resolvers = this.resolvers,
    middlewares = this.middlewareChain,
    deferredChain = this.deferredChain
  } = {}) {
    return new FTransport({
      url,
      options,
      catchers,
      resolvers,
      middlewares,
      deferredChain
    });
  }

  /**
   * Sets the default fetch options used for every subsequent fetch call.
   * @param opts New default options
   * @param mixin If true, mixes in instead of replacing the existing options
   */
  defaults (opts, mixin = false) {
    configuration.defaults = mixin ? mix(configuration.defaults, opts) : opts;

    return this;
  }

  /**
   * Sets the method (text, json ...) used to parse the data contained in the response body in case of an HTTP error.
   *
   * Persists for every subsequent requests.
   *
   * Default is "text".
   */
  errorType (method) {
    configuration.errorType = method;

    return this;
  }

  /**
   * Sets the non-global polyfills which will be used for every subsequent calls.
   *
   * Needed for libraries like [fetch-ponyfill](https://github.com/qubyte/fetch-ponyfill).
   *
   * @param polyfills An object containing the polyfills.
   */
  polyfills (polyfills) {
    configuration.polyfills = {
      ...configuration.polyfills,
      ...polyfills
    };

    return this;
  }

  /**
   * Returns a new FTransport object with the argument url appended and the same options.
   * @param url String url
   * @param replace Boolean If true, replaces the current url instead of appending
   */
  url (url, replace = false) {
    if (replace) {
      return this.selfFactory({url});
    }

    const [baseUrl, queryString] = this.baseUrl.split('?');
    const newUrl = queryString ? `${baseUrl}${url}?${queryString}` : `${this.baseUrl}${url}`;

    return this.selfFactory({url : newUrl});
  }

  /**
   * Returns a new FTransport object with the same url and new options.
   * @param options New options
   * @param mixin If true, mixes in instead of replacing the existing options
   */
  options (options, mixin = true) {
    return this.selfFactory({options : mixin ? mix(this.baseOptions, options) : options});
  }

  /**
   * Converts a javascript object to query parameters,
   * then appends this query string to the current url.
   *
   * ```
   * let w = ftransport("http://example.com") // url is http://example.com
   * w = w.query({ a: 1, b : 2 }) // url is now http://example.com?a=1&b=2
   * ```
   *
   * @param queryParams An object which will be converted.
   */
  query (queryParams, replace = false) {
    return this.selfFactory({url : appendQueryParams(this.baseUrl, queryParams, replace)});
  }

  /**
   * Set request headers.
   * @param headerValues An object containing header keys and values
   */
  headers (headerValues) {
    return this.selfFactory({options : mix(this.baseOptions, {headers : headerValues})});
  }

  /**
   * Shortcut to set the "Accept" header.
   * @param headerValue Header value
   */
  accept (headerValue) {
    return this.headers({Accept : headerValue});
  }

  /**
   * Shortcut to set the "Content-Type" header.
   * @param headerValue Header value
   */
  content (headerValue) {
    return this.headers({'Content-Type' : headerValue});
  }

  /**
   * Shortcut to set the "Authorization" header.
   * @param headerValue Header value
   */
  auth (headerValue) {
    return this.headers({Authorization : headerValue});
  }

  /**
   * Adds a default catcher which will be called on every subsequent request error when the error code matches.
   * @param errorId Error code or name
   * @param catcher: The catcher method
   */
  catcher (errorId, catcher) {
    const newMap = new Map(this.catchers);

    newMap.set(errorId, catcher);

    return this.selfFactory({catchers : newMap});
  }

  /**
   * Associates a custom signal with the request.
   * @param controller : An AbortController
   */
  signal (controller) {
    return this.selfFactory({
      options : {
        ...this.baseOptions,
        signal : controller.signal
      }
    });
  }

  /**
   * Program a resolver to perform response chain tasks automatically.
   * @param doResolve : Resolver callback
   */
  resolve (doResolve, clear = false) {
    return this.selfFactory({
      resolvers : clear ? [doResolve] : [...this.resolvers, doResolve]
    });
  }

  /**
   * Defer ftransport methods that will be chained and called just before
   * the request is performed
   */
  defer (callback, clear = false) {
    return this.selfFactory({
      deferredChain : clear ? [callback] : [...this.deferredChain, callback]
    });
  }

  /**
   * Add middlewares to intercept a request before being sent.
   */
  middlewares (middlewares, clear = false) {
    return this.selfFactory({
      middlewares : clear ? middlewares : [...this.middlewareChain, ...middlewares]
    });
  }

  [methodSymbol] (method, options, body = null) {
    // eslint-disable-next-line consistent-this
    let baseFTransport = this;

    if (body) {
      baseFTransport = typeof body === 'object' ? this.json(body) : this.body(body);
    }

    const deferredFTransport = baseFTransport
      .deferredChain
      .reduce((acc, current) => current(acc, acc.baseUrl, acc.baseOptions), baseFTransport);

    return resolver(deferredFTransport.options({
      ...options,
      method
    }));
  }

  /**
   * Performs a get request.
   */
  get (options = {}) {
    return this[methodSymbol](HTTP_METHOD.GET, options);
  }

  /**
   * Performs a delete request.
   */
  delete (options = {}) {
    return this[methodSymbol](HTTP_METHOD.DELETE, options);
  }

  /**
   * Performs a put request.
   */
  put (body, options = {}) {
    return this[methodSymbol](HTTP_METHOD.PUT, options, body);
  }

  /**
   * Performs a post request.
   */
  post (body, options = {}) {
    return this[methodSymbol](HTTP_METHOD.POST, options, body);
  }

  /**
   * Performs a patch request.
   */
  patch (body, options = {}) {
    return this[methodSymbol](HTTP_METHOD.PATCH, options, body);
  }

  /**
   * Performs a head request.
   */
  head (options = {}) {
    return this[methodSymbol](HTTP_METHOD.HEAD, options);
  }

  /**
   * Performs an options request
   */
  opts (options = {}) {
    return this[methodSymbol](HTTP_METHOD.OPTIONS, options);
  }

  /**
   * Sets the request body with any content.
   * @param contents The body contents
   */
  body (contents) {
    return this.selfFactory({
      options : {
        ...this.baseOptions,
        body : contents
      }
    });
  }

  /**
   * Sets the content type header, stringifies an object and sets the request body.
   * @param jsObject An object which will be serialized into a JSON
   */
  json (jsObject) {
    return this.content('application/json').body(JSON.stringify(jsObject));
  }

  /**
   * Converts the javascript object to a FormData and sets the request body.
   * @param formObject An object which will be converted to a FormData
   */
  formData (formObject) {
    return this.body(convertFormData(formObject));
  }

  /**
   * Converts the input to an url encoded string and sets the content-type header and body.
   * If the input argument is already a string, skips the conversion part.
   *
   * @param input An object to convert into an url encoded string or an already encoded string
   */
  formUrl (input) {
    return this
      .body(typeof input === 'string' ? input : convertFormUrl(input))
      .content('application/x-www-form-urlencoded');
  }
}

export default FTransport;
