import configuration from './configuration';

// eslint-disable-next-line complexity
const appendQueryParams = (url, queryParams, replace) => {
  let queryString = '';

  if (typeof queryParams === 'string') {
    queryString = queryParams;
  } else {
    const usp = configuration.polyfill('URLSearchParams', true, true);

    // eslint-disable-next-line no-unused-vars
    for (const key in queryParams) {
      if (queryParams[key] instanceof Array) {
        // eslint-disable-next-line no-unused-vars
        for (const val of queryParams[key]) {
          usp.append(key, val);
        }
      } else {
        usp.append(key, queryParams[key]);
      }
    }

    queryString = usp.toString();
  }

  const parts = url.split('?');

  if (replace || parts.length < 2) {
    return `${parts[0]}?${queryString}`;
  }

  return `${url}&${queryString}`;
};

const convertFormData = formObject => {
  const formData = configuration.polyfill('FormData', true, true);

  Object.entries(formObject).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(currentValue => {
        formData.append(`${key}[]`, currentValue);
      });
    } else {
      formData.append(key, value);
    }
  });

  return formData;
};

const encodeQueryValue = (key, value) => {
  const encodedKey = global.encodeURIComponent(key);
  const formattedValue = typeof value === 'object' ? JSON.stringify(value) : String(value);
  const encodedValue = global.encodeURIComponent(formattedValue);

  return `${encodedKey}=${encodedValue}`;
};

const convertFormUrl = formObject => Object
  .entries(formObject)
  .map(([key, value]) => {
    if (Array.isArray(value)) {
      return value.map(currentValue => encodeQueryValue(key, currentValue)).join('&');
    }

    return encodeQueryValue(key, value);
  })
  .join('&');

export {
  appendQueryParams,
  convertFormData,
  convertFormUrl
};
