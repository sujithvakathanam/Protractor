/* eslint no-use-before-define : off */

import configuration from './configuration';

const lazyObserver = (perf, _observer) => {
  if (!perfs.observer && perf && _observer) {
    perfs.observer = new _observer(entries => {
      perfs.callbacks.forEach((callback, name) => {
        onMatch(entries, name, callback, perf);
      });
    });

    if (perf.clearResourceTimings) {
      perf.clearResourceTimings();
    }
  }

  return perfs.observer;
};

const perfs = {
  callbacks : new Map(),
  observer  : null,
  // eslint-disable-next-line complexity
  observe   : (name, callback) => {
    if (!name || !callback) {
      return;
    }

    const perf = configuration.polyfill('performance', false);
    const observer = configuration.polyfill('PerformanceObserver', false);

    if (!lazyObserver(perf, observer)) {
      return;
    }

    if (!onMatch(perf, name, callback, perf)) {
      if (perfs.callbacks.size < 1) {
        perfs.observer.observe({
          entryTypes : ['resource', 'measure']
        });
      }

      perfs.callbacks.set(name, callback);
    }
  }
};

// eslint-disable-next-line max-params
const onMatch = (entries, name, callback, perf) => {
  const matches = entries.getEntriesByName(name);

  if (matches && matches.length > 0) {
    callback(matches.reverse()[0]);
    perf.clearMeasures(name);
    perfs.callbacks.delete(name);

    if (perfs.callbacks.size < 1) {
      perfs.observer.disconnect();

      if (perf.clearResourceTimings) {
        perf.clearResourceTimings();
      }
    }

    return true;
  }

  return false;
};

export default perfs;
