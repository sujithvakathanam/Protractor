import FTransport from './FTransport';
import * as middlewares from './middlewares';
import {HTTP_ERROR_WILDCARD, HTTP_METHOD, HTTP_STATUS} from './constant';

const ftransport = FTransport.factory;

export {
  ftransport,
  middlewares,

  HTTP_ERROR_WILDCARD,
  HTTP_METHOD,
  HTTP_STATUS
};

export default ftransport;
