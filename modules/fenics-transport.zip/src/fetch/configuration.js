const config = {
  // Default options
  defaults : {},

  // Error type
  errorType : null,

  // Polyfills
  polyfills : {
    fetch               : null,
    FormData            : null,
    URLSearchParams     : null,
    performance         : null,
    PerformanceObserver : null,
    AbortController     : null
  },

  // eslint-disable-next-line complexity, max-params
  polyfill (key, doThrow = true, instance = false, ...args) {
    const Polyfill = this.polyfills[key]
      || (typeof self === 'undefined' ? null : self[key])
      || (typeof global === 'undefined' ? null : global[key]);

    if (doThrow && !Polyfill) {
      throw new Error(`${key} is not defined`);
    }

    return instance && Polyfill ? new Polyfill(...args) : Polyfill;
  }
};

export default config;
