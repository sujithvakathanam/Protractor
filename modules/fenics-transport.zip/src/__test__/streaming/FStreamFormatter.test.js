/* eslint-disable no-magic-numbers */
import {expect} from 'chai';
import {CompressionFormatter} from '../../streaming/formatter';

let sampleMessage = null;
let sampleEncoded = null;

describe('[FStreamFormatter]', () => {
  describe('[CompressionFormatter]', () => {
    beforeEach(() => {
      sampleMessage = {
        topic   : 'marketDataTopic',
        payload : {
          header : {
            messageType : 'LogoutResponse',
            success     : false,
            requestId   : 'jx1q3aj7-jx1q3b5d',
            timestamp   : '2019-06-18T12:27:05.759+01:00'
          }
        }
      };
      /* eslint-disable max-len */
      sampleEncoded = JSON.stringify({
        __compression : 'zlib/base64',
        payload       : 'eJwdzEEKwjAQheG7zNZGJpEYOzcQXEkvEJuxWqxJOwkopXc3uHvwf7wVHuwDL0ArTCziB+6+iYHgEodY8pUlxbcwNCCl76sAuvuXcAMLz4Uln0PF40fPBz869R83G6rPz3qY/ZRqN6hbhUelT502ZByh3Tvb7lATImzbD0O3Kn0=',
        topic         : 'marketDataTopic'
      });
      /* eslint-enable max-len */
    });

    describe('[fromMessage]', () => {
      it('should decode and decompress payload', () => {
        const formatter = new CompressionFormatter();
        const payload = sampleEncoded;
        const actual = formatter.fromMessage(payload);

        expect(actual).to.be.an('object');
        expect(actual).to.not.have.a.property('__decompressionError');
        expect(actual).to.have.a.property('topic');
        expect(actual).to.have.a.property('payload');
        expect(actual.topic).to.equal('marketDataTopic');
        expect(actual.payload).to.deep.equal(sampleMessage.payload);
      });

      it('should return __decompressionError', () => {
        const formatter = new CompressionFormatter();
        const payload = 'invalid payload';
        const result = formatter.fromMessage(payload);

        expect(result).to.be.an('object');
        expect(result).to.have.a.property('__decompressionError');
      });

      it('should parse uncompressed payload', () => {
        const formatter = new CompressionFormatter();
        // eslint-disable-next-line max-len
        const payload = '{"topic": "/fenics/pong", "payload": {"clientTimestamp": 1560778290324, "id": 1, "serverTimestamp": 1560778290197}}';

        const result = formatter.fromMessage(payload);

        expect(result).to.be.an('object');
      });
    });

    describe('[toMessage]', () => {
      it('should compress and encode payload', () => {
        const formatter = new CompressionFormatter();
        const payload = sampleMessage;
        const actual = formatter.toMessage(payload);

        expect(actual).to.equal(sampleEncoded);
      });

      it('should not compress and encode ping message', () => {
        const formatter = new CompressionFormatter();
        const payload = {
          topic : '/fenics/ping'
        };
        const expected = JSON.stringify({
          __compression : 'none',
          ...payload
        });
        const actual = formatter.toMessage(payload);

        expect(actual).to.equal(expected);
      });
    });

    describe('[roundTrip]', () => {
      it('should compress/encode then decode/decompress payload', () => {
        const formatter = new CompressionFormatter();
        const payload = sampleMessage;
        const compressed = formatter.toMessage(payload);
        const uncompressed = formatter.fromMessage(compressed);

        expect(uncompressed).to.deep.equal(payload);
      });
    });
  });
});
