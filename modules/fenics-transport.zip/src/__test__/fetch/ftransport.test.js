/* eslint max-lines : off, no-magic-numbers : off, no-underscore-dangle : off */

import fetch from 'cross-fetch';
import {expect} from 'chai';
import FormData from 'form-data';
import URLSearchParams from 'url-search-params';
import AbortController from 'abort-controller';
import FTransport from '../../fetch/FTransport';

const ftransport = FTransport.factory;
const mockServer = require('./mock');

const WHITE_PIXEL_64 = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
const image = new Buffer(WHITE_PIXEL_64, 'base64');

const PORT = 9876;
const URL = `http://localhost:${PORT}`;

// eslint-disable-next-line max-params
const allRoutes = (obj, type, action, opts) => Promise.all([
  obj.get(opts)[type](response => response)
    .then(action),
  obj.put(opts)[type](action),
  obj.patch(opts)[type](action),
  obj.post(opts)[type](action),
  obj.delete(opts)[type](action)
]);

// eslint-disable-next-line max-statements
describe('FTransport', () => {
  before(() => {
    mockServer.launch(PORT);
  });

  after(() => {
    mockServer.stop();
  });

  it('should set and use non global polyfills', async () => {
    global.FormData = null;
    global.URLSearchParams = null;

    expect(() => ftransport(URL).query({
      foo : 1,
      bar : 2
    })).to.throw('URLSearchParams is not defined');

    expect(() => ftransport(URL).formData({
      foo : 1,
      bar : 2
    })).to.throw('FormData is not defined');

    expect(() => ftransport(URL).get('/path')).to.throw('fetch is not defined');

    ftransport().polyfills({
      fetch,
      FormData,
      URLSearchParams
    });

    // eslint-disable-next-line
    await ftransport(`${URL}/text`).get().perfs(() => fail('should never be called')).res();

    ftransport(null, null).polyfills({
      fetch,
      FormData,
      URLSearchParams,
      AbortController
    });
  });

  it('should perform crud requests and parse a text response', async () => {
    const init = ftransport(`${URL}/text`);
    const test = response => expect(response).to.equal('A text string');

    await allRoutes(init, 'text', test);
    await allRoutes(init, 'text', test, {});
  });

  it('should perform crud requests and parse a json response', async () => {
    const test = response => expect(response).to.deep.equal({
      one    : 'json',
      object : 'which',
      is     : 'stringified'
    });

    const init = ftransport(`${URL}/json`).polyfills({
      fetch,
      FormData,
      URLSearchParams
    });

    await allRoutes(init, 'json', test);
    await allRoutes(init, 'json', test, {});
  });

  it('should perform crud requests and parse a blob response', async () => {
    const test = response => expect(response.size).to.be.deep.equal(image.length);
    const init = ftransport(`${URL}/blob`);

    await allRoutes(init, 'blob', test);
    await allRoutes(init, 'blob', test, {});
  });

  it('should perform crud requests and parse an arrayBuffer response', async () => {
    const test = arrayBuffer => {
      const buffer = new Buffer(arrayBuffer.byteLength);
      const view = new Uint8Array(arrayBuffer);

      // eslint-disable-next-line no-plusplus
      for (let index = 0; index < buffer.length; ++index) {
        buffer[index] = view[index];
      }

      // C expect(buffer.equals(Buffer.from([0x00, 0x01, 0x02, 0x03]))).to.equal(true);

      expect(buffer.equals(Buffer.from([0x00, 0x01, 0x02]))).to.equal(true);
    };

    const init = ftransport(`${URL}/arrayBuffer`);

    await allRoutes(init, 'arrayBuffer', test);
    await allRoutes(init, 'arrayBuffer', test, {});
  });

  it('should perform a plain text round trip', async () => {
    const text = 'hello, server !';
    const roundTrip = await ftransport(`${URL}/text/roundTrip`)
      .content('text/plain')
      .body(text)
      .post()
      .text();

    expect(roundTrip).to.equal(text);
  });

  it('should perform a json round trip', async () => {
    const jsonObject = {
      foo : 1,
      bar : 2,
      baz : 3
    };

    const roundTrip = await ftransport(`${URL}/json/roundTrip`)
      .json(jsonObject)
      .post()
      .json();

    expect(roundTrip).deep.equal(jsonObject);
  });

  it('should perform an url encoded form data round trip', async () => {
    const reference = 'foo=1&bar=2&baz=%203&yet=%7B%22another%22%3A1%7D';
    const jsonObject = {
      foo : 1,
      bar : 2,
      baz : ' 3',
      yet : {
        another : 1
      }
    };

    let roundTrip = await ftransport(`${URL}/urlencoded/roundTrip`)
      .formUrl(reference)
      .post()
      .text();

    expect(roundTrip).to.equal(reference);

    roundTrip = await ftransport(`${URL}/urlencoded/roundTrip`)
      .formUrl(jsonObject)
      .post()
      .text();

    expect(roundTrip).equal(reference);
  });

  it('should send a FormData object', async () => {
    const form = {
      hello : 'world',
      duck  : 'Muscovy'
    };
    const decoded = await ftransport(`${URL}/formData/decode`)
      .formData(form)
      .post()
      .json();

    expect(decoded).deep.equal({
      hello : 'world',
      duck  : 'Muscovy'
    });

    // Form-data package has an implementation which differs from the browser standard.
    const formDataPayload = {
      arr : [1, 2, -1]
    };

    // eslint-disable-next-line
    const result = ftransport(`${URL}/formData/decode`).formData(formDataPayload).post().json();

    /**
     * Impl of form-data package differs from the real browser impl
     *
     * expect(result).equal({
     *   'arr[]' : [1, 2, -1]
     * });
     */
  });

  it('should perform OPTIONS and HEAD requests', async () => {
    const optsRes = await ftransport(`${URL}/options`)
      .opts()
      .res();
    const optsRes2 = await ftransport(`${URL}/options`)
      .opts({})
      .res();

    expect(optsRes.headers.get('Allow')).to.equal('OPTIONS');
    expect(optsRes2.headers.get('Allow')).to.equal('OPTIONS');

    const headRes = await ftransport(`${URL}/json`)
      .head()
      .res();
    const headRes2 = await ftransport(`${URL}/json`)
      .head({})
      .res();

    expect(headRes.headers.get('content-type')).to.equal('application/json; charset=utf-8');
    expect(headRes2.headers.get('content-type')).to.equal('application/json; charset=utf-8');
  });

  it('should catch common error codes', async () => {
    const fti = ftransport(`${URL}/`);

    let check = 0;

    await fti.url('400')
      .get()
      .badRequest(response => {
        expect(response.message).to.equal('error code : 400');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    await fti.url('401')
      .get()
      .unauthorized(response => {
        expect(response.message).to.equal('error code : 401');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    await fti.url('403')
      .get()
      .forbidden(response => {
        expect(response.message).to.equal('error code : 403');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    await fti.url('404')
      .get()
      .notFound(response => {
        expect(response.message).to.equal('error code : 404');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    await fti.url('408')
      .get()
      .timeout(response => {
        expect(response.message).to.equal('error code : 408');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    await fti.url('500')
      .get()
      .internalError(response => {
        expect(response.message).to.equal('error code : 500');
        check += 1;
      })
      .text(response => expect(response).to.equalNull());

    expect(check).to.equal(6);
  });

  it('should catch other error codes', async () => {
    let check = 0;

    await ftransport(`${URL}/444`)
      .get()
      .notFound(() => {
        check += 1;
      })
      .error(444, () => {
        check += 1;
      })
      .unauthorized(() => {
        check += 1;
      })
      .res(param => expect(param).to.equal(undefined));

    expect(check).to.equal(1);
  });

  it('should set and catch errors with global catchers', async () => {
    let check = 0;

    const fti = ftransport(`${URL}`)
      .catcher(404, () => {
        check += 1;
      })
      .catcher(500, () => {
        check += 1;
      })
      .catcher(400, () => {
        check += 1;
      })
      .catcher(401, () => {
        check -= 1;
      })
      .catcher('FetchError', () => {
        check += 1;
      });

    await fti.url('/text')
      .get()
      .res(() => {
        check += 1;
      });

    await fti.url('/text')
      .get()
      .json(() => {
        check -= 1;
      });

    await fti.url('/400')
      .get()
      .res(() => {
        check -= 1;
      });

    await fti.url('/401')
      .get()
      .unauthorized(() => {
        check += 1;
      })
      .res(() => {
        check -= 1;
      });

    await fti.url('/404')
      .get()
      .res(() => {
        check -= 1;
      });

    await fti.url('/408')
      .get()
      .timeout(() => {
        check += 1;
      })
      .res(() => {
        check -= 1;
      });

    await fti.url('/418')
      .get()
      .res(() => {
        check -= 1;
      })
      .catch(() => 'muted');

    await fti.url('/500')
      .get()
      .res(() => {
        check -= 1;
      });

    expect(check).to.equal(7);
  });

  it('should capture the original request with resolvers/catchers', async () => {
    let check = 0;

    const redirectedNotFound = await ftransport(`${URL}/404`)
      .get()
      .notFound((response, fti) => {
        check += 1;

        return fti.url(`${URL}/text`, true)
          .get()
          .text();
      })
      .text();

    expect(redirectedNotFound).to.equal('A text string');

    const withNotFoundCatcher = ftransport(`${URL}/401`)
      .catcher(401, (response, fti) => {
        check += 1;

        return fti.url(`${URL}/text`, true)
          .get()
          .text();
      });

    const withNotFoundRedirect = ftransport(`${URL}/404`)
      .resolve(resolver => resolver.notFound((response, fti) => {
        check += 1;

        return fti.url(`${URL}/text`, true)
          .get()
          .text();
      }));

    expect(await withNotFoundCatcher.get().text()).to.equal('A text string');
    expect(await withNotFoundRedirect.get().text()).to.equal('A text string');
    expect(check).to.equal(3);
  });

  it('should set default fetch options', async () => {
    let rejected = await new Promise(res => ftransport(`${URL}/customHeaders`)
      .get()
      .badRequest(() => res(true))
      .res(result => res(!result)));

    // eslint-disable-next-line
    expect(rejected).to.be.ok;

    ftransport().defaults({
      headers : {
        'X-Custom-Header' : 'Anything'
      }
    });

    rejected = await new Promise(res => ftransport(`${URL}/customHeaders`)
      .get()
      .badRequest(() => {
        res(true);
      })
      .res(result => res(!result)));

    // eslint-disable-next-line
    expect(rejected).to.be.ok;

    ftransport().defaults({
      headers : {
        'X-Custom-Header-2' : 'Anything'
      }
    }, true);

    rejected = await new Promise(res => ftransport(`${URL}/customHeaders`)
      .get()
      .badRequest(() => {
        res(true);
      })
      .res(result => res(!result)));

    ftransport().defaults('not an object', true);

    // eslint-disable-next-line
    expect(rejected).to.be.ok;

    const accepted = await new Promise(res => ftransport(`${URL}/customHeaders`)
      .options({
        headers : {
          'X-Custom-Header-3' : 'Anything'
        }
      }, false)
      .options({
        headers : {
          'X-Custom-Header-4' : 'Anything'
        }
      })
      .get()
      .badRequest(() => {
        res(false);
      })
      .res(result => res(Boolean(result))));

    // eslint-disable-next-line
    expect(accepted).to.be.ok;
  });

  // eslint-disable-next-line
  it('should allow url, query parameters & options modifications and return a fresh new ftransport instance containing the change', async () => {
    const obj1 = ftransport('...');
    const obj2 = obj1.url(URL, true);

    expect(obj1.baseUrl).to.equal('...');
    expect(obj2.baseUrl).to.equal(URL);

    const obj3 = obj1.options({
      headers : {
        'X-test' : 'test'
      }
    });

    expect(obj3.baseOptions).to.deep.equal({
      headers : {
        'X-test' : 'test'
      }
    });

    expect(obj1.baseOptions).to.deep.equal({});

    const obj4 = obj2.query({
      foo : '1!',
      bar : '2'
    });

    expect(obj4.baseUrl).to.equal(`${URL}?foo=1%21&bar=2`);
    expect(obj2.baseUrl).to.equal(URL);

    const obj5 = obj4.query({
      baz : 6,
      bar : [7, 8]
    });

    expect(obj4.baseUrl).to.equal(`${URL}?foo=1%21&bar=2`);
    expect(obj5.baseUrl).to.equal(`${URL}?foo=1%21&bar=2&baz=6&bar=7&bar=8`);

    const obj6 = obj5.query('param[]=value&anotherValue', true);

    expect(obj6.baseUrl).to.equal(`${URL}?param[]=value&anotherValue`);
    expect(obj5.baseUrl).to.equal(`${URL}?foo=1%21&bar=2&baz=6&bar=7&bar=8`);

    const obj7 = obj5.query('param[]=value&anotherValue').url('/test');

    expect(obj7.baseUrl).to.equal(`${URL}/test?foo=1%21&bar=2&baz=6&bar=7&bar=8&param[]=value&anotherValue`);
    expect(obj5.baseUrl).to.equal(`${URL}?foo=1%21&bar=2&baz=6&bar=7&bar=8`);
  });

  it('should set the Accept header', async () => {
    expect(await ftransport(`${URL}/accept`)
      .get()
      .text()).to.equal('text');
    expect(await ftransport(`${URL}/accept`)
      .accept('application/json')
      .get()
      .json()).to.deep.equal({
      json : 'ok'
    });
  });

  it('should set the Authorization header', async () => {
    try {
      await ftransport(`${URL}/basicauth`)
        .get()
        // eslint-disable-next-line
        .res(() => fail('Authenticated route should not respond without credentials.'))
    } catch (err) {
      expect(err.status).to.equal(401);
    }

    const res = await ftransport(`${URL}/basicauth`)
      .auth('Basic ZnRyYW5zcG9ydDpyb2Nrcw==')
      .get()
      .text();

    expect(res).to.equal('ok');
  });

  it('should change the parsing used in the default error handler', async () => {
    ftransport().errorType('json');

    await ftransport(`${URL}/json500`)
      .get()
      .internalError(error => {
        expect(error.json).to.deep.equal({
          error   : 500,
          message : 'ok'
        });
      })
      // eslint-disable-next-line
      .res(() => fail('I should never be called because an error was thrown'))
      .then(response => expect(response).to.equal(undefined));

    // Change back
    ftransport().errorType('text');
  });

  it('should abort a request', done => {
    let count = 0;

    const handleError = error => {
      expect(error.name).to.equal('AbortError');

      count += 1;
    };

    const controller = new AbortController();

    ftransport(`${URL}/longResult`)
      .signal(controller)
      .get()
      .text(() => 1)
      .catch(handleError);

    controller.abort();

    const [c, w] = ftransport(`${URL}/longResult`)
      .get()
      .controller();

    w.res().catch(handleError);
    c.abort();

    ftransport(`${URL}/longResult`)
      .get()
      .setTimeout(500)
      .onAbort(handleError)
      .res();

    const [c2, w2] = ftransport(`${URL}/longResult`)
      .get()
      .controller();

    w2.setTimeout(100, c2)
      .onAbort(handleError)
      .res();

    setTimeout(() => {
      expect(count).to.equal(4);

      done();
    }, 1000);
  });

  it('should program resolvers', async () => {
    let check = 0;

    const fti = ftransport()
      .url(URL)
      .resolve(resolver => resolver.unauthorized(() => {
        check -= 1;
      }))
      .resolve(resolver => resolver.unauthorized(() => {
        check += 1;
      }), true)
      .resolve(resolver => resolver
        .json(response => {
          check += 1;

          return response;
        }));

    const result = await fti.url('/json').get();

    expect(result).to.deep.equal({
      one    : 'json',
      object : 'which',
      is     : 'stringified'
    });

    expect(check).to.equal(1);
    await fti.url('/401').get();
    expect(check).to.equal(2);
  });

  it('should use middlewares', async () => {
    const shortCircuit = () => () => (url, opts) => Promise.resolve({
      ok   : true,
      text : () => Promise.resolve(`${opts.method}@${url}`)
    });

    const setGetMethod = () => next => (url, opts) => next(url, {
      ...opts,
      method : 'GET'
    });

    const setPostMethod = () => next => (url, opts) => next(url, {
      ...opts,
      method : 'POST'
    });

    const fti = ftransport().middlewares([
      shortCircuit()
    ]);

    expect(await fti.url(URL)
      .head()
      .text()).to.equal(`HEAD@${URL}`);

    const w2 = fti.middlewares([
      setGetMethod(),
      shortCircuit()
    ], true);

    expect(await w2.url(URL)
      .head()
      .text()).to.equal(`GET@${URL}`);

    const w3 = fti.middlewares([
      setGetMethod(),
      setPostMethod(),
      shortCircuit()
    ], true);

    expect(await w3.url(URL)
      .head()
      .text()).to.equal(`POST@${URL}`);
  });

  it('should chain actions that will be performed just before the request is sent', async () => {
    const fti = ftransport(`${URL}/basicauth`)
      .defer((instance, url) => {
        expect(url).to.equal(`${URL}/basicauth`);

        return instance.auth('nada');
      })
      .defer((instance, url, {token}) => instance.auth(token), true);

    const result = await fti
      .options({token : 'Basic ZnRyYW5zcG9ydDpyb2Nrcw=='})
      .get()
      .text();

    expect(result).to.equal('ok');
  });
});
