/* eslint id-length : off, no-magic-numbers : off */

import {expect} from 'chai';
import mix from '../../fetch/mix';

describe('Mix', () => {
  it('should mix two objects', () => {
    const obj1 = {
      a : 1,
      b : 2,
      c : [3, 4]
    };

    const obj2proto = {
      z : 1
    };

    const obj2 = Object.create(obj2proto);

    Object.assign(obj2, {
      a : 0,
      d : 5,
      e : [6],
      c : [5, 6]
    });

    expect(mix(obj1, obj2, false)).to.be.deep.equal({
      a : 0,
      b : 2,
      c : [5, 6],
      d : 5,
      e : [6],
      z : 1
    });

    expect(mix(obj1, obj2, true)).to.be.deep.equal({
      a : 0,
      b : 2,
      c : [3, 4, 5, 6],
      d : 5,
      e : [6],
      z : 1
    });
  });
});
