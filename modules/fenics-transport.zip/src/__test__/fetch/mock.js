/* eslint no-magic-numbers : off */

const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const basicAuth = require('express-basic-auth');
const upload = multer();

const WHITE_PIXEL_64 = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
const image = new Buffer(WHITE_PIXEL_64, 'base64');

const preload = {
  image
};

const textReply = (req, res) => {
  res.status(200).send('A text string');
};

const jsonReply = (req, res) => {
  res.status(200).json({
    one    : 'json',
    object : 'which',
    is     : 'stringified'
  });
};

const imgReply = (req, res) => {
  res.setHeader('content-type', 'image/jpeg');

  res.status(200).send(preload.image);
};

const binaryReply = (req, res) => {
  res.setHeader('content-type', 'application/octet-stream');

  const binaryData = Buffer.from([0x00, 0x01, 0x02]);

  res.status(200).send(binaryData);
};

const setupReplies = (server, type, fun) => {
  server.get(`/${type}`, fun);
  server.post(`/${type}`, fun);
  server.put(`/${type}`, fun);
  server.patch(`/${type}`, fun);
  server.delete(`/${type}`, fun);
};

// eslint-disable-next-line complexity
const setupErrors = server => {
  const errorList = [444, 449, 450, 451, 456, 495, 496, 497, 498, 499];

  for (let index = 0; index < 512; index += 1) {
    errorList.push(index);

    if (index === 418) {
      index += 2;
    } else if (index === 426 || index === 429) {
      index += 1;
    }
  }

  // eslint-disable-next-line no-unused-vars
  for (const error of errorList) {
    server.get(`/${error}`, (req, res) => {
      res.status(error).send(`error code : ${error}`);
    });
  }
};

const mockServer = {
  // eslint-disable-next-line max-statements
  launch : port => {
    const server = express();

    server.use(bodyParser.json({type : 'application/json'}));
    server.use(bodyParser.raw({type : ['text/plain', 'application/x-www-form-urlencoded']}));
    server.use(upload.array());

    setupReplies(server, 'text', textReply);
    setupReplies(server, 'json', jsonReply);
    setupReplies(server, 'blob', imgReply);
    setupReplies(server, 'arrayBuffer', binaryReply);

    server.head('/json', (req, res) => {
      res.setHeader('content-type', 'application/json');
      res.end();
    });

    server.options('/options', (req, res) => {
      res.header('Allow', 'OPTIONS');
      res.end();
    });

    server.get('/customHeaders', (req, res) => {
      const hasCustomHeaders = req.header('X-Custom-Header', false)
        && req.header('X-Custom-Header-2', false)
        && req.header('X-Custom-Header-3', false)
        && req.header('X-Custom-Header-4', false);

      res.status(hasCustomHeaders ? 200 : 400).send();
    });

    setupErrors(server);

    server.post('/text/roundTrip', (req, res) => {
      if (req.header('content-type') === 'text/plain') {
        res.status(200).send(req.body);
      } else {
        res.status(400).send();
      }
    });

    server.post('/json/roundTrip', (req, res) => {
      if (req.header('content-type') === 'application/json') {
        res.status(200).json(req.body);
      } else {
        res.status(400).send();
      }
    });

    server.post('/urlencoded/roundTrip', (req, res) => {
      if (req.header('content-type') === 'application/x-www-form-urlencoded') {
        res.status(200).send(req.body);
      } else {
        res.status(400).send();
      }
    });

    server.post('/formData/decode', (req, res) => {
      if (req.header('content-type').startsWith('multipart/form-data')) {
        res.status(200).json(req.body);
      } else {
        res.status(400).send();
      }
    });

    server.get('/accept', (req, res) => {
      const accept = req.header('Accept');

      if (accept.indexOf('application/json') === -1) {
        res.status(200).send('text');
      } else {
        res.status(200).json({
          json : 'ok'
        });
      }
    });

    server.get('/basicauth', basicAuth({
      users : {ftransport : 'rocks'}
    }), (req, res) => {
      if (
        req.auth
        && req.auth.user === 'ftransport'
        && req.auth.password === 'rocks'
      ) {
        res.status(200).send('ok');
      } else {
        res.status(401).send();
      }
    });

    server.get('/json500', (req, res) => {
      res.status(500).json({
        error   : 500,
        message : 'ok'
      });
    });

    server.get('/longResult', (req, res) => {
      setTimeout(() => res.status(200).send('ok'), 1000);
    });

    mockServer.server = server.listen(port);
  },
  stop : () => {
    mockServer.server.close();
  }
};

module.exports = mockServer;
