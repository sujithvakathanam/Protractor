import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import TestCommons from '../../lib/TestCommons';
import {shellExec} from '../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import ApiClient from '../../utilities/api/ApiClient';
import {expect} from 'chai';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {frameworkConfig} from '../../config/framework.config';
import {join} from 'path';
import {usersConfig} from '../../config/users.config';

describe('BC2709 TC004: No longer invite Broking Users to participate in a VC instead show size traded so far to relevant brokers', function BC2709EndToEndTest () {
  const browser = global.browser;
  let context = null;
  let logger = null;
  let configuration = null;

  let common = null;
  let mainPageFrame = null;

  before(() => {
    const bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    configuration = context.getConfiguration();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', configuration.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  // eslint-disable-next-line max-len
  describe('BC2709 TC004: As a broker who is not relevant to the trade I should not receive VC notifications and should not see VC lots traded in the market view and should see VC price traded in the market view  when a trader I represent initiates a direct VC with another trader where the prices being traded originated from the order book', () => {
    let relevantBrokerUser = null;
    let irrelevantBrokerUser = null;
    let nlpTradeUser = null;
    let lpTradeUser = null;

    let nlpTradeClient = null;
    let lpTradeClient = null;
    let relevantBrokerClient = null;

    let strategyId = 0;
    let strategyFound = false;
    let strategyRow = null;

    const sellPrice = 105;
    const buyPrice = 100;
    const amount = 2500;
    const strike001 = 2100;
    const strike002 = 2200;
    const strike003 = 2300;
    const refPrice = 3800;
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, refPrice, 11, POLARITY.positive, null, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', strike001, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', strike002, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', strike003, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', strike002, 1);


    it('Relevant broker should login and create a strategy to trade', async () => {
      relevantBrokerUser = common.getBroker('AUTBR04');
      irrelevantBrokerUser = common.getBroker('AUTBR07');
      nlpTradeUser = common.getTrader('AUTTR10');
      lpTradeUser = common.getTrader('AUTTR01');

      await start(relevantBrokerUser);
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('User should log in', async () => {
      expect(strategyFound).to.equal(true, 'Strategy was not found');

      nlpTradeClient = new ApiClient(nlpTradeUser);
      await nlpTradeClient.login();

      lpTradeClient = new ApiClient(lpTradeUser);
      await lpTradeClient.login();

      relevantBrokerClient = new ApiClient(relevantBrokerUser);
      await relevantBrokerClient.login();
      await start(irrelevantBrokerUser);
    });

    it('I should create the strategy', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      const myStrategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = myStrategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('Relevant broker should initiate an RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await relevantBrokerClient.initiateRFS(strategyId);
      await lpTradeClient.respondToRFS(strategyId);
      await nlpTradeClient.respondToRFS(strategyId);
    });

    it('I should see grey RFS status for the strategy on the market view', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const strategyInMarketView = await common.waitUntilStrategyFound(strategy, configuration.shortTimeout);

      expect(strategyInMarketView)
        .to
        .equal(true, 'Unable to find the strategy in the Market View');

      const table = await mainPageFrame.getMarketViewTab().clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await table.getTableRow(strategy);
      await strategyRow.waitUntilStatus('RFS', configuration.shortTimeout);
      const status = await strategyRow.getStatusText();
      const statusIsInactive = await strategyRow.statusHasInactiveFlag();

      expect(status)
        .to
        .equal('RFS', 'Strategy Status');

      expect(statusIsInactive)
        .to
        .equal(true, 'RFS status should be inactive');
    });

    it('LP Trader should quote on the RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const quoted = await lpTradeClient.rfsQuote(strategyId, buyPrice, sellPrice, amount);
      expect(quoted.response[0])
        .to
        .equal('successful', 'LP trader did was unable to quote inside the timeout period');
    });

    it('Relevant broker should activate the NLP trade user in the Trading Phase', async () => {
      const timeout = configuration.darkPhaseTimeout + configuration.litPhaseTimeout;

      await browser.waitUntil(async () => {
        const phase = await relevantBrokerClient.getRfsPhase(strategyId);

        return phase === 'TRADING';
      }, timeout);

      await relevantBrokerClient.rfsSelectTrader(strategyId, nlpTradeUser.userShortName);
    });

    it('NLP trader should accept the RFS quote', async () => {
      await browser.waitUntil(() => nlpTradeClient.userActivated(strategyId), configuration.shortTimeout);
      const rfsAcceptMsg = await nlpTradeClient.rfsAccept(strategyId, sellPrice, null, amount);

      expect(rfsAcceptMsg.response[0])
        .to
        .equal('successful', 'Expected RFS to be accepted');
    });

    it('I should see grey VC status against the strategy in the Market View', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await strategyRow.waitUntilStatus('VC', configuration.shortTimeout);
      const status = await strategyRow.getStatusText();
      const statusIsInactive = await strategyRow.statusHasInactiveFlag();

      expect(status)
        .to
        .equal('VC', 'Market View Strategy Status');

      expect(statusIsInactive)
        .to
        .equal(true, 'Market View Strategy Status should be inactive');
    });

    // Changed test to match new requirements detailed in BC-3542
    it('I should not see price of the VC against the strategy in the Market View during the priority phase of the VC', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const price = await strategyRow.getPrices();

      expect(price)
        .to
        .equal('', 'Market view strategy price');
    });

    it('I should not be able to open the VC window', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await strategyRow.clickStatus();

      const vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      expect(foundWindow)
        .to
        .equal(false, 'VC window found, VC window should not exist');
    });

    it('I should not see VC notification message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const vcNotification = await notifications.getVC(strategy, '105.000');
      const found = await vcNotification.waitForExist(configuration.veryShortTimeout);

      expect(found)
        .to
        .equal(false, 'VC notification message should not exist but it does');
    });

    it('I should not see the VC alert toast message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const toastMsg = new ToastNotification(context);
      const vcMesages = await toastMsg.getVcToastMsg('105.000', strategy);

      expect(vcMesages.length)
        .to
        .equal(0, 'Did not expect to find Responder toast message');
    });

    it('I should not see size sold in the market view during the VC', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();
      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('', 'Market view strategy ask size');
    });

    it('Users should logout', () => {
      relevantBrokerClient.logout();
      lpTradeClient.logout();
      nlpTradeClient.logout();
    });
  });
});

