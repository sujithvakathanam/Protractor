/* eslint-disable max-lines,max-statements */
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, UNDERLYING, STRATEGY, POLARITY, STYLE, OPTION_TYPE, COLOR_PURPOSE} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import ApiClient from '../../utilities/api/ApiClient';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';

describe('BC2704 OBO RFS Tests', function BC2704EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let common = null;
  let mainPageFrame = null;
  let toastNotification = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    toastNotification = new ToastNotification(context);
  }

  describe('BC2704 TC002: As a broker I should not receive RFS notification when', () => {
    // NOTE BC-3129 - Only an NLP trader can launch an RFS, TODO: have the broker create the strategy as well as the trader.
    let brokerOne = null;
    let nlpTraderOne = null;
    let lpTraderOne = null;
    let nlpTraderOneClient = null;
    let lpTraderOneClient = null;

    /* eslint-disable no-magic-numbers */
    const strategyThree = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 250, 5, POLARITY.positive, null, null);
    strategyThree.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, 1);
    strategyThree.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 200, 2.25);
    /* eslint-enable no-magic-numbers */

    let strategyThreeId = null;
    let strategyThreeTitle = null;

    describe('When A NLP trader initiates an direct RFS', () => {
      it('NLP trader should login', async () => {
        brokerOne = common.getBroker('AUTBR03');
        nlpTraderOne = common.getTrader('AUTTR10');
        lpTraderOne = common.getTrader('AUTTR01');
        nlpTraderOneClient = new ApiClient(nlpTraderOne);
        lpTraderOneClient = new ApiClient(lpTraderOne);
        await start(nlpTraderOne);
        logger.info(`Logged in with user ${nlpTraderOne.email}.`);
      });

      it('NLP trader should have a strategy to trade', async () => {
        strategyThreeId = await common.getStrategyId(strategyThree);
        if (strategyThreeId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategyThree);
          await strategyTab.btnSubmitClick();
          const strategyFound = await common.waitUntilStrategyFound(strategyThree);
          if (strategyFound) {
            strategyThreeId = await common.getStrategyId(strategyThree);
          }
        }
        const strategyExist = strategyThreeId !== null;
        expect(strategyExist).to.equal(true, 'Could not find Strategy.');
      });

      it('I should login (broker)', async () => {
        await start(brokerOne);
        logger.info(`Logged in with user ${brokerOne.email}.`);
      });

      it('I should have a strategy to trade', async () => {
        strategyThreeId = await common.getStrategyId(strategyThree);
        if (strategyThreeId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategyThree);
          await strategyTab.btnSubmitClick();
          const strategyFound = await common.waitUntilStrategyFound(strategyThree);
          if (strategyFound) {
            strategyThreeId = await common.getStrategyId(strategyThree);
          }
        }
        const strategyExist = strategyThreeId !== null;
        expect(strategyExist).to.equal(true, 'Could not find Strategy.');
      });

      /*
       *This has been added because a check has been added to the request for quotes button.
       *A user cannot launch an RFS if there are no responders logged in.
       */
      it('LP trader should login', async () => {
        await lpTraderOneClient.login();
      });

      it('NLP trader should initiate an RFS', async () => {
        await nlpTraderOneClient.login();
        await nlpTraderOneClient.initiateRFS(strategyThreeId);
      });

      it('I should be able to see the strategy with grey RFS status in the market view', async () => {
        const strategyFound = await common.waitUntilStrategyFound(strategyThree);
        expect(strategyFound).to.equal(true, 'Broker should be able to see the strategy in the Market View');
        const strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
          .getTableRow(strategyThree);
        await strategyRow.waitUntilStatus('RFS');
        const flag = await strategyRow.statusHasInactiveFlag();
        expect(flag).to.equal(true, 'Status inactive flag should exist');
        await strategyRow.verifyStatusColour(COLOR_PURPOSE.INACTIVE_COLOR);
      });

      it('I should not see a toast notification', async () => {
        let toastMsgs = null;
        strategyThreeTitle = strategyThree.strategy.shortName.concat(' ', strategyThree.expiry);

        try {
          await browser.waitUntil(
            async () => {
              toastMsgs = await toastNotification.getRfsResponderToastMsg(strategyThree);

              return toastMsgs.length > 0;
            }
            , frameworkConfig.shortTimeout, `Timed out after ${frameworkConfig.shortTimeout}ms, Could not find RFS responder toast message.`
          );
        } catch (err) {
          logger.info(err);
        }

        expect(toastMsgs.length).to.equal(0, 'Expected to find Responder toast message');
      });

      it('I should not see an RFS alert', async () => {
        const notifications = await mainPageFrame.notificationsPanel.notifications;
        const rfsNotification = await notifications.getRfsResponderInvite(strategyThree);
        logger.info('Getting notification alerts.');

        const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
        expect(found).to.equal(false, 'Expected to find RFS responder notification message');
      });

      it('I should see grey RFS status against the strategy in the market view', async () => {
        await mainPageFrame.clickMarketViewHeader();
        const strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
          .getTableRow(strategyThree);
        logger.info('Found strategy in Market View.');
        await strategyRow.waitUntilStatus('RFS');
        const actualStatus = await strategyRow.getStatusButtonText();
        const expectedStatus = 'RFS';
        expect(actualStatus).to.equal(expectedStatus, 'Expected the strategy status to be RFS');
        logger.info('Status RFS found in Market View.');
        const inactiveFlag = await strategyRow.statusHasInactiveFlag();
        expect(inactiveFlag).to.equal(true, 'Status should have inactive flag');
        logger.info('Status has inactive flag');
      });

      it('Uses should log out', async () => {
        await nlpTraderOneClient.logout();
        await lpTraderOneClient.logout();
      });
    });
  });
});
