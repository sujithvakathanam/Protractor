import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import TestCommons from '../../lib/TestCommons';
import Rfs from '../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Strategy from '../../lib/Strategy';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import MarketViewTabs from '../../constant/MarketViewTabs';
import ApiClient from '../../utilities/api/ApiClient';

describe('BC1835: RFS Priority Timer', function BC2706Test () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;

  before(async () => {
    bootstrapper = await new Bootstrap([frameworkConfig, usersConfig]);
    context = await bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC1835 TC001: For DIRECT RFS', () => {
    let nlpInitiator = {};
    let lpResponder1 = {};
    let lpResponder2 = {};
    let lpResponder3 = {};
    let lpResponder4 = {};
    let nlpInitiatorClient = null;
    let lpResponder1Client = null;
    let lpResponder2Client = null;
    let lpResponder3Client = null;
    let lpResponder4Client = null;
    let marketView = null;
    let strategyId = 0;
    let rfsWindow = null;
    let strategyRow = null;
    let priorityTimerValue = '0:00';

    /* eslint-disable */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 265, 15, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 700, null);
    strategy.addLeg(null, null, 'DEC26', null, null);
    /* eslint-enable */

    describe('Test UI priority behaviour from the initiator perspective', () => {
      it('Setup', () => {
        nlpInitiator = common.getTrader('AUTTR02');
        lpResponder1 = common.getTrader('AUTTR05');
        lpResponder2 = common.getTrader('AUTTR08');
        lpResponder3 = common.getTrader('AUTTR14');
        lpResponder4 = common.getTrader('AUTTR18');
      });

      it('The initiator should have a strategy to trade', async () => {
        await start(nlpInitiator);
        const username = await mainPageFrame.getUsername();
        expect(username).to.equal(nlpInitiator.fenicsGoUsername, 'Unexpected username on application window');

        strategyId = await common.getStrategyId(strategy);
        if (strategyId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategy);
          await strategyTab.btnSubmitClick();
          expect(await common.waitUntilStrategyFound(strategy)).to.be.true;
          strategyId = await common.getStrategyId(strategy);
        }
      });

      it('The strategy should be tradeable', async () => {
        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);
        strategyRow = await marketView.getTable().getTableRow(strategy);
        const isTradable = await strategyRow.isStrategyTradable();
        expect(isTradable).to.be.true;
      });

      it('Traders should all login', async () => {
        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);

        lpResponder1Client = new ApiClient(lpResponder1);
        await lpResponder1Client.login();

        lpResponder2Client = new ApiClient(lpResponder2);
        await lpResponder2Client.login();

        lpResponder3Client = new ApiClient(lpResponder3);
        await lpResponder3Client.login();

        lpResponder4Client = new ApiClient(lpResponder4);
        await lpResponder4Client.login();
      });

      it('NLP trader initiates RFS', async () => {
        await strategyRow.clickUnderlying();
        await marketView.clickMarketDepthHeader();
        const marketDepth = await marketView.getMarketDepthTab();
        expect(await marketDepth.requestQuotesBtnEnabled()).to.be.true;

        await marketDepth.clickRequestQuotesBtn();
        await strategyRow.waitUntilStatus('RFS');
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
        expect(foundWindow).to.equal(true, 'Expected to find the RFS window');
      });

      it('Traders should respond to the rfs', async () => {
        await lpResponder1Client.respondToRFS(strategyId);
        await lpResponder2Client.respondToRFS(strategyId);
        await lpResponder3Client.respondToRFS(strategyId);
        await lpResponder4Client.respondToRFS(strategyId);
      });

      it('RFS window should transition to LIT phase', async () => {
        await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        const phase = await rfsWindow.getPhase();
        expect(phase).to.equal('LIT', 'RFS should be in LIT PHASE');
      });

      it('Traders enter their orders during lit phase', async () => {
        await lpResponder1Client.rfsQuote(strategyId, 99, 103, 1000);
        await lpResponder2Client.rfsQuote(strategyId, 98, 102.5, 1000);
        await lpResponder3Client.rfsQuote(strategyId, 98, 104, 1000);
        await lpResponder4Client.rfsQuote(strategyId, 99, 101.5, 1000);
        await lpResponder4Client.rfsSubject(strategyId);
      });

      it('RFS window should transition to TRADING phase', async () => {
        await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
        const phase = await rfsWindow.getPhase();

        expect(phase)
          .to
          .equal('TRADING', 'RFS should be in TRADING PHASE');
      });

      it('Scenario #1.1: RFS window should show order stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 2 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('103.000', 'RFS offers row 2 showed unexpected ask price');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        bidPrice = await rowThree.getBidPrice();
        askPrice = await rowThree.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 3 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('104.000', 'RFS offers row 3 showed unexpected ask price');

        const rowFour = await rfsWindow.getBidOfferRow(4);
        bidPrice = await rowFour.getBidPrice();
        askPrice = await rowFour.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('101.500', 'RFS offers row 4 showed unexpected ask price');
      });

      it('Scenario #1.2: Responder 3 improves bid', async () => {
        await lpResponder3Client.rfsQuote(strategyId, 100, 104, 1000);

        await browser.waitUntil(async () => {
          const rowOne = await rfsWindow.getBidOfferRow(1);
          const bidPrice = await rowOne.getBidPrice();

          return bidPrice === '100.000';
        }, frameworkConfig.shortTimeout);
      });

      it('Scenario #1.2: RFS window should show order stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 2 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('103.000', 'RFS offers row 2 showed unexpected ask price');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        bidPrice = await rowThree.getBidPrice();
        askPrice = await rowThree.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 3 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('104.000', 'RFS offers row 3 showed unexpected ask price');

        const rowFour = await rfsWindow.getBidOfferRow(4);
        bidPrice = await rowFour.getBidPrice();
        askPrice = await rowFour.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('101.500', 'RFS offers row 4 showed unexpected ask price');
      });

      it('Scenario #1.2: Priority timer should NOT be triggered', async () => {
        // Neither top of of book order belongs to initiator, so they are no RFS Matchable, so no priority phase can start
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.3: Initiator adds 2-way firm quote', async () => {
        await rfsWindow.quote(100.5, 102, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('100.500', '102.000');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator 2-way quote did not appear in quote book');
      });

      it('Scenario #1.3: Priority timer should NOT be triggered', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.4: Initiator pulls his offer back', async () => {
        await rfsWindow.quote(null, 105, null);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('100.500', '102.500');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator ask was not reduced as expected');
      });

      it('Scenario #1.4: RFS window should show order stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.500', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers row 2 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('103.000', 'RFS offers row 2 showed unexpected ask price');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        bidPrice = await rowThree.getBidPrice();
        askPrice = await rowThree.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 3 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('104.000', 'RFS offers row 3 showed unexpected ask price');

        const rowFour = await rfsWindow.getBidOfferRow(4);
        bidPrice = await rowFour.getBidPrice();
        askPrice = await rowFour.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('105.000', 'RFS offers row 4 showed unexpected ask price');

        const rowFive = await rfsWindow.getBidOfferRow(5);
        bidPrice = await rowFive.getBidPrice();
        askPrice = await rowFive.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('101.500', 'RFS offers row 4 showed unexpected ask price');
      });

      it('Scenario #1.4: Priority timer should NOT be triggered', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.5: Initiator improves his bid', async () => {
        await rfsWindow.quote(101, null, null);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('101.000\n*', '102.500');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator bid was not improved to 101 as expected');
      });

      it('Scenario #1.5: Priority timer should start, responder 2 has priority', async () => {
        await rfsWindow.waitUntilPriorityActive();

        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-OTHER', 'RFS should be in PRIORITY phase, with priority to Responder 2');

        priorityTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
      });

      it('Scenario #1.5: RFS window should show order stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('101.000\n*', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers row 2 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('103.000', 'RFS offers row 2 showed unexpected ask price');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        bidPrice = await rowThree.getBidPrice();
        askPrice = await rowThree.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 3 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('104.000', 'RFS offers row 3 showed unexpected ask price');

        const rowFour = await rfsWindow.getBidOfferRow(4);
        bidPrice = await rowFour.getBidPrice();
        askPrice = await rowFour.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('105.000', 'RFS offers row 4 showed unexpected ask price');

        const rowFive = await rfsWindow.getBidOfferRow(5);
        bidPrice = await rowFive.getBidPrice();
        askPrice = await rowFive.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('101.500', 'RFS offers row 4 showed unexpected ask price');
      });

      it('Scenario #1.6: Responder 1 tries to update his ask to better than the priority responder', async () => {
        await lpResponder1Client.rfsQuote(strategyId, 100, 101, 1000);

        let quoteFailed = false;
        try {
          await browser.waitUntil(async () => {
            const rowOne = await rfsWindow.getBidOfferRow(1);
            const bidPrice = await rowOne.getBidPrice();
            const askPrice = await rowOne.getAskPrice();

            return bidPrice === '100.500' && askPrice === '102.000';
          }, frameworkConfig.shortTimeout);
        } catch (error) {
          quoteFailed = true;
        }

        expect(quoteFailed)
          .to
          .equal(true, 'Responder 1 should not be able to better the ask of the priority responder');
      });

      it('Scenario #1.6: order stack should not have changed', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('101.000\n*', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers row 2 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('103.000', 'RFS offers row 2 showed unexpected ask price');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        bidPrice = await rowThree.getBidPrice();
        askPrice = await rowThree.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 3 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('104.000', 'RFS offers row 3 showed unexpected ask price');

        const rowFour = await rfsWindow.getBidOfferRow(4);
        bidPrice = await rowFour.getBidPrice();
        askPrice = await rowFour.getAskPrice();
        expect(bidPrice)
          .to
          .equal('98.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('105.000', 'RFS offers row 4 showed unexpected ask price');

        const rowFive = await rfsWindow.getBidOfferRow(5);
        bidPrice = await rowFive.getBidPrice();
        askPrice = await rowFive.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 4 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('101.500', 'RFS offers row 4 showed unexpected ask price');
      });

      it('Scenario #1.7: Responder 1 updates his quote with ask worse than the priority responder', async () => {
        await lpResponder1Client.rfsQuote(strategyId, 99.5, 102.5, 1000);

        const rowOne = await rfsWindow.getBidOfferRow(1);
        let isExpectedValues = await rowOne.waitUntilPrice('101.000\n*', '102.500');
        expect(isExpectedValues)
          .to
          .equal(true, 'Row 1 prices not as expected');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        isExpectedValues = await rowTwo.waitUntilPrice('100.000', '102.500');
        expect(isExpectedValues)
          .to
          .equal(true, 'Row 2 prices not as expected');

        const rowThree = await rfsWindow.getBidOfferRow(3);
        isExpectedValues = await rowThree.waitUntilPrice('99.500', '104.000');
        expect(isExpectedValues)
          .to
          .equal(true, 'Row 3 prices not as expected');
      });

      /*
       * Scenario #1.8 tests responder 2 improving ask price, but results in termination of the RFS.
       * Scenario #1.9 ALSO tests responder 2 improving ask price, but allows us to carry on.
       */

      it('Scenario #1.9: Responder 2 can make his ask price better', async () => {
        await lpResponder2Client.rfsQuote(strategyId, 98, 102, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const isExpectedValues = await rowOne.waitUntilPrice('101.000', '102.000\n*');
        expect(isExpectedValues)
          .to
          .equal(true, 'Expected row 1 to show 101/102P');
      });

      it('Scenario #1.9: New priority phase should start', async () => {
        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-MINE', 'RFS should be in PRIORITY phase, initiator has priority');

        const currentTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
        expect(currentTimerValue)
          .to
          .equal(priorityTimerValue, 'Priority timer should be reset');
      });

      it('Scenario #1.9: Responder 2 ask price should be blue and clickable to priority responder (initiator)', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const askButtonEnabled = await rowOne.isAskPriceBtnEnabled();
        expect(askButtonEnabled)
          .to
          .equal(true, 'Ask price should be enabled for trading');
      });

      it('Scenario #1.10: Responder 4 firms up, giving better ask', async () => {
        await lpResponder4Client.rfsFirm(strategyId, 99, 101.5, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const isExpectedValues = await rowOne.waitUntilPrice('101.000', '101.500\n*');
        expect(isExpectedValues)
          .to
          .equal(true, 'Expected row 1 to show 101/101.5P');
      });

      it('Scenario #1.10: New priority phase should start', async () => {
        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-MINE', 'RFS should be in PRIORITY phase, initiator has priority');

        const currentTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
        expect(currentTimerValue)
          .to
          .equal(priorityTimerValue, 'Priority timer should be reset');
      });

      it('Scenario #1.10: Responder 4 ask price should be blue and clickable to priority responder (initiator)', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const askButtonEnabled = await rowOne.isAskPriceBtnEnabled();
        expect(askButtonEnabled)
          .to
          .equal(true, 'Ask price should be enabled for trading');
      });

      it('Scenario #1.11: Clear the way for responder 4 to worsen their ask by worsening responder 2 ask', async () => {
        await lpResponder2Client.rfsQuote(strategyId, 98, 102.5, 1000);
        const rowTwo = await rfsWindow.getBidOfferRow(2);
        const isExpectedValues = await rowTwo.waitUntilPrice('100.000', '102.500');
        expect(isExpectedValues)
          .to
          .equal(true, 'Expected row 2 to show 100/102.5');
      });

      it('Scenario #1.11: Responder 4 worsens their ask but it is still best', async () => {
        await lpResponder4Client.rfsQuote(strategyId, 99, 102, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const isExpectedValues = await rowOne.waitUntilPrice('101.000', '102.000\n*');
        expect(isExpectedValues)
          .to
          .equal(true, 'Expected row 1 to show 101/102P');
      });

      it('Scenario #1.11: NO new priority phase should start, priority continues', async () => {
        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-MINE', 'RFS should be in PRIORITY phase, initiator has priority');

        const currentTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
        expect(currentTimerValue)
          .to
          .not
          .equal(priorityTimerValue, 'Priority timer should not be reset');
      });

      it('Scenario #1.12: Responder 4 goes subject again', async () => {
        await lpResponder4Client.rfsSubject(strategyId);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const isExpectedValues = await rowOne.waitUntilPrice('101.000', '102.500');
        expect(isExpectedValues)
          .to
          .equal(true, 'Expected row 1 to show 101/102.5');
      });

      it('Scenario #1.12: Price priority should be cancelled', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', 'PRIORITY phase should be cancelled');
      });

      it('Scenario #1.13: Initiator improves bid', async () => {
        await rfsWindow.quote(101.5, null, null);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('101.500\n*', '102.500');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator bid was not improved to 101.5 as expected');
      });

      it('Scenario #1.13: Priority timer should start, responder 2 has priority', async () => {
        await rfsWindow.waitUntilPriorityActive();
        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-OTHER', 'RFS should be in PRIORITY phase, with priority to Responder 2');

        const currentTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
        expect(currentTimerValue)
          .to
          .equal(priorityTimerValue, 'Priority timer should be reset');
      });

      it('Users should make their prices subject to prevent them moving to the order book', async () => {
        await lpResponder1Client.rfsSubject(strategyId);
        await lpResponder2Client.rfsSubject(strategyId);
        await lpResponder3Client.rfsSubject(strategyId);
        await rfsWindow.btnSubjectClick();
      });

      it('Wait until RFS terminates', async () => {
        await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
      });

      it('Users should logout', async () => {
        await lpResponder1Client.logout();
        await lpResponder2Client.logout();
        await lpResponder3Client.logout();
        await lpResponder4Client.logout();
      });
    });

    describe('Test UI non-priority behaviour from responder 1 perspective', () => {
      it('Setup', () => {
        nlpInitiator = common.getTrader('AUTTR02');
        lpResponder1 = common.getTrader('AUTTR05');
        lpResponder2 = common.getTrader('AUTTR08');
        lpResponder3 = common.getTrader('AUTTR14');
        lpResponder4 = common.getTrader('AUTTR18');
      });

      it('Traders should all login and register for notifications as required', async () => {
        await start(lpResponder1);
        const username = await mainPageFrame.getUsername();
        expect(username).to.equal(lpResponder1.fenicsGoUsername, 'Unexpected username on application window');
        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);
        strategyId = await common.getStrategyId(strategy);

        nlpInitiatorClient = new ApiClient(nlpInitiator);
        await nlpInitiatorClient.login();

        lpResponder2Client = new ApiClient(lpResponder2);
        await lpResponder2Client.login();

        lpResponder3Client = new ApiClient(lpResponder3);
        await lpResponder3Client.login();

        lpResponder4Client = new ApiClient(lpResponder4);
        await lpResponder4Client.login();
      });

      it('NLP trader initiates RFS and LP traders should respond', async () => {
        await nlpInitiatorClient.initiateRFS(strategyId);
        await nlpInitiatorClient.respondToRFS(strategyId);
        await lpResponder2Client.respondToRFS(strategyId);
        await lpResponder3Client.respondToRFS(strategyId);
        await lpResponder4Client.respondToRFS(strategyId);
      });

      it('Market view should show a blue RFS label against the strategy being traded', async () => {
        strategyRow = await marketView.getTable().getTableRow(strategy);
        await strategyRow.waitUntilStatus('RFS', frameworkConfig.mediumTimeout);
        const strategyStatus = await strategyRow.getStatusText();
        expect(strategyStatus)
          .to
          .equal('RFS');
      });

      it('Responder 1 launches the RFS window', async () => {
        await strategyRow.clickStatus();
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });

      it('RFS window should transition to LIT phase', async () => {
        await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('LIT', 'RFS should be in LIT PHASE');
      });

      it('Traders enter their orders during lit phase', async () => {
        await rfsWindow.quote(99, 103, 1000);

        // Responder 2
        await lpResponder2Client.rfsQuote(strategyId, 98, 102.5, 1000);
        await lpResponder3Client.rfsQuote(strategyId, 98, 104, 1000);
        await lpResponder4Client.rfsQuote(strategyId, 99, 101.5, 1000);
        await lpResponder4Client.rfsSubject(strategyId);
      });

      it('RFS window should transition to TRADING phase', async () => {
        await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', 'RFS should be in TRADING PHASE');
      });

      it('Scenario #1.1: RFS window should top of stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('99.000', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        bidPrice = await rowTwo.getBidPrice();
        askPrice = await rowTwo.getAskPrice();
        expect(bidPrice)
          .to
          .equal('', 'RFS offers row 2 should not show prices');
        expect(askPrice)
          .to
          .equal('', 'RFS offers row 2 should not show prices');
      });

      it('Scenario #1.2: Responder 3 improves bid', async () => {
        await lpResponder3Client.rfsQuote(strategyId, 100, 104, 1000);
        await browser.waitUntil(async () => {
          const rowOne = await rfsWindow.getBidOfferRow(1);
          const bidPrice = await rowOne.getBidPrice();

          return bidPrice === '100.000';
        }, frameworkConfig.shortTimeout);
      });

      it('Scenario #1.2: RFS window should show top of stack correctly', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const bidPrice = await rowOne.getBidPrice();
        const askPrice = await rowOne.getAskPrice();
        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers row 1 showed unexpected bid price');
        expect(askPrice)
          .to
          .equal('102.500', 'RFS offers row 1 showed unexpected ask price');
      });

      it('Scenario #1.2: Priority timer should NOT be triggered', async () => {
        // Neither top of of book order belongs to initiator, so they are no RFS Matchable, so no priority phase can start
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.3: Initiator adds 2-way firm quote', async () => {
        await nlpInitiatorClient.rfsQuote(strategyId, 100.5, 102, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('100.500', '102.000');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator 2-way quote did not appear in quote book');
      });

      it('Scenario #1.3: Priority timer should NOT be triggered', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.4: Initiator pulls his offer back', async () => {
        await nlpInitiatorClient.rfsQuote(strategyId, 100.5, 105, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('100.500', '102.500');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator ask was not reduced as expected');
      });

      it('Scenario #1.4: Priority timer should NOT be triggered', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
      });

      it('Scenario #1.5: Initiator improves his bid', async () => {
        await nlpInitiatorClient.rfsQuote(strategyId, 101, 105, 1000);
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const quoteSucceeded = await rowOne.waitUntilPrice('101.000\n*', '102.500');
        expect(quoteSucceeded)
          .to
          .equal(true, 'Initiator bid was not improved to 101 as expected');
      });

      it('Scenario #1.5: Priority timer should start, responder 2 has priority', async () => {
        await rfsWindow.waitUntilPriorityActive();
        const phase = await rfsWindow.getPriorityPhaseType();
        expect(phase)
          .to
          .equal('PRIORITY-OTHER', 'RFS should be in PRIORITY phase, with priority to Responder 2');

        priorityTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
      });

      it('Scenario #1.5: Responder 1 should not be able to hit the bid', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const hitBidEnabled = await rowOne.isBidPriceBtnEnabled();
        expect(hitBidEnabled)
          .to
          .equal(false, 'Responder 1 should not be able to hit the bid when responder 2 has priority');
      });

      it('Scenario #1.6: Responder 1 tries to better the priority ask', async () => {
        await rfsWindow.quote(100, 101, 1000);
        const msg = 'Update Rejected: Priority Phase in progress.';
        const isRejected = await common.browser.waitUntil(() => rfsWindow.notificationExists(msg), frameworkConfig.shortTimeout);
        expect(isRejected)
          .to
          .equal(true, `Expected rejection msg: '${msg}'; Observed rejection msg: '${await rfsWindow.getNotificationMsg()}'`);

        await rfsWindow.clickNotificationOk();
      });

      it('Users should make their prices subject to prevent them moving to the order book', async () => {
        await nlpInitiatorClient.rfsSubject(strategyId);
        await lpResponder2Client.rfsSubject(strategyId);
        await lpResponder3Client.rfsSubject(strategyId);
        await lpResponder4Client.rfsSubject(strategyId);
        await rfsWindow.btnSubjectClick();
        await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
      });

      it('Users should logout', async () => {
        await nlpInitiatorClient.logout();
        await lpResponder2Client.logout();
        await lpResponder3Client.logout();
        await lpResponder4Client.logout();
      });
    });
  });
});
