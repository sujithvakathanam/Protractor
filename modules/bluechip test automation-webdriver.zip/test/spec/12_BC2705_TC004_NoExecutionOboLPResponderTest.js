import Strategy from '../../lib/Strategy';
import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import {expect} from 'chai';
import ApiClient from '../../utilities/api/ApiClient';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import ToastNotification from '../../pages/child_windows/ToastNotification';


// Framwework vars
const browser = global.browser;
let bootstrapper = null;
let context = null;
let logger = null;

// Page object vars
let mainPageFrame = null;
let mainWindowHandle = null;
let common = null;
let toastNotification = null;

before(() => {
  bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
  context = bootstrapper.getInstance();
  logger = context.getLogger();
  logger.info('Framework setup complete.');

  // Page object  setup.
  common = new TestCommons(context);

  expect(browser).to.exist;
});

after(() => {
  const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
  shellExec(clearDownScript);
});

async function start ({email, password}) {
  mainPageFrame = await common.login(email, password);
  mainWindowHandle = await browser.getCurrentTabId();
  toastNotification = await new ToastNotification(context);
}

describe('BC2705 TC004: As a LP trader who is participating in an OBO RFS without interest I should not be able to match a quote from another LP', () => {
  let broker = null;
  let brokerClient = null;
  let lpTraderOne = null;
  let lpTraderTwo = null;
  let lpTraderTwoClient = null;
  let strategyId = null;
  let rfsWindow = null;

  const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 3000, 100, POLARITY.positive, null, null);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 3000, 1);
  strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 2950, 1);

  it('Should get the test users', () => {
    broker = common.getBroker('AUTBR04');
    lpTraderOne = common.getTrader('AUTTR01');
    lpTraderTwo = common.getTrader('AUTTR04');
  });

  it('The broker should have a strategy to trade', async () => {
    await start(broker);
    strategyId = await common.getStrategyId(strategy);
    if (strategyId === null) {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmit.click();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
    }
    const hasStrategyId = strategyId !== null;
    expect(hasStrategyId !== null).to.equal(true, 'Could not find strategy');
  });

  it('Test users should login', async () => {
    await start(lpTraderOne);
    brokerClient = new ApiClient(broker);
    await brokerClient.login();
    lpTraderTwoClient = new ApiClient(lpTraderTwo);
    await lpTraderTwoClient.login();
  });

  it('Broker should initiate an RFS', async () => {
    await brokerClient.initiateRFS(strategyId);
  });

  it('trader should respond to the RFS', async () => {
    await lpTraderTwoClient.respondToRFS(strategyId);
  });

  it('I should open the RFS window', async () => {
    await browser.switchTab(mainWindowHandle);
    const marketView = mainPageFrame.getMarketViewTab();
    await marketView.clickTabEuroStoxx();
    await common.waitUntilStrategyFound(strategy);
    const strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
    await strategyRow.waitUntilStatus('RFS');
    await strategyRow.clickStatus();
    rfsWindow = await new Rfs(context);
    const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
    expect(foundWindow).to.equal(true, 'Expected to find the RFS window');
  });

  it('I should respond to the RFS with a quote', async () => {
    await lpTraderTwoClient.rfsQuote(strategyId, '111', '113', 2500);
    await rfsWindow.quote('110', '115', 2500);
    await rfsWindow.waitUntilMyCurrentBid('110.000');
    const myCurrentBid = await rfsWindow.getMyCurrentBid();
    const myCurrentAsk = await rfsWindow.getMyCurrentAsk();
    const mySize = await rfsWindow.getMyCurrentSize();
    expect(myCurrentBid).to.equal('110.000', 'RFS My Current Bid');
    expect(myCurrentAsk).to.equal('115.000', 'RFS My Current Ask');
    expect(mySize).to.equal('2500 L', 'RFS My Current Size');
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const bidPrice = await bidOfferRow.getBidPrice();
    const askPrice = await bidOfferRow.getAskPrice();
    expect(bidPrice).to.equal('', 'RFS Offers table Bid price');
    expect(askPrice).to.equal('', 'RFS Offers table Ask price');
  });

  it('I should see the top of market bid and offer in the LIT phase of the RFS', async () => {
    const inLitPhase = await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
    expect(inLitPhase).to.equal(true, 'RFS should of transitioned to the LIT phase');
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const offerRowUpdate = await bidOfferRow.waitUntilPrice('111.000', '113.000');
    expect(offerRowUpdate).to.equal(true, 'Bid offer row has not been updated for the user');
  });

  it('I should wait for the RFS to transition to trading phase', async () => {
    const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout;
    await rfsWindow.waitUntilPhase('TRADING', timeout);
    const phase = await rfsWindow.getPhase();
    expect(phase).to.equal('TRADING', 'RFS should be in trading phase');
  });

  it('RFS window should show counterparty LP traders quote is top of market', async () => {
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const topBidPrice = await bidOfferRow.getBidPrice();
    const topAskPrice = await bidOfferRow.getAskPrice();
    expect(topBidPrice).to.equal('111.000', 'RFS top of market bid price');
    expect(topAskPrice).to.equal('113.000', 'RFS top of market ask price');
  });

  it('I should not be able lift or hit offer from another LP', async () => {
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const bidEnabled = await bidOfferRow.isBidPriceBtnEnabled();
    const askEnabled = await bidOfferRow.isAskPriceBtnEnabled();
    expect(bidEnabled).to.equal(false, 'RFS bid price should not be clickable');
    expect(askEnabled).to.equal(false, 'RFS ask price should not be clickable');
  });

  it('LP trader order should not match when ask price matches that of another LP', async () => {
    await rfsWindow.quote('115', '118', 2500);
  });

  it('LP trader order should not match when ask price matches that of another LP', async () => {
    await lpTraderTwoClient.rfsQuote(strategyId, '109', '115', 2500);
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const priceFound = await bidOfferRow.waitUntilPrice('115.000', '115.000');
    expect(priceFound).to.equal(true, 'RFS unexpected price displayed');
  });

  it('I should see RFS end without a match', async () => {
    const found = await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
    expect(found).to.equal(true, 'RFS should of timeout without a match');
  });

  it('users should logout', async () => {
    await brokerClient.logout();
    await lpTraderTwoClient.logout();
  });
});
