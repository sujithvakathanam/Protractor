import {shellExec} from '../../utilities/framework/shell-exec';
import {MARKET, STRATEGY, STYLE, UNDERLYING, POLARITY} from '../../constant/GenericType';
import {expect} from 'chai';
import {join} from 'path';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../lib/TestCommons';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';

describe('BC3362 LP Traders can launch RFS when LP request flag is set to true', function BC3129EndToEndTest () {
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;
  let marketView = null;
  let marketDepth = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser)
      .to
      .exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC3129 TC001: Test Broker, LP Trader, NLP Trader', () => {
    let broker = {};
    let lpTrader = {};
    let nlpTrader = {};
    let strategyId = 0;
    let rfsWindow = null;
    let strategyRow = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 221, 15, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 700, null);
    strategy.addLeg(null, null, 'DEC26', null, null);
    /* eslint-enable no-magic-numbers */

    it('Get test users', () => {
      broker = common.getBroker('AUTBR03');
      lpTrader = common.getTrader('AUTTR01');
      nlpTrader = common.getTrader('AUTTR07');
    });

    it('The users should have a strategy to trade', async () => {
      await start(broker);
      strategyId = await common.getStrategyId(strategy);

      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmit.click();
        await common.waitUntilStrategyFound(strategy);
        strategyId = await common.getStrategyId(strategy);
      }

      expect(strategyId !== null)
        .to
        .equal(true, 'Could not find Strategy');
    });

    it('The strategy should be tradeable', async () => {
      await mainPageFrame.clickMarketViewHeader();
      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickTabEuroStoxx();
      strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
      const isTradable = await strategyRow.isStrategyTradable();

      expect(isTradable)
        .to
        .be
        .true;
    });

    describe('Broker RFS capabilities', () => {
      it('Can launch', async () => {
        await strategyRow.clickUnderlying();
        await marketView.clickMarketDepthHeader();
        marketDepth = await marketView.getMarketDepthTab();
        const rfsQuoteBtnEnabled = await marketDepth.requestQuotesBtnEnabled();

        expect(rfsQuoteBtnEnabled)
          .to
          .be
          .true;
      });

      it('Launches', async () => {
        await marketDepth.clickRequestQuotesBtn();
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });

      it('Waits until finished', async () => {
        await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
        await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
      });
    });

    describe('LP Trader RFS capabilities', () => {
      it('The trader logs in', async () => {
        await start(lpTrader);
        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
      });

      it('The strategy should be tradeable', async () => {
        strategyId = await common.getStrategyId(strategy);

        if (strategyId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategy);
          await strategyTab.btnSubmit.click();
          await common.waitUntilStrategyFound(strategy);
          strategyId = await common.getStrategyId(strategy);
        }

        expect(strategyId !== null)
          .to
          .equal(true, 'Could not find Strategy');

        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
        strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
        const isTradable = await strategyRow.isStrategyTradable();

        expect(isTradable)
          .to
          .be
          .true;
      });

      it('Can launch when LP request flag is set to true', async () => {
        await strategyRow.clickUnderlying();
        await marketView.clickMarketDepthHeader();
        marketDepth = await marketView.getMarketDepthTab();
        const rfsQuoteBtnEnabled = await marketDepth.requestQuotesBtnEnabled()

        expect(rfsQuoteBtnEnabled)
          .to
          .be
          .true;
      });

      it('Launches', async () => {
        await marketDepth.clickRequestQuotesBtn();
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });
    });

    // Need to add a lp/nlp to respond to the RFS request.
    describe('NLP Trader RFS capabilities', () => {
      it('The trader logs in', async () => {
        await start(nlpTrader);
        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
      });

      it('The strategy should be tradeable', async () => {
        strategyId = await common.getStrategyId(strategy);

        if (strategyId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategy);
          await strategyTab.btnSubmit.click();
          await common.waitUntilStrategyFound(strategy);
          strategyId = await common.getStrategyId(strategy);
        }

        expect(strategyId !== null)
          .to
          .equal(true, 'Could not find Strategy');

        await mainPageFrame.clickMarketViewHeader();
        marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
        strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
        const isTradable = await strategyRow.isStrategyTradable();

        expect(isTradable)
          .to
          .be
          .true;
      });

      it('Can launch', async () => {
        await strategyRow.clickUnderlying();
        await marketView.clickMarketDepthHeader();
        marketDepth = await marketView.getMarketDepthTab();
        const rfsQuoteBtnEnabled = await marketDepth.requestQuotesBtnEnabled()

        expect(rfsQuoteBtnEnabled)
          .to
          .be
          .true;
      });

      it('Launches', async () => {
        await marketDepth.clickRequestQuotesBtn();
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });

      it('Cancels', async () => {
        await rfsWindow.btnCancelRfsClick();
      });
    });
  });
});
