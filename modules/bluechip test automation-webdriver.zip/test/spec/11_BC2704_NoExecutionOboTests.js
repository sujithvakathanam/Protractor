/* eslint-disable max-lines,max-statements */
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, UNDERLYING, STRATEGY, POLARITY, STYLE, OPTION_TYPE} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import Rfs from '../../pages/child_windows/Rfs';
import ApiClient from '../../utilities/api/ApiClient';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';

describe('BC2704 OBO RFS Tests', function BC2704EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let common = null;
  let mainPageFrame = null;
  let toastNotification = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
    logger.info(browser.sessionId);
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    toastNotification = new ToastNotification(context);
  }

  describe('BC2704 TC001: As a broker I should receive RFS notification messages when', () => {
    let strategyRow = null;
    let strategyId = 0;
    let strategyIdTwo = 0;
    let strategyTitle = '';
    let strategyTwoTitle = '';

    let brokerOne = null;
    let brokerTwo = null;
    let brokerTwoClient = null;

    /* eslint-disable no-magic-numbers */
    const strategyOne = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 200, 35, POLARITY.positive, null, null);
    strategyOne.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, null);
    strategyOne.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 300, null);

    const strategyTwo = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 200, 21, POLARITY.negative, null, null);
    strategyTwo.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 300, 1);
    /* eslint-enable no-magic-numbers */

    describe('When I initiate an RFS', () => {
      it('brokers should login', async () => {
        brokerOne = common.getBroker('AUTBR03');
        brokerTwo = common.getBroker('AUTBR04');
        brokerTwoClient = new ApiClient(brokerTwo);

        await start(brokerOne);
        logger.info(`Logged in with user ${brokerOne.email}.`);

        const actualUsername = await mainPageFrame.getUsername();
        expect(actualUsername).to.equal(
          brokerOne.fenicsGoUsername,
          'Expected to find username of logged in user main page'
        );
      });

      it('broker should have a strategy to trade', async () => {
        strategyId = await common.getStrategyId(strategyOne);
        if (strategyId === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategyOne);
          await strategyTab.btnSubmitClick();
          const strategyFound = await common.waitUntilStrategyFound(strategyOne);
          if (strategyFound) {
            strategyId = await common.getStrategyId(strategyOne);
          }
        }
        const strategyExist = strategyId !== null;
        expect(strategyExist).to.equal(
          true,
          'Could not find Strategy.'
        );
      });

      it('My broker colleague should have a strategy to trade', async () => {
        strategyIdTwo = await common.getStrategyId(strategyTwo);
        if (strategyIdTwo === null) {
          await mainPageFrame.clickCreateStrategyHeader();
          const strategyTab = await mainPageFrame.getCreateStrategyTab();
          await strategyTab.addNewStrategy(strategyTwo);
          await strategyTab.btnSubmitClick();
          const strategyFound = await common.waitUntilStrategyFound(strategyTwo);
          if (strategyFound) {
            strategyIdTwo = await common.getStrategyId(strategyTwo);
          }
        }
        const strategyExist = strategyIdTwo !== null;
        expect(strategyExist).to.equal(
          true,
          'Could not find Strategy.'
        );
      });

      it('I should initiate an RFS', async () => {
        await mainPageFrame.clickMarketViewHeader();
        strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
          .getTableRow(strategyOne);
        logger.info('Found newly created strategy in Market View.');

        await strategyRow.clickStatus();

        const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
        const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
        expect(btnEnabled).to.equal(
          true,
          'Request quotes button on Market Depth Tab.'
        );

        await marketDepth.clickRequestQuotesBtn();
        logger.info('Clicked request for quotes.');
      });

      it('I should see RFS toast message', async () => {
        let toastMsgs = null;
        strategyTitle = strategyOne.strategy.shortName.concat(' ', strategyOne.expiry);

        await common.browser.waitUntil(
          async () => {
            toastMsgs = await toastNotification.getRfsResponderToastMsg(strategyOne);

            return toastMsgs.length > 0;
          }
          , frameworkConfig.shortTimeout
          , `Timed out after ${frameworkConfig.shortTimeout}ms, Could not find RFS responder toast message.`
        );

        const hasToastMsgs = toastMsgs.length === 1;
        expect(hasToastMsgs).to.equal(true, 'Expected to find Responder toast message');
      });

      it('I should see RFS alert message', async () => {
        const notifications = await mainPageFrame.notificationsPanel.notifications;
        const rfsNotification = await notifications.getRfsResponderInvite(strategyOne);
        logger.info('Getting notification alerts.');

        const found = await rfsNotification.waitForExist();
        expect(found).to.equal(true, 'Expected to find RFS responder notification message');
      });

      it('Should show RFS in the strategy status field', async () => {
        await strategyRow.waitUntilStatus('RFS');
        const actualStatus = await strategyRow.getStatusText();
        const expectedStatus = 'RFS';
        expect(actualStatus).to.equal(
          expectedStatus,
          'Expected the strategy status to be RFS'
        );
      });

      it('I should see Broker RFS Window', async () => {
        const rfsWindow = new Rfs(context);
        await rfsWindow.switchToWindow('R', strategyOne.underlying, strategyOne.strategy.shortName, strategyOne.expiry);
        logger.info(`Switched to RFS window for ${strategyOne.underlying} ${strategyOne.strategy.shortName} ${strategyOne.expiry}`);
        logger.info(`Switched to RFS window for ${strategyOne.underlying} ${strategyOne.strategy.shortName} ${strategyOne.expiry}`);

        const windowLetter = await rfsWindow.getWindowLetter();
        expect(windowLetter).to.equal(
          'R',
          'Expected RFS window letter to be R'
        );

        const windowTitle = await rfsWindow.getTitle();
        expect(windowTitle).to.equal(
          strategyTitle,
          'RFS window title'
        );

        const delta = await rfsWindow.getDelta();
        expect(delta).to.equal(
          strategyOne.getDisplayDelta().toString(),
          'RFS window delta'
        );

        const ref = await rfsWindow.getRef();
        expect(ref).to.equal(
          strategyOne.referencePrice.toString(),
          'RFS window ref'
        );

        const responded = await rfsWindow.getResponded();
        expect(responded).to.include(
          '0/',
          'RFS window expected zero rfs participants'
        );

        const phase = await rfsWindow.getPhase();
        expect(phase).to.equal(
          'DARK',
          'RFS window should be in DARK phase'
        );
      });
    });

    describe('When my desk colleague initiates an RFS and I cover users for the segment', () => {
      it('Broker colleague should login', async () => {
        await brokerTwoClient.login();
      });

      it('My colleague should initiate an RFS', async () => {
        await brokerTwoClient.initiateRFS(strategyIdTwo);
      });

      it('I should see RFS toast message', async () => {
        let toastMsgs = null;

        await browser.waitUntil(
          async () => {
            toastMsgs = await toastNotification.getRfsResponderToastMsg(strategyTwo);

            return toastMsgs.length > 0;
          }
          , frameworkConfig.shortTimeout
          , `Timed out after ${frameworkConfig.shortTimeout}ms, Could not find RFS responder toast message.`
        );

        const hasToastMsgs = toastMsgs.length === 1;
        expect(hasToastMsgs).to.equal(true, 'Expected to find Responder toast message');
      });

      it('I should see an RFS alert message', async () => {
        await mainPageFrame.switchToWindow();
        const notifications = await mainPageFrame.notificationsPanel.notifications;
        const rfsNotification = await notifications.getRfsResponderInvite(strategyTwo);
        logger.info('Getting notification alerts.');

        const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
        if (found) {
          await rfsNotification.clickOnNotification();
        }
        expect(found).to.equal(
          true,
          'Expected to find RFS responder notification message'
        );
      });

      it('I should see RFS in the strategy status field', async () => {
        await mainPageFrame.switchToWindow();
        await mainPageFrame.clickMarketViewHeader();
        strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
          .getTableRow(strategyTwo);
        logger.info('Found strategy in Market View.');

        await strategyRow.waitUntilStatus('RFS');
        const actualStatus = await strategyRow.getStatusText();
        const expectedStatus = 'RFS';
        expect(actualStatus).to.equal(
          expectedStatus,
          'Expected the strategy status to be RFS'
        );
      });


      it('I should see Broker RFS Window when I click on the strategy in the market view', async () => {
        const rfsWindow = new Rfs(context);
        strategyTwoTitle = strategyTwo.strategy.shortName.concat(' ', strategyTwo.expiry);
        await rfsWindow.switchToWindow('R', strategyTwo.underlying, strategyTwo.strategy.shortName, strategyTwo.expiry);
        logger.info(`Switched to RFS window for ${strategyTwo.underlying} ${strategyTwo.strategy.shortName} ${strategyTwo.expiry}`);

        const windowLetter = await rfsWindow.getWindowLetter();
        expect(windowLetter).to.equal(
          'R',
          'Expected RFS window letter to be R'
        );

        const windowTitle = await rfsWindow.getTitle();
        expect(windowTitle).to.equal(
          strategyTwoTitle,
          'RFS window title'
        );

        const delta = await rfsWindow.getDelta();
        expect(delta).to.equal(
          strategyTwo.getDisplayDelta().toString(),
          'RFS window delta'
        );

        const ref = await rfsWindow.getRef();
        expect(ref).to.equal(
          strategyTwo.referencePrice.toString(),
          'RFS window ref'
        );

        const phase = await rfsWindow.getPhase();
        expect(phase).to.equal(
          'DARK',
          'RFS window should be in DARK phase'
        );
      });

      it('Users should log out', async () => {
        await brokerTwoClient.logout();
      });
    });
  });
});
