import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import TestCommons from '../../lib/TestCommons';
import {shellExec} from '../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import ApiClient from '../../utilities/api/ApiClient';
import Rfs from '../../pages/child_windows/Rfs';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import {expect} from 'chai';
import {join} from 'path';

describe('BC2709 TC001 No longer invite Broking Users to participate in a VC instead show size traded so far to relevant brokers', function BC2709EndToEndTest () {
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;

  let mainPageFrame = null;
  let common = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe.only('BC2709 TC001: As a broker relevant to a trade I should not receive VC notifications and I should see VC price and I should see lots in the market view when I initiate an RFS that proceeds to a VC', () => {
    let brokerUser = null;
    let nlpTradeUser = null;
    let lpTradeUser = null;

    let nlpTradeClient = null;
    let lpTradeClient = null;

    let strategyId = null;
    let strategyFound = false;
    let strategyRow = null;
    let rfsWindow = null;

    const sellPrice = 105;
    const buyPrice = 100;
    const amount = 2500;
    const strike001 = 2100;
    const strike002 = 2200;
    const strike003 = 2300;
    const refPrice = 3380;
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, refPrice, 10, POLARITY.positive, null, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', strike001, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', strike002, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', strike003, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', strike002, 1);

    it('Users should login', async () => {
      brokerUser = common.getBroker('AUTBR04');
      nlpTradeUser = common.getTrader('AUTTR10');
      lpTradeUser = common.getTrader('AUTTR01');
      await start(brokerUser);

      nlpTradeClient = new ApiClient(nlpTradeUser);
      lpTradeClient = new ApiClient(lpTradeUser);
      await nlpTradeClient.login();
      await lpTradeClient.login();
    });

    it('I should have a strategy to trade', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('I should initiate an RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.clickMarketViewHeader();
      const table = await mainPageFrame.getMarketViewTab().clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await table.getTableRow(strategy);
      await strategyRow.clickStatus();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();

      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();

      await nlpTradeClient.respondToRFS(strategyId);
      await lpTradeClient.respondToRFS(strategyId);

      logger.info('Clicked request for quotes.');
    });

    it('I should see blue RFS status against the strategy in the market view', async () => {
      const status = await strategyRow.waitUntilStatus('RFS', frameworkConfig.shortTimeout);

      expect(status)
        .to
        .equal(true, 'Strategy status in market view should be RFS');

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
    });

    it('I should see RFS window open', async () => {
      expect(strategyFound).to.equal(true, 'Strategy was not found');
      rfsWindow = new Rfs(context);
      const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();

      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');

      const windowTitle = await rfsWindow.getTitle();
      expect(windowTitle)
        .to
        .equal(rfsWindowTitle, 'RFS window title');

      const delta = await rfsWindow.getDelta();
      expect(delta)
        .to
        .equal(strategy.getDisplayDelta().toString(), 'RFS window delta');

      const ref = await rfsWindow.getRef();
      expect(ref)
        .to
        .equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    it('LP trader should provide a quote', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const msg = await lpTradeClient.rfsQuote(strategyId, buyPrice, sellPrice, amount);

      expect(msg.response[0])
        .to
        .equal('successful', 'RFS quote for user failed');
    });

    it('I should see RFS transition to Trading Phase', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout + frameworkConfig.shortTimeout;
      const tradingPhase = await rfsWindow.waitUntilPhase('TRADING', timeout);

      expect(tradingPhase)
        .to
        .equal(true, 'Expected RFS to be in Trading phase');
    });

    it('I should activate the NLP trader', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const nlpShortCode = nlpTradeUser.leShortCode.concat(' - ', nlpTradeUser.userShortName);
      const ddTrader = rfsWindow.ddActivateUser;
      await ddTrader.setSelected(nlpShortCode);
      await rfsWindow.btnActivateClick();
      await rfsWindow.waitUntilActivatedTraderExists(nlpShortCode);
    });

    it('NLP trader should lift the offer', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const msg = await nlpTradeClient.rfsAccept(strategyId, sellPrice, null, amount);

      expect(msg.response[0])
        .to
        .equal('successful');
    });

    it('I should see RFS window summary page', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const rfsMatched = await rfsWindow.waitUntilRfsMatchesHaveOccurred(frameworkConfig.veryShortTimeout);
      expect(rfsMatched)
        .to
        .equal(true, 'Broker should see rfs summary page');

      const rfsMatchedAmount = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(rfsMatchedAmount)
        .to
        .equal('2500 L', 'Total Amount Matched in RFS');
    });

    it('I should see pink VC status against the strategy in the Market View', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();

      const status = await strategyRow.getStatusText();
      expect(status)
        .to
        .equal('VC', 'Market View Strategy Status');

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.VC_COLOR);
    });

    it('I should see price of the VC against the strategy in the Market View', async () => {
      let price = await strategyRow.getPrices();
      price = parseFloat(price);

      expect(price)
        .to
        .equal(sellPrice, 'Market view strategy price');
    });

    it('I should not be able to open the VC window', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await strategyRow.clickStatus();
      const vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      expect(foundWindow)
        .to
        .equal(false, 'VC window found, VC window should not exist');
    });

    it('I should not see VC notification message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const vcNotification = await notifications.getVC(strategy, '105.000');
      const found = await vcNotification.waitForExist(frameworkConfig.veryShortTimeout);

      expect(found)
        .to
        .equal(false, 'VC notification message should not exist but it does');
    });

    it('I should not see the VC alert toast message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const toastMsg = new ToastNotification(context);
      const vcMesages = await toastMsg.getVcToastMsg('105.000', strategy);

      expect(vcMesages.length)
        .to
        .equal(0, 'Did not expect to find Responder toast message');
    });

    it('I should see total size sold', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();
      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('2500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('2500', 'Market view strategy ask size');
    });

    it('Traders participating in the VC should buy and sell more volume', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const lpAddIntMsg = await lpTradeClient.vcAddInterest(strategyId, 'SELL', 5000);
      const nlpAddIntMsg = await nlpTradeClient.vcAddInterest(strategyId, 'BUY', 3000);

      expect(lpAddIntMsg.response[0])
        .to
        .equal('successful');

      expect(nlpAddIntMsg.response[0])
        .to
        .equal('successful');
    });

    it('I should see total size sold should be updated', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await browser.waitUntil(async () => {
        const bidSize = await strategyRow.getBidSize();


        return bidSize === '5500';
      }, frameworkConfig.shortTimeout);

      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('5500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('5500', 'Market view strategy ask size');
    });

    it('nlp trader should by more volume', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const addIntMsg =  await nlpTradeClient.vcAddInterest(strategyId, 'BUY', 3000);

      expect(addIntMsg.response[0])
        .to
        .equal('successful');
    });

    it('I should see the amount currently traded updated against the strategy in the Market View', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await browser.waitUntil(async () => {
        const bidSize = await strategyRow.getBidSize();


        return bidSize === '7500';
      }, frameworkConfig.shortTimeout);

      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('7500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('7500', 'Market view strategy ask size');
    });

    it('Traders should logout', () => {
      lpTradeClient.logout();
      nlpTradeClient.logout();
    });
  });
});

