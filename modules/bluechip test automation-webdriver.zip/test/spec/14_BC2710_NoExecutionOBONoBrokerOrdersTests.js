import {expect} from 'chai';
import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import TestCommons from '../../lib/TestCommons';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';


describe('BC2710 Brokers can no longer interact with the public Order Book', function BC2710Test () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser)
      .to
      .exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  const strike = 2500;
  const delta = 100;
  const higherStrike = 2600;
  const rollStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.roll, null, null, null, null, null, null);
  rollStrategy.addLeg(POLARITY.positive, null, 'MAR20', null, null);
  rollStrategy.addLeg(POLARITY.negative, null, 'JUN20', null, null);

  const jellyStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.jellyRoll, STYLE.euro, null, null, null, null, null);
  jellyStrategy.addLeg(POLARITY.positive, 'C', 'DEC25', strike, 1);
  jellyStrategy.addLeg(POLARITY.negative, 'P', 'DEC25', strike, 1);
  jellyStrategy.addLeg(POLARITY.negative, 'C', 'DEC26', strike, 1);
  jellyStrategy.addLeg(POLARITY.positive, 'P', 'DEC26', strike, 1);

  const synthStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.syntheticPplus, STYLE.euro, strike, delta, POLARITY.positive, null, null);
  synthStrategy.addLeg(POLARITY.negative, 'C', 'DEC25', higherStrike, 1);
  synthStrategy.addLeg(POLARITY.positive, 'P', 'DEC25', higherStrike, 1);

  describe('BC2710 TC001: for ROLL strategy', () => {
    let trader1 = null;
    let trader2 = null;
    let broker1 = null;

    it('Setup', async () => {
      trader1 = await common.getTrader('AUTTR01');
      trader2 = await common.getTrader('AUTTR07');
      broker1 = await common.getBroker('AUTBR04');
    });

    it('should be visible to the trader that creates it', async () => {
      await start(trader1);
      logger.info(`Logged in with user ${trader1.email}.`);

      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = mainPageFrame.getCreateStrategyTab();

      await strategyTab.addNewStrategy(rollStrategy);
      await strategyTab.btnSubmitClick();
      const found = await common.waitUntilStrategyFound(rollStrategy, frameworkConfig.shortTimeout, MarketViewTabs.DELTA_ONE);

      expect(found)
        .to
        .be
        .true;
    });

    it('should be visible to other traders', async () => {
      await start(trader2);
      logger.info(`Logged in with user ${trader2.email}.`);

      const strategyId = await common.getStrategyId(rollStrategy, MarketViewTabs.DELTA_ONE);

      expect(strategyId > 0)
        .to
        .equal(true, 'I should be able to see the strategy already created');
    });

    it('should not be visible to brokers', async () => {
      await start(broker1);
      logger.info(`Logged in with user ${broker1.email}.`);

      const strategyId = await common.getStrategyId(rollStrategy, MarketViewTabs.DELTA_ONE);
      expect(strategyId > 0)
        .to
        .equal(false, 'I should not be able to see the strategy already created');
    });
  });

  describe('BC2710 TC002: for JELLY ROLL strategy', () => {
    let trader1 = {};
    let trader2 = {};
    let broker1 = {};

    it('Setup', async () => {
      trader1 = await common.getTrader('AUTTR01');
      trader2 = await common.getTrader('AUTTR07');
      broker1 = await common.getBroker('AUTBR04');
    });

    it('should be visible to the trader that creates it', async () => {
      await start(trader1);
      logger.info(`Logged in with user ${trader1.email}.`);

      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = mainPageFrame.getCreateStrategyTab();

      await strategyTab.addNewStrategy(jellyStrategy);
      await strategyTab.btnSubmitClick();

      const found = await common.waitUntilStrategyFound(jellyStrategy, frameworkConfig.shortTimeout, MarketViewTabs.DELTA_ONE);
      expect(found)
        .to
        .be
        .true;
    });

    it('should be visible to other traders', async () => {
      await start(trader2);
      logger.info(`Logged in with user ${trader2.email}.`);

      const strategyId = await common.getStrategyId(jellyStrategy, MarketViewTabs.DELTA_ONE);
      expect(strategyId > 0)
        .to
        .equal(true, 'I should be able to see the strategy already created');
    });

    it('should not be visible to brokers', async () => {
      await start(broker1);
      logger.info(`Logged in with user ${broker1.email}.`);

      const strategyId = await common.getStrategyId(jellyStrategy, MarketViewTabs.DELTA_ONE);
      expect(strategyId > 0)
        .to
        .equal(false, 'I should not be able to see the strategy already created');
    });
  });

  describe('BC2710 TC003: for SYNTHETIC strategy', () => {
    let trader1 = {};
    let trader2 = {};
    let broker1 = {};

    it('Setup', async () => {
      trader1 = await common.getTrader('AUTTR01');
      trader2 = await common.getTrader('AUTTR07');
      broker1 = await common.getBroker('AUTBR04');
    });

    it('should be visible to the trader that creates it', async () => {
      await start(trader1);
      logger.info(`Logged in with user ${trader1.email}.`);

      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = mainPageFrame.getCreateStrategyTab();

      await strategyTab.addNewStrategy(synthStrategy);
      await strategyTab.btnSubmitClick();

      const found = await common.waitUntilStrategyFound(synthStrategy, frameworkConfig.shortTimeout, MarketViewTabs.DELTA_ONE);
      expect(found)
        .to
        .be
        .true;
    });

    it('should be visible to other traders', async () => {
      await start(trader2);
      logger.info(`Logged in with user ${trader2.email}.`);

      const strategyId = await common.getStrategyId(synthStrategy, MarketViewTabs.DELTA_ONE);
      expect(strategyId > 0)
        .to
        .equal(true, 'I should be able to see the strategy already created');
    });

    it('should not be visible to brokers', async () => {
      await start(broker1);
      logger.info(`Logged in with user ${broker1.email}.`);

      const strategyId = await common.getStrategyId(synthStrategy, MarketViewTabs.DELTA_ONE);
      expect(strategyId > 0)
        .to
        .equal(false, 'I should not be able to see the strategy already created');
    });
  });
});
