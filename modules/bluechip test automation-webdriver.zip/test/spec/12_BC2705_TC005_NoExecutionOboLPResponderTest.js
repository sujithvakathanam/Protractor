import Strategy from '../../lib/Strategy';
import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import {expect} from 'chai';
import ApiClient from '../../utilities/api/ApiClient';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';


// Framwework vars
const browser = global.browser;
let bootstrapper = null;
let context = null;
let logger = null;

// Page object vars
let mainPageFrame = null;
let common = null;

before(() => {
  bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
  context = bootstrapper.getInstance();
  logger = context.getLogger();
  logger.info('Framework setup complete.');

  // Page object  setup.
  common = new TestCommons(context);

  expect(browser).to.exist;
});

after(() => {
  const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
  shellExec(clearDownScript);
});

async function start ({email, password}) {
  mainPageFrame = await common.login(email, password);
}

describe('BC2705 TC005: As a LP trader who is participating in an OBO RFS without interest my quote should not match a quote from a NLP trader in the same legal entity', () => {
  let broker = null;
  let brokerClient = null;
  let lpTraderOne = null;
  let nlpTraderOne = null;
  let nlpTraderOneClient = null;
  let strategyId = null;
  let rfsWindow = null;

  const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 2000, 300, POLARITY.positive, null, null);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 700, null);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2100, null);

  it('Should get the test users', () => {
    broker = common.getBroker('AUTBR03');
    lpTraderOne = common.getTrader('AUTTR05');
    nlpTraderOne = common.getTrader('AUTTR06');
  });

  it('The broker should have a strategy to trade', async () => {
    await start(broker);
    strategyId = await common.getStrategyId(strategy);
    if (strategyId === null) {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmit.click();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
    }
    const hasStrategyId = strategyId !== null;
    expect(hasStrategyId).to.equal(true, 'Could not find strategy');
  });

  it('Test users should login', async () => {
    await start(lpTraderOne);
    brokerClient = new ApiClient(broker);
    await brokerClient.login();
    nlpTraderOneClient = new ApiClient(nlpTraderOne);
    await nlpTraderOneClient.login();
  });

  it('I should open the RFS window', async () => {
    await mainPageFrame.switchToWindow();
    const marketView = mainPageFrame.getMarketViewTab();
    await marketView.clickTabEuroStoxx();
    await brokerClient.initiateRFS(strategyId);
    await nlpTraderOneClient.respondToRFS(strategyId);
    await common.waitUntilStrategyFound(strategy);
    const strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
    await strategyRow.waitUntilStatus('RFS');
    await strategyRow.clickStatus();
    rfsWindow = await new Rfs(context);
    const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
    expect(foundWindow).to.equal(true, 'Expected to find the RFS window');
  });

  it('I should respond to the RFS with a quote', async () => {
    await rfsWindow.quote('2120', '2130', 2500);
    const inLitPhase = await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
    expect(inLitPhase).to.equal(true, 'RFS should of transitioned to the LIT phase');
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    await bidOfferRow.waitUntilPrice('2120.000', '2130.000');
  });

  it('I should wait for the RFS to transition to trading phase', async () => {
    const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout;
    await rfsWindow.waitUntilPhase('TRADING', timeout);
    const phase = await rfsWindow.getPhase();
    expect(phase).to.equal('TRADING', 'RFS should be in trading phase');
  });

  it('The broker should activate NLP trader', async () => {
    const msg = await brokerClient.rfsSelectTrader(strategyId, nlpTraderOne.userShortName);
    const myTrader = msg.response.filter(trader => trader.code === nlpTraderOne.userShortName);

    expect(myTrader[0].activated)
      .to
      .equal(true, 'User activated is false, expected true');
  });

  it('NLP trader should now be activated', async () => {
    const activated = await browser.waitUntil(() => nlpTraderOneClient.userActivated(strategyId), frameworkConfig.shortTimeout);
    expect(activated)
      .to
      .equal(true, 'User was not activated');
  });

  it('NLP trader should respond to the RFS with a quote', async () => {
    const msg = await nlpTraderOneClient.rfsQuote(strategyId, '2130', '2140', 2500);

    expect(msg.response[0])
      .to
      .equal('successful');
  });

  it('LP trader order should not match when ask price matches that of the NLP in the same legal entity', async () => {
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const priceFound = await bidOfferRow.waitUntilPrice('2130.000', '2130.000');
    expect(priceFound).to.equal(true, 'RFS unexpected price displayed');
  });

  it('LP trader should subject his offer', async () => {
    await rfsWindow.btnSubjectClick();
  });

  it('NLP trader should quote best Bid and Ask price', async () => {
    await nlpTraderOneClient.rfsQuote(strategyId, '2140', '2150', 2500);
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const priceFound = await bidOfferRow.waitUntilPrice('2140.000', '2150.000');
    expect(priceFound).to.equal(true, 'RFS unexpected price displayed');
  });

  it('LP trader should not be able to lift or hit quote of an NLP in the same legal entity', async () => {
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    const bidBtnEnabled = await bidOfferRow.isBidPriceBtnEnabled();
    const askBtnEnabled = await bidOfferRow.isAskPriceBtnEnabled();
    expect(bidBtnEnabled).to.equal(false, 'RFS window BID price button should be disabled');
    expect(askBtnEnabled).to.equal(false, 'RFS window ASK price button should be disabled');
  });

  it('I should see RFS end without a match', async () => {
    const foundRfsTimedOutMsg = await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
    expect(foundRfsTimedOutMsg).to.equal(true, 'RFS should of timeout without a match');
  });

  it('Users should logout', async () => {
    await brokerClient.logout();
    await nlpTraderOneClient.logout();
  });
});
