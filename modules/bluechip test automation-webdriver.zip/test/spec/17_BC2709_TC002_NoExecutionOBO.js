import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import TestCommons from '../../lib/TestCommons';
import {shellExec} from '../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import ApiClient from '../../utilities/api/ApiClient';
import {expect} from 'chai';
import Rfs from '../../pages/child_windows/Rfs';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {join} from 'path';

describe('BC2709 TC002: No longer invite Broking Users to participate in a VC instead show size traded so far to relevant brokers', function BC2709EndToEndTest () {
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;

  let common = null;
  let mainPageFrame = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2709 TC002: As a broker relevant to the trade because his desk colleague launched the RFS I should should not receive VC notifications and I should see VC price in the Market View and I should see VC size in the Market View', () => {
    let brokerOne = null;
    let brokerTwo = null;
    let nlpTrader = null;
    let lpTrader = null;

    let brokerTwoClient = null;
    let nlpTradeClient = null;
    let lpTradeClient = null;

    let strategyRow = null;
    let strategyId = null;
    let strategyFound = false;
    const sellPrice = 105;
    const buyPrice = 100;
    const amount = 2500;
    const strike001 = 2100;
    const strike002 = 2200;
    const strike003 = 2300;
    const refPrice = 3000;
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, refPrice, 10, POLARITY.positive, null, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', strike001, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', strike002, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', strike003, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', strike002, 1);

    let rfsNotification = null;
    let rfsWindow = null;

    it('Users should login', async () => {
      brokerOne = common.getBroker('AUTBR03');
      brokerTwo = common.getBroker('AUTBR04');
      nlpTrader = common.getTrader('AUTTR10');
      lpTrader = common.getTrader('AUTTR01');

      brokerTwoClient = new ApiClient(brokerTwo);
      nlpTradeClient = new ApiClient(nlpTrader);
      lpTradeClient = new ApiClient(lpTrader);

      await start(brokerOne);
      await brokerTwoClient.login();
      await nlpTradeClient.login();
      await lpTradeClient.login();
    });

    it('I should have a strategy to trade', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('My broker colleague should launch an RFS on the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy ID could not be found');

      await brokerTwoClient.initiateRFS(strategyId);
      await nlpTradeClient.respondToRFS(strategyId);
      await lpTradeClient.respondToRFS(strategyId);
    });

    it('I should see blue RFS status against the strategy in the Market View', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.clickMarketViewHeader();
      const table = await mainPageFrame.getMarketViewTab().clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await table.getTableRow(strategy);
      const statusVC = await strategyRow.waitUntilStatus('RFS', frameworkConfig.shortTimeout);

      expect(statusVC)
        .to
        .equal(true, 'Strategy status should be RFS but is not');
    });

    it('When I click on the Request for quotes button I should see a message stating RFS is running on the strategy', async () => {
      await strategyRow.clickStatus();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();

      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab was not enabled');

      await marketDepth.clickRequestQuotesBtn();
      const rfsOngoing = await browser.waitUntil(() => marketDepth.onGoingRfsMsgExists(), frameworkConfig.veryShortTimeout);

      expect(rfsOngoing)
        .to
        .equal(true, 'Market Depth did not show "There is an ongoing RFS in this strategy" message');

      await marketDepth.clickOkBtn();
      const rfsBtnExists = await marketDepth.requestQuotesBtnExists();

      expect(rfsBtnExists)
        .to
        .equal(true, 'Request for quotes button should be displayed but it could not be found.');
    });

    it('I should see a notification for the RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      rfsNotification = await notifications.getRfsResponderInvite(strategy);
      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);

      expect(found)
        .to
        .equal(true, 'RFS notification message should exist but it does not');
    });

    it('LP Trader should respond to the RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const quoteMsg = await lpTradeClient.rfsQuote(strategyId, buyPrice, sellPrice, amount);
      expect(quoteMsg.response[0])
        .to
        .equal('successful', 'LP trader did was unable to quote inside the timeout period');
    });

    it('RFS window should open when I click on the RFS notification', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await rfsNotification.clickOnNotification();

      rfsWindow = new Rfs(context);
      const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');

      const windowTitle = await rfsWindow.getTitle();
      expect(windowTitle)
        .to
        .equal(rfsWindowTitle, 'RFS window title');

      const delta = await rfsWindow.getDelta();
      expect(delta)
        .to
        .equal(strategy.getDisplayDelta().toString(), 'RFS window delta');

      const ref = await rfsWindow.getRef();
      expect(ref)
        .to
        .equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    it('I should see 1 responder to the RFS in the dark period', async () => {
      const responded = await rfsWindow.getResponded();

      expect(responded)
        .to
        .include('1/', 'RFS window expected one rfs participants');
    });

    it('I should see the spread in the LIT phase of the RFS', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const currentSpread = await rfsWindow.getCurrentSpread();
      const darkSpread = await rfsWindow.getDarkSpread();

      expect(currentSpread)
        .to
        .equal('5.00', 'RFS current spread');

      expect(darkSpread)
        .to
        .equal('5.00', 'RFS dark spread');
    });

    it('I should see the price in the trading phase', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.darkPhaseTimeout);
      const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);
      const askSize = await bidOfferRowOne.getAskSize();
      const askPrice = await bidOfferRowOne.getAskPrice();
      const bidSize = await bidOfferRowOne.getBidSize();
      const bidPrice = await bidOfferRowOne.getBidPrice();

      expect(askSize)
        .to
        .equal('2500', 'RFS ask size');

      expect(askPrice)
        .to
        .equal('105.000', 'RFS top of market ask');

      expect(bidSize)
        .to
        .equal('2500', 'RFS bid size');

      expect(bidPrice)
        .to
        .equal('100.000', 'RFS top of market bid');
    });

    it('Broker colleague should enable NLP trader in the trading phase', async () => {
      await brokerTwoClient.rfsSelectTrader(strategyId, nlpTrader.userShortName);
    });

    it('NLP trader should lift or hit the offer', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await browser.waitUntil(() => nlpTradeClient.userActivated(strategyId), frameworkConfig.shortTimeout);

      const rfsAcceptMsg = await nlpTradeClient.rfsAccept(strategyId, sellPrice, null, amount);
      expect(rfsAcceptMsg.response[0])
        .to
        .equal('successful', 'Expected RFS to be accepted');
    });

    it('I should see rfs summary', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const rfsMatched = await rfsWindow.waitUntilRfsMatchesHaveOccurred(frameworkConfig.veryShortTimeout);

      expect(rfsMatched)
        .to
        .equal(true, 'Broker should see rfs summary page');

      const rfsMatchedAmount = await rfsWindow.getSummaryTotalMatchedInRFS();

      expect(rfsMatchedAmount)
        .to
        .equal('2500 L', 'Total Amount Matched in RFS');
    });

    it('I should see Strategy status change to Pink VC in the market view table', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();
      const status = await strategyRow.getStatusText();

      expect(status)
        .to
        .equal('VC', 'Market View Strategy Status');

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.VC_COLOR);
    });

    it('I should not see a VC notification alert', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const vcNotification = await notifications.getVC(strategy, '105.000');
      const found = await vcNotification.waitForExist(frameworkConfig.veryShortTimeout);

      expect(found)
        .to
        .equal(false, 'VC notification message should not exist but it does');
    });

    it('I should not see a VC toast message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const toastMsg = new ToastNotification(context);
      const vcMesages = await toastMsg.getVcToastMsg('105.000', strategy);

      expect(vcMesages.length)
        .to
        .equal(0, 'Did not expect to find Responder toast message');
    });

    it('I should see VC bid and size shown against the strategy in the market view', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();
      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('2500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('2500', 'Market view strategy ask size');
    });

    it('Traders should add more volume in the VC', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const sellInterest = 5000;
      const buyInterest = 3000;
      const lpInterest = await lpTradeClient.vcAddInterest(strategyId, 'SELL', sellInterest);
      const nlpInterest = await nlpTradeClient.vcAddInterest(strategyId, 'BUY', buyInterest);

      expect(lpInterest.response[0])
        .to
        .equal('successful', 'LP user should add VC interest');

      expect(nlpInterest.response[0])
        .to
        .equal('successful', 'NLP user should add VC interest');
    });

    it('I should see bid and size updated against the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await browser.waitUntil(async () => {
        const bidSize = await strategyRow.getBidSize();

        return bidSize === '5500';
      }, frameworkConfig.shortTimeout);

      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();

      expect(bidSize)
        .to
        .equal('5500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('5500', 'Market view strategy ask size');
    });

    it('I should not be able to open a VC window', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await strategyRow.clickStatus();
      const vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      expect(foundWindow)
        .to
        .equal(false, 'VC window found, VC window should not exist');
    });

    /*
     *Todo improvement, check market depth and end of VC to see if size volume displayed correctly
     *Todo improvement, check colours of size and price against strategy in marketview.
     */

    it('User should logout', () => {
      brokerTwoClient.logout();
      nlpTradeClient.logout();
      lpTradeClient.logout();
    });
  });
});

