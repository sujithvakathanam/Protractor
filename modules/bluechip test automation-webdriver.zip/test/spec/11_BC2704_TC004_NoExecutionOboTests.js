/* eslint-disable max-lines,max-statements */
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, UNDERLYING, STRATEGY, POLARITY, STYLE, OPTION_TYPE} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';

describe('BC2704 OBO RFS Tests', function BC2704EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let common = null;
  let mainPageFrame = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
    logger.info(browser.sessionId);
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2704 TC004: As a broker, if I initiate an RFS which ends without a trade then a RFS timed out summary message should be displayed', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 125, 33, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 200, 2);
    /* eslint-enable no-magic-numbers */

    let strategyId = null;
    let broker = {};

    it('Broker should login', async () => {
      broker = common.getBroker('AUTBR04');
      await start(broker);
    });

    it('Broker should have a strategy to trade', async () => {
      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmitClick();
        const strategyFound = await common.waitUntilStrategyFound(strategy);
        if (strategyFound) {
          strategyId = await common.getStrategyId(strategy);
        }
      }
      const strategyExist = strategyId !== null;
      expect(strategyExist).to.equal(true, 'Could not find Strategy.');
    });

    it('Broker should initiate an RFS', async () => {
      await mainPageFrame.clickMarketViewHeader();
      const strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(strategy);
      await strategyRow.clickStatus();
      logger.info('Found newly created strategy in Market View.');

      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled).to.equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();
      logger.info('Clicked request for quotes.');
    });

    it('RFS window should display RFS timed out summary message', async () => {
      const rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);
      const darkPhase = await rfsWindow.waitUntilPhase('DARK', frameworkConfig.shortTimeout);
      expect(darkPhase).to.equal(true, 'RFS should be in DARK phase');
      const litPhase = await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      expect(litPhase).to.equal(true, 'RFS should be in LIT phase');
      const tradingPhase = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      expect(tradingPhase).to.equal(true, 'RFS should be in TRADING phase');
      const summaryTimeout = frameworkConfig.tradePhaseTimeout + frameworkConfig.shortTimeout;
      const rfsTimedOut = await rfsWindow.waitUntilRfsTimedout(summaryTimeout);
      expect(rfsTimedOut).to.equal(true, 'RFS should of timed out');
    });
  });
});
