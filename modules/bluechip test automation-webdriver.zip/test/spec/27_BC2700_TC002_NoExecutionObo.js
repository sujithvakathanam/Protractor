import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {expect} from 'chai';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';

describe('BC2700 Tidy up of Obo Broker', function bc2700EndToEndTest () {
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;

  let mainPageFrame = null;
  let common = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2700 TC002: As a broker I should no longer be able to view matched trades orders', () => {
    let brokerUser = null;

    it('I should login', async () => {
      brokerUser = common.getUser('AUTBR07');
      await start(brokerUser);
      const loggedInUser = await mainPageFrame.getUsername();
      expect(loggedInUser)
        .to
        .equal(brokerUser.fenicsGoUsername, 'Logged in user id');
    });

    it('I should not be able see "MATCHED TRADES" tab in the market view', async () => {
      const matchedPageTabExists = await mainPageFrame.matchedTradesTabExists();
      expect(matchedPageTabExists)
        .to
        .equal(false, 'Broker should not be able to see the Matched Trades tab');
    });
  });
});
