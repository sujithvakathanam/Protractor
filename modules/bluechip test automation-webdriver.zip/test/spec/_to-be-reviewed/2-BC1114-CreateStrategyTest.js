import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import {expect} from 'chai';
import Strategy from '../../../lib/Strategy';
import {shellExec} from '../../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import {MARKET, UNDERLYING, STRATEGY, POLARITY, STYLE} from '../../../constant/GenericType';
import MarketViewTabs from '../../../constant/MarketViewTabs';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';

describe('BC1114 - Create strategy test suite', function StrategyTests () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let stgyTab = null;
  const common = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);

    expect(browser).to.exist;
  });

  after(() => {
    common.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  this.timeout(frameworkConfig.testMaxTime);

  async function start (username, password) {
    await common.login(username, password);
    stgyTab = mainPageFrame.getCreateStrategyTab();
  }

  describe('Test 1: As a broker user I want to associate trade user with a strategy', function BC1114Test2 () {
    let broker = null;

    it('Should load blue chip page and login as broker', async () => {
      broker = await common.getBroker('AUTBR03');
      await start(broker.email, broker.password);
      logger.info(`Logged in with user ${broker.email}.`);
      expect(await mainPageFrame.getUsername()).to.equal(broker.fenicsGoUsername, 'Expected to find username of logged in user main page');
    });

    it('Should allow broker to associate trading user with strategy', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      logger.info('Navigated to Create Strategy page.');
      const newStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, null, null, null, null, null, 'CEA - TR02');
      await stgyTab.addNewStrategy(newStrategy);
      logger.info(`Selected Call Calendar strategy ${STRATEGY.callCalendar.name}.`);
      const user = await stgyTab.associatedTradingUser.getSelected();
      expect(user).to.equal(newStrategy.tradingUser);
    });

    it('Associate Trading User drop down list should contain users the broker is authorised to represent', async () => {
      const traders = await stgyTab.associatedTradingUser.getSelections();
      expect(traders[0]).to.equal('Select Trading User', 'Unexpected value found in Associated Trading User drop down list');
      expect(traders[1]).to.equal('CEA - TR02', 'Unexpected value found in Associated Trading User drop down list');
      expect(traders[2]).to.equal('DEA - TR06', 'Unexpected value found in Associated Trading User drop down list');
      expect(traders[3]).to.equal('DEA - TR07', 'Unexpected value found in Associated Trading User drop down list');
      expect(traders.length).to.equal(4, 'Unexpectd number of traders found in Associated Trading User drop down list');
      logger.info(traders);
    });
  });

  describe('Test 2: As a broker user I should not be able to create Order Book protocol strategies', function BC1114Test3 () {
    let broker = null;

    it('Broker should login and get strategy list ', async () => {
      broker = await common.getBroker('AUTBR03');
      await start(broker.email, broker.password);
      await mainPageFrame.clickCreateStrategyHeader();
      const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, null, null, null, null, null, null, null);
      await stgyTab.addNewStrategy(strategy);
    });

    it('Roll should not be visible in the Strategy drop down', async () => {
      const foundStrategy = await stgyTab.hasStrategy(STRATEGY.roll.name);
      expect(foundStrategy).to.equal(false, 'Found ROLL in strategy type list, Broker should not be able to create Order Book type strategies');
    });

    it('Jelly Rolls should not be visible in the Strategy drop down ', async () => {
      const foundStrategy = await stgyTab.hasStrategy(STRATEGY.jellyRoll.name);
      expect(foundStrategy).to.equal(false, 'Found JROLL in strategy type list, Broker should not be able to create Order Book type strategies');
    });

    it('Synthetics should not be visible in the Strategy drop down ', async () => {
      const foundStrategy = await stgyTab.hasStrategy(STRATEGY.synthetic.name);
      expect(foundStrategy).to.equal(false, 'Found SYN P+ in strategy type list, Broker should not be able to create Order Book type strategies');
    });
  });

  describe('Test 3: As as application user I should be able to see the Create Strategy Tab', function BC1114Test4 () {
    describe('Test 3.1: A LP trader User should be able to access create strategy tab', () => {
      it('LP trader should login', async () => {
        const trader = common.getTrader('AUTTR04');
        await start(trader.email, trader.password);
      });

      it('LP trader should be able to access the create startegy tab', async () => {
        await mainPageFrame.clickCreateStrategyHeader();
        expect(await stgyTab.pageHasLoaded()).to.equal(true, 'Expected to be on the create strategy tab but could not locate element on page');
      });
    });

    describe('Test 3.2: A NLP trader should be able to access create strategy tab', () => {
      it('NLP trader should login', async () => {
        const trader = common.getTrader('AUTTR06');
        await start(trader.email, trader.password);
      });

      it('NLP trader should be able to access the create startegy tab', async () => {
        await mainPageFrame.clickCreateStrategyHeader();
        expect(await stgyTab.pageHasLoaded()).to.equal(true, 'Expected to be on the create strategy tab but could not locate element on page');
      });
    });

    describe('Test 3.2: A broker should be able to access create strategy tab', () => {
      // Place holder covered by Test 1
    });
  });

  describe('Test 4: As a broker when I create a new strategy with RFS protocol it should only be visible to me and my desk', function BC1114Test81 () {
    let strategyId = 0;
    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 841, 15, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 2500, null);

    it('Broker should login', async () => {
      const broker = await common.getBroker('AUTBR03');
      await start(broker.email, broker.password);
    });

    it('Strategy should be visible to me', async () => {
      strategy = await common.makeNewStrategy(strategy);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
      expect(strategyId > 0).to.equal(true, 'I should be able to see the strategy I created');
    });

    it('Strategy should be visible to my desk colleague', async () => {
      const myDeskBroker = await common.getBroker('AUTBR04');
      await start(myDeskBroker.email, myDeskBroker.password);
      expect(await common.getStrategyId(strategy)).to.equal(strategyId, 'My broker desk colleague should be able to see the new strategy');
    });

    it('Strategy should not be visible to a broker who is not a member of my desk', async () => {
      const cpBroker = await common.getBroker('AUTBR06');
      await start(cpBroker.email, cpBroker.password);
      expect(await common.getStrategyId(strategy)).to.equal(null, 'A counterparty broker who is not member of my desk should not see the new strategy');
    });

    it('should not be visible to a trader who is not a member of my desk', async () => {
      const trader = await common.getTrader('AUTTR02');
      await start(trader.email, trader.password);
      expect(await common.getStrategyId(strategy)).to.equal(null, 'A trader who is not a member of my desk should not see the new strategy');
    });
  });

  describe('Test 5: As a trader when I create a new strategy with RFS protocol it should only be visible to me and my desk', function BC1114Test82 () {
    // Get strike prices for product builder service.
    let strategyId = null;
    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 850, 3, POLARITY.positive, null, null);
    strategy.addLeg(null, null, 'DEC25', 2025, null);
    strategy.addLeg(null, null, null, 2050, null);
    strategy.addLeg(null, null, null, 2100, null);

    it('should be visible to me', async () => {
      const trader = common.getTrader('AUTTR04');
      await start(trader.email, trader.password);
      strategy = await common.makeNewStrategy(strategy);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
      expect(strategyId > 0).to.equal(true, 'I should see the strategy I created');
    });

    it('should be visible to my colleague', async () => {
      const myDeskTrader = common.getTrader('AUTTR05');
      await start(myDeskTrader.email, myDeskTrader.password);
      expect(await common.getStrategyId(strategy)).to.equal(strategyId, 'My desk colleague should see the strategy I created');
    });

    it('should not be visible to a broker', async () => {
      const broker = await common.getBroker('AUTBR04');
      await start(broker.email, broker.password);
      expect(await common.getStrategyId(strategy)).to.equal(null, 'My broker should not see the strategy I created');
    });

    it('should not be visible to a trader who is not a member of my desk', async () => {
      const cpTrader = common.getTrader('AUTTR06');
      await start(cpTrader.email, cpTrader.password);
      expect(await common.getStrategyId(strategy)).to.equal(null, 'Traders that do not belong to my desk should not see the strategy');
    });
  });

  describe.skip('As a broker when I create a new strategy and launch RFS then the strategy will be visible to all users', function BC1114Test83 () {
    // Users with permissions to trade on market segment -  BC-2120 To be implemented with RFS tests.

  });

  describe.skip('As a trader when I create a new strategy and launch RFS then the strategy will be visible all users', function BC1114Test84 () {
    // Users with permissions to trade on market segment. - BC-2121 To be implemented with RFS test
  });

  describe('Test 6: As as broker if i try to create a strategy that already exists for another trader or broker then the strategy will be added to my market view', function BC1114Test92 () {
    let strategyId = null;
    let trader = null;
    let broker = null;
    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 21, 15, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 2500, null);

    it('Trader should create a new strategy', async () => {
      trader = common.getTrader('AUTTR04');
      await start(trader.email, trader.password);
      strategyId = await common.getStrategyId(strategy);
      strategy = await common.makeNewStrategy(strategy);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      const foundStrategy = await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
      expect(foundStrategy).to.be.true;
    });

    it('Strategy should not be visible to the broker', async () => {
      broker = await common.getBroker('AUTBR04');
      await start(broker.email, broker.password);
      const foundStgy = await common.getStrategyId(strategy);
      expect(foundStgy === null).to.equal(true, 'Found strategy, strategy should not exist for Broker user.');
    });

    it('Broker should see strategy in the market view after he creates the strategy', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      await common.waitUntilStrategyFound(strategy, frameworkConfig.shortTimeout);
      const foundStgy = await common.getStrategyId(strategy);
      expect(strategyId).to.equal(foundStgy);
    });
  });

  describe('Test 7: As a trader if i try to create a strategy that already exists and I do not have access to the strategy then it will be added to my Market View', function BC1114Test93 () {
    let strategyId = null;
    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 300, 15, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.positive, 'P', 'DEC25', 3500, 1);
    strategy.addLeg(POLARITY.negative, 'P', null, 3000, 2);
    strategy.addLeg(POLARITY.positive, 'P', null, 2600, 1);

    it('The strategy should already exist for the broker', async () => {
      const broker = await common.getBroker('AUTBR04');
      await start(broker.email, broker.password);
      strategy = await common.makeNewStrategy(strategy);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      await common.waitUntilStrategyFound(strategy, frameworkConfig.shortTimeout);
      strategyId = await common.getStrategyId(strategy);
      expect(strategyId === null).to.equal(false, 'Expected to find strategy');
    });

    it('should be shown in the traders market view tab when the trader adds the strategy', async () => {
      await common.logout();
      const trader = await common.getTrader('AUTTR04');
      await start(trader.email, trader.password);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();
      await common.waitUntilStrategyFound(strategy);
      const foundStgy = await common.getStrategyId(strategy);
      expect(foundStgy).to.equal(strategyId, 'I should see the strategy');
    });

    it('should be shown in market view tab for traders on my desk', async () => {
      const myDeskTrader = await common.getTrader('AUTTR04');
      await start(myDeskTrader.email, myDeskTrader.password);
      expect(await common.getStrategyId(strategy)).to.equal(strategyId, 'A trader who is a member of my desk should see the strategy');
    });
  });

  describe.skip('Test 8: As a user when I create a new strategy I should be shown a recommended delta', () => {
    // Blocked due to defect BC-2990
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 275, null, POLARITY.positive, null, null);
    let deltaValue = null;
    strategy.addLeg(null, null, 'DEC22', 300, null);
    strategy.addLeg(null, null, null, 225, null);

    it('Trader should login and enter strategy details', async () => {
      const trader = common.getTrader('AUTTR04');
      await start(trader.email, trader.password);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
    });

    it('Trader should see suggested delta value added to the delta field', async () => {
      deltaValue = await stgyTab.deltaValue;
      expect(deltaValue >= 0 && deltaValue <= 100).to.equal(true, 'Delta:- suggested value should be between 0 and 100');
    });

    it('Trader should be able to override the suggested delta value', async () => {
      await stgyTab.setDeltaValue(97);
    });

    it('Trader should see delta warning message', () => {
      // Updated when you have the warning message.
      const warningMessage = '';
      expect(warningMessage).to.equal('Message');
    });
  });

  describe(' TODO Test 9: As a user when I create a new strategy I should be shown a leg price', async () => {
    // Blocked due to defect bc-2993
  });

  describe('Create roll strategy', () => {
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.roll, null, null, null, null, null, null);
    strategy.addLeg(POLARITY.positive, null, 'DEC20', null, null);
    strategy.addLeg(POLARITY.negative, null, 'MAR21', null, null);

    it('should create a strategy, which should appear in the DELTA ONE view', async () => {
      const trader = common.getTrader('AUTTR04');
      await start(trader.email, trader.password);
      await mainPageFrame.clickCreateStrategyHeader();
      await stgyTab.addNewStrategy(strategy);
      await stgyTab.btnSubmitClick();

      const found = await common.waitUntilStrategyFound(strategy, frameworkConfig.shortTimeout, MarketViewTabs.DELTA_ONE);
      expect(found).to.be.true;
    });
  });
});
