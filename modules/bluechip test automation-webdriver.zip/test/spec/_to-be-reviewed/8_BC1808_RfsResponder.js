/* eslint-disable */
describe('As a trader I should be invited to an RFS initiated by a trader in the same market segment', async function BC1808ResponderTest2() {
});

describe('As a trader I should be invited to an RFS initiated by a broker in the same market segment', async function BC1808ResponderTest3 () {
});

describe('As a trader I should not be able to trade on an RFS in which a broker has already responded on my behalf', async function BC1808ResponderTest4 () {
});

describe('As a trader I should be able to respond to the RFS and quote', async function BC1808ResponderTest1 () {
});
