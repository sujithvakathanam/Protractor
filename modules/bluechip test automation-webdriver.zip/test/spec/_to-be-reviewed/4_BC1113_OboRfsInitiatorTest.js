import StartUp from '../pages/StartUp';
import {hasTabOpen, switchToTab} from '../../../utilities/webdriverHelper/tabsHelper';
import {shellExec} from '../../../utilities/framework/shell-exec';
import UserLogin from '../../../pages/UserLogin';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import {Bootstrap} from '@fenics/fenics-test-core';
import Rfs from '../../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Instrument from '../lib/Instrument';
import {UNDERLYING} from '../../../constant/GenericType';
import ApiClient from '../../../utilities/api/ApiClient';
import {usersConfig} from '../../../config/users.config';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';

describe('BC-1113 OBO RFS Initiator Test suite', function rfsInitiatorTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let startUp = null;
  let userLogin = null;
  let mainPageFrame = null;
  let rfsWindow = null;

  let traderApi = null;
  const broker = usersConfig.brokers[0];
  let isLoggedOut = true;
  let firstTime = true;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    startUp = new StartUp(context);
    userLogin = new UserLogin(context);
    rfsWindow = new Rfs(context);

    expect(browser).to.exist;
  });

  after(() => {
    traderApi.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  this.timeout(frameworkConfig.testMaxTime);

  async function logout () {
    await mainPageFrame.clickLogout();
    await mainPageFrame.clickLogoutConfirmOk();
    isLoggedOut = true;
  }

  async function login (username, password) {
    if (firstTime) {
      traderApi = new ApiClient();
      await browser.waitUntil(() => hasTabOpen(browser, 'FenicsGO'), frameworkConfig.shortTimeout);
      firstTime = false;
    }
    if (!isLoggedOut) {
      await logout();
    }
    await startUp.clickLogin();
    await userLogin.login(username, password);
    isLoggedOut = false;
  }


  describe('As Broker user I should be able to initiate RFS on an authorised strategy', function BC1113Test111 () {
    it('Should be logged in', async () => {
      await login(broker.username, broker.password);
      const user = await mainPageFrame.getUsername();
      expect(user).to.equal(broker.username, 'Application logged in user');
    });

    it('Should enable the Request for Quotes button', async () => {
      const inst = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '275', null, null, null, '101', '222', null);
      await mainPageFrame.clickMarketViewHeader();
      await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst);
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.setTradingUserDD('LP01 - L1U0');
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled).to.equal(true, 'Request quotes button on Market Depth Tab');
    });
  });

  describe('As a Broker user I should not be able to initiate an RFS on a strategy that is not authorised', function BC1113Test12 () {
    // More detail required on how to create this scenario
    it('Should be logged in', async () => {
      await login(broker.username, broker.password);
      const user = await mainPageFrame.getUsername();
      expect(user).to.equal(broker.username, 'Application logged in user');
    });
  });

  describe('As a Broker I should be able to initiate an RFS on behalf of an associated trader', function BC1113Test2 () {
    // Covers test 2, 3 and 4.
    const inst = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '275', null, null, null, '101', '222', null);
    let mainWh = null;
    let rfsWh = null;

    it('Should be logged in', async () => {
      await login(broker.username, broker.password);
      const user = await mainPageFrame.getUsername();
      expect(user).to.equal(broker.username, 'Application logged in user');
    });

    it('RFS, Should be initiated', async () => {
      mainWh = await browser.getCurrentTabId();
      await mainPageFrame.clickMarketViewHeader();
      await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst);
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();

      // Await marketDepth.setTradingUserDD('LP01 - L1U0');
      await marketDepth.clickRequestQuotesBtn();
      await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'), frameworkConfig.shortTimeout);
      rfsWh = await browser.getCurrentTabId();
      const rfsTitle = await rfsWindow.getTitle();
      const windowLetter = await rfsWindow.getWindowLeter();
      const underlying = await rfsWindow.getUnderlying();
      expect(rfsTitle).to.equal(`${inst.strategy} ${inst.expiry}`, 'RFS window title did not match expected');
      expect(windowLetter).to.equal('Q', 'RFS window identifier letter');
      expect(underlying).to.equal(UNDERLYING.sx5e, 'RFS window underlying value');
    });

    it('Should show trading users details at the bottom of the RFS window', async () => {
      const traderShortName = await rfsWindow.getBrokerTradingUser();
      expect(traderShortName).to.equal('L1U0 - LP01', 'RFS broker trading on behalf of user');
    });

    it('Should show tool tip when I hover over the username', async () => {
      const traderFullName = await rfsWindow.getBrokerTradingUserFullText();
      expect(traderFullName).to.equal('LP01 U10 - LP01D01 - LP01', 'RFS trading username mouseover tooltip');
    });

    it('Should display a RFS initiator notification message', async () => {
      await browser.switchTab(mainWh);
      const notificationTitle = `${inst.strategy} ${inst.expiry}`;
      const notification = await mainPageFrame.notificationsPanel
        .notifications
        .getRfsInitiator(notificationTitle, inst.strikes, inst.underlying);
      const found = await notification.waitForExist();
      expect(found).to.be.equal(true, 'Found RFS Initiator notification message');
      await browser.switchTab(rfsWh);
      await rfsWindow.cancelRfs();
    });
  });
});
