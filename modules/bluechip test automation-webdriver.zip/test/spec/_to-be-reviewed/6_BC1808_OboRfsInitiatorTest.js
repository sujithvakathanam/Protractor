import {switchToTab} from '../../../utilities/webdriverHelper/tabsHelper';
import {shellExec} from '../../../utilities/framework/shell-exec';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import Rfs from '../../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Instrument from '../lib/Instrument';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../constants/GenericType';
import ApiClient from '../../../utilities/api/ApiClient';
import VolumeClearing from '../../../pages/child_windows/VolumeClearing';
import TestCommons from '../../../lib/TestCommons';
import Strategy from '../../../lib/Strategy';
import ToastNotification from '../../../pages/child_windows/ToastNotification';
import {usersConfig} from '../../../config/users.config';
import {frameworkConfig} from '../../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {join} from 'path';

/*
 * This test suite supersedes the functionality implemented in 4_BC1113_OboRfsInitiatorTest.js
 */
describe('BC-1808 OBO RFS Initiator Test suite', function rfsInitiatorTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let rfsWindow = null;
  let vcWindow = null;
  let common = null;
  let mainWh = null;
  let toastNotification = null;

  let trader1 = null;
  let trader2 = null;
  const broker = usersConfig.brokers[0];

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    rfsWindow = new Rfs(context);
    vcWindow = new VolumeClearing(context);
    common = new TestCommons(context);
    toastNotification = new ToastNotification(context);
    trader1 = new ApiClient();
    trader2 = new ApiClient();

    expect(browser).to.exist;
  });

  after(() => {
    trader1.logout();
    trader2.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  this.timeout(frameworkConfig.testMaxTime);


  const inst1 = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '275', null, null, null, '101', '222', null);
  const strategy1 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 101, 222, POLARITY.negative, null, null);
  strategy1.addLeg('DEC25', '275', null);

  describe('Setup test data', async () => {
    it('Should have a strategies ', async () => {
      await common.login(broker.username, broker.password);
      await mainPageFrame.clickMarketViewHeader();
      if (!await common.getStrategyId(inst1)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy1);
        await cst.btnSubmit.click();
      }
      await common.logout();
    });
    it('Should have traders logged in ready to trade', async () => {
      await trader1.login(usersConfig.traders[0].username, usersConfig.traders[0].password);
      await trader2.login(usersConfig.traders[6].username, usersConfig.traders[6].password);
      await browser.waitUntil(async () => await trader1.wsOpen & trader2.wsOpen, frameworkConfig.mediumTimeout);
    });
  });

  describe('BC1808_OboRfsInitiator Test 1: As Broker user I should be able to initiate an RFS and trade on behalf of traders', async () => {
    let strategyRow = null;
    let rfsWindow = null;
    let bidOffer = null;
    let vcWindow = null;
    const instTitle = `${inst1.strategy} ${inst1.expiry}`;
    it('Should be logged in', async () => {
      await common.login(broker.username, broker.password);
      const user = await mainPageFrame.getUsername();
      expect(user).to.equal(broker.username, 'Application logged in user');
      mainWh = await browser.getCurrentTabId();
    });
    it('Should show blank row status on the strategy I am going to start RFS on', async () => {
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
\      const status = await strategyRow.getStatusText();
      expect(status).to.equal('', 'Strategy status should be blank');
      const strategyId = await strategyRow.getStrategyId();
      await trader1.respondToRFS(strategyId);
      await trader2.respondToRFS(strategyId);
    });
    it('Should enable the Request for Quotes button when a strategy is selected', async () => {
      await strategyRow.clickUnderlying();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled).to.equal(true, 'Request quotes button on Market Depth Tab should be enabled');
    });
    it('Should show a toast message with R label when the Request for Quotes button is clicked', async () => {
      let toastMsgs = null;
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await browser.waitUntil(async () => {
        toastMsgs = await toastNotification.getRfsResponderToastMsg(inst1.underlying, instTitle, inst1.strikes);

        return toastMsgs.length > 0;
      }, frameworkConfig.mediumTimeout);
      expect(toastMsgs.length === 1).to.equal(true, 'Expected to find Responder toast message');
    });
    it('Should show a notification message in the notification panel with R label', async () => {
      const rfsNotification = await mainPageFrame.notificationsPanel.notifications.getRfsResponderInvite(instTitle, inst1.strikes, inst1.underlying);
      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, 'Expected to find RFS responder notification message');
    });
    it('Should show RFS in the strategy status field', async () => {
      expect(await strategyRow.getStatusText()).to.equal('RFS', 'Expected the strategy status to be RFS');
    });
    it('Should show the RFS window with R label', async () => {
      rfsWindow = new Rfs(context);
      await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'));
      const windowLetter = await rfsWindow.getWindowLetter();
      const windowTitle = await rfsWindow.getTitle();
      const delta = await rfsWindow.getDelta();
      const ref = await rfsWindow.getRef();
      const responded = await rfsWindow.getResponded();
      const phase = await rfsWindow.getPhase();
      expect(windowLetter).to.equal('R', 'Expected RFS window letter to be R');
      expect(windowTitle).to.equal(instTitle, 'RFS window title');
      expect(delta).to.equal(inst1.delta, 'RFS window delta');
      expect(ref).to.equal(inst1.ref, 'RFS window ref');
      expect(responded).to.include('0/', 'RFS window expected zero rfs participants');
      expect(phase).to.equal('DARK', 'RFS window should be in DARK phase');
    });
    it('RFS window should show 1 responder when the first trader submits a quote', async () => {
      await browser.waitUntil(() => trader1.rfsQuote(100, 110, 2500), frameworkConfig.shortTimeout);
      await rfsWindow.waitUntilResponderCount(1);
      const responded = await rfsWindow.getResponded();
      expect(responded).to.include('1/', 'RFS window expected zero rfs participants');
    });
    it('RFS window should show 2 responders when a second trader submits a quote', async () => {
      await browser.waitUntil(async () => trader2.rfsQuote(101, 109, 2500), frameworkConfig.shortTimeout);
      await rfsWindow.waitUntilResponderCount(2);
      const responded = await rfsWindow.getResponded();
      expect(responded).to.include('2/', 'RFS window expected zero rfs participants');
    });
    it('RFS window should transition to LIT phase', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('LIT', 'Expected RFS phase to be LIT');
      const countDownTime = await rfsWindow.getDarkCountDownTimer();
      expect(countDownTime).to.equal('0s', 'Dark timer should be zero');
    });
    it('RFS window should show the spread between bid and ask quotes', async () => {
      const darkSpread = await rfsWindow.getDarkSpread();
      const currentSpread = await rfsWindow.getCurrentSpread();
      expect(darkSpread).to.equal('16 Ticks', 'Expected dark spread to be 16 Ticks');
      expect(currentSpread).to.equal('16 Ticks', 'Expected current spread to be 16 Ticks');
    });
    it('RFS window should update the current spread when a counterparty trader submits a new offer', async () => {
      await browser.waitUntil(() => trader1.rfsQuote(103, 108, 2500), frameworkConfig.shortTimeout);
      await rfsWindow.waitUntilCurrentSpread(10);
      const darkSpread = await rfsWindow.getDarkSpread();
      const currentSpread = await rfsWindow.getCurrentSpread();
      expect(darkSpread).to.equal('16 Ticks', 'Expected dark spread to equal 16 Ticks');
      expect(currentSpread).to.equal('10 Ticks', 'Expected current spread to equal 10 Ticks');
    });
    it('RFS window should show list of users the Broker can act on behalf of', async () => {
      const traders = await rfsWindow.ddTradingUser.getSelections();
      expect(traders).to.include('LP01 - L1U9', 'Expected OBO RFS window to include user LP01 - L1U9 in trading user drop down');
      expect(traders).to.include('LP01 - L1U0', 'Expected OBO RFS window to include user LP01 - L1U0 in trading user drop down');
    });
    it('Broker should be able to add traders to the RFS', async () => {
      await rfsWindow.addTradingUser('LP01 - L1U9');
      await rfsWindow.addTradingUser('LP01 - L1U0');
      const userBtn1 = await rfsWindow.btnUserExists('LP01 - L1U9');
      const userBtn2 = await rfsWindow.btnUserExists('LP01 - L1U0');
      expect(userBtn1).to.equal(true, 'Expected user button to be added to RFS window');
      expect(userBtn2).to.equal(true, 'Expected user button to be added to RFS window');
    });
    it('RFS window should transition to TRADING phase', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      const litCountDownTimer = await rfsWindow.getLitCountDownTimer();
      expect(phase).to.equal('TRADING', 'Expected RFS window to be in TRADING phase');
      expect(litCountDownTimer).to.equal('0s', 'Lit timer should be zero');
    });
    it('RFS window should show top of book offer', async () => {
      bidOffer = await rfsWindow.getBidOfferRow(1);
      const bidPrice = await bidOffer.getBidPrice();
      const askPrice = await bidOffer.getAskPrice();
      expect(bidPrice).to.equal('103.000', 'Top of market BID');
      expect(askPrice).to.equal('108.000', 'Top of market ASK');
    });
    it('Broker should be able to Hit the top of market Bid', async () => {
      bidOffer = await rfsWindow.getBidOfferRow(1);
      await bidOffer.tdAskPriceClick();
      const liftBtnExists = await rfsWindow.btnLiftExists();
      const liftBtnEnabled = await rfsWindow.btnLiftEnabled();
      expect(liftBtnExists).to.equal(true, 'Hit button should exist');
      expect(liftBtnEnabled).to.equal(true, 'Hit button should be enabled');
    });
    it('Broker should be able to Lift the top of the market Ask', async () => {
      bidOffer = await rfsWindow.getBidOfferRow(1);
      await bidOffer.tdBidPriceClick();
      const hitBtnExists = await rfsWindow.btnHitExists();
      const hitBtnEnabled = await rfsWindow.btnHitEnabled();
      expect(hitBtnExists).to.equal(true, 'Lift button should exist');
      expect(hitBtnEnabled).to.equal(true, 'Lift button should be enabled');
    });
    it('RFS window should remove offer when trader subjects offer', async () => {
      await trader1.rfsSubject();
      await bidOffer.waitUntilPrice('101.000', '109.000');
      const bidPrice = await bidOffer.getBidPrice();
      const askPrice = await bidOffer.getAskPrice();
      expect(bidPrice).to.equal('101.000', 'Top of market BID was not updated after trader subjected bid');
      expect(askPrice).to.equal('109.000', 'Top of market ASK was not updated after trader subjected bid');
    });
    it('RFS window should show offer reinstated when trader firms up his offer', async () => {
      await trader1.rfsFirm(103, 108, 2500);
      await bidOffer.waitUntilPrice('103.000', '108.000');
      const bidPrice = await bidOffer.getBidPrice();
      const askPrice = await bidOffer.getAskPrice();
      expect(bidPrice).to.equal('103.000', 'Top of market BID was not updated after trader subjected bid');
      expect(askPrice).to.equal('108.000', 'Top of market ASK was not updated after trader subjected bid');
    });
    it('Broker should be able submit an bid and ask offer on behalf of a trader', async () => {
      await rfsWindow.quote(105, 106, 2500, 'LP01 - L1U9');
      await rfsWindow.btnConfirmClick();
      await bidOffer.waitUntilPrice('105.000', '106.000');
      const bidPrice = await bidOffer.getBidPrice();
      const askPrice = await bidOffer.getAskPrice();
      const myCurrentBid = await rfsWindow.getMyCurrentBid();
      const myCurrentAsk = await rfsWindow.getMyCurrentAsk();
      expect(bidPrice).to.equal('105.000', 'Broker bid should be top of market');
      expect(askPrice).to.equal('106.000', 'Broker bid should be top of market');
      expect(myCurrentBid).to.equal('105.000', 'Brokers current bid');
      expect(myCurrentAsk).to.equal('106.000', 'Brokers current ask');
    });
    it('Broker should be able to subject the offer', async () => {
      await rfsWindow.btnSubjectClick();
      await bidOffer.waitUntilPrice('103.000', '108.000');
      expect(await bidOffer.getBidPrice()).to.equal('103.000', 'Top of market BID was not updated after trader subjected bid');
      expect(await bidOffer.getAskPrice()).to.equal('108.000', 'Top of market ASK was not updated after trader subjected bid');
    });
    it('Broker should be able to firm up the offer', async () => {
      await rfsWindow.btnFirmUpClick();
      await rfsWindow.btnConfirmClick();
      await bidOffer.waitUntilPrice('105.000', '106.000');
      const bidPrice = await bidOffer.getBidPrice();
      const askPrice = await bidOffer.getAskPrice();
      const myCurrentBid = await rfsWindow.getMyCurrentBid();
      const myCurrentAsk = await rfsWindow.getMyCurrentAsk();
      expect(bidPrice).to.equal('105.000', 'Top of market BID was not updated after trader subjected bid');
      expect(askPrice).to.equal('106.000', 'Top of market ASK was not updated after trader subjected bid');
      expect(myCurrentBid).to.equal('105.000', 'Brokers current bid');
      expect(myCurrentAsk).to.equal('106.000', 'Brokers current ask');
    });
    it('Broker should not be a able to Lift or Hit orders on behalf of trading user he placed the order for', async () => {
      await bidOffer.tdBidPriceClick();
      const hitBtnExists = await rfsWindow.btnHitExists();
      expect(hitBtnExists).to.equal(false, 'Hit button should not exist');
      await bidOffer.tdAskPriceClick();
      const btnLiftExists = await rfsWindow.btnLiftExists();
      const btnSubjectExists = await rfsWindow.btnSubjectExists();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      const btnUpdateExists = await rfsWindow.btnUpdateExists();
      const btnUpdateEnabled = await rfsWindow.btnUpdateEnabled();
      expect(btnLiftExists).to.equal(false, 'Lift button should not exist');
      expect(btnSubjectExists).to.equal(true, 'Subject button should exist');
      expect(btnSubjectEnabled).to.equal(true, 'Subject button should be enabled');
      expect(btnUpdateExists).to.equal(true, 'Update button should exist');
      expect(btnUpdateEnabled).to.equal(false, 'Update button should be disabled');
    });
    it('Broker should not be allowed to trade for a trader who has a desk colleague already participating in the RFS', async () => {
      await rfsWindow.btnUserClick('LP01 - L1U0');
      const hasMsg = await rfsWindow.colleagueTradingMsgExists();
      expect(hasMsg).to.equal(true, 'Colleague trading message displayed');
    });
    it('Broker should be able to Lift counterparty Ask on behalf of a trader', async () => {
      await rfsWindow.btnUserClick('LP01 - L1U9');
      await trader1.rfsQuote(103, 105.5, 2500);
      await bidOffer.waitUntilPrice('105.000', '105.500');
      await bidOffer.tdAskPriceClick();
      await rfsWindow.btnLiftClick();
    });
    it('Should display a RFS summary for LP01 - L1U0 showing zero volume traded by this trader', async () => {
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      await rfsWindow.btnUserClick('LP01 - L1U0');
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      const totalBoughtExists = await rfsWindow.summaryTotalBoughtExists();
      const totalSoldExists = await rfsWindow.summaryTotalSoldExists();
      expect(totalMatched).equals('2500 L', 'Total Amount Matched in RFS');
      expect(totalBoughtExists).equals(false, 'Should not find My Total Bought');
      expect(totalSoldExists).equals(false, 'Should not find My Total Sold');
    });
    it('Should display a RFS summary for trader LP01 - L1U9 showing a Brought Amount of 2500 L', async () => {
      await rfsWindow.btnUserClick('LP01 - L1U9');
      const summaryTotalBought = await rfsWindow.getSummaryTotalBought();
      const summaryTotalSold = await rfsWindow.getSummaryTotalSold();
      const summaryTotalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(summaryTotalBought).equals('2500 L', 'My Total Brought Amount');
      expect(summaryTotalSold).equals('0 L', 'My Total Sold Amount');
      expect(summaryTotalMatched).equals('2500 L', 'Total Amount Matched in RFS');
    });
    it('Market View Should show VC status against the strategy', async () => {
      await browser.switchTab(mainWh);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy status should be VC');
    });
    it('Should show VC notification', async () => {
      await mainPageFrame.notificationsPanel.tabAlerts.click();
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC('C DEC25', '105.500', 'SX5E');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });
    it('Should show VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('105.500', 'SX5E', 'C DEC25', '275');
      expect(vcToastMsgs.length).to.equal(1, 'VC toast message should exist');
      await vcToastMsgs[0].click();
    });
    it('Should block order book', async () => {
      const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
      const orderBookDisabled = await orderBook.disabled();
      expect(orderBookDisabled).to.equal(true, 'Order Book should be disabled');
    });
    it('Should show Buy notification and toast message', async () => {
      const buyToastMsgs = await toastNotification.getBuyToastMsg('105.500', '2500 L', 'SX5E', 'C DEC25', '275', 'L1U9 - LP01');
      expect(buyToastMsgs.length).to.equal(1, 'Buy Toast notification message should exist');
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillBuy('C DEC25', '105.500', '275', '', 'SX5E', 'L1U9 - LP01');
      const notificationSize = await buyNotification.getSize();
      expect(notificationSize).to.equal('2500 L');
    });
    it('Broker should be invited to the VC to trade on behalf of trader LP01 - L1U9 as a priority buyer', async () => {
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const vcId = await vcWindow.vcId;
      expect(vcId > 0).to.equal(true, 'VC window should open');
      const windowLetter = await vcWindow.getWindowLetter();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      const pxValue = await vcWindow.getPxValue();
      const sellInterestInputEnabled = await vcWindow.sellInterestInputEnabled();
      const buyInterestInputEnabled = await vcWindow.buyInterestInputEnabled();
      const isPriorityBuyer = await vcWindow.isPriorityBuyer();
      const userBtnExists = await vcWindow.btnUserExists('LP01 - L1U9');
      expect(windowLetter).to.equal('V', 'Window Letter');
      expect(ref).to.equal('101', 'Window should show REF');
      expect(delta).to.equal('222', 'Window should show delta');
      expect(pxValue).to.equal('105.500', 'Window should show PX Value');
      expect(sellInterestInputEnabled).to.equal(false, 'Sell interest entry should not be enabled');
      expect(buyInterestInputEnabled).to.equal(true, 'Buy Interest input should be enabled');
      expect(isPriorityBuyer).to.equal(true, 'Should be VC priority buyer');
      expect(userBtnExists).to.equal(true, 'Trader button should exist on the VC window');
    });
    it('VC should show no interest', async () => {
      await vcWindow.waitUntilOpenToAll();
      const row = await vcWindow.getBidOfferRow(1);
      const bid = await row.getBid();
      const offer = await row.getOffer();
      expect(bid).to.equal(null, 'Should not find any Bid interest in VC');
      expect(offer).to.equal(null, 'Should not find any Offer interest in VC');
    });
    it('VC should show broker summary page', async () => {
      await vcWindow.waitForSummary();
      const totalBought = await vcWindow.getSummaryTotalBought();
      const totalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      await browser.switchTab(mainWh);
      expect(totalBought).to.equal('2500', 'VC Summary Total Bought');
      expect(totalSold).to.equal('0', 'VC Summary Total Sold');
      expect(totalMatched).to.equal('2500', 'VC Summary Total Matched');
    });
  });

  describe('BC1808_OboRfsInitiator Test 2: As a broker if I start an RFS and no one responds then an appropriate message will be displayed', async () => {
    let strategyRow = null;
    let rfsWindow = null;
    it('Should be logged in', async () => {
      await common.login(broker.username, broker.password);
      const user = await mainPageFrame.getUsername();
      expect(user).to.equal(broker.username, 'Application logged in user');
      mainWh = await browser.getCurrentTabId();
    });
    it('Should show blank row status on the strategy I am going to start RFS on', async () => {
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('', 'Strategy status should be blank');
    });
    it('Should enable the Request for Quotes button when a strategy is selected', async () => {
      await strategyRow.clickUnderlying();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled).to.equal(true, 'Request quotes button on Market Depth Tab should be enabled');
    });
    it('Should open the RFS window when I click on the Request for Quotes button', async () => {
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      rfsWindow = new Rfs(context);
      const found = await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'));
      const windowLetter = await rfsWindow.getWindowLetter();
      const windowTitle = await rfsWindow.getTitle();
      expect(found).to.equal(true, 'Could not find the RFS window');
      expect(windowLetter).to.equal('R', 'Expected RFS window letter to be R');
      expect(windowTitle).to.equal(`${inst1.strategy} ${inst1.expiry}`, 'RFS window title');
    });
    it('Should transition from DARK to LIT to TRADING phases', async () => {
      let phase = await rfsWindow.getPhase();
      expect(phase).to.equal('DARK', 'RFS should be in DARK phase');
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      phase = await rfsWindow.getPhase();
      expect(phase).to.equal('LIT', 'RFS should be in LIT phase');
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      phase = await rfsWindow.getPhase();
      expect(phase).to.equal('TRADING', 'RFS should be in TRADING phase');
    });
    it('Should show RFS timed out message', async () => {
      await rfsWindow.waitUntilRfsTimedout();
      const hasTimedOutMsg = await rfsWindow.rfsTimedoutMsgExists();
      expect(hasTimedOutMsg).to.equal(true, 'RFS window should show RFS timed out message');
    });
  });

  describe.skip('As a broker I should not be able to initiate an RFS on a strategy that has existing active quotes in the order book', async () => {});
  describe.skip('As a broker I should not be able to initiate an RFS on a strategy that is currently taking part in an RFS', async () => {});
  describe.skip('As a broker I should not be able to initiate an RFS on a strategy that is currently taking part in a VC', async () => {});

  // Lock out rules
  describe.skip('As a broker I should not be able to trade on behalf of a trader that is actively taking part in the RFS', async () => {});
  describe.skip('As a broker I should not be able to trade on behalf of a trader who has a desk colleague who is actively trading in the the RFS', async () => {});
});
