import {shellExec} from '../../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import VolumeClearing from '../../../pages/child_windows/VolumeClearing';
import {expect} from 'chai';
import ApiClient from '../../../utilities/api/ApiClient';
import ToastNotification from '../../../pages/child_windows/ToastNotification';
import {FILL_TYPE, TIME_TYPE} from '../../../constant/GenericType';
import Instrument from '../lib/Instrument';
import TestCommons from '../../../lib/TestCommons';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';
import {usersConfig} from '../../../config/users.config';

describe('End to end test', function endToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;
  let vcWindow = null;
  let mainWindowHandle = null;

  const trader1 = usersConfig.traders[9];
  const trader2 = usersConfig.traders[10];
  let traderApi = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    common = new TestCommons(context);
    traderApi = new ApiClient();

    expect(browser).to.exist;
  });

  after(() => {
    traderApi.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  describe('Trader places buy order, order is matched and volume clearing session is started and completed', () => {
    const myBid = '100.000';
    const myBidSize = '1000';
    let vcNotification = null;
    let strategyId = null;

    const instrument = new Instrument('SX5E', 'SYN P+', 'MAR19', '3000', null, null, null, '3000', '100', null);

    let row = null;
    let marketDepth = null;
    const notificationTitle = `${instrument.strategy} ${instrument.expiry}`;

    it('should log in', async () => {
      logger.info('Debug time.');
      await traderApi.login(trader2.username, trader2.password);
      await common.login(trader1.username, trader1.password);
      const mainPageLoaded = await mainPageFrame.pageHasLoaded();
      const loggedInUser = await mainPageFrame.txtUserName.getText();
      expect(mainPageLoaded).to.be.true;
      expect(loggedInUser).to.equal(trader1.fenicsGoUsername);
      mainWindowHandle = await browser.getCurrentTabId();
    });

    it('should enable the Order Book when the instrument is selected from the EUROSTOXX tab', async () => {
      row = await mainPageFrame
        .getMarketViewTab()
        .getEuroStoxxTable()
        .getTableRow(instrument);

      const id = await row.strategyId;
      if (id !== null) {
        strategyId = id;
      }

      const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
      expect(await orderBook.disabled()).to.be.false;
    });

    it('should populate the Market Depth tab with instrument information', async () => {
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      expect(await marketDepth.getTitle()).to.equal(marketDepth.expectedTitle(instrument));
      expect(await marketDepth.getStrikes()).to.equal(instrument.strikes);
      expect(await marketDepth.getDelta()).to.equal(instrument.delta);
      expect(await marketDepth.getRef()).to.equal(instrument.ref);
    });

    it('should update the market depth table when a bid is submitted using the order book', async () => {
      const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
      await orderBook.enterBid(myBid, myBidSize, TIME_TYPE.day, FILL_TYPE.partial, null);
      await orderBook.btnSubmitClick();
      const bidFound = await marketDepth.bidFound(myBid, '1 000');
      expect(bidFound).to.be.true;
    });

    it('should display VC notification when orders are matched', async () => {
      await traderApi.strategyOrderAdd(strategyId, false, true, false, myBid, 'SELL', myBidSize, false);
      vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC(notificationTitle, myBid, instrument.underlying);
      const found = await vcNotification.waitForExist();
      expect(found).to.be.true;
    });

    it('should display buy notification when orders are matched', async () => {
      const buyNotification = await mainPageFrame
        .notificationsPanel
        .notifications
        .getFillBuy(notificationTitle, myBid, instrument.strikes, 'Sz 1,000 L', instrument.underlying);
      await buyNotification.waitForExist();
      expect(await buyNotification.getSize()).to.equal('Sz 1,000 L');
      expect(await buyNotification.filled.getText()).to.equal('FILLED');
    });
    it('should disable the order book when volume clearing is in progress', async () => {
      const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
      await orderBook.btnOkClick();
      expect(await orderBook.vcOverlayDisplayed()).to.be.true;
    });

    it('should display toast notifications for VC and BUY', async () => {
      const tn = new ToastNotification(context);
      const buyNots = await tn.getBuyToastMsg(myBid, `${myBidSize} L`, instrument.underlying, `${instrument.strategy} ${instrument.expiry}`, instrument.strikes);
      const vcNots = await tn.getVcToastMsg(myBid, instrument.underlying, `${instrument.strategy} ${instrument.expiry}`, instrument.strikes);
      logger.info('Check the toasts');
      expect(buyNots.length).to.equal(1);
      expect(vcNots.length).to.equal(1);
      const buyNotExists = await buyNots[0].exists();
      const vcNotExists = await vcNots[0].exists();
      expect(buyNotExists).to.be.true;
      expect(vcNotExists).to.be.true;
    });

    it('should open VC window once show me button is clicked', async () => {
      await vcNotification.btnShowMeClick();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
    });
    it('should update total brought amount when volume is added', async () => {
      await traderApi.vcAddInterest('SELL', '5000');
      await browser.pause(5000);
      await vcWindow.setMyBuyInterestInput(5000);
      await vcWindow.submitBtn.click();
      let totalBroughtAmount = null;
      await browser.waitUntil(async () => {
        totalBroughtAmount = await vcWindow.totBoughtAmount.getText();

        return totalBroughtAmount === '6000';
      });
      expect(totalBroughtAmount).to.equal('6000');
    });

    it('should show a summary when VC session ends', async () => {
      await vcWindow.waitForSummary();
      expect(await vcWindow.summaryTotalBought.getText()).to.equal('6000');
      expect(await vcWindow.summaryTotalSold.getText()).to.equal('0');
      expect(await vcWindow.summaryTotalMatched.getText()).to.equal('6000');
      await vcWindow.okBtn.click();
    });

    it('should display a buy notification with updated trade volume', async () => {
      await browser.switchTab(mainWindowHandle);
      await mainPageFrame.notificationsPanel.tabAlerts.click();
      const buyNotification = await mainPageFrame
        .notificationsPanel
        .notifications
        .getFillBuy(notificationTitle, myBid, instrument.strikes, 'Sz 6,000 L', instrument.underlying);
      await buyNotification.waitForExist();
      expect(await buyNotification.getSize()).to.equal('Sz 6,000 L');
      expect(await buyNotification.filled.getText()).to.equal('FILLED');
    });

    it('should enable the order book when volume clearing is complete', async () => {
      const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
      expect(await orderBook.vcOverlayDisplayed()).to.be.false;
    });
  });
});
