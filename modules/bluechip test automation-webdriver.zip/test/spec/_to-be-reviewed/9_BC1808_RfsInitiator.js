import {shellExec} from '../../../utilities/framework/shell-exec';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../constants/GenericType';
import ApiClient from '../../../utilities/api/ApiClient';
import Strategy from '../../../lib/Strategy';
import {Bootstrap} from '@fenics/fenics-test-core';
import {join} from 'path';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';

describe('BC-1808 Initiator Test suite', function rfsInitiatorTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let trader1 = null;
  let trader2 = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    trader1 = new ApiClient();
    trader2 = new ApiClient();

    expect(browser).to.exist;
  });

  after(() => {
    trader1.logout();
    trader2.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  this.timeout(frameworkConfig.testMaxTime);

  // Is this needed? const str1 = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '275', null, null, null, '101', '222', null);
  const strategy1 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 101, 222, POLARITY.negative, null, null);
  strategy1.addLeg('DEC25', '275', null);

  describe('Setup test data', async () => {
    // Create test
  });

  describe('As a trader I should be able to initiate an RFS', async () => {
    // Create test
  });
});

// Lockout rules
describe.skip('As a trader I should not be able to initiate an RFS on a strategy that has existing active quotes in the order book', async () => { });
describe.skip('As a trader I should not be able to initiate an RFS on a strategy that is currently in an RFS', async () => { });
describe.skip('As a trader I should not be able to initiate an RFS on a strategy that is currently in a VC', async () => { });
describe.skip('As a trader I should be able to initiate an RFS on a strategy that has indicative orders in the order book', async () => { });
describe.skip('As a broker I should be able to initiate an RFS on a strategy that has indicative orders in the order book', async () => { });
