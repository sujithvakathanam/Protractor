import {shellExec} from '../../../utilities/framework/shell-exec';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import Rfs from '../../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Instrument from '../lib/Instrument';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../../constant/GenericType';
import ApiClient from '../../../utilities/api/ApiClient';
import VolumeClearing from '../../../pages/child_windows/VolumeClearing';
import TestCommons from '../../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import Strategy from '../../../lib/Strategy';
import {usersConfig} from '../../../config/users.config';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';


describe('BC-1111 OBO RFS VC Test suite', function vcTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let vcWindow = null;
  let rfsWindow = null;
  const toastNotification = null;
  let common = null;

  const broker = usersConfig.brokers[0];
  let trader1 = null;
  let trader2 = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    rfsWindow = new Rfs(context);
    vcWindow = new VolumeClearing(context);
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    if (trader1 !== null) {
      trader1.logout();
    }
    if (trader2 !== null) {
      trader2.logout();
    }
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  this.timeout(frameworkConfig.veryLongTimeout);

  describe('Test 1: As a broker if I initiate an RFS it will transition to a VC and the trading user should be a priority buyer', () => {
    const inst1 = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '150', null, null, null, '156', '130', null);
    const strategy1 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 156, 130, POLARITY.negative, null, null);
    strategy1.addLeg('DEC25', '150', null);

    let strategyRow = null;
    let marketDepth = null;
    let mainWh = null;
    let strategyId = null;
    let rejectedOrder = null;
    const tradingUser1 = 'LP01 - L1U9';
    const tradingUser2 = 'LP05 - L5U2';
    const tradingUser3 = 'LP03 - L3U2';
    it('Broker should login', async () => {
      await common.login(broker.username, broker.password);
      const userTxt = await mainPageFrame.getUsername();
      mainWh = await browser.getCurrentTabId();
      expect(userTxt).to.equal(broker.username, 'Expected username');
    });
    it('Setup - Broker should have strategies that can be used to book orders01', async () => {
      if (!await common.getStrategyId(inst1)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy1);
        await cst.btnSubmit.click();
      }
      strategyId = await common.getStrategyId(inst1);
      expect(parseInt(strategyId)).to.be.a('number', 'Strategy ID');
    });
    it('Counterparty trading user should log in', async () => {
      trader1 = new ApiClient();
      let wsOpen = false;
      await trader1.login(usersConfig.traders[0].username, usersConfig.traders[0].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader1.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      await trader1.respondToRFS(strategyId);
    });
    it('Broker should initiate an RFS', async () => {
      mainWh = await browser.getCurrentTabId();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
      await strategyRow.clickStatus();
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status');
    });
    it(`Broker should add trader ${tradingUser1} to the RFS`, async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow();
      await rfsWindow.addTradingUser(tradingUser1);
      const btnExists = await rfsWindow.btnUserExists(tradingUser1);
      expect(btnExists).to.equal(true, `RFS User button ${tradingUser1} exists`);
    });
    it(`Broker should be able to add a quote to the RFS during trading phase on behalf of trader ${tradingUser1}`, async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      await rfsWindow.quote(100, 104, 2500);
      await rfsWindow.waitUntilMyCurrentAsk('104.000');
      const ask = await rfsWindow.getMyCurrentAsk();
      const bid = await rfsWindow.getMyCurrentBid();
      expect(ask).to.equal('104.000', 'RFS My Current Ask');
      expect(bid).to.equal('100.000', 'RFS My Current Bid');
    });
    it('Broker should see RFS summary when counterparty trader accepts my Bid', async () => {
      await trader1.rfsAccept(null, 100, 2500, null);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      const myTotalBought = await rfsWindow.getSummaryTotalBought();
      const myTotalSold = await rfsWindow.getSummaryTotalSold();
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(myTotalBought).to.equal('2500 L', 'RFS My Total Bought Amount');
      expect(myTotalSold).to.equal('0 L', 'RFS My Total Sold Amount');
      expect(totalMatched).to.equal('2500 L', 'RFS Total Matched');
    });
    it('Broker should see VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('100.000', 'SX5E', 'C DEC25', '150');
      expect(vcToastMsgs.length).to.equal(1, 'VC toast message should exist');
    });
    it('Broker should see VC notification message', async () => {
      await browser.switchTab(mainWh);
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC('C DEC25', '100.000', 'SX5E');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });
    it('Broker should see VC status against the strategy', async () => {
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy row status');
    });
    it('Broker should see VC window open when strategy is clicked on', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const instTitle = await vcWindow.getInstrumentTitle();
      const index = await vcWindow.getIndex();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      expect(index).to.equal('SX5E', 'VC window index');
      expect(instTitle).to.equal('C DEC25', 'VC window instrument title');
      expect(ref).to.equal('156', 'VC window reference');
      expect(delta).to.equal('130', 'VC window delta');
    });
    it(`Broker should see trader ${tradingUser1} is a priority buyer`, async () => {
      await vcWindow.btnUserClick(tradingUser1);
      const isPriorityBuyer = await vcWindow.isPriorityBuyer();
      expect(isPriorityBuyer).to.equal(true, `${tradingUser1}Should be Priority Buyer in VC`);
    });
    it(`Broker should see VC sell volume is disabled for ${tradingUser1}`, async () => {
      const sellInputEnabled = await vcWindow.sellInterestInputEnabled();
      expect(sellInputEnabled).to.equal(false, 'VC Window sell interest should be disabled');
    });
    it(`Broker should see VC buy volume is enabled for ${tradingUser1}`, async () => {
      const buyInputEnabled = await vcWindow.buyInterestInputEnabled();
      expect(buyInputEnabled).to.equal(true, 'VC Window buy interest should be enabled');
    });
    it(`Broker should be able to add a new trader ${tradingUser2} to the VC`, async () => {
      await vcWindow.addTradingUser(tradingUser2);
      const userBtnExists = await vcWindow.btnUserExists(tradingUser2);
      expect(userBtnExists).to.equal(true, `VC Window user ${tradingUser2} button should exist`);
    });
    it(`Broker should see user ${tradingUser2} is non-priority participant in the VC `, async () => {
      await vcWindow.btnUserClick(tradingUser2);
      const isNonPrioirty = await vcWindow.isNonPriority();
      expect(isNonPrioirty).to.equal(true, 'VC user should be non priority');
    });
    it(`Broker should only be allowed to add sell volume on behalf of trader ${tradingUser2} as the trade was initiated by a desk colleague on the sell side`, async () => {
      const buyInputEnabled = await vcWindow.buyInterestInputEnabled();
      const sellInputEnabled = await vcWindow.sellInterestInputEnabled();
      expect(buyInputEnabled).to.equal(false, 'VC buy input should be disabled for trading user');
      expect(sellInputEnabled).to.equal(true, 'VC sell input should be enabled for trading user');
    });
    it(`Broker should be able to add buy or sell volume for a trader ${tradingUser3} that is not already participating in the VC`, async () => {
      await vcWindow.addTradingUser(tradingUser3);
      await vcWindow.btnUserClick(tradingUser3);
      const buyInputEnabled = await vcWindow.buyInterestInputEnabled();
      const sellInputEnabled = await vcWindow.sellInterestInputEnabled();
      expect(buyInputEnabled).to.equal(true, 'VC buy input should be enabled for trading user');
      expect(sellInputEnabled).to.equal(true, 'VC sell input should be enabled for trading user');
    });
    it(`Broker should see new trader ${tradingUser3} is a non-priority participant`, async () => {
      const isNonPrioirty = await vcWindow.isNonPriority();
      expect(isNonPrioirty).to.equal(true, 'VC user should be non priority');
    });
    it('Broker should see during priority period non priority traders volume will not be matched', async () => {
      await vcWindow.btnUserClick(tradingUser3);
      await vcWindow.setMyBuyInterestInput(3000);
      await vcWindow.btnSubmitClick();
      await vcWindow.btnUserClick(tradingUser2);
      await vcWindow.setMySellInterestInput(2500);
      await vcWindow.btnSubmitClick();
      await vcWindow.btnUserClick(tradingUser1);
      await vcWindow.setMyBuyInterestInput(2500);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(2, frameworkConfig.shortTimeout);
      const row1 = await vcWindow.getBidOfferRow(1);
      const bidRow1 = await row1.getBid();
      const bidRow1Text = await bidRow1.getText();
      const offerRow1 = await row1.getOffer();
      const offerRow1Text = await offerRow1.getText();
      const row2 = await vcWindow.getBidOfferRow(2);
      const bidRow2 = await row2.getBid();
      const bidRow2Text = await bidRow2.getText();
      const offerRow2 = await row2.getOffer();
      const offerRow2Text = await offerRow2.getText();
      await expect(bidRow1Text).to.equal('L1U9-LP012500', 'VC Bid/Offer table row 1 Bid');
      await expect(offerRow1Text).to.equal('', 'VC Bid/Offer table row 1 Offer');
      await expect(bidRow2Text).to.equal('L3U2-LP033000', 'VC Bid/Offer table row 2 Bid');
      await expect(offerRow2Text).to.equal('L5U2-LP052500', 'VC Bid/Offer table row 2 Offer');
    });
    it('Broker should see during priority period priority traders volume will be matched', async () => {
      const traderId = await trader1.userData.user.id;
      const traderDeskId = await trader1.userData.user.deskId;
      await trader1.vcAddInterest('SELL', 2500, traderId, traderDeskId);
      await vcWindow.waitUntilOffers(1, frameworkConfig.shortTimeout);
      const row1 = await vcWindow.getBidOfferRow(1);
      const bid = await row1.getBid();
      const offer = await row1.getOffer();
      const bidText = await bid.getText();
      const offerText = await offer.getText();
      expect(bidText).to.equal('L3U2-LP033000', 'VC Bid/Offer table row 1 Bid');
      expect(offerText).to.equal('L5U2-LP052500', 'VC Bid/Offer table row 1 Offer');
    });
    it('Broker should see non priority volume matched during open vc period', async () => {
      await vcWindow.waitUntilOpenToAll();
      await vcWindow.waitUntilOffers(0);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(0, 'Should be zero bid/offers in the VC');
    });
    it('Broker should see offer interest when counterparty trader makes an offer', async () => {
      const traderId = await trader1.userData.user.id;
      const traderDeskId = await trader1.userData.user.deskId;
      await trader1.vcAddInterest('SELL', 1500, traderId, traderDeskId);
      await vcWindow.waitUntilOffers(1, frameworkConfig.shortTimeout);
      const row1 = await vcWindow.getBidOfferRow(1);
      const offer = await row1.getOffer();
      const offerText = await offer.getText();
      expect(offerText).to.equal('INT', 'VC Bid/Offer table row 1 Offer');
    });
    it(`Broker should be able to add volume on behalf of ${tradingUser1}`, async () => {
      await vcWindow.btnUserClick(tradingUser1);
      await vcWindow.setMyBuyInterestInput(1500);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(0, frameworkConfig.shortTimeout);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(0, 'Should not see any offers in the VC');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser1}`, async () => {
      await vcWindow.waitForSummary();
      await vcWindow.btnUserClick(tradingUser1);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('6500', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('0', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('9000', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser2}`, async () => {
      await vcWindow.btnUserClick(tradingUser2);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('0', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('2500', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('9000', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser3}`, async () => {
      await vcWindow.btnUserClick(tradingUser3);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('2500', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('0', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('9000', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see buy notification for trader ${tradingUser1}`, async () => {
      await browser.switchTab(mainWh);
      const notification = await mainPageFrame.notificationsPanel.notifications.getFillBuy('C DEC25', '100.000', '150', 'Sz 6,500 L', 'SX5E', 'L1U9 - LP01');
      const found = await notification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, `Expected to find buy notification for trader ${tradingUser1}`);
    });
    it(`Broker should see sell notification for trader ${tradingUser2}`, async () => {
      await browser.switchTab(mainWh);
      const notification = await mainPageFrame.notificationsPanel.notifications.getFillSell('C DEC25', '100.000', '150', 'Sz 2,500 L', 'SX5E', 'L5U2 - LP05');
      const found = await notification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, `Expected to find sell notification for trader ${tradingUser2}`);
    });
    it(`Broker should see buy notification for trader ${tradingUser3}`, async () => {
      await browser.switchTab(mainWh);
      const notification = await mainPageFrame.notificationsPanel.notifications.getFillBuy('C DEC25', '100.000', '150', 'Sz 2,500 L', 'SX5E', 'L3U2 - LP03');
      const found = await notification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, `Expected to find buy notification for trader ${tradingUser3}`);
    });
    it('Broker should see part volume that was not traded resulting in a rejected order message', async () => {
      rejectedOrder = await mainPageFrame.notificationsPanel.notifications.getRejectedOrder('C DEC25', 'SX5E', '100.000', '500', 'L3U2 - LP03');
      const found = await rejectedOrder.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, `Expected to find Rejected Trade Order notification for trader${tradingUser3}`);
    });
    it('Broker should be able to dismiss the rejected order message', async () => {
      await rejectedOrder.btnDismissClick();
      const dismissed = await rejectedOrder.isDismissed();
      expect(dismissed).to.equal(true, 'Expected Rejected Trade Order notification to be dismissed');
    });
  });

  describe('Test 2: As a broker if I initiate an RFS it will transition to a VC and the trading user should be a priority seller', () => {
    const inst2 = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '175', null, null, null, '132', '122', null);
    const strategy2 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 132, 122, POLARITY.negative, null, null);
    strategy2.addLeg('DEC25', '175', null);

    let strategyRow = null;
    let marketDepth = null;
    let strategyId = null;
    let mainWh = null;
    const tradingUser1 = 'LP01 - L1U9';

    let trader1Id = null;
    let trader1DeskId = null;

    it('Broker should login', async () => {
      await common.login(broker.username, broker.password);
      const userTxt = await mainPageFrame.getUsername();
      mainWh = await browser.getCurrentTabId();
      expect(userTxt).to.equal(broker.username, 'Expected username');
    });
    it('Setup - Broker should have strategies that can be used to book orders', async () => {
      if (!await common.getStrategyId(inst2)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy2);
        await cst.btnSubmit.click();
      }
      strategyId = await common.getStrategyId(inst2);
      expect(parseInt(strategyId)).to.be.a('number', 'Strategy ID');
    });
    it('Counterparty trading user should log in', async () => {
      trader1 = new ApiClient();
      let wsOpen = false;
      await trader1.login(usersConfig.traders[0].username, usersConfig.traders[0].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader1.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      await trader1.respondToRFS(strategyId);
      trader1Id = await trader1.userData.user.id;
      trader1DeskId = await trader1.userData.user.deskId;
    });
    it('Broker should initiate an RFS', async () => {
      mainWh = await browser.getCurrentTabId();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst2);
      await strategyRow.clickStatus();
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status');
    });
    it(`Broker should add trader ${tradingUser1} to the RFS`, async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow();
      await rfsWindow.addTradingUser(tradingUser1);
      const btnExists = await rfsWindow.btnUserExists(tradingUser1);
      expect(btnExists).to.equal(true, `RFS User button ${tradingUser1} exists`);
    });
    it(`Broker should be able to add a quote to the RFS during trading phase on behalf of trader ${tradingUser1}`, async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      await rfsWindow.quote(101.5, 104.5, 2500);
      await rfsWindow.waitUntilMyCurrentAsk('104.500');
      const ask = await rfsWindow.getMyCurrentAsk();
      const bid = await rfsWindow.getMyCurrentBid();
      expect(ask).to.equal('104.500', 'RFS My Current Ask');
      expect(bid).to.equal('101.500', 'RFS My Current Bid');
    });
    it('Broker should see RFS summary when counterparty trader accepts my Bid', async () => {
      await trader1.rfsAccept(104.5, null, 2500, null);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      const myTotalBought = await rfsWindow.getSummaryTotalBought();
      const myTotalSold = await rfsWindow.getSummaryTotalSold();
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(myTotalBought).to.equal('0 L', 'RFS My Total Bought Amount');
      expect(myTotalSold).to.equal('2500 L', 'RFS My Total Sold Amount');
      expect(totalMatched).to.equal('2500 L', 'RFS Total Matched');
    });
    it('Broker should see VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('104.500', 'SX5E', 'C DEC25', '175');
      expect(vcToastMsgs.length).to.equal(1, 'VC toast message should exist');
    });
    it('Broker should see VC notification message', async () => {
      await browser.switchTab(mainWh);
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC('C DEC25', '104.500', 'SX5E');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });
    it('Broker should see VC status against the strategy', async () => {
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy row status');
    });
    it('Broker should see VC window open when strategy is clicked on', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const instTitle = await vcWindow.getInstrumentTitle();
      const index = await vcWindow.getIndex();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      expect(index).to.equal('SX5E', 'VC window index');
      expect(instTitle).to.equal('C DEC25', 'VC window instrument title');
      expect(ref).to.equal('132', 'VC window reference');
      expect(delta).to.equal('122', 'VC window delta');
    });
    it(`Broker should see trader ${tradingUser1} is a priority seller`, async () => {
      await vcWindow.btnUserClick(tradingUser1);
      const isPrioritySeller = await vcWindow.isPrioritySeller();
      expect(isPrioritySeller).to.equal(true, `${tradingUser1}Should be Priority Seller in VC`);
    });
    it(`Broker should see VC sell volume is enabled for ${tradingUser1}`, async () => {
      const sellInputEnabled = await vcWindow.sellInterestInputEnabled();
      expect(sellInputEnabled).to.equal(true, 'VC Window sell interest should be enabled');
    });
    it(`Broker should see VC buy volume is disabled for ${tradingUser1}`, async () => {
      const buyInputEnabled = await vcWindow.buyInterestInputEnabled();
      expect(buyInputEnabled).to.equal(false, 'VC Window buy interest should be disabled');
    });
    it(`Broker should be able to add sell volume for ${tradingUser1} during the priority period`, async () => {
      await vcWindow.setMySellInterestInput(3500);
      await vcWindow.btnSubmitClick();
      const priority = await vcWindow.isPrioritySeller();
      expect(priority).to.equal(true, 'VC Should be in priority seller period');
    });
    it(`Broker should see 3500 sell volume for trader ${tradingUser1} in the bid offers table`, async () => {
      await vcWindow.waitUntilOffers(1);
      const bidOfferRow = await vcWindow.getBidOfferRow(1);
      const bid = await bidOfferRow.getBid();
      const offer = await bidOfferRow.getOffer();
      const bidText = await bid.getText();
      const offerText = await offer.getText();
      expect(offerText).to.equal('L1U9-LP013500', 'VC window bid offers table should show offer');
      expect(bidText).to.equal('', 'VC window bid offers table should show bid');
    });
    it('Broker should see empty bid offers table when counter-party trader buys all volume on offer', async () => {
      await trader1.vcAddInterest('BUY', 3500, trader1Id, trader1DeskId);
      await vcWindow.waitUntilOffers(0, frameworkConfig.shortTimeout);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(0, 'Should be 0 offers in the VC window bid offer table');
    });
    it('Broker should see VC transition to Open to All', async () => {
      await vcWindow.waitUntilOpenToAll();
      const openToAll = await vcWindow.isOpenToAll();
      expect(openToAll).to.equal(true, 'VC period should be open to all');
    });
    it(`Broker should be able to add sell volume for ${tradingUser1} during the vc open to all period`, async () => {
      await vcWindow.setMySellInterestInput(2500);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(1);
      const bidOfferRow = await vcWindow.getBidOfferRow(1);
      const bid = await bidOfferRow.getBid();
      const offer = await bidOfferRow.getOffer();
      const bidText = await bid.getText();
      const offerText = await offer.getText();
      expect(offerText).to.equal('L1U9-LP012500', 'VC window bid offers table should show offer');
      expect(bidText).to.equal('', 'VC window bid offers table should show bid');
    });
    it('Broker should see empty bid offers table when counter-party trader buys all volume on offer', async () => {
      await trader1.vcAddInterest('BUY', 2500, trader1Id, trader1DeskId);
      await vcWindow.waitUntilOffers(0, frameworkConfig.shortTimeout);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(0, 'Should be 0 offers in the VC window bid offer table');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser1}`, async () => {
      await vcWindow.waitForSummary();
      await vcWindow.btnUserClick(tradingUser1);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('0', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('8500', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('8500', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see a sell notification for trader ${tradingUser1}`, async () => {
      await browser.switchTab(mainWh);
      const notification = await mainPageFrame.notificationsPanel.notifications.getFillSell('C DEC25', '104.500', '175', 'Sz 8,500 L', 'SX5E', 'L1U9 - LP01');
      const found = await notification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, `Expected to find buy notification for trader ${tradingUser1}`);
    });
  });


  describe('Test 3: As a broker I should not be able to trade on behalf of traders that are already participating in the VC', () => {
    const inst = new Instrument(UNDERLYING.sx5e, 'P', 'DEC25', '175', null, null, null, '132', '122', null);
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 132, 122, POLARITY.positive, null, null);
    strategy.addLeg('DEC25', '175', null);

    let strategyRow = null;
    let marketDepth = null;
    let strategyId = null;
    let mainWh = null;
    const tradingUser1 = 'LP01 - L1U9';
    const tradingUser2 = 'LP03 - L3U2';

    it('Broker should login', async () => {
      await common.login(broker.username, broker.password);
      const userTxt = await mainPageFrame.getUsername();
      mainWh = await browser.getCurrentTabId();
      expect(userTxt).to.equal(broker.username, 'Expected username');
    });
    it('Setup - Broker should have strategies that can be used to book orders', async () => {
      if (!await common.getStrategyId(inst)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy);
        await cst.btnSubmit.click();
      }
      strategyId = await common.getStrategyId(inst);
      expect(parseInt(strategyId)).to.be.a('number', 'Strategy ID');
    });
    it('Counterparty trading user should log in', async () => {
      trader1 = new ApiClient();
      let wsOpen = false;
      await trader1.login(frameworkConfig.users.traders[0].username, frameworkConfig.users.traders[0].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader1.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      await trader1.respondToRFS(strategyId);
    });
    it(`Counterparty trading user ${usersConfig.traders[7].username} should log in`, async () => {
      trader2 = new ApiClient();
      let wsOpen = false;
      await trader2.login(usersConfig.traders[7].username, usersConfig.traders[7].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader2.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      trader2.strategyId = strategyId;
    });
    it('Broker should initiate an RFS', async () => {
      mainWh = await browser.getCurrentTabId();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst);
      await strategyRow.clickStatus();
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status');
    });
    it(`Broker should add trader ${tradingUser1} to the RFS`, async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow();
      await rfsWindow.addTradingUser(tradingUser1);
      const btnExists = await rfsWindow.btnUserExists(tradingUser1);
      expect(btnExists).to.equal(true, `RFS User button ${tradingUser1} exists`);
    });
    it(`Broker should be able to add a quote to the RFS during trading phase on behalf of trader ${tradingUser1}`, async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      await rfsWindow.quote(101.5, 104.5, 2500);
      await rfsWindow.waitUntilMyCurrentAsk('104.500');
      const ask = await rfsWindow.getMyCurrentAsk();
      const bid = await rfsWindow.getMyCurrentBid();
      expect(ask).to.equal('104.500', 'RFS My Current Ask');
      expect(bid).to.equal('101.500', 'RFS My Current Bid');
    });
    it('Broker should see RFS summary when counterparty trader accepts my Bid', async () => {
      await trader1.rfsAccept(104.5, null, 2500, null);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      const myTotalBought = await rfsWindow.getSummaryTotalBought();
      const myTotalSold = await rfsWindow.getSummaryTotalSold();
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(myTotalBought).to.equal('0 L', 'RFS My Total Bought Amount');
      expect(myTotalSold).to.equal('2500 L', 'RFS My Total Sold Amount');
      expect(totalMatched).to.equal('2500 L', 'RFS Total Matched');
    });
    it('Broker should see VC status against the strategy', async () => {
      await browser.switchTab(mainWh);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy row status');
    });
    it('Broker should see VC window open when strategy is clicked on', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const instTitle = await vcWindow.getInstrumentTitle();
      const index = await vcWindow.getIndex();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      expect(index).to.equal('SX5E', 'VC window index');
      expect(instTitle).to.equal('P DEC25', 'VC window instrument title');
      expect(ref).to.equal('132', 'VC window reference');
      expect(delta).to.equal('122', 'VC window delta');
    });
    it(`Broker should add trader ${tradingUser2} to the VC`, async () => {
      await vcWindow.addTradingUser(tradingUser2);
      const btnExists = await rfsWindow.btnUserExists(tradingUser2);
      expect(btnExists).to.equal(true, `Button for Trader ${tradingUser2} should be added to the VC`);
    });
    it(`Trader ${tradingUser2} should responded to the VC`, async () => {
      await vcWindow.btnUserClick(tradingUser1);
      const traderId = await trader2.userData.user.id;
      const traderDeskId = await trader2.userData.user.deskId;
      await trader2.vcAddInterest('SELL', 2500, traderId, traderDeskId);
      await vcWindow.waitUntilOpenToAll();
      await vcWindow.waitUntilOffers(1, frameworkConfig.shortTimeout);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(1, 'VC window should show counter-party traders offer');
    });
    it(`Broker should see a warning message informing him trader ${tradingUser2} has already participating`, async () => {
      await vcWindow.btnUserClick(tradingUser2);
      const hasMessage = await vcWindow.userParticipatingMsgExists();
      expect(hasMessage).to.equal(true, `Expected 'USER ALREADY PARTICIPATING' message in VC window for trader ${tradingUser2}`);
    });
    it('Trader should cancel VC volume', async () => {
      await trader2.vcCancelInterest();
      await vcWindow.btnUserClick(tradingUser1);
      await vcWindow.waitUntilOffers(0);
      const offers = await vcWindow.getBidOfferRowCount();
      expect(offers).to.equal(0, 'VC window should show 0 offers');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser1}`, async () => {
      await vcWindow.waitForSummary();
      await vcWindow.btnUserClick(tradingUser1);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('0', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('2500', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('2500', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser2}`, async () => {
      await vcWindow.btnUserClick(tradingUser2);
      const hasMessage = await vcWindow.userParticipatingMsgExists();
      expect(hasMessage).to.equal(true, `Expected 'USER ALREADY PARTICIPATING' message in VC window for trader ${tradingUser2}`);
    });
  });

  describe('Test 4: As a broker I should see any unmatched volume will be added to the Market Depth table after the VC session has completed', () => {
    const inst = new Instrument(UNDERLYING.sx5e, 'C', 'DEC25', '175', null, null, null, '155', '101', null);
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 155, 101, POLARITY.negative, null, null);
    strategy.addLeg('DEC25', '175', null);

    let strategyRow = null;
    let marketDepth = null;
    let strategyId = null;
    let mainWh = null;
    const tradingUser1 = 'LP01 - L1U9';

    it('Broker should login', async () => {
      await common.login(broker.username, broker.password);
      const userTxt = await mainPageFrame.getUsername();
      mainWh = await browser.getCurrentTabId();
      expect(userTxt).to.equal(broker.username, 'Expected username');
    });
    it('Setup - Broker should have strategies that can be used to book orders', async () => {
      if (!await common.getStrategyId(inst)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy);
        await cst.btnSubmit.click();
      }
      strategyId = await common.getStrategyId(inst);
      expect(parseInt(strategyId)).to.be.a('number', 'Strategy ID');
    });
    it('Counterparty trading user should log in', async () => {
      trader1 = new ApiClient();
      let wsOpen = false;
      await trader1.login(usersConfig.traders[0].username, usersConfig.traders[0].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader1.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      await trader1.respondToRFS(strategyId);
    });
    it('Broker should initiate an RFS', async () => {
      mainWh = await browser.getCurrentTabId();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst);
      await strategyRow.clickStatus();
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status');
    });
    it(`Broker should add trader ${tradingUser1} to the RFS`, async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow();
      await rfsWindow.addTradingUser(tradingUser1);
      const btnExists = await rfsWindow.btnUserExists(tradingUser1);
      expect(btnExists).to.equal(true, `RFS User button ${tradingUser1} exists`);
    });
    it(`Broker should be able to add a quote to the RFS during trading phase on behalf of trader ${tradingUser1}`, async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      await rfsWindow.quote(101.5, 104.5, 2500);
      await rfsWindow.waitUntilMyCurrentAsk('104.500');
      const ask = await rfsWindow.getMyCurrentAsk();
      const bid = await rfsWindow.getMyCurrentBid();
      expect(ask).to.equal('104.500', 'RFS My Current Ask');
      expect(bid).to.equal('101.500', 'RFS My Current Bid');
    });
    it('Broker should see RFS summary when counterparty trader accepts my Bid', async () => {
      await trader1.rfsAccept(104.5, null, 2500, null);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      const myTotalBought = await rfsWindow.getSummaryTotalBought();
      const myTotalSold = await rfsWindow.getSummaryTotalSold();
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(myTotalBought).to.equal('0 L', 'RFS My Total Bought Amount');
      expect(myTotalSold).to.equal('2500 L', 'RFS My Total Sold Amount');
      expect(totalMatched).to.equal('2500 L', 'RFS Total Matched');
    });
    it('Broker should see VC status against the strategy', async () => {
      await browser.switchTab(mainWh);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy row status');
    });
    it('Broker should see VC window open when strategy is clicked on', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const instTitle = await vcWindow.getInstrumentTitle();
      const index = await vcWindow.getIndex();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      expect(index).to.equal('SX5E', 'VC window index');
      expect(instTitle).to.equal('C DEC25', 'VC window instrument title');
      expect(ref).to.equal('155', 'VC window reference');
      expect(delta).to.equal('101', 'VC window delta');
    });
    it(`Broker should be able to add VC interest for trader ${tradingUser1}`, async () => {
      await vcWindow.setMySellInterestInput(2500);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(1);
      const row = await vcWindow.getBidOfferRow(1);
      const offer = await row.getOffer();
      const offerTxt = await offer.getText();
      expect(offerTxt).to.equal('L1U9-LP012500', 'VC window should show offer');
    });
    it(`Broker should see summary at the end of the VC for trader ${tradingUser1}`, async () => {
      await vcWindow.waitForSummary();
      await vcWindow.btnUserClick(tradingUser1);
      const myTotalBought = await vcWindow.getSummaryTotalBought();
      const myTotalSold = await vcWindow.getSummaryTotalSold();
      const totalMatched = await vcWindow.getSummaryTotalMatched();
      expect(myTotalBought).to.equal('0', 'VC Summary My Total Bought Amount');
      expect(myTotalSold).to.equal('2500', 'VC Summary My Total Sold Amount');
      expect(totalMatched).to.equal('2500', 'VC Summary Total Amount Matched');
    });
    it(`Broker should see 2500 ask for trading user ${tradingUser1} in the market depth table`, async () => {
      await browser.switchTab(mainWh);
      const marketDepthTab = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const found = await marketDepthTab.askFound('104.500', '2 500', 'LP01-L1U9');
      expect(found).to.equal(true, `Market Depth bid should contain ask for trader ${tradingUser1}`);
      await marketDepthTab.clickDeleteAsk('104.500', '2 500', 'LP01-L1U9');
    });
  });


  describe('Test 5: As a broker I should be able to clear, update and cancel unmatched volume added on behalf of traders during a VC', () => {
    const inst = new Instrument(UNDERLYING.sx5e, 'P', 'DEC25', '175', null, null, null, '155', '101', null);
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 155, 101, POLARITY.positive, null, null);
    strategy.addLeg('DEC25', '175', null);

    let strategyRow = null;
    let marketDepth = null;
    let strategyId = null;
    let mainWh = null;
    const tradingUser1 = 'LP01 - L1U9';

    it('Broker should login', async () => {
      await common.login(broker.username, broker.password);
      const userTxt = await mainPageFrame.getUsername();
      mainWh = await browser.getCurrentTabId();
      expect(userTxt).to.equal(broker.username, 'Expected username');
    });
    it('Setup - Broker should have strategies that can be used to book orders', async () => {
      if (!await common.getStrategyId(inst)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy);
        await cst.btnSubmit.click();
      }
      strategyId = await common.getStrategyId(inst);
      expect(parseInt(strategyId)).to.be.a('number', 'Strategy ID');
    });
    it('Counterparty trading user should log in', async () => {
      trader1 = new ApiClient();
      let wsOpen = false;
      await trader1.login(usersConfig.traders[0].username, usersConfig.traders[0].password);
      await browser.waitUntil(async () => {
        wsOpen = await trader1.wsOpen;

        return wsOpen;
      }, frameworkConfig.shortTimeout);
      expect(wsOpen).to.equal(true, 'Trader API Websocket Open');
      await trader1.respondToRFS(strategyId);
    });
    it('Broker should initiate an RFS', async () => {
      mainWh = await browser.getCurrentTabId();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst);
      await strategyRow.clickStatus();
      marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      await marketDepth.clickRequestQuotesBtn();
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status');
    });
    it(`Broker should add trader ${tradingUser1} to the RFS`, async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow();
      await rfsWindow.addTradingUser(tradingUser1);
      const btnExists = await rfsWindow.btnUserExists(tradingUser1);
      expect(btnExists).to.equal(true, `RFS User button ${tradingUser1} exists`);
    });
    it(`Broker should be able to add a quote to the RFS during trading phase on behalf of trader ${tradingUser1}`, async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      await rfsWindow.quote(101.5, 104.5, 2500);
      await rfsWindow.waitUntilMyCurrentAsk('104.500');
      const ask = await rfsWindow.getMyCurrentAsk();
      const bid = await rfsWindow.getMyCurrentBid();
      expect(ask).to.equal('104.500', 'RFS My Current Ask');
      expect(bid).to.equal('101.500', 'RFS My Current Bid');
    });
    it('Broker should see RFS summary when counterparty trader accepts my Bid', async () => {
      await trader1.rfsAccept(104.5, null, 2500, null);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      const myTotalBought = await rfsWindow.getSummaryTotalBought();
      const myTotalSold = await rfsWindow.getSummaryTotalSold();
      const totalMatched = await rfsWindow.getSummaryTotalMatchedInRFS();
      expect(myTotalBought).to.equal('0 L', 'RFS My Total Bought Amount');
      expect(myTotalSold).to.equal('2500 L', 'RFS My Total Sold Amount');
      expect(totalMatched).to.equal('2500 L', 'RFS Total Matched');
    });
    it('Broker should see VC status against the strategy', async () => {
      await browser.switchTab(mainWh);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('VC', 'Strategy row status');
    });
    it('Broker should see VC window open when strategy is clicked on', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const instTitle = await vcWindow.getInstrumentTitle();
      const index = await vcWindow.getIndex();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      expect(index).to.equal('SX5E', 'VC window index');
      expect(instTitle).to.equal('P DEC25', 'VC window instrument title');
      expect(ref).to.equal('155', 'VC window reference');
      expect(delta).to.equal('101', 'VC window delta');
    });
    it(`Broker should be able to add VC interest for trader ${tradingUser1}`, async () => {
      await vcWindow.setMySellInterestInput(2500);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(1);
      const row = await vcWindow.getBidOfferRow(1);
      const offer = await row.getOffer();
      const offerTxt = await offer.getText();
      expect(offerTxt).to.equal('L1U9-LP012500', 'VC window should show offer');
    });
    it(`Broker should be able to update VC interest for trader ${tradingUser1}`, async () => {
      await vcWindow.setMySellInterestInput(3000);
      await vcWindow.btnUpdateClick();
      await vcWindow.waitUntilOffers(2);
      const row = await vcWindow.getBidOfferRow(2);
      const offer = await row.getOffer();
      await offer.waitUntilTdText('L1U9-LP01500');
      const offerTxt = await offer.getText();
      expect(offerTxt).to.equal('L1U9-LP01500', 'VC window should show offer');
    });
    it(`Broker should be able to cancel VC interest for trader ${tradingUser1}`, async () => {
      await vcWindow.btnCancelClick();
      await vcWindow.waitUntilOffers(0);
      const offersCount = await vcWindow.getBidOfferRowCount();
      expect(offersCount).to.equal(0, 'VC window bids/offers count');
    });
    it(`Broker should be able to add VC sell interest for trader ${tradingUser1}`, async () => {
      await vcWindow.setMySellInterestInput(6000);
      await vcWindow.btnSubmitClick();
      await vcWindow.waitUntilOffers(1);
      const row = await vcWindow.getBidOfferRow(1);
      const offer = await row.getOffer();
      const offerTxt = await offer.getText();
      expect(offerTxt).to.equal('L1U9-LP016000', 'VC window should show offer');
    });
    it(`Broker should be able to update VC sell interest for trader ${tradingUser1}`, async () => {
      await vcWindow.setMySellInterestInput(2000);
      await vcWindow.btnUpdateClick();
      const row = await vcWindow.getBidOfferRow(1);
      const offer = await row.getOffer();
      await offer.waitUntilTdText('L1U9-LP012000');
      const offerTxt = await offer.getText();
      expect(offerTxt).to.equal('L1U9-LP012000', 'VC window should show offer');
    });
    it(`Broker should be able to cancel VC sell interest for trader ${tradingUser1}`, async () => {
      await vcWindow.btnCancelClick();
      await vcWindow.waitUntilOffers(0);
      const offersCount = await vcWindow.getBidOfferRowCount();
      expect(offersCount).to.equal(0, 'VC window bids/offers count');
    });
  });
});
