import StartUp from '../pages/StartUp';
import should from 'chai';
import {Bootstrap} from '@fenics/fenics-test-core';
import {hasTabOpen} from '../../../utilities/webdriverHelper/tabsHelper';
import WaitForHelper from '../../../utilities/webdriverHelper/waitForHelper';
import {shellExec} from '../../../utilities/framework/shell-exec';
import UserLogin from '../../../pages/UserLogin';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';

describe('Testing login functionality for Blue Chip', function loginTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let waitForHelper = null;
  let startUp = null;
  let userLogin = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    waitForHelper = new WaitForHelper(context);
    startUp = new StartUp(context);
    userLogin = new UserLogin(context);

    expect(browser).to.exist;
  });

  after(() => {
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  this.timeout(frameworkConfig.testMaxTime);

  it('Should load blue chip page', async () => {
    should.assert.exists(browser);
    await browser.waitUntil(() => hasTabOpen(browser, 'FenicsGO'));
  });

  it('Should produce error message when no username is provided', async () => {
    const username = '';
    const password = 'random password';

    await startUp.clickLogin();

    await userLogin.pageHasLoaded();
    await userLogin.enterUsername(username);
    await userLogin.enterPassword(password);
    await userLogin.clickLogin();
    await userLogin.clickExitLogin();
  });

  it('Should be able to login to Blue Chip successfully', async () => {
    const username = 'LP05U05';
    const password = 'BlueChip!8';

    await startUp.clickLogin();

    await userLogin.pageHasLoaded();
    await userLogin.enterUsername(username);
    await userLogin.enterPassword(password);
    await waitForHelper.waitForEnabled(userLogin.btnlogin);
    await userLogin.clickLogin();

    await mainPageFrame.pageHasLoaded();
    const loggedInUser = await mainPageFrame.txtUserName.getText();
    should.expect(loggedInUser).to.have.string(username);

    await mainPageFrame.clickLogout();
    const warningLogoutTitle = await mainPageFrame.txtConfirmLogout.getText();
    const warningLogoutMessage = await mainPageFrame.txtConfirmLogoutDescription.getText();
    should.expect(warningLogoutTitle).to.have.string('Confirm exit');
    should.expect(warningLogoutMessage).to.have.string('All orders on the platform will be cancelled.');
    await mainPageFrame.clickLogoutConfirmOk();
  });
});
