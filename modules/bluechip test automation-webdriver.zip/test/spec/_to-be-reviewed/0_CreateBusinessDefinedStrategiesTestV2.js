import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../../utilities/framework/shell-exec';
import {join} from 'path';
import {STRATEGY_WORKFLOW, FILL_TYPE, TIME_TYPE} from '../../../constant/GenericType';
import {expect} from 'chai';
import TestCommons from '../../../lib/TestCommons';
import {frameworkConfig} from '../../../config/framework.config';
import {usersConfig} from '../../../config/users.config';
import {apiConfig} from "../../../config/api.config";
import ApiClient from '../../../utilities/api/ApiClient';
import Rfs from '../../../pages/child_windows/Rfs';
import MarketViewTabs from '../../../constant/MarketViewTabs';
import TestCaseReader from '../../../lib/excelutils/TestCaseReader';
import EurexSimulatorPrices from '../../../lib/eurexsimulator/EurexSimulatorPrices';

let context = null;
const strategyCount = 700;
const fileToTrade = 'C:\\temp\\BusinessTestData\\Result_2019-11-1329.csv';

async function createStrategy (mainPageFrame, strategy) {

  await mainPageFrame.switchToWindow();
  await mainPageFrame.clickCreateStrategyHeader();
  const strategyTab = await mainPageFrame.getCreateStrategyTab();
  await global.browser.pause(frameworkConfig.veryShortTimeout);
  await strategyTab.addNewStrategy(strategy);
  const submitClicked = await strategyTab.btnSubmitClick();

  if (submitClicked === false) {
    strategy.failed = true;
    strategy.failureReason = 'CREATION_FAILED';
  } else {
    strategy.failed = false;
  }

  return strategy;
}

async function priceStrategy (eurexPricer, strategy) {
  const bidDifference = 1.5;
  let pricedStrategy = null;

  if (strategy.failed === false) {
    // Price the strategy
    pricedStrategy = await eurexPricer.priceLegs(strategy);
    const lpQuotePrice = pricedStrategy.suggestedTradePrice;

    if (lpQuotePrice === null) {
      pricedStrategy.failed = true;
      pricedStrategy.failureReason = 'PRICING_FAILED';
    } else {
      const lpBidPrice = Math.floor(lpQuotePrice);
      const lpAskPrice = Math.ceil(lpBidPrice) + bidDifference;
      pricedStrategy.bidPrice = lpBidPrice;
      pricedStrategy.askPrice = lpAskPrice;
      pricedStrategy.offerSize = 3500;
    }

    return pricedStrategy;
  }

  return pricedStrategy;
}

async function tradeRfsStrategy (strategy, mainPageFrame, common, apiTrader) {
  const logger = context.getLogger();
  const browser = global.browser;

  if (strategy.failed === true) {
    return strategy;
  }

  const marketView  = await mainPageFrame.getMarketViewTab();
  const marketDepth = await marketView.getMarketDepthTab();
  await marketDepth.clickRequestQuotesBtn();
  await apiTrader.respondToRFS(strategy.strategyId);
  await apiTrader.rfsQuote(strategy.strategyId, strategy.bidPrice, strategy.askPrice, strategy.offerSize);

  const rfsWindow = new Rfs(context);

  let foundRfsWindow = null;
  try {
    foundRfsWindow = await browser.waitUntil(async () => {
      const foundWindow = await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      return foundWindow === true;
    }, frameworkConfig.mediumTimeout);
  } catch (err) {
    logger.log('RFS window was not found within the timeout period');
  }

  if (foundRfsWindow === false && strategy.failed === false) {
    strategy.failed = true;
    strategy.failureReason = 'RFS_WINDOW_NOTFOUND';
  }

  const timeout = frameworkConfig.litPhaseTimeout + frameworkConfig.darkPhaseTimeout + frameworkConfig.veryShortTimeout;
  await rfsWindow.waitUntilPhase('TRADING', timeout);
  const bidOfferRow = await rfsWindow.getBidOfferRow(1);
  await bidOfferRow.waitUntilPrice(strategy.bidPrice, strategy.askPrice);
  await bidOfferRow.clickBidPriceBtn();
  await rfsWindow.btnHitClick();
  const foundMatches = await rfsWindow.waitUntilRfsMatchesHaveOccurred();

  if (!foundMatches) {
    await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
    strategy.failed = true;
    strategy.failureReason = 'RFS_ENDED_NOMATCH';
  }

  await rfsWindow.btnOkClick();

  return strategy;
}


async function tradeOrderbookStrategy (strategy, mainPageFrame, common, apiTrader) {

  const marketView = await mainPageFrame.getMarketViewTab();
  const orderBook = await marketView.getOrderBook();
  await orderBook.enterOffer(strategy.bidPrice, strategy.offerSize, TIME_TYPE.day, FILL_TYPE.partial);
  await orderBook.btnSubmitClick();
  const confirm = await orderBook.btnConfirmExists();

  if (confirm) {
    await orderBook.btnConfirmClick();
  }

  const ok = await orderBook.btnOkExists();
  if (ok) {
    await orderBook.btnOkClick();
  }

  await apiTrader.strategyOrderAdd(strategy.strategyId, false, true, false, strategy.askPrice, 'BUY', strategy.offerSize, false);

  return strategy;
}

async function tradeStrategy (strategy, mainPageFrame, common, apiTrader) {

  if (strategy.failed === true) {
    return strategy;
  }

  let marketViewTab = null;

  if (strategy.strategy.workflow === STRATEGY_WORKFLOW.rfs) {
    marketViewTab = MarketViewTabs.EUROSTOXX;
  } else if (strategy.strategy.workflow === STRATEGY_WORKFLOW.orderBook) {
    marketViewTab = MarketViewTabs.DELTA_ONE;
  } else {
    strategy.failed = true;
    strategy.failureReason = `UNKNOWN_WORKFLOW_${strategy.strategy.workflow}`;

    return strategy;
  }

  await mainPageFrame.switchToWindow();
  const strategyId = await common.waitUntilStrategyId(strategy, frameworkConfig.mediumTimeout, marketViewTab, false);
  const marketView = mainPageFrame.getMarketViewTab();
  const alerts = await mainPageFrame.notificationsPanel;
  await alerts.clearAlerts();
  const strategyRow = await marketView.getTable().getTableRow(strategy);
  await strategyRow.waitUntilStatus('', frameworkConfig.mediumTimeout);
  const strategyStatus = await strategyRow.getStatusText();

  if (strategyId === null) {
    strategy.failed = true;
    strategy.failureReason = 'STRATEGY_NOTFOUND_IN_MKVIEW';

    return strategy;
  }

  if (strategyStatus !== '') {
    strategy.failed = true;
    strategy.failureReason = `UNEXPECTED_STATUS_${strategyStatus}`;

    return strategy;
  }

  strategy.strategyId = strategyId;

  if (strategy.strategy.workflow === STRATEGY_WORKFLOW.rfs) {
    return tradeRfsStrategy(strategy, mainPageFrame, common, apiTrader);
  }

  return tradeOrderbookStrategy(strategy, mainPageFrame, common, apiTrader);
}

async function getFenicsGoTradeDetails (strategy, mainPageFrame) {

  if (strategy.failed) {
    return strategy;
  }

  await mainPageFrame.switchToWindow();
  await mainPageFrame.clickMatchedTradesHeader();
  const matchedTradesTab = await mainPageFrame.getMatchedTradesTab();
  const tradesTable = await matchedTradesTab.clickMyTradesTab();

  let matchedTrade = null;

  if (!strategy.tradeId) {
    matchedTrade = await tradesTable.getFirstMatchingTrade(strategy, 'SELL', strategy.bidPrice, strategy.offerSize, null, null, null);
  } else {
    matchedTrade = await tradesTable.getTradeById(strategy);
  }

  if (matchedTrade) {
    const tradePopup = await matchedTrade.clickOnTrade();
    strategy.tradeId = await tradePopup.getFencisGoId();
    strategy.exchangeTradeStatus = await tradePopup.getTransactionStatus();
  } else {
    strategy.failed = true;
    strategy.failureReason = 'GOTRADEID_NOTFOUND_IN_MATCHEDTRADES';
  }

  console.log(`Stratgey trade id: ${strategy.tradeId} status: ${strategy.exchangeTradeStatus}`);

  return strategy;
}


describe('Create strategies defined by business ', function createBusinessStrategies () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let logger = null;
  const matchedTrades = {};

  // Page object vars
  let mainPageFrame = null;
  let eurexPricer = null;
  let lpClientOne = null;
  let common = null;
  let strategies = null;
  let tcReader = null;

  this.timeout(frameworkConfig.veryLongTimeout * strategyCount);

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    eurexPricer = new EurexSimulatorPrices(context);
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  let nlpTrader = {};
  let lpTraderOne = {};

  describe('Users should login', () => {
    it('NLP trader should login', async () => {
      lpTraderOne = await common.getTrader('LIMK3');
      //lpTraderOne = await common.getTrader('AUTTR18');
      lpClientOne = new ApiClient(lpTraderOne, context);
      await lpClientOne.login();
      //nlpTrader = await common.getTrader('GENLP6');
      nlpTrader = await common.getTrader('GENTR1');
      //nlpTrader = await common.getTrader('AUTTR16');
      await start(nlpTrader);
    });
  });

  describe('Process data', function processData () {

    it('Open input file', async () => {
      tcReader = new TestCaseReader(context);
      await tcReader.openFile(fileToTrade);
      strategies = await tcReader.readAll();
      console.log('checkit');
    });

    it('Create and trade strategies', async () => {
      for (let index = 0; index < strategies.length; index += 1) {
        let strategy = strategies[index];
        console.log(`Creating strategy: ${strategy.rowDataName}`);

        strategy = await createStrategy(mainPageFrame, strategy);
        await browser.pause(1000);
        strategy = await priceStrategy(eurexPricer, strategy);
        await browser.pause(1000);
        strategy = await tradeStrategy(strategy, mainPageFrame, common, lpClientOne);
        const date = new Date();
        strategy.lastTradeTime = date.toLocaleString();
        await browser.pause(frameworkConfig.veryShortTimeout);
        console.log(`Check matched trader: ${strategy.rowDataName}`);
        strategy = await getFenicsGoTradeDetails(strategy, mainPageFrame);
        await tcReader.setResults(strategy);
        strategies[index] = strategy;
      }
    });

    it('Get trade status', async () => {
      await mainPageFrame.switchToWindow();
      await mainPageFrame.clickMatchedTradesHeader();
      const matchedTradesTab = await mainPageFrame.getMatchedTradesTab();
      const tradesTable = await matchedTradesTab.clickMyTradesTab();

      for (let index = 1; index < strategies.length + 1; index += 1) {
        const matchedTrade = await tradesTable.getTradeByRow(index);
        await matchedTrade.clickOnTrade();
        const popover = await matchedTrade.getTradePopover();
        await matchedTrade.dismissPopup();
        matchedTrades[popover.tradeId] = popover.status;
      }
    });

    it('Update spreadsheet', async () => {
      for (let index = 0; index < strategies.length; index += 1) {
        const strategy = strategies[index];

        if (strategy.tradeId && strategy.failed === false) {
          if (strategy.tradeId in matchedTrades) {
            strategy.exchangeTradeStatus = matchedTrades[strategy.tradeId];
          }

          await tcReader.setResults(strategy);
          strategies[index] = strategy;
          console.log(`strategy details status: ${strategy.exchangeTradeStatus}  trade id  ${strategy.tradeId}`);
        } else {
          console.log('if condition did not match');
        }
      }
    });

    it('write results', async () => {
      await tcReader.writeResultsExcel();
    });
  });
});

