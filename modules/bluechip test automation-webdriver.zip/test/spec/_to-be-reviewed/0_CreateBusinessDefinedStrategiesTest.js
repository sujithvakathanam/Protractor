import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import WaitForHelper from '../../utilities/webdriverHelper/waitForHelper';
import {Bootstrap} from '@fenics/fenics-test-core';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {strategies} from '../../data/BusinessDefinedStrategies';
import {FILL_TYPE, STRATEGY, STRATEGY_WORKFLOW, TIME_TYPE} from '../../constant/GenericType';
import EurexSimulatorPrices from '../../lib/eurexsimulator/EurexSimulatorPrices';
import ApiClient from '../../utilities/api/EnhancedApiClient';
import MarketViewTabs from '../../constant/MarketViewTabs';
import Rfs from '../../pages/child_windows/Rfs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import {frameworkConfig} from '../../config/framework.config';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import {usersConfig} from '../../config/users.config';
import TestCaseReader from "../../../lib/excelutils/TestCaseReader";


describe('Create strategies defined by business ', function createBusinessStrategies () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let eurexPricer = null;
  let mainWindowHandle = null;
  let waitForHelper = null;
  let startUp = null;
  let marketViewTab = null;
  let toastNotification = null;
  let lpClientOne = null;
  let common = null;
  let strategyTab = null;
  let tcReader = null;
  let strategies = [];

  before(() => {
    tcReader = new TestCaseReader();
    strategies = tcReader.readAll();
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    eurexPricer = new EurexSimulatorPrices(context);

    expect(browser).to.exist;
  });

  after(() => {
    lpClientOne.logout();
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  const todaysFuturePrices = {
    STXEM0 : 3487.5,
    STXEH0 : 3570.0,
    STXEZ9 : 3584.5
  };

  const startAt = 0;
  let endAt = 1;
  const strategyToTrade = [];
  const testcasesToTrade = [2464, 2467];
  let nlpTrader = [];
  let lpTraderOne = [];

  this.timeout(frameworkConfig.mediumTimeout * strategies.length * 3);

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    mainWindowHandle = await browser.getCurrentTabId();
    waitForHelper = new WaitForHelper(context);
    strategyTab = mainPageFrame.getCreateStrategyTab();
    marketViewTab = mainPageFrame.getMarketViewTab();
    toastNotification = new ToastNotification(context);
  }

  if (endAt === 0) {
    endAt = strategies.length;
  }

  describe('Users should login', () => {
    it('NLP trader should login', async () => {
      this.timeout(frameworkConfig.veryLongTimeout);
      lpTraderOne = await common.getTrader('LIMK1');
      lpClientOne = new ApiClient(lpTraderOne, context);
      await lpClientOne.login();
      nlpTrader = await common.getTrader('GENLP6');
      await start(nlpTrader);
    });
  });

  describe('As a NLP trader I want to create and trade all business strategies', () => {
    for (let strat = startAt; strat < endAt; strat += 1) {
      let marketView = null;
      let strategyRow = null;
      let strategy = strategies[strat];

      let lpQuotePrice = null;
      let lpBidPrice = null;
      let lpAskPrice = null;
      let lpSize = null;

      let traded = false;
      if (strategyToTrade.includes(strategies[strat].strategy) && strategies[strat].skip === false
            || strategyToTrade.includes('ALL') && strategies[strat].skip === false
            || testcasesToTrade.includes(strategies[strat].testCaseId)) {
        const future = strategies[strat].future;
        const oldStrategyDisplayName = strategies[strat].rowDataName;

        if (future) {
          strategies[strat].referencePrice = todaysFuturePrices[future];
        }

        const strategyDisplayName = strategies[strat].rowDataName;

        describe(`Traders should create and direct trade strategy [Test case: ${strategies[strat].testCaseId}][ROW: ${strat}] ${strategyDisplayName}`, () => {
          it.only(`I should create strategy [Test case: ${strategies[strat].testCaseId}][ROW: ${strat}]${strategyDisplayName}`, async () => {
            strategies[strat].created = false;

            this.timeout(frameworkConfig.testMaxTime);

            logger.info(`Updating strategy reference price old: ${oldStrategyDisplayName} new: ${strategyDisplayName}`);
            let failed = false;
            let pageValid = false;


            try {
              logger.info(`Creating strategy ${strategies[strat].testCaseId}: ${strategyDisplayName}`);
              await browser.switchTab(mainWindowHandle);
              await mainPageFrame.clickMarketViewHeader();
              await mainPageFrame.clickCreateStrategyHeader();
              const strategyTab = await mainPageFrame.getCreateStrategyTab();
              await strategyTab.addNewStrategy(strategies[strat]);
              pageValid = await strategyTab.validatePage(strategies[strat]);
              let clicked = await strategyTab.btnSubmitClick();
              await browser.pause(1000);
              if (!clicked) {
                clicked = await strategyTab.btnSubmitClick();

                // Try again
                if (!clicked) {
                  logger.error(`Failed to create strategy, submit button was disabled. Strategy: ${strategyDisplayName}`);
                  failed = true;
                }
              }
            } catch (err) {
              logger.error('Strategy creation failed due to error: ', err.toString());
            }

            expect(pageValid).to.equal(true, 'Strategy Info displayed on page did not match Strategy data provided');
            expect(failed).to.equal(false, 'Strategy creation failed, check logs for details');
            strategies[strat].created = true;
          });

          it(`I should trade strategy [Test case: ${strategies[strat].testCaseId}][ROW: ${strat}]${strategyDisplayName}`, async () => {
            traded = false;
            const created = strategy.created;
            expect(created).to.equal(true, 'Strategy creation failed or an error occurred during the creation phase so it will not be traded');

            strategy = await eurexPricer.priceLegs(strategy);
            lpQuotePrice = strategy.suggestedTradePrice;

            const quoted = lpQuotePrice !== null;
            expect(quoted).to.equal(true, 'Suggested trade price could not be calculated.');

            const priceIsNegative = lpQuotePrice <= 0;
            expect(priceIsNegative).to.equal(false, `Suggested price is negative ${lpQuotePrice} Go does not currently allow negative prices`);

            lpBidPrice = Math.floor(lpQuotePrice);
            lpAskPrice = Math.ceil(lpBidPrice) + 0.5;
            lpSize = 3500;

            await browser.switchTab(mainWindowHandle);
            let strategyId = null;
            let mvTab = MarketViewTabs.EUROSTOXX;

            if (strategy.strategy === STRATEGY.jellyRoll
                  || strategy.strategy === STRATEGY.synthetic
                  || strategy.strategy === STRATEGY.roll) {
              mvTab = MarketViewTabs.DELTA_ONE;
            }

            strategyId = await common.waitUntilStrategyId(strategy, frameworkConfig.mediumTimeout, mvTab, false);

            const strategyFound = strategyId !== null;
            expect(strategyFound).to.equal(true, `Could not find strategy ${strategy.rowDataName} in the market view`);

            marketView = mainPageFrame.getMarketViewTab();
            await marketView.clickSubTab(mvTab);
            const alerts = await mainPageFrame.notificationsPanel;
            await alerts.clearAlerts();
            strategyRow = await marketView.getTable().getTableRow(strategy);
            await strategyRow.waitUntilStatus('', frameworkConfig.mediumTimeout);
            const strategyStatus = await strategyRow.getStatusText();
            expect(strategyStatus).to.equal('', `Strategy cannot be traded, strategy is in active ${strategyStatus}`);

            lpClientOne.setStrategy(strategyId);

            if (strategy.strategy.workflow === STRATEGY_WORKFLOW.rfs) {
              await lpClientOne.respondToRFS();
              const marketDepth = await marketView.getMarketDepthTab();
              await marketDepth.clickRequestQuotesBtn();

              let quoted = false;
              try {
                quoted = await browser.waitUntil(async () => {
                  const quoted = await lpClientOne.rfsQuote(lpBidPrice, lpAskPrice, lpSize);

                  return quoted === true;
                }, frameworkConfig.mediumTimeout);
              } catch (err) {
                logger.info('LP trader did not trade in time');
              }

              expect(quoted).to.equal(true, 'LP Trader did not quote on the RFS in time');

              const rfsWindow = await new Rfs(context);

              let foundRfsWindow = null;
              try {
                foundRfsWindow = await browser.waitUntil(async () => {
                  const foundWindow = await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

                  return foundWindow === true;
                }, frameworkConfig.mediumTimeout);
              } catch (err) {
                logger.log('RFS window was not found within the timeout period');
              }

              expect(foundRfsWindow).to.equal(true, `Could not locate the RFS window for strategy ${strategy.rowDataName}`);

              const timeout = frameworkConfig.litPhaseTimeout + frameworkConfig.darkPhaseTimeout + frameworkConfig.veryShortTimeout;
              await rfsWindow.waitUntilPhase('TRADING', timeout);
              const bidOfferRow = await rfsWindow.getBidOfferRow(1);
              await bidOfferRow.waitUntilPrice(lpBidPrice, lpAskPrice);
              await bidOfferRow.clickBidPriceBtn();
              await rfsWindow.btnHitClick();
              const foundMatches = await rfsWindow.waitUntilRfsMatchesHaveOccurred();

              if (!foundMatches) {
                await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
              }
              await rfsWindow.btnOkClick();
              expect(foundMatches).to.equal(true, `RFS for strategy did not end in a match ${strategy.rowDataName}`);
            }

            if (strategy.strategy.workflow === STRATEGY_WORKFLOW.orderBook) {
              const orderBook = await mainPageFrame.getMarketViewTab().getOrderBook();
              await orderBook.enterOffer(lpBidPrice, lpSize, TIME_TYPE.day, FILL_TYPE.partial);
              await orderBook.btnSubmitClick();
              const confirm = await orderBook.btnConfirmExists();
              if (confirm) {
                await orderBook.btnConfirmClick();
              }

              const ok = await orderBook.btnOkExists();
              if (ok) {
                await orderBook.btnOkClick();
              }

              await lpClientOne.strategyOrderAdd(strategyId, false, true, false, lpBidPrice, 'BUY', lpSize, false);
            }

            await mainPageFrame.switchToWindow();
            const startegyInVC = await strategyRow.waitUntilStatus('VC', frameworkConfig.mediumTimeout);
            expect(startegyInVC).to.equal(true, `VC has not been started on strategy ${strategy.rowDataName}`);
            await strategyRow.clickStatus();
            const vcWindow = new VolumeClearing(context);

            const foundVcWindow = await browser.waitUntil(async () => {
              const foundWindow = await vcWindow.switchToWindow();

              return foundWindow === true;
            }, frameworkConfig.shortTimeout);

            expect(foundVcWindow).to.equal(true, `VC window could not be found for strategy ${strategy.rowDataName}`);
            await vcWindow.waitForSummary();
            await vcWindow.btnOkClick();
            traded = true;
          });

          it(`Trade should be in NOT APPROVED Status [Test case: ${strategies[strat].testCaseId}][ROW: ${strat}]${strategyDisplayName}`, async () => {
            if (traded === false) {
              expect(traded).to.equal(true, 'Trade phase failed, will not check status.');
            }
            this.timeout(frameworkConfig.mediumTimeout);
            await browser.switchTab(mainWindowHandle);
            await mainPageFrame.clickMatchedTradesHeader();
            const matchedTradesTab = mainPageFrame.getMatchedTradesTab();
            const tradesTable = await matchedTradesTab.clickMyTradesTab();
            await browser.pause(3000);

            let refPrice = 0;
            let delta = 0;

            if (strategy.strategy === STRATEGY.jellyRoll) {
              refPrice = '';
              delta = 0;
            } else {
              refPrice = strategy.referencePrice;
              delta = strategy.getDisplayDelta();
            }

            let tradeStrategyTitle = strategy.underlying.concat(' ', strategy.strategy.shortName, ' ', strategy.expiry, ' ', strategy.strike, ' ', strategy.ratio, ' r', refPrice, ' d', delta, '%');


            logger.info('Finding status for strategy ', tradeStrategyTitle);

            const trade = await tradesTable.getTradeByRow(1);
            let tradeStrategy = await trade.getStrategy();
            tradeStrategy = tradeStrategy.trim();
            tradeStrategy = tradeStrategy.replace('  ', ' ');
            tradeStrategyTitle = tradeStrategyTitle.replace('  ', ' ');
            expect(tradeStrategy).to.equal(tradeStrategyTitle, 'First row in My Trades Table strategy title');

            const tradeId = await trade.getFencicGoTradeId();

            logger.info(`Strategy:${tradeStrategyTitle} Fenics Go Trade ID: ${tradeId}`);
            strategy.tradeId = tradeId;

            let tradeStatus = '';
            await browser.waitUntil(async () => {
              tradeStatus = await trade.getExchangeStatus();
              tradeStatus = tradeStatus.trim();
              const found = tradeStatus === 'NOT APPROVED' || tradeStatus === 'FAILED';

              return found;
            }, frameworkConfig.mediumTimeout);

            strategy.exchangeStatus = tradeStatus;
            expect(tradeStatus).to.equal('NOT APPROVED', `Actual trade status is ${tradeStatus}`);
          });
        });
      }
    }
  });
});
