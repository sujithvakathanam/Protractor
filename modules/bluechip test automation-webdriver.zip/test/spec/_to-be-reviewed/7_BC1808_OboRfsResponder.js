import {switchToTab} from '../../../utilities/webdriverHelper/tabsHelper';
import {shellExec} from '../../../utilities/framework/shell-exec';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import Rfs from '../../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Instrument from '../lib/Instrument';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../constants/GenericType';
import ApiClient from '../../../utilities/api/ApiClient';
import VolumeClearing from '../../../pages/child_windows/VolumeClearing';
import TestCommons from '../../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import Strategy from '../../../lib/Strategy';
import ToastNotification from '../../../pages/child_windows/ToastNotification';
import {frameworkConfig} from '../../../config/framework.config';
import {join} from 'path';
import {usersConfig} from '../../../config/users.config';

/*
 * This test suite supersedes the functionality implemented in 4_BC1113_OboRfsInitiatorTest.js
 */
describe('BC-1808 OBO RFS Responder Test suite', function rfsResponderTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let rfsWindow = null;
  let vcWindow = null;
  let common = null;
  let mainWindowH = null;
  let toastNotification = null;

  let broker1 = null;
  let trader1 = null;
  let trader2 = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    mainPageFrame = new MainPageFrame(context);
    rfsWindow = new Rfs(context);
    vcWindow = new VolumeClearing(context);
    common = new TestCommons(context);
    toastNotification = new ToastNotification(context);
    broker1 = new ApiClient();
    trader1 = new ApiClient();
    trader2 = new ApiClient();

    expect(browser).to.exist;
  });

  after(() => {
    broker1.logout();
    trader1.logout();
    trader2.logout();
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  this.timeout(frameworkConfig.testMaxTime);

  const inst1 = new Instrument(UNDERLYING.sx5e, 'P', 'DEC25', '300', null, null, null, '220', '51', null);
  const strategy1 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 220, 51, POLARITY.positive, null, null);
  strategy1.addLeg('DEC25', '300', null);

  describe('Setup test data', () => {
    it('Should have a strategies to trade', async () => {
      await common.login(usersConfig.brokers[0].username, usersConfig.brokers[0].password);
      await mainPageFrame.clickMarketViewHeader();
      if (!await common.getStrategyId(inst1)) {
        await mainPageFrame.clickCreateStrategyHeader();
        const cst = await mainPageFrame.getCreateStrategyTab();
        await cst.addNewStrategy(strategy1);
        await cst.btnSubmit.click();
      }
      await common.logout();
    });
  });

  describe('BC1808_OboRfsResponder Test 1: As a broker I should be able to respond to an RFS and then trade on behalf of a trader', () => {
    let strategyId = null;
    let strategyRow = null;
    let bidOffer = null;
    it('Broker should have trader user to represent', async () => {
      await trader1.login(usersConfig.traders[3].username, usersConfig.traders[3].password);
    });
    it('Should have a strategy that I can trade', async () => {
      await common.login(usersConfig.brokers[3].username, usersConfig.brokers[3].password);
      mainWindowH = await browser.getCurrentTabId();
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
      strategyId = await common.getStrategyId(inst1);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('', 'Strategy status should be blank');
    });
    it('Should start an RFS', async () => {
      await broker1.login(usersConfig.brokers[0].username, usersConfig.brokers[0].password);
      await browser.waitUntil(() => broker1.wsOpen, frameworkConfig.mediumTimeout);
      await broker1.initiateRFS(strategyId);
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy status');
    });
    it('Should see responder notification and toast message', async () => {
      const rfsNotification = await mainPageFrame.notificationsPanel.notifications.getRfsResponderInvite(`${inst1.strategy} ${inst1.expiry}`, inst1.strikes, inst1.underlying);
      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, 'Expected to find RFS responder notification message');
      let toastMsgs = null;
      await browser.waitUntil(async () => {
        toastMsgs = await toastNotification.getRfsResponderToastMsg(inst1.underlying, `${inst1.strategy} ${inst1.expiry}`, inst1.strikes);

        return toastMsgs.length > 0;
      }, frameworkConfig.mediumTimeout);
      expect(toastMsgs.length === 1).to.equal(true, 'Expected to find Responder toast message');
    });
    it('Should be able to click on the strategy to open the RFS responder window', async () => {
      await strategyRow.clickStatus();
      rfsWindow = new Rfs(context);
      await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'));
      await browser.getCurrentTabId();
      const windowLetter = await rfsWindow.getWindowLetter();
      const windowTitle = await rfsWindow.getTitle();
      const delta = await rfsWindow.getDelta();
      const ref = await rfsWindow.getRef();
      const responded = await rfsWindow.getResponded();
      const phase = await rfsWindow.getPhase();
      expect(windowLetter).to.equal('R', 'Expected RFS window letter to be R');
      expect(windowTitle).to.equal(`${inst1.strategy} ${inst1.expiry}`, 'RFS window title');
      expect(delta).to.equal(inst1.delta, 'RFS window delta');
      expect(ref).to.equal(inst1.ref, 'RFS window ref');
      expect(responded).to.include('0/', 'RFS window expected zero rfs participants');
      expect(phase).to.equal('DARK', 'RFS window should be in DARK phase');
    });
    it('Broker should be able to add traders to the RFS', async () => {
      await rfsWindow.addTradingUser('LP01 - L2U3');
      const user = await rfsWindow.btnUserExists('LP01 - L2U3');
      expect(user).to.equal(true, 'User button labeled LP01 - L2U3 should be added to RFS window');
    });
    it('RFS should be in DARK trading phase', async () => {
      const phase = await rfsWindow.getPhase();
      const responded = await rfsWindow.getResponded();
      const fldEnterSizeEnabled = await rfsWindow.fldEnterSizeEnabled();
      const fldEnterAskEnabled = await rfsWindow.fldEnterAskEnabled();
      const fldEnterBidEnabled = await rfsWindow.fldEnterBidEnabled();
      const btnSubmitEnabled = await rfsWindow.btnSubmitEnabled();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      expect(phase).to.equal('DARK');
      expect(responded).to.include('0/', 'Expected zero users to of responded to RFS');
      expect(fldEnterSizeEnabled).to.equal(false, 'Enter Size field should be disabled');
      expect(fldEnterAskEnabled).to.equal(false, 'Enter Ask field should be disabled');
      expect(fldEnterBidEnabled).to.equal(false, 'Enter size field should be disabled');
      expect(btnSubmitEnabled).to.equal(false, 'Button Submit should be disabled');
      expect(btnSubjectEnabled).to.equal(false, 'Button Subject should be disabled');
    });
    it('RFS should transition to LIT trading phase', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      const fldEnterSizeEnabled = await rfsWindow.fldEnterSizeEnabled();
      const fldEnterAskEnabled = await rfsWindow.fldEnterAskEnabled();
      const fldEnterBidEnabled = await rfsWindow.fldEnterBidEnabled();
      const btnSubmitEnabled = await rfsWindow.btnSubmitEnabled();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      const darkSpread = await rfsWindow.getDarkSpread();
      const currentSpread = await rfsWindow.getCurrentSpread();
      expect(phase).to.equal('LIT', 'Phase should be LIT');
      expect(fldEnterSizeEnabled).to.equal(false, 'Enter Size field should be disabled');
      expect(fldEnterAskEnabled).to.equal(false, 'Enter Ask field should be disabled');
      expect(fldEnterBidEnabled).to.equal(false, 'Enter size field should be disabled');
      expect(btnSubmitEnabled).to.equal(false, 'Button Submit should be disabled');
      expect(btnSubjectEnabled).to.equal(false, 'Button Subject should be disabled');
      expect(darkSpread).to.equal('-', 'Dark spread should be blank');
      expect(currentSpread).to.equal('-', 'Current spread should be blank');
    });
    it('RFS should transition to TRADING phase', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      const fldEnterSizeEnabled = await rfsWindow.fldEnterSizeEnabled();
      const fldEnterAskEnabled = await rfsWindow.fldEnterAskEnabled();
      const fldEnterBidEnabled = await rfsWindow.fldEnterBidEnabled();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      expect(phase).to.equal('TRADING', 'Phase should be TRADING');
      expect(fldEnterSizeEnabled).to.equal(true, 'Enter Size field should be enabled');
      expect(fldEnterAskEnabled).to.equal(true, 'Enter Ask field should be enabled');
      expect(fldEnterBidEnabled).to.equal(true, 'Enter size field should be enabled');
      expect(btnSubjectEnabled).to.equal(false, 'Button Subject should be disabled');
    });
    it('Broker should be able to submit an offer', async () => {
      await rfsWindow.quote(100, 105, 5000, null);
      bidOffer = await rfsWindow.getBidOfferRow(1);
      await bidOffer.waitUntilPrice('100.000', '105.000');
    });
    it('When a counterparty broker LIFTs my bid I should see the RFS summary window', async () => {
      const traderId = await trader1.userData.user.id;
      await broker1.rfsAccept(105, null, 2500, traderId);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      await rfsWindow.btnUserClick('LP01 - L2U3');
      const summaryMatchedInRfs = await rfsWindow.getSummaryTotalMatchedInRFS();
      const summaryTotalBought = await rfsWindow.getSummaryTotalBought();
      const summaryTotalSold = await rfsWindow.getSummaryTotalSold();
      expect(summaryMatchedInRfs).equals('2500 L', 'Total Amount Matched in RFS');
      expect(summaryTotalBought).equals('0 L', 'My Total Bought Amount');
      expect(summaryTotalSold).equals('2500 L', 'My Total Sold Amount');
    });
    it('RFS should transition to VC', async () => {
      await browser.switchTab(mainWindowH);
      await mainPageFrame.notificationsPanel.tabAlerts.click();
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC('P DEC25', '105.000', 'SX5E');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });
    it('Should show a VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('105.000', 'SX5E', 'P DEC25', '300');
      expect(vcToastMsgs.length).to.equal(1, 'VC toast message should exist');
      await vcToastMsgs[0].click();
    });
    it('Should show a sell toast message', async () => {
      const sellToastMsgs = await toastNotification.getSellToastMsg('105.000', '2500 L', 'SX5E', 'P DEC25', '300', 'L2U3 - LP01');
      expect(sellToastMsgs.length).to.equal(1, 'Buy Toast notification message should exist');
    });
    it('Should show a sell notification', async () => {
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '105.000', '300', 'Sz 2,500 L', 'SX5E', 'L2U3 - LP01');
      expect(await buyNotification.getSize()).to.equal('Sz 2,500 L');
      const found = await buyNotification.waitUntilRemaining('2,500 L');
      expect(found).to.equal(true, 'Sell Notification - Remaining volume should be 2,500 L');
    });
    it('should open the VC window', async () => {
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const vcId = await vcWindow.vcId;
      const windowLetter = await vcWindow.getWindowLetter();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      const pxValue = await vcWindow.getPxValue();
      const sellInterestInputEnabled = await vcWindow.sellInterestInputEnabled();
      const buyInterestInputEnabled = await vcWindow.buyInterestInputEnabled();
      const isPrioritySeller = await vcWindow.isPrioritySeller();
      const btnUserExists = await vcWindow.btnUserExists('LP01 - L2U3');
      const myLiveSellInterest = await vcWindow.getMyLiveSellInterest();
      const myLiveBuyInterest = await vcWindow.getMyLiveBuyInterest();
      expect(vcId > 0).to.equal(true, 'VC window should open');
      expect(windowLetter).to.equal('V', 'Window Letter');
      expect(ref).to.equal('220', 'Window should show REF');
      expect(delta).to.equal('51', 'Window should show delta');
      expect(pxValue).to.equal('105.000', 'Window should show PX Value');
      expect(sellInterestInputEnabled).to.equal(true, 'Sell interest entry should not be enabled');
      expect(buyInterestInputEnabled).to.equal(false, 'Buy Interest input should be enabled');
      expect(isPrioritySeller).to.equal(true, 'Should be VC priority seller');
      expect(btnUserExists).to.equal(true, 'Trader button should exist on the VC window');
      expect(myLiveSellInterest).to.equal('2500 L', 'My Live Sell Interest');
      expect(myLiveBuyInterest).to.equal('', 'My Live Buy Interest');
    });
    it('VC window should show the offer I have made for the trader I am trading on behalf of', async () => {
      bidOffer = await vcWindow.getBidOfferRow(1);
      const offer = await bidOffer.getOffer();
      const bid = await bidOffer.getBid();
      expect(await bid.getText()).to.equal('', 'Volume Clearing Bid');
      expect(await offer.getText()).to.equal('L2U3-LP012500', 'Volume Clearing Offer');
    });
    it('VC window should update the offer when counterparty adds buy interest', async () => {
      const traderId = await trader1.userData.user.id;
      const traderDeskId = await trader1.userData.user.deskId;
      await broker1.vcAddInterest('BUY', 1000, traderId, traderDeskId);
      const offer = await bidOffer.getOffer();
      await offer.waitUntilTdText('L2U3-LP011500');
      expect(await offer.getText()).to.equal('L2U3-LP011500', 'Volume Clearing Offer');
    });
    it('VC window should remove offer when counterparty buys all volume', async () => {
      const traderId = await trader1.userData.user.id;
      const traderDeskId = await trader1.userData.user.deskId;
      await broker1.vcAddInterest('BUY', 1500, traderId, traderDeskId);
      await browser.waitUntil(async () => await vcWindow.hadBidOfferTblRows() === false, frameworkConfig.shortTimeout);
      expect(await vcWindow.hadBidOfferTblRows()).to.equal(false, 'Expecting no bids or offers in VC window table.');
    });
    it('VC window will show vc session summary', async () => {
      await vcWindow.waitForSummary();
      const summaryTotalBought = await vcWindow.getSummaryTotalBought();
      const summaryTotalSold = await vcWindow.getSummaryTotalSold();
      const summaryTotalMatched = await vcWindow.getSummaryTotalMatched();
      const btnUserExists = await vcWindow.btnUserExists('LP01 - L2U3');
      expect(summaryTotalBought).to.equal('0', 'VC Summary - My Total Bought Amount');
      expect(summaryTotalSold).to.equal('5000', 'VC Summary - My Total Sold Amount');
      expect(summaryTotalMatched).to.equal('5000', 'VC Summary - Total Matched');
      expect(btnUserExists).to.equal(true, 'VC Summary - User button');
    });
    it('Should update the sell notification volume', async () => {
      await browser.switchTab(mainWindowH);
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '105.000', '300', 'Sz 5,000 L', 'SX5E', 'L2U3 - LP01');
      const filled = await buyNotification.waitForFilled();
      expect(filled).to.equal(true, 'Sell Notification - should be Filled');
    });
    it('User should logout', async () => {
      await trader1.logout();
      await broker1.logout();
    });
  });

  describe('BC1808_OboRfsResponder Test 2: As a broker I should be able to respond to an RFS and trade on behalf of multiple traders', () => {
    let strategyId = null;
    let strategyRow = null;
    let bidOffer = null;
    it('Broker should have trader user to represent', async () => {
      await trader2.login(usersConfig.traders[4].username, usersConfig.traders[4].password);
    });
    it('Should have a strategy that I can trade', async () => {
      await common.login(usersConfig.brokers[0].username, usersConfig.brokers[0].password);
      mainWindowH = await browser.getCurrentTabId();
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
      strategyId = await common.getStrategyId(inst1);
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('', 'Strategy status should be blank');
    });
    it('Status field should display RFS when a broker on my desk initiates an RFS', async () => {
      await broker1.login(usersConfig.brokers[3].username, usersConfig.brokers[3].password);
      await browser.waitUntil(() => broker1.wsOpen, frameworkConfig.mediumTimeout);
      await broker1.initiateRFS(strategyId);
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy status');
    });
    it('I Should see RFS responder notification and toast messages for the strategy', async () => {
      const rfsNotification = await mainPageFrame.notificationsPanel.notifications.getRfsResponderInvite(`${inst1.strategy} ${inst1.expiry}`, inst1.strikes, inst1.underlying);
      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found).to.equal(true, 'Expected to find RFS responder notification message');
      let toastMsgs = null;
      await browser.waitUntil(async () => {
        toastMsgs = await toastNotification.getRfsResponderToastMsg(inst1.underlying, `${inst1.strategy} ${inst1.expiry}`, inst1.strikes);

        return toastMsgs.length > 0;
      }, frameworkConfig.mediumTimeout);
      expect(toastMsgs.length === 1).to.equal(true, 'Expected to find Responder toast message');
    });
    it('I Should be able to click on the strategy to open the RFS responder window', async () => {
      await strategyRow.clickStatus();
      rfsWindow = new Rfs(context);
      await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'));
      await browser.getCurrentTabId();
      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter).to.equal('R', 'Expected RFS window letter to be R');
    });
    it('I should be able to add a trader LP04 to the RFS', async () => {
      await rfsWindow.addTradingUser('LP04 - L4U2');
      const btnUserExists = await rfsWindow.btnUserExists('LP04 - L4U2');
      expect(btnUserExists).to.equal(true, 'User button labeled LP04 - L2U2 should be added to RFS window');
    });
    it('I should be able to add a another trader LP05 to the RFS', async () => {
      await rfsWindow.addTradingUser('LP05 - L5U2');
      const btnUserExists = await rfsWindow.btnUserExists('LP05 - L5U2');
      expect(btnUserExists).to.equal(true, 'User button labeled LP05 - L5U2 should be added to RFS window');
    });
    it('RFS should be in DARK trading phase for trader LP05', async () => {
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('DARK');
    });
    it('RFS should be in DARK trading phase for trader LP04', async () => {
      await rfsWindow.btnUserClick('LP04 - L4U2');
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('DARK');
    });
    it('RFS should transition to LIT trading phase for trader LP04', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('LIT', 'Phase should be LIT');
    });
    it('RFS should transition to LIT trading phase for trader LP05', async () => {
      await rfsWindow.btnUserClick('LP05 - L5U2');
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('LIT', 'Phase should be LIT');
    });
    it('RFS should transition to TRADING phase  for trader LP05', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      const fldEnterSizeEnabled = await rfsWindow.fldEnterSizeEnabled();
      const fldEnterAskEnabled = await rfsWindow.fldEnterAskEnabled();
      const fldEnterBidEnabled = await rfsWindow.fldEnterBidEnabled();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      expect(phase).to.equal('TRADING', 'Phase should be TRADING');
      expect(fldEnterSizeEnabled).to.equal(true, 'Enter Size field should be enabled');
      expect(fldEnterAskEnabled).to.equal(true, 'Enter Ask field should be enabled');
      expect(fldEnterBidEnabled).to.equal(true, 'Enter size field should be enabled');
      expect(btnSubjectEnabled).to.equal(false, 'Button Subject should be disabled');
    });
    it('RFS should transition to TRADING phase for trader LP04', async () => {
      await rfsWindow.btnUserClick('LP04 - L4U2');
      const phase = await rfsWindow.getPhase();
      const fldEnterSizeEnabled = await rfsWindow.fldEnterSizeEnabled();
      const fldEnterAskEnabled = await rfsWindow.fldEnterAskEnabled();
      const fldEnterBidEnabled = await rfsWindow.fldEnterBidEnabled();
      const btnSubjectEnabled = await rfsWindow.btnSubjectEnabled();
      expect(phase).to.equal('TRADING', 'Phase should be TRADING');
      expect(fldEnterSizeEnabled).to.equal(true, 'Enter Size field should be enabled');
      expect(fldEnterAskEnabled).to.equal(true, 'Enter Ask field should be enabled');
      expect(fldEnterBidEnabled).to.equal(true, 'Enter size field should be enabled');
      expect(btnSubjectEnabled).to.equal(false, 'Button Subject should be disabled');
    });
    it('I should be able to submit an offer on behalf of trader LP04', async () => {
      await rfsWindow.quote(100, 104, 2500, 'LP04 - L4U2');
      bidOffer = await rfsWindow.getBidOfferRow(1);
      await bidOffer.waitUntilPrice('100.000', '104.000');
    });
    it('I should be able to submit an offer on behalf of trader LP05', async () => {
      await rfsWindow.quote(102, 104, 2500, 'LP05 - L5U2');
      await rfsWindow.btnConfirmClick();
      bidOffer = await rfsWindow.getBidOfferRow(1);
      await bidOffer.waitUntilPrice('102.000', '104.000');
    });
    it('RFS summary should be displayed when counterparty broker LIFTs the best bid', async () => {
      const traderId = await trader2.userData.user.id;
      await browser.waitUntil(() => broker1.rfsAccept(104, null, 3500, traderId), frameworkConfig.mediumTimeout);
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      await rfsWindow.btnUserClick('LP05 - L5U2');
      let summaryTotalMatchedInRFS = await rfsWindow.getSummaryTotalMatchedInRFS();
      let summaryTotalBought = await rfsWindow.getSummaryTotalBought();
      let summaryTotalSold = await rfsWindow.getSummaryTotalSold();
      expect(summaryTotalMatchedInRFS).equals('3500 L', 'Total Amount Matched in RFS');
      expect(summaryTotalBought).equals('0 L', 'My Total Bought Amount');
      expect(summaryTotalSold).equals('1000 L', 'My Total Sold Amount');
      await rfsWindow.btnUserClick('LP04 - L4U2');
      summaryTotalMatchedInRFS = await rfsWindow.getSummaryTotalMatchedInRFS();
      summaryTotalBought = await rfsWindow.getSummaryTotalBought();
      summaryTotalSold = await rfsWindow.getSummaryTotalSold();
      expect(summaryTotalMatchedInRFS).equals('3500 L', 'Total Amount Matched in RFS');
      expect(summaryTotalBought).equals('0 L', 'My Total Bought Amount');
      expect(summaryTotalSold).equals('2500 L', 'My Total Sold Amount');
    });
    it('RFS should transition to VC', async () => {
      await browser.switchTab(mainWindowH);
      await mainPageFrame.notificationsPanel.tabAlerts.click();
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC('P DEC25', '104.000', 'SX5E');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });
    it('Should show a VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('104.000', 'SX5E', 'P DEC25', '300');
      expect(vcToastMsgs.length).to.equal(1, 'VC toast message should exist');
      await vcToastMsgs[0].click();
    });
    it('Should show a sell toast message for trader LP04', async () => {
      await browser.switchTab(mainWindowH);
      const sellToastMsgs = await toastNotification.getSellToastMsg('104.000', '2500 L', 'SX5E', 'P DEC25', '300', 'L4U2 - LP04');
      expect(sellToastMsgs.length).to.equal(1, 'Sell Toast notification message should exist');
    });
    it('Should show a sell toast message for trader LP05', async () => {
      const sellToastMsgs = await toastNotification.getSellToastMsg('104.000', '1000 L', 'SX5E', 'P DEC25', '300', 'L5U2 - LP05');
      expect(sellToastMsgs.length).to.equal(1, 'Buy Toast notification message should exist');
    });
    it('Should show a sell notification for trader LP04', async () => {
      await browser.switchTab(mainWindowH);
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '104.000', '300', 'Sz 2,500 L', 'SX5E', 'L4U2 - LP04');
      const buySize = await buyNotification.getSize();
      expect(buySize).to.equal('2500 L', 'Buy Notification - Size');
    });
    it('Should show a sell notification for trader LP05', async () => {
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '104.000', '300', 'Sz 1,000 L', 'SX5E', 'L5U2 - LP05');
      const buySize = await buyNotification.getSize();
      const remaining = await buyNotification.getRemaining();
      expect(buySize).to.equal('1000 L', 'Buy Notification - Size');
      expect(remaining).to.equal('1500 L', 'Buy Notification - Remaining');
    });
    it('Should open the VC window', async () => {
      vcWindow = new VolumeClearing(context);
      await vcWindow.switchToWindow();
      const vcId = await vcWindow.vcId;
      expect(vcId > 0).to.equal(true, 'VC window should open');
      const windowLetter = await vcWindow.getWindowLetter();
      const ref = await vcWindow.getRef();
      const delta = await vcWindow.getDelta();
      const pxValue = await vcWindow.getPxValue();
      const sellInterestInputEnabled = await vcWindow.sellInterestInputEnabled();
      const buyInterestInputEnabled = await vcWindow.buyInterestInputEnabled();
      const isPrioritySeller = await vcWindow.isPrioritySeller();
      const userBtn1Exists = await vcWindow.btnUserExists('LP05 - L5U2');
      const userBtn2Exists = await vcWindow.btnUserExists('LP04 - L4U2');
      expect(windowLetter).to.equal('V', 'Window Letter');
      expect(ref).to.equal('220', 'Window should show REF');
      expect(delta).to.equal('51', 'Window should show delta');
      expect(pxValue).to.equal('104.000', 'Window should show PX Value');
      expect(sellInterestInputEnabled).to.equal(true, 'Sell interest entry should not be enabled');
      expect(buyInterestInputEnabled).to.equal(false, 'Buy Interest input should be enabled');
      expect(isPrioritySeller).to.equal(true, 'Should be VC priority seller');
      expect(userBtn1Exists).to.equal(true, 'Trader button should exist on the VC window');
      expect(userBtn2Exists).to.equal(true, 'Trader button should exist on the VC window');
    });
    it('VC window will show my live sell interest for trader LP05', async () => {
      await vcWindow.btnUserClick('LP05 - L5U2');
      const liveSellInterest = await vcWindow.getMyLiveSellInterest();
      expect(liveSellInterest).to.equal('1500 L', 'My Live Sell Interest');
      const myLiveBuyInterest = await vcWindow.getMyLiveBuyInterest();
      expect(myLiveBuyInterest).to.equal('', 'My Live Buy Interest');
    });
    it('VC window should show the offer I have made on behalf of trader LP05', async () => {
      bidOffer = await vcWindow.getBidOfferRow(1);
      const offer = await bidOffer.getOffer();
      const bid = await bidOffer.getBid();
      expect(await bid.getText()).to.equal('', 'Volume Clearing Bid');
      expect(await offer.getText()).to.equal('L5U2-LP051500', 'Volume Clearing Offer');
      await browser.pause(2000);
    });
    it('VC window should remove offer when counterparty buys all volume', async () => {
      const traderId = await trader2.userData.user.id;
      const traderDeskId = await trader2.userData.user.deskId;
      await broker1.vcAddInterest('BUY', 1500, traderId, traderDeskId);
      await browser.waitUntil(async () => await vcWindow.hadBidOfferTblRows() === false, frameworkConfig.shortTimeout);
      const hasBidOfferRows = await vcWindow.hadBidOfferTblRows();
      expect(hasBidOfferRows).to.equal(false, 'Expecting no bids or offers in VC window table.');
    });
    it('VC window will show vc session summary for trader LP05', async () => {
      await vcWindow.waitForSummary();
      await vcWindow.btnUserClick('LP05 - L5U2');
      const summaryTotalBought = await vcWindow.getSummaryTotalBought();
      const summaryTotalSold = await vcWindow.getSummaryTotalSold();
      const summaryTotalMatched = await vcWindow.getSummaryTotalMatched();
      expect(summaryTotalBought).to.equal('0', 'VC Summary - My Total Bought Amount');
      expect(summaryTotalSold).to.equal('2500', 'VC Summary - My Total Sold Amount');
      expect(summaryTotalMatched).to.equal('5000', 'VC Summary - Total Matched');
    });
    it('VC window will show vc session summary for trader LP04', async () => {
      await vcWindow.btnUserClick('LP04 - L4U2');
      const summaryTotalBought = await vcWindow.getSummaryTotalBought();
      const summaryTotalSold = await vcWindow.getSummaryTotalSold();
      const summaryTotalMatched = await vcWindow.getSummaryTotalMatched();
      expect(summaryTotalBought).to.equal('0', 'VC Summary - My Total Bought Amount');
      expect(summaryTotalSold).to.equal('2500', 'VC Summary - My Total Sold Amount');
      expect(summaryTotalMatched).to.equal('5000', 'VC Summary - Total Matched');
    });
    it('Should update the sell notification volume for trader LP05', async () => {
      await browser.switchTab(mainWindowH);
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '104.000', '300', 'Sz 2,500 L', 'SX5E', 'L5U2 - LP05');
      const filled = await buyNotification.waitForFilled();
      expect(filled).to.equal(true, 'Sell Notification - should be Filled');
    });
    it('Should update the sell notification volume for trader LP04', async () => {
      await browser.switchTab(mainWindowH);
      const buyNotification = await mainPageFrame.notificationsPanel.notifications.getFillSell('P DEC25', '104.000', '300', 'Sz 2,500 L', 'SX5E', 'L4U2 - LP04');
      const filled = await buyNotification.waitForFilled();
      expect(filled).to.equal(true, 'Sell Notification - should be Filled');
    });
  });

  describe('BC1808OboRfsResponder Test 3: As a broker I should not be able to trade on behalf of a trader who has responded to an RFS', () => {
    let strategyId = null;
    let strategyRow = null;
    it('Broker, CP trader and broker should be logged in', async () => {
      await common.login(usersConfig.brokers[0].username, usersConfig.brokers[0].password);
      await broker1.login(usersConfig.brokers[3].username, usersConfig.brokers[3].password);
      await trader1.login(usersConfig.traders[5].username, usersConfig.traders[5].password);
      await browser.waitUntil(async () => await broker1.wsOpen === true, frameworkConfig.shortTimeout);
      await browser.waitUntil(async () => await trader1.wsOpen === true, frameworkConfig.shortTimeout);
    });
    it('Counterparty broker should initiate an RFS', async () => {
      mainWindowH = await browser.getCurrentTabId();
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(inst1);
      strategyId = await common.getStrategyId(inst1);
      await trader1.respondToRFS(strategyId);
      await broker1.initiateRFS(strategyId);
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      expect(status).to.equal('RFS', 'Strategy Status should be RFS');
    });
    it('Broker should open RFS Window and add users that he will trade on behalf of', async () => {
      await strategyRow.clickStatus();
      rfsWindow = new Rfs(context);
      await browser.waitUntil(() => switchToTab(browser, '//request-for-stream'));
      await browser.getCurrentTabId();
      await rfsWindow.addTradingUser('LP01 - L1U9');
      await rfsWindow.addTradingUser('LP01 - L1U0');
      await rfsWindow.addTradingUser('LP05 - L5U2');
      const userBtn1Exists = await rfsWindow.btnUserExists('LP01 - L1U9');
      const userBtn2Exists = await rfsWindow.btnUserExists('LP01 - L1U0');
      const userBtn3Exists = await rfsWindow.btnUserExists('LP05 - L5U2');
      expect(userBtn1Exists).to.equal(true, 'RFS Window - User button LP01 - L1U9 should exist');
      expect(userBtn2Exists).to.equal(true, 'RFS Window - User button LP01 - L1U0 should exist');
      expect(userBtn3Exists).to.equal(true, 'RFS Window - User button LP05 - L5U2 should exist');
    });
    it('A Trader who the Broker is trying to trade on behalf of should respond to the RFS', async () => {
      await browser.waitUntil(() => trader1.rfsQuote(101, 105, 2500), frameworkConfig.mediumTimeout);
      await rfsWindow.waitUntilCurrentSpread(8, frameworkConfig.darkPhaseTimeout);
      await trader1.rfsSubject();
    });
    it('Broker should not be allowed to trade on behalf of a trader who has responded to the RFS', async () => {
      await rfsWindow.btnUserClick('LP01 - L1U0');
      const msgExists = await rfsWindow.colleagueTradingMsgExists();
      expect(msgExists).to.equal(true, 'RFS window should display colleague trading message');
    });
    it('Broker should not be allowed to trade on behalf of a trader who is on the same desk as that trader', async () => {
      await rfsWindow.btnUserClick('LP01 - L1U9');
      const msgExists = await rfsWindow.colleagueTradingMsgExists();
      expect(msgExists).to.equal(true, 'RFS window should display colleague trading message');
    });
    it.skip('Broker should be allowed to trade on behalf of trader who is on a different desk', async () => {
      // User setup required to complete this step.
    });
    it('Broker should be allowed to trade on behalf of a trader who is a part of a different legal entity', async () => {
      await rfsWindow.btnUserClick('LP05 - L5U2');
      const msgExists = await rfsWindow.colleagueTradingMsgExists();
      expect(msgExists).to.equal(false, 'RFS window should not display colleague trading message');
    });
    it('Should wait until RFS timed out is displayed', async () => {
      await rfsWindow.waitUntilRfsTimedout();
      const timedOutMsgExists = await rfsWindow.rfsTimedoutMsgExists();
      expect(timedOutMsgExists).to.equal(true, 'Expect to find RFS timed out message');
      await rfsWindow.btnOkClick();
    });
  });
});
