import StartUp from '../pages/StartUp';
import {shellExec} from '../../../utilities/framework/shell-exec';
import UserLogin from '../../../pages/UserLogin';
import MainPageFrame from '../../../pages/main_page/MainPageFrame';
import {usersConfig} from '../../../config/users.config';
import {frameworkConfig} from '../../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {join} from 'path';

describe('BC1113 OBO RFS Initiator Test suite', function rfsInitiatorTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let startUp = null;
  let userLogin = null;
  let mainPageFrame = null;
  let isLoggedOut = true;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    startUp = new StartUp(context);
    userLogin = new UserLogin(context);
    mainPageFrame = new MainPageFrame(context);

    expect(browser).to.exist;
  });

  after(() => {
    browser.end();
    const clearDownScript = require.resolve(join('./../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  this.timeout(frameworkConfig.veryLongTimeout);

  async function logout () {
    await mainPageFrame.clickLogout();
    await mainPageFrame.clickLogoutConfirmOk();
    isLoggedOut = true;
  }

  async function login (username, password) {
    if (!isLoggedOut) {
      await logout();
    }
    await startUp.clickLogin();
    await userLogin.login(username, password);
    isLoggedOut = false;
  }

  /*
   * Broker co-brokers will be invited when broker initiates an RFS
   * The Brokers must cover the same user and belong to the same desk.
   */
  describe('As Broker user I should see a notification and toast message when a Broker colleague starts', async function BC1112Test2 () {
    const brokerA = 'br01u01';
    const brokerB = 'br01u02';

    it('Brokers should log in', async () => {

    });
    it('Broker should start RFS', async () => {

    });
    it('Broker desk colleague should receive rfs invite notification', async () => {

    });
    it('Broker desk colleague should receive rfs invite toast message', async () => {

    });
  });

  describe('As a Broker user I should be able to trade on behalf of my authorised Traders', async function BC1112Test3 () {
  });

  describe('As a Trader I should see notifications when a Trader initiates an RFS', async () => {

  });

  describe('As a Trader I should see notification when a Broker initiates an RFS', async () => {

  });

  describe('As a Broker I should not be invited to RFS that has been initiated by a Trader', async () => {

  });

  describe('As a Trader if I trade on an RFS before my broker then my broker will not be able to trade on my behalf', () => {

  });
});
