/* eslint-disable no-use-before-define,max-statements,no-unused-vars,max-lines,no-extra-parens,lines-around-comment,no-warning-comments,no-shadow,no-param-reassign,eqeqeq,arrow-body-style,block-spacing,brace-style,semi */
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, STRATEGY, STYLE, UNDERLYING, POLARITY, OPTION_TYPE, COLOR_PURPOSE} from '../../constant/GenericType';
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import ApiClient from '../../utilities/api/ApiClient';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import MarketViewTabs from '../../constant/MarketViewTabs';
import MarketSegmentIds from '../../constant/MarketSegmentIds';
import ProductGroupIds from '../../constant/ProductGroupIds';


describe('BC-3540 LP Scoring', function BC3540LPScoringUATCases () {
  // Framework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  this.timeout(frameworkConfig.testMaxTime);

  // Page object vars
  let mainPageFrame = null;
  let mainWindowHandle = null;
  let common = null;
  let rfsWindow = null;
  let strategyId = 0;
  let strategyFound = false;
  let requestId = 0;
  let adminClient = {};
  let strategyRow = null;

  let lpTrader1 = {};
  let lpTrader2 = {};
  let lpTrader3 = {};
  let nlpTrader = {};
  let broker = {};
  let lpTradeClient1 = {};
  let lpTradeClient2 = {};
  let lpTradeClient3 = {};
  let nlpTradeClient = {};
  let brokerClient = {};

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    mainWindowHandle = await browser.getCurrentTabId();
  }

  describe('CASE 1: no market move', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
      logger.info(`the request ID is ${requestId}`);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
    });
  });

  describe('CASE 1: no market move - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    // TODO Remove delta when delta is returned
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.call, STYLE.euro, 24002, 12, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 16250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
    });
  });

  describe('CASE 1: no market move - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    // TODO Remove delta when delta is returned
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.call, STYLE.euro, 24002, 12, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 16250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
    });
  });

  describe('CASE 2: market move & hold spread', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 4002, 3, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
    });
  });

  describe('CASE 2: market move & hold spread - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24002, 3, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);


      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
    });
  });

  describe('CASE 2: market move & hold spread - NKYO Responders should have 0 score based on configuration BC-4441', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24002, 3, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 400
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 300
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 400
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 300
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 400
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 300
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 400
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 300
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
    });
  });

  describe('CASE 2: market move & hold spread - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24002, 3, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
    });
  });

  describe('CASE 3: Move & Join & do not hold price', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3813, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 10, 0, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);
    });
  });

  describe('CASE 3: Move & Join & do not hold price - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24013, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 10, 0, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);
    });
  });

  describe('CASE 3: Move & Join & do not hold price - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24104, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 10, 0, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 13, 0, -52, 0, 0, -10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 31, 0, -41, 0, 0, -10]);
    });
  });

  describe('CASE 4: Subject and double trade adjustment', () => {
    // eslint-disable-next-line no-magic-numbers,no-warning-comments
    // TODO: Gen expiry X months in future to pass FP/QP Key none key
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3804, null, POLARITY.negative, null, null);
    strategy.addLeg('-', 'C', 'MAR20', 3100, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 23.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
      await lpTradeClient2.rfsSubject(strategyId);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsFirm(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 24, 0, -39, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 12, -12, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 4: Subject and double trade adjustment - NKYO', () => {
    // eslint-disable-next-line no-magic-numbers,no-warning-comments
    // TODO: Gen expiry X months in future to pass FP/QP Key none key
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.straddle, STYLE.euro, 24004, 1, POLARITY.negative, null, null);
    strategy.addLeg('-', 'C', 'MAR20', 19000, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 23.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
      await lpTradeClient2.rfsSubject(strategyId);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsFirm(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 24, 0, -39, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 12, -12, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 4: Subject and double trade adjustment - NKYS', () => {
    // eslint-disable-next-line no-magic-numbers,no-warning-comments
    // TODO: Gen expiry X months in future to pass FP/QP Key none key
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.straddle, STYLE.euro, 24004, 1, POLARITY.negative, null, null);
    strategy.addLeg('-', 'C', 'MAR20', 19000, 1);
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 23.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
      await lpTradeClient2.rfsSubject(strategyId);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsFirm(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 24, 0, -39, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 12, -12, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 33, 0, -19, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 5: No submission and Hold Spread adjustment', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3825, null, POLARITY.positive, null, null);
    strategy.addLeg('+', 'C', 'DEC26', 3100, 1);
    strategy.addLeg('-', 'C', 'DEC26', 3400, 4);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
    });
  });

  describe('CASE 5: No submission and Hold Spread adjustment - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callRatioSpread, STYLE.euro, 24105, 1, POLARITY.positive, null, null);
    strategy.addLeg('+', 'C', 'DEC26', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC26', 19250, 4);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
    });
  });

  describe('CASE 5: No submission and Hold Spread adjustment - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callRatioSpread, STYLE.euro, 24105, 1, POLARITY.positive, null, null);
    strategy.addLeg('+', 'C', 'DEC26', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC26', 19250, 4);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 22, 0, -16, 0, 0, 6]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
    });
  });

  describe('CASE 6: Fast Market (analogous to Case 7)', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3806, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.SX5E);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
    });
  });

  describe.only('CASE 6: Fast Market (analogous to Case 7) - NKYO', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24007, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYO);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
    });
  });

  describe('CASE 6: Fast Market (analogous to Case 7) - NKYS', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24007, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYS);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
    });
  });

  describe('CASE 7: Slow Market', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3806, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 7: Slow Market - NKYO', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24007, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 7: Slow Market - NKYS', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24007, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 29.5,
        sellPrice : 34.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 35.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.litQuote = {
        buyPrice  : 30.5,
        sellPrice : 33.5,
        amount    : 3000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 31.0,
        amount    : 3000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.litQuote = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 30.0,
        sellPrice : 34.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 8: Dark Adjustments and trading adjustment tests', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3809, 4, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC21', 3100, 1);
    strategy.addLeg('-', 'C', 'DEC21', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.SX5E);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
    });
  });

  describe('CASE 8: Dark Adjustments and trading adjustment tests - NKYO', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24001, 4, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC21', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC21', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYO);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
    });
  });

  describe('CASE 8: Dark Adjustments and trading adjustment tests - NKYS', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24001, 4, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC21', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC21', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      dateFrom = await common.getEpochNow();
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYS);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 35, 0, -74, 0, 0, -10]);
    });
  });

  describe('CASE 9: Dark Adjustments and trading adjustment tests', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3829, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 3100, 1);
    strategy.addLeg('-', 'C', 'JUN22', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([10, 10, -6, 0, 0, 0, 14]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 10, -20, -10, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 26, -7, -52, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 9: Dark Adjustments and trading adjustment tests - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24009, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 19000, 1);
    strategy.addLeg('-', 'C', 'JUN22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([10, 10, -6, 0, 0, 0, 14]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 10, -20, -10, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 26, -7, -52, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 9: Dark Adjustments and trading adjustment tests - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24009, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 19000, 1);
    strategy.addLeg('-', 'C', 'JUN22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([10, 10, -6, 0, 0, 0, 14]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 10, -20, -10, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 26, -7, -52, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 10: Dark Adjustments and trading adjustment tests', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3810, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.7,
        sellPrice : 29.8,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, -10, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, -5, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);

      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 10: Dark Adjustments and trading adjustment tests - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24010, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.7,
        sellPrice : 29.8,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, -10, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, -5, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);

      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 10: Dark Adjustments and trading adjustment tests - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24010, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 2000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.7,
        sellPrice : 29.8,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, -10, 0, 0, 0, 10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, -5, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, -64, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);

      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 11: Dark Adjustments and trading adjustment tests', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3811, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);


    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
      logger.info(requestId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.SX5E);
    });

    it('LP Ranking Request', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);
    });
  });

  describe('CASE 11: Dark Adjustments and trading adjustment tests - NKYO', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24111, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);


    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
      logger.info(requestId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYO);
    });

    it('LP Ranking Request', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);
    });
  });

  describe('CASE 11: Dark Adjustments and trading adjustment tests - NKYS', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24011, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);


    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait until hold spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
      logger.info(requestId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYS);
    });

    it('LP Ranking Request', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 10, -11, -16, 0, 0, 12]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 31, 0, -31, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([29, 15, 0, 0, 0, 0, 44]);
    });
  });

  describe('CASE 12: 1500 check and join prices', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3700, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 3100, 1);
    strategy.addLeg('-', 'C', 'JUN22', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      logger.info('In Trading Spread');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
      const buyId3 = await lpTradeClient3.getBuyOrderID(strategyId);
      const sellId3 = await lpTradeClient3.getSellOrderID(strategyId);
      await lpTradeClient3.cancelOrder(buyId3);
      await lpTradeClient3.cancelOrder(sellId3);
      logger.info('lp3 cancel');
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, -2.5, -12.5]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, -2.5, -12.5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);
    });
  });

  describe('CASE 12: 1500 check and join prices - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24012, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 19000, 1);
    strategy.addLeg('-', 'C', 'JUN22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      logger.info('In Trading Spread');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
      const buyId3 = await lpTradeClient3.getBuyOrderID(strategyId);
      const sellId3 = await lpTradeClient3.getSellOrderID(strategyId);
      await lpTradeClient3.cancelOrder(buyId3);
      await lpTradeClient3.cancelOrder(sellId3);
      logger.info('lp3 cancel');
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, 0, -10]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, -2.5, -12.5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);
    });
  });
  // TODO: suspended
  describe('CASE 12: 1500 check and join prices - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24012, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'JUN22', 19000, 1);
    strategy.addLeg('-', 'C', 'JUN22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      logger.info('In Trading Spread');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
      const buyId3 = await lpTradeClient3.getBuyOrderID(strategyId);
      const sellId3 = await lpTradeClient3.getSellOrderID(strategyId);
      await lpTradeClient3.cancelOrder(buyId3);
      await lpTradeClient3.cancelOrder(sellId3);
      logger.info('lp3 cancel');
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, -2.5, -12.5]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([12, 23, -3, 0, 0, 0, 32]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 19, 0, -29, 0, -2.5, -12.5]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 29, 0, 0, 0, 13, 65]);
    });
  });

  describe('CASE 13: Reference Spread check', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3785, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient1.rfsSubject(strategyId);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      logger.info(`the request ID is: ${requestId}`);
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([18, 22, 0, 0, 0, 0, 40]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([18, 22, 0, 0, 0, 0, 40]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 13: Reference Spread check - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24013, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', '20DEC19', 22000, 1);
    strategy.addLeg('-', 'C', '20DEC19', 22250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient1.rfsSubject(strategyId);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([18, 22, 0, 0, 0, 0, 40]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([18, 22, 0, 0, 0, 0, 40]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 14: Subj and no submission', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3814, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      nlpTrader.counterQuote = {
        buyLevel : 28,
        amount   : 1500
      };
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsSubject(strategyId);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsFirm(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient3.rfsSubject(strategyId);
    });

    it('NLP counter and LP accept', async () => {
      await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      await rfsWindow.quote(null, nlpTrader.counterQuote.buyLevel, nlpTrader.counterQuote.amount);
      await lpTradeClient1.rfsAccept(strategyId, nlpTrader.counterQuote.buyLevel, null, nlpTrader.counterQuote.amount);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      logger.info(`the request ID is: ${requestId}`);
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 20, 0, 20]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 29, 0, -49, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 20, 0, 20]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 14: Subj and no submission - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24014, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      nlpTrader.counterQuote = {
        buyLevel : 28,
        amount   : 1500
      };
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsSubject(strategyId);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsFirm(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient3.rfsSubject(strategyId);
    });

    it('NLP counter and LP accept', async () => {
      await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      await rfsWindow.quote(null, nlpTrader.counterQuote.buyLevel, nlpTrader.counterQuote.amount);
      await lpTradeClient1.rfsAccept(strategyId, nlpTrader.counterQuote.buyLevel, null, nlpTrader.counterQuote.amount);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 10, 0, 10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 29, 0, -49, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 10, 0, 10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 14: Subj and no submission - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24014, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 30.0,
        amount    : 1500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 28.5,
        amount    : 1500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      nlpTrader.counterQuote = {
        buyLevel : 28,
        amount   : 1500
      };
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsSubject(strategyId);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsFirm(strategyId, lpTrader1.tradingHoldPrice.buyPrice, lpTrader1.tradingHoldPrice.sellPrice, lpTrader1.tradingHoldPrice.amount);
      await lpTradeClient3.rfsSubject(strategyId);
    });

    it('NLP counter and LP accept', async () => {
      await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      await rfsWindow.quote(null, nlpTrader.counterQuote.buyLevel, nlpTrader.counterQuote.amount);
      await lpTradeClient1.rfsAccept(strategyId, nlpTrader.counterQuote.buyLevel, null, nlpTrader.counterQuote.amount);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 10, 0, 10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([10, 29, 0, -49, 0, 0, -10]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([0, 0, 0, 0, 10, 0, 10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 15: Dark Adjustment', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3814, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
      logger.info('In Lit Phase');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Trading Spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(90000);
      // TODO: Wait until getOrderId is returned because then you know it has fed into order book
    });

    it('Cancel after first 60 seconds', async () => {
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
    });

    it('Trader after first 120 seconds', async () => {
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      await browser.pause(10000);
      nlpTradeClient = new ApiClient(nlpTrader);
      await nlpTradeClient.login();
      const order = [{price : 28.5,
        side  : 'BUY',
        size  : 1500}];
      await nlpTradeClient.strategyOrderAdd(strategyId, false, false, false, true, order);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.SX5E);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);
    });
  });

  describe('CASE 15: Dark Adjustment - NKYO', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24015, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
      logger.info('In Lit Phase');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Trading Spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(90000);
      // TODO: Wait until getOrderId is returned because then you know it has fed into order book
    });

    it('Cancel after first 60 seconds', async () => {
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
    });

    it('Trader after first 120 seconds', async () => {
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      await browser.pause(10000);
      nlpTradeClient = new ApiClient(nlpTrader);
      await nlpTradeClient.login();
      const order = [{price : 28.5,
        side  : 'BUY',
        size  : 1500}];
      await nlpTradeClient.strategyOrderAdd(strategyId, false, false, false, true, order);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYO);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);
    });
  });

  describe('CASE 15: Dark Adjustment - NKYS', () => {
    let dateFrom = null;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24015, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 1500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 1500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      dateFrom = await common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
      logger.info('In Lit Phase');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Trading Spread
      await browser.pause(frameworkConfig.fastTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Feed into order book', async () => {
      logger.info('In Order book');
      await browser.pause(90000);
      // TODO: Wait until getOrderId is returned because then you know it has fed into order book
    });

    it('Cancel after first 60 seconds', async () => {
      await browser.pause(frameworkConfig.first60SecondsOfOrderBook);
      const buyId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      const sellId1 = await lpTradeClient1.getSellOrderID(strategyId);
      await lpTradeClient1.cancelOrder(buyId1);
      await lpTradeClient1.cancelOrder(sellId1);
      logger.info('lp1 cancel');
      const buyId2 = await lpTradeClient2.getBuyOrderID(strategyId);
      const sellId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.cancelOrder(buyId2);
      await lpTradeClient2.cancelOrder(sellId2);
      logger.info('lp2 cancel');
    });

    it('Trader after first 120 seconds', async () => {
      await browser.pause(frameworkConfig.next60SecondsOfOrderBook);
      await browser.pause(10000);
      nlpTradeClient = new ApiClient(nlpTrader);
      await nlpTradeClient.login();
      const order = [{price : 28.5,
        side  : 'BUY',
        size  : 1500}];
      await nlpTradeClient.strategyOrderAdd(strategyId, false, false, false, true, order);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYS);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 32, -9, -16, 0, 0, 36]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([20, 26, 0, -46, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([23, 0, -23, 0, 0, 0, 0]);
    });
  });

  describe('CASE 16: Spread check', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3780, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC28', 3600, 1);
    strategy.addLeg('-', 'C', 'DEC28', 3700, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 27.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 27.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 27.5,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
      dateFrom = common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsSubject(strategyId);
    });

    it('Wait till Trading Spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsFirm(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsSubject(strategyId);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Wait till feed into order book', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Match in order book', async () => {
      // TODO: Verify match in orderbook
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.SX5E);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      //Scoring has been changed to -10 as per https://embonds.atlassian.net/browse/BC-4997
      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 22, -11, -50, 0, 0, -10]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 16, 0, -36, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 22, -11, -50, 0, 0, -10]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 16: Spread check - NKYO', () => {
    let dateFrom = null;
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24016, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'FEB20', 22000, 1);
    strategy.addLeg('-', 'C', 'FEB20', 22250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader1.litQuote = {
        buyPrice  : 26.5,
        sellPrice : 27.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 26.5,
        sellPrice : 27.0,
        amount    : 3000
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 27.5,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 28.0,
        sellPrice : 28.5,
        amount    : 3000
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 30.0,
        amount    : 3000
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 30.0,
        amount    : 3000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      dateFrom = common.getEpochNow();
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
      await lpTradeClient1.rfsSubject(strategyId);
    });

    it('Wait till Trading Spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsFirm(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsSubject(strategyId);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Wait till feed into order book', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Match in order book', async () => {
      // TODO: Verify match in orderbook
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Apply fast markets for request', async () => {
      const dateTo = await common.getEpochNow();
      await adminClient.addFastMarkets(dateFrom, dateTo, MarketSegmentIds.NKYO);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 22, -11, -50, 0, -2.5, -12.5]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([20, 16, 0, -36, 0, 0, 0]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 22, -11, -50, 0, -2.5, -12.5]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 0, 0, 0, 0, 0, 0]);
    });
  });

  describe('CASE 17: Spread check', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3700, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 2600, 1);
    strategy.addLeg('-', 'C', 'MAR20', 2700, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
    });

    it('Wait till Trading Spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('Wait till order book and tighten/widen spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
      const buyOrderId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      await lpTradeClient1.strategyOrderUpdate(buyOrderId1, false, false, false, true, 28, 2500);
      const sellOrderId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.strategyOrderUpdate(sellOrderId2, false, false, false, true, 29, 2500);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 16, 80]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 16, 80]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);
    });
  });

  describe('CASE 17: Spread check - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24017, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
    });

    it('Wait till Trading Spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('Wait till order book and tighten/widen spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
      const buyOrderId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      await lpTradeClient1.strategyOrderUpdate(buyOrderId1, false, false, false, true, 28, 2500);
      const sellOrderId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.strategyOrderUpdate(sellOrderId2, false, false, false, true, 29, 2500);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);
    });
  });

  describe('CASE 17: Spread check - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24017, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 7500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      logger.info('In Dark Phase');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      logger.info('In Lit Phase');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      logger.info('In Trading Hold');
    });

    it('Wait till Trading Spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
    });

    it('Wait till order book and tighten/widen spread', async () => {
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
      const buyOrderId1 = await lpTradeClient1.getBuyOrderID(strategyId);
      await lpTradeClient1.strategyOrderUpdate(buyOrderId1, false, false, false, true, 28, 2500);
      const sellOrderId2 = await lpTradeClient2.getSellOrderID(strategyId);
      await lpTradeClient2.strategyOrderUpdate(sellOrderId2, false, false, false, true, 29, 2500);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 0, 25]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([0, 25, 0, 0, 0, 6.25, 31.25]);
    });
  });

  describe('CASE 18: Spread check', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC22', 3100, 1);
    strategy.addLeg('-', 'C', 'DEC22', 3200, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
    });
  });

  describe('CASE 18: Spread check - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24018, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC22', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
    });
  });

  describe('CASE 18: Spread check - NKYS', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkys, STRATEGY.callSpread, STYLE.euro, 24018, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'DEC22', 19000, 1);
    strategy.addLeg('-', 'C', 'DEC22', 19250, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 173.0,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 171.5,
        sellPrice : 174.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 172.0,
        sellPrice : 173.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      rfsWindow = new Rfs(context);
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SGX);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([8, 6, 0, 0, 0, 0, 14]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([22, 26, 0, 0, 0, 0, 48]);
    });
  });

  describe('BUG-4627: Lp Ranking: Rounding error', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    /* eslint-enable no-magic-numbers */
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');

      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      // TODO: Get bestDark/Lit and dark/litSpread and verify it is calculated correctly
    });
  });

  describe('BC-4596: Case 1: Price maintained', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([true]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([true]);
    });
  });

  describe('BC-4596: Case 2: 3ai) Bid Price lowered in min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldPrice = {
        buyPrice  : 47.2,
        sellPrice : 48.1,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 2: 3aii) Ask Price raised in min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldPrice = {
        buyPrice  : 47.3,
        sellPrice : 48.2,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 2: 3aiii) Widen spread in min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldPrice = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 2: 3vi) Bid or Ask size is lowered in min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader2.tradingHoldPrice = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldPrice = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2000
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([false]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([false]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 3: Widen spread after min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, 55, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldSpread = {
        buyPrice  : 47.2,
        sellPrice : 48.3,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
      logger.info('logged in with LP responders...');
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait till end of hold
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
      // Wait till end of trading period
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 4: Bid or Ask size is lowered after min hold time', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3801, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader2.tradingHoldPrice = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 1000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      lpTrader3.tradingHoldPrice = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait till end of trading hold period
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldPrice.buyPrice, lpTrader2.tradingHoldPrice.sellPrice, lpTrader2.tradingHoldPrice.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldPrice.buyPrice, lpTrader3.tradingHoldPrice.sellPrice, lpTrader3.tradingHoldPrice.amount);
      // Wait till end of trading period
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([false]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([false]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 5: Fails size requirements', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAY20', 3400, 1);
    strategy.addLeg('-', 'C', 'MAY20', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
      await logger.info('Logged in as LP responders..');
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      // await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait till end of trading period
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
      await browser.pause(5000);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([true]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 5: Fails spread requirements', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAY20', 3400, 1);
    strategy.addLeg('-', 'C', 'MAY20', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 46.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR20');

      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Wait till end of trading period
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 5: Fails size and spread requirements', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAY20', 3400, 1);
    strategy.addLeg('-', 'C', 'MAY20', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 46.3,
        sellPrice : 48.1,
        amount    : 1000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([false]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([false]);
    });
  });

  describe('BC-4596: Case 5: Passes size and/or spread requirement', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAY20', 3400, 1);
    strategy.addLeg('-', 'C', 'MAY20', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 3000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till after Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await browser.pause(frameworkConfig.normalTradingHoldSpreadLength);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify response is valid', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperationWithValidResponse(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([true]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([true]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([true]);
    });
  });

  describe('BC-4657 Lp Ranking: points taken away in case of partial fills', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3718, null, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAY20', 3400, 1);
    strategy.addLeg('-', 'C', 'MAY20', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.2,
        amount    : 7500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 47.2,
        sellPrice : 48.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 47.3,
        sellPrice : 48.1,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR20');
      nlpTrader.acceptQuote = {
        buyLevel : 48.2,
        amount   : 4000
      };

      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
    });

    it('Wait till after Trading Phase and NLP accept', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      await rfsWindow.quote(nlpTrader.acceptQuote.buyLevel, null, nlpTrader.acceptQuote.amount);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay);
    });

    it('Verify points are correct ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
      expect(qpLpTrader1.response[0].data[1])
        .to.eql([29, 35, 0, 0, 0, 0, 64]);
    });
  });

  //TODO see comment on Set LP Ranking Run Time - test will not
  describe('LP Ranking Run Time - SX5E', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3821, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      requestId = await returnRequestId(strategyId);
    });

    it('Set LP Ranking Run Time', async () => {

      //TODO: This is now in product group
      const startOfDay = await getToday();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      marketSegment[0].lpRankingRunTime = getHHMM(new Date());
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      await browser.pause(120000)
    });

    it('Verify points are correct ', async () => {
      /*
       *Wait till LP Ranking is ran - can this be verified?
       *Run query till data is returned? Wait X Time then kill
       */
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader1.userData.desk);
      const fpLpTrader1 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader1.userData.desk);
      const qpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader2.userData.desk);
      const fpLpTrader2 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader2.userData.desk);
      const qpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'QP', lpTrader3.userData.desk);
      const fpLpTrader3 = await adminClient.executeLpRankingDatabaseOperation(requestId, 'FP', lpTrader3.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());
      logger.info((qpLpTrader2.response[0].data[1]).toString());
      logger.info((qpLpTrader3.response[0].data[1]).toString());
      logger.info((fpLpTrader1.response[0].data[1]).toString());
      logger.info((fpLpTrader2.response[0].data[1]).toString());
      logger.info((fpLpTrader3.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(qpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(qpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);

      expect(fpLpTrader1.response[0].data[1])
        .to.eql([26, 32, 0, 0, 0, 0, 58]);
      expect(fpLpTrader2.response[0].data[1])
        .to.eql([10, 10, 0, 0, 0, 0, 20]);
      expect(fpLpTrader3.response[0].data[1])
        .to.eql([5, 0, 0, 0, 0, 0, 5]);
    });
  });

  describe('KTP - All RFS types initiated outside of key time are non-key - Direct RFS - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Set Key Time Period as future time - Non-key time ', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(10)
      const endTime = addMinsToDate(20);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Non-Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['NON_KEY']);
    });
  });

  describe('KTP - All RFS types initiated outside of key time are non-key - RFS Without Interest - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
      broker = common.getBroker('AUTBR04');
    });

    it('Set Key Time Period as future time - Non-key time ', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(10)
      const endTime = addMinsToDate(20);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as Broker ', async () => {
      await clearAndReload();
      await start(broker);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('Log in as NLP Traders ', async () => {
      nlpTradeClient = new ApiClient(nlpTrader);
      await nlpTradeClient.login();
    });

    it('Broker creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('Broker will log in API', async () => {
      brokerClient = new ApiClient(broker);
      await brokerClient.login();
    });

    it('Broker initiate an RFS', async () => {
      //await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await brokerClient.rfsInitial(strategyId)
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Broker will activate NLP trader', async () => {
      await brokerClient.rfsSelectTrader(strategyId, nlpTrader.userShortName);
    });

    it('NLP trader should hit the bid', async () => {
      await nlpTradeClient.rfsAccept(strategyId, null, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Get Request Id for Strategy', async () => {
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Non-Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['NON_KEY']);
    });
  });

  describe('KTP - All RFS types initiated outside of key time are non-key - Direct RFS - Non-Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnNonKeyStrategy();

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2000
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2000
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2000
      };

      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Set Key Time Period as future time - Non-key time ', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(10)
      const endTime = addMinsToDate(20);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Non-Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['NON_KEY']);
    });
  });

  describe('KTP - Key strategy in key time period - Direct RFS - Key - SX5E', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Set Key Time Period as now', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['KEY']);
    });
  });

  describe('KTP - Key strategy in key time period - Direct RFS - Key - NKYO', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnNkyoKeyStrategy();

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Set Key Time Period as now', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.NKYO);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.NKYO);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.NIKKEI_OPTIONS);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.NIKKEI_OPTIONS);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.OSAKA);
    });

    it('Verify strategy type is correct - Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['KEY']);
    });
  });

  describe('KTP - Key strategy in key time period - RFS Without Interest - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
      broker = common.getBroker('AUTBR04');
    });

    it('Set Key Time Period as now', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as Broker ', async () => {
      await clearAndReload();
      await start(broker);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('Log in as NLP Traders ', async () => {
      nlpTradeClient = new ApiClient(nlpTrader);
      await nlpTradeClient.login();
    });

    it('Broker creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('Broker will log in API', async () => {
      brokerClient = new ApiClient(broker);
      await brokerClient.login();
    });

    it('Broker initiate an RFS', async () => {
      //await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await brokerClient.rfsInitial(strategyId)
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Broker will activate NLP trader', async () => {
      await brokerClient.rfsSelectTrader(strategyId, nlpTrader.userShortName);
    });

    it('NLP trader should hit the bid', async () => {
      await nlpTradeClient.rfsAccept(strategyId, null, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('Get Request Id for Strategy', async () => {
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Non-Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['KEY']);
    });
  });

  describe('KTP - Non-Key strategy in key time period - Direct RFS - Non-Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnNonKeyStrategy();

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Set Key Time Period as now', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Non-Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['NON_KEY']);
    });
  });

  describe('KTP - No key time period configured - constant key time period', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Delete Key Time Period', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      marketSegment[0].keyTimePeriods = []
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['KEY']);
    });
  });

  describe('KTP - Ranking points awarded for RFS started outside of Key Time period - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    let currentDayScore = null;
    let newDateScore = null;

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Get Current Day score for desk', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      currentDayScore = await adminClient.getDayScoreForDesk(getToday(), strategy.underlying, lpTrader1.userData.deskId)
    });

    it('Set Key Time Period as future time - Non-key time ', async () => {
      logger.info((currentDayScore.response[0].data[1]).toString());
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(10)
      const endTime = addMinsToDate(20);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Get New Day score for desk', async () => {
      newDateScore = await adminClient.getDayScoreForDesk(getToday(), strategy.underlying, lpTrader1.userData.deskId)
    });

    it('Verify DayScore has been added', async () => {
      logger.info((currentDayScore.response[0].data[1]).toString());
      logger.info((newDateScore.response[0].data[1]).toString());
      const expectedPoints = 5;
      expect(parseInt(newDateScore.response[0].data[1])).to.equal(parseInt(currentDayScore.response[0].data[1]) + expectedPoints)
    });
  });

  describe('KTP - Ranking points awarded for RFS started inside of Key Time period - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();
    let currentDayScore = null;
    let newDateScore = null;

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Get Current Day score for desk', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      currentDayScore = await adminClient.getDayScoreForDesk(getToday(), strategy.underlying, lpTrader1.userData.deskId)
    });

    it('Set Key Time Period as current time - key time ', async () => {
      logger.info((currentDayScore.response[0].data[1]).toString());
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Get New Day score for desk', async () => {
      newDateScore = await adminClient.getDayScoreForDesk(getToday(), strategy.underlying, lpTrader1.userData.deskId)
    });

    it('Verify DayScore has been added', async () => {
      logger.info((currentDayScore.response[0].data[1]).toString());
      logger.info((newDateScore.response[0].data[1]).toString());
      const expectedPoints = 5;
      expect(parseInt(newDateScore.response[0].data[1])).to.equal(parseInt(currentDayScore.response[0].data[1]) + expectedPoints)
    });
  });

  describe('KTP - Starts on boundary - Key', () => {
    /* eslint-disable no-magic-numbers */
    const strategy = returnKeyStrategy();

    it('Get users and prices', () => {
      lpTrader1 = common.getTrader('LIMK6');
      lpTrader1.darkQuote = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader1.litQuote = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldPrice = {
        buyPrice  : 27.0,
        sellPrice : 30.0,
        amount    : 2500
      };
      lpTrader1.tradingHoldSpread = {
        buyPrice  : 26.5,
        sellPrice : 29.5,
        amount    : 2500
      };

      lpTrader2 = common.getTrader('LIMK4');
      lpTrader2.darkQuote = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader2.litQuote = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldPrice = {
        buyPrice  : 27.5,
        sellPrice : 29.5,
        amount    : 2500
      };
      lpTrader2.tradingHoldSpread = {
        buyPrice  : 27.0,
        sellPrice : 29.0,
        amount    : 2500
      };

      lpTrader3 = common.getTrader('LIMK1');
      lpTrader3.darkQuote = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      lpTrader3.litQuote = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldPrice = {
        buyPrice  : 28.0,
        sellPrice : 29.0,
        amount    : 2500
      };
      lpTrader3.tradingHoldSpread = {
        buyPrice  : 27.5,
        sellPrice : 28.5,
        amount    : 2500
      };
      nlpTrader = common.getTrader('AUTTR20');
      adminClient = common.getTrader('ADMJB1');
    });

    it('Log in as NLP Trader ', async () => {
      await clearAndReload();
      await start(nlpTrader);
    });

    it('Log in as LP Traders ', async () => {
      lpTradeClient1 = new ApiClient(lpTrader1);
      await lpTradeClient1.login();
      lpTradeClient2 = new ApiClient(lpTrader2);
      await lpTradeClient2.login();
      lpTradeClient3 = new ApiClient(lpTrader3);
      await lpTradeClient3.login();
    });

    it('NLP Trader creates strategy', async () => {
      await createStrategy(strategy, MarketViewTabs.EUROSTOXX);
    });

    it('Set Key Time Period as now', async () => {
      adminClient = new ApiClient(adminClient);
      await adminClient.login();
      const marketSegment = await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
      const startTime = addMinsToDate(0)
      const endTime = addMinsToDate(10);
      const startTimeDate = getHHMM(startTime);
      const endTimeDate = getHHMM(endTime);
      marketSegment[0].keyTimePeriods = [{timePeriodFrom : startTimeDate,
        timePeriodTo   : endTimeDate}]
      await adminClient.updateMarketSegment(marketSegment[0]);
      await adminClient.getMarketSegment(MarketSegmentIds.SX5E);
    });

    it('NLP should initiate an RFS', async () => {
      await clickRequestQuotesOnMarketView(strategy, MarketViewTabs.EUROSTOXX);
      await lpTradeClient1.respondToRFS(strategyId);
      await lpTradeClient2.respondToRFS(strategyId);
      await lpTradeClient3.respondToRFS(strategyId);
    });

    it('LP traders should provide a quote in dark', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'DARK');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.darkQuote.buyPrice, lpTrader1.darkQuote.sellPrice, lpTrader1.darkQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.darkQuote.buyPrice, lpTrader2.darkQuote.sellPrice, lpTrader2.darkQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.darkQuote.buyPrice, lpTrader3.darkQuote.sellPrice, lpTrader3.darkQuote.amount);
    });

    it('LP traders should provide a quote in lit', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'LIT');
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.litQuote.buyPrice, lpTrader1.litQuote.sellPrice, lpTrader1.litQuote.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.litQuote.buyPrice, lpTrader2.litQuote.sellPrice, lpTrader2.litQuote.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.litQuote.buyPrice, lpTrader3.litQuote.sellPrice, lpTrader3.litQuote.amount);
    });

    it('Wait till Trading Phase', async () => {
      await waitUntilPhaseForApiClient(lpTradeClient1, strategyId, 'TRADING');
      // Await browser.pause(frameworkConfig.normalTradingHoldPriceLength);
      await lpTradeClient1.rfsQuote(strategyId, lpTrader1.tradingHoldSpread.buyPrice, lpTrader1.tradingHoldSpread.sellPrice, lpTrader1.tradingHoldSpread.amount);
      await lpTradeClient2.rfsQuote(strategyId, lpTrader2.tradingHoldSpread.buyPrice, lpTrader2.tradingHoldSpread.sellPrice, lpTrader2.tradingHoldSpread.amount);
      await lpTradeClient3.rfsQuote(strategyId, lpTrader3.tradingHoldSpread.buyPrice, lpTrader3.tradingHoldSpread.sellPrice, lpTrader3.tradingHoldSpread.amount);
    });

    it('NLP trader should hit the bid', async () => {
      rfsWindow = new Rfs(context);
      await hitTopBid(rfsWindow, strategy);
    });

    it('Get Request Id for Strategy', async () => {
      /*
       * AdminClient = new ApiClient(adminClient);
       * await adminClient.login();
       */
      requestId = await returnRequestId(strategyId);
    });

    it('LP Ranking Request ', async () => {
      const startOfDay = await getToday();
      await adminClient.runLpRankingQuery(startOfDay, ProductGroupIds.SX5E);
    });

    it('Verify strategy type is correct - Key ', async () => {
      const qpLpTrader1 = await adminClient.executeLpRankingDatabaseOperationWithStrategyType(requestId, 'QP', lpTrader1.userData.desk);
      logger.info((qpLpTrader1.response[0].data[1]).toString());

      expect(qpLpTrader1.response[0].data[1])
        .to.eql(['KEY']);
    });
  });

  async function returnRequestId (strategyId) {
    const start = await getEpochForTimeToday(0, 0, 0, 0);
    const end = await getEpochForTimeToday(23, 30, 0, 0);
    const activityResponse = await adminClient.searchActivityLog(start, end);
    const filteredResponse = activityResponse.response.filter(order => {
      return (order.strategy == strategyId && order.requestId !== '' && order.event != 'REJECTION' && order.event != 'CANCEL')});
    const requestId = filteredResponse[filteredResponse.length - 1].requestId;


    return requestId;
  }

  function getEpochForTimeToday (hours, min, sec, ms) {
    const start = new Date();
    start.setHours(hours, min, sec, ms);

    return (new Date(start)).getTime() / 1000;
  }

  function getHHMM (date) {
    const today = new Date(date);
    const hhmm = `${today.getHours()}:${(today.getMinutes() < 10 ? `0${today.getMinutes()}` : today.getMinutes())}`

    return hhmm;
  }

  function getToday () {
    const today = new Date();
    const dateFormat = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;

    return dateFormat;
  }

  function addMinsToDate (minutes) {
    const date = new Date();

    return date.setMinutes(date.getMinutes() + minutes)
  }

  async function createStrategy (strategy, marketView) {
    strategyId = await common.getStrategyId(strategy, marketView);
    if (strategyId === null) {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      strategy = await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmit.click();
      logger.info('Strategy has been created.');
      await common.waitUntilStrategyFound(strategy, frameworkConfig.shortTimeout, marketView);
      strategyId = await common.getStrategyId(strategy, marketView);
      strategyFound = strategyId !== -1;
    }
    expect(strategyId !== null)
      .to
      .equal(true, 'Could not find Strategy');
  }

  async function waitUntilPhaseForApiClient (client, strategyId, expectedPhase) {
    await browser.waitUntil(
      async () => {
        const phase = await client.getRfsPhase(strategyId);


        return phase === expectedPhase;
      },
      120000
    );
  }

  async function hitTopBid (rfsWindow, strategy) {
    await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
    const bidOfferRow = await rfsWindow.getBidOfferRow(1);
    await bidOfferRow.clickBidPriceBtn();
    await rfsWindow.btnHitClick();
    await browser.switchTab(mainWindowHandle);
  }

  async function clearAndReload () {
    const clearDownScript = await require.resolve(join('../../', frameworkConfig.clearDownScript));
    await shellExec(clearDownScript);
    await browser.reload();
  }

  async function clickRequestQuotesOnMarketView (strategy, marketView) {
    await mainPageFrame.clickMarketViewHeader();
    const table = await mainPageFrame.getMarketViewTab().clickSubTab(marketView);
    await browser.pause(3000);
    strategyRow = await table.getTableRow(strategy);
    await strategyRow.clickStatus();
    logger.info('Found newly created strategy in Market View.');
    const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
    const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
    expect(btnEnabled).to.equal(
      true,
      'Request quotes button on Market Depth Tab should be enabled.'
    );
    await marketDepth.clickRequestQuotesBtn();
    logger.info('Clicked request for quotes.');
  }

  function returnKeyStrategy () {
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3700, 3, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 3100, 1);
    strategy.addLeg('-', 'C', 'MAR20', 3200, 1);

    return strategy;
  }

  //TODO: function to add market and underlying in parameter
  function returnNkyoKeyStrategy () {
    const strategy = new Strategy(MARKET.nikkei, UNDERLYING.nkyo, STRATEGY.callSpread, STYLE.euro, 24007, 1, POLARITY.negative, null, null);
    strategy.addLeg('+', 'C', 'MAR20', 19000, 1);
    strategy.addLeg('-', 'C', 'MAR20', 19250, 1);

    return strategy;
  }

  function returnNonKeyStrategy () {
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3701, null, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 3500, 1);

    return strategy;
  }
});

