import Strategy from '../../../lib/Strategy';
import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../constants/GenericType';

const strategies = [];

let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, null, 37, '-', null, null, 1);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 40, '-', 'STXEU9', null, 2);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 21);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 22);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 23);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 24);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 25);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 26);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 27);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 28);
strategy.addLeg('+', 'C', 'JUN21', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 29);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 30);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 31);
strategy.addLeg('+', 'C', 'DEC19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 32);
strategy.addLeg('+', 'C', 'JUN21', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 33);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 34);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 35);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 36);
strategy.addLeg('+', 'C', 'JUN21', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 37);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 38);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 39);
strategy.addLeg('+', 'C', 'DEC19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 3179, 0, null, 'STXEU9', null, 40);
strategy.addLeg('+', 'C', 'JUN21', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 41);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 42);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 43);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 44);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 45);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 46);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 47);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 48);
strategy.addLeg('+', 'P', 'JUN21', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 49);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 50);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 51);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 52);
strategy.addLeg('+', 'P', 'JUN21', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 53);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 54);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 55);
strategy.addLeg('+', 'P', 'DEC19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 56);
strategy.addLeg('+', 'P', 'JUN21', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 57);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 58);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 59);
strategy.addLeg('+', 'P', 'DEC19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 0, null, 'STXEU9', null, 60);
strategy.addLeg('+', 'P', 'JUN21', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 97, '+', 'STXEU9', null, 61);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.put, STYLE.euro, 3179, 94, '+', 'STXEU9', null, 62);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3179, 3, '-', 'STXEU9', null, 81);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3179, 41, '-', 'STXEU9', null, 82);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 97);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 98);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 113);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 114);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 3179, 1, '+', 'STXEU9', null, 129);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpread, STYLE.euro, 3179, 63, '+', 'STXEU9', null, 130);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 38, '-', 'STXEU9', null, 145);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 16, '-', 'STXEU9', null, 146);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 160);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 161);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 11, '+', 'STXEU9', null, 175);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendar, STYLE.euro, 3179, 81, '+', 'STXEU9', null, 176);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 56, '-', 'STXEU9', null, 190);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 26, '-', 'STXEU9', null, 191);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 205);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 206);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 90, '+', 'STXEU9', null, 220);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 3179, 87, '+', 'STXEU9', null, 221);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.risky, STYLE.euro, 3179, 0, null, 'STXEU9', null, 235);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.risky, STYLE.euro, 3179, 0, null, 'STXEU9', null, 236);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.risky, STYLE.euro, 3179, 40, '+', 'STXEU9', null, 251);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.risky, STYLE.euro, 3179, 95, '+', 'STXEU9', null, 252);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 23, '-', 'STXEU9', null, 267);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1.5);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 87, '-', 'STXEU9', null, 268);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 2);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 68, '-', 'STXEU9', null, 270);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 36, '-', 'STXEU9', null, 271);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 2);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 65, '-', 'STXEU9', null, 292);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 78, '-', 'STXEU9', null, 295);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 2);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 303);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1.5);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 304);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 2);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 306);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 307);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 2);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 328);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 331);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 2);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 1, '+', 'STXEU9', null, 339);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1.5);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 82, '+', 'STXEU9', null, 340);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 2);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 94, '+', 'STXEU9', null, 342);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 24, '+', 'STXEU9', null, 343);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 2);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 66, '+', 'STXEU9', null, 364);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3179, 50, '+', 'STXEU9', null, 367);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 2);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 81, '-', 'STXEU9', null, 375);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 6, '-', 'STXEU9', null, 376);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 2);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 33, '-', 'STXEU9', null, 378);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 48, '-', 'STXEU9', null, 379);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 2);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 2, '-', 'STXEU9', null, 388);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 2);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 43, '-', 'STXEU9', null, 391);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 2);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 411);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 412);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 2);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 414);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 415);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 2);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 424);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 2);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 427);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 2);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 54, '+', 'STXEU9', null, 447);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 44, '+', 'STXEU9', null, 448);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 2);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 98, '+', 'STXEU9', null, 450);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 97, '+', 'STXEU9', null, 451);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 2);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 63, '+', 'STXEU9', null, 460);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 2);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putFly, STYLE.euro, 3179, 38, '+', 'STXEU9', null, 463);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 2);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 82, '-', 'STXEU9', null, 483);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 68, '-', 'STXEU9', null, 484);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 503);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 504);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 14, '+', 'STXEU9', null, 523);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddle, STYLE.euro, 3179, 2, '+', 'STXEU9', null, 524);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 2, '-', 'STXEU9', null, 543);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 35, '-', 'STXEU9', null, 544);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 559);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 560);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 19, '+', 'STXEU9', null, 575);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 3179, 9, '+', 'STXEU9', null, 576);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.synthetic, STYLE.euro, 3179, 100, '+', 'STXEU9', null, 591);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.synthetic, STYLE.euro, 3179, 100, '+', 'STXEU9', null, 592);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.synthetic, STYLE.euro, 3179, 0, null, 'STXEU9', null, 611);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.synthetic, STYLE.euro, 3179, 0, null, 'STXEU9', null, 612);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 70, '-', 'STXEU9', null, 631);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 44, '-', 'STXEU9', null, 634);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 667);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 666666);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 670);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 80, '+', 'STXEU9', null, 703);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleSpread, STYLE.euro, 3179, 85, '+', 'STXEU9', null, 706);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.jellyRoll, STYLE.euro, 3179, 0, null, 'STXEU9', null, 754);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.jellyRoll, STYLE.euro, 3179, 0, null, 'STXEU9', null, 755);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 81, '-', 'STXEU9', null, 784);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 1, '-', 'STXEU9', null, 785);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 6, '-', 'STXEU9', null, 786);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 23, '-', 'STXEU9', null, 787);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 16, '-', 'STXEU9', null, 788);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 74, '-', 'STXEU9', null, 789);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 832);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 833);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 834);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 835);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 836);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 837);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 72, '+', 'STXEU9', null, 880);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 88, '+', 'STXEU9', null, 881);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 68, '+', 'STXEU9', null, 882);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 61, '+', 'STXEU9', null, 883);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 25, '+', 'STXEU9', null, 884);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callRatioSpread, STYLE.euro, 3179, 77, '+', 'STXEU9', null, 885);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 77, '-', 'STXEU9', null, 928);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 74, '-', 'STXEU9', null, 929);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 7, '-', 'STXEU9', null, 930);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 56, '-', 'STXEU9', null, 931);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 10, '-', 'STXEU9', null, 932);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 11, '-', 'STXEU9', null, 933);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 976);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 977);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 978);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 979);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 980);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 981);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 78, '+', 'STXEU9', null, 1024);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 18, '+', 'STXEU9', null, 1025);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 40, '+', 'STXEU9', null, 1026);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 70, '+', 'STXEU9', null, 1027);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 30, '+', 'STXEU9', null, 1028);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putRatioSpread, STYLE.euro, 3179, 68, '+', 'STXEU9', null, 1029);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 3);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 57, '-', 'STXEU9', null, 1072);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 31, '-', 'STXEU9', null, 1075);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1117);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1120);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 45, '+', 'STXEU9', null, 1162);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarRatio, STYLE.euro, 3179, 39, '+', 'STXEU9', null, 1165);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 19, '-', 'STXEU9', null, 1207);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 88, '-', 'STXEU9', null, 1210);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1252);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1255);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 58, '+', 'STXEU9', null, 1297);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarRatio, STYLE.euro, 3179, 37, '+', 'STXEU9', null, 1300);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3179, 83, '+', 'STXEU9', null, 1342);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3179, 76, '+', 'STXEU9', null, 1345);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3179, 76, null, 'STXEU9', null, 1346);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1390);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1393);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 35, '-', 'STXEU9', null, 1486);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 14, '-', 'STXEU9', null, 1487);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'JUN21', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1498);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1499);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'JUN21', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 47, '+', 'STXEU9', null, 1510);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callDiagonalCalendar, STYLE.euro, 3179, 22, '+', 'STXEU9', null, 1511);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'JUN21', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 45, '-', 'STXEU9', null, 1522);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 85, '-', 'STXEU9', null, 1523);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1534);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1535);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 77, '+', 'STXEU9', null, 1546);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putDiagonalCalendar, STYLE.euro, 3179, 15, '+', 'STXEU9', null, 1547);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadVCall, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1570);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadVCall, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1571);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadVCall, STYLE.euro, 3179, 83, '+', 'STXEU9', null, 1582);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadVCall, STYLE.euro, 3179, 48, '+', 'STXEU9', null, 1583);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPut, STYLE.euro, 3179, 16, '-', 'STXEU9', null, 1594);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3000, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPut, STYLE.euro, 3179, 25, '-', 'STXEU9', null, 1595);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPut, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1606);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategy.addLeg('-', 'P', '27JUN19', 3000, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPut, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1607);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskyTimeSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1666);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskyTimeSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1669);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskyTimeSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1669);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3200, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskyTimeSpread, STYLE.euro, 3179, 96, '+', 'STXEU9', null, 1702);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskyTimeSpread, STYLE.euro, 3179, 25, '+', 'STXEU9', null, 1705);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 88, '-', 'STXEU9', null, 1738);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 69, '-', 'STXEU9', null, 1739);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1754);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1755);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 13, '+', 'STXEU9', null, 1770);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.boxSpread, STYLE.euro, 3179, 16, '+', 'STXEU9', null, 1771);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 3, '-', 'STXEU9', null, 1786);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 77, '-', 'STXEU9', null, 1787);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 11, '-', 'STXEU9', null, 1794);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 61, '-', 'STXEU9', null, 1795);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1798);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1799);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1806);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1807);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 74, '+', 'STXEU9', null, 1810);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 26, '+', 'STXEU9', null, 1811);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3500, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 25, '+', 'STXEU9', null, 1818);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callLadder, STYLE.euro, 3179, 18, '+', 'STXEU9', null, 1819);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 97, '-', 'STXEU9', null, 1822);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 97, '-', 'STXEU9', null, 1823);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 7, '-', 'STXEU9', null, 1826);
strategy.addLeg('-', 'P', '27JUN19', 3000, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 61, '-', 'STXEU9', null, 1827);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1834);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1835);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1838);
strategy.addLeg('-', 'P', '27JUN19', 3000, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1839);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 14, '+', 'STXEU9', null, 1846);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 4, '+', 'STXEU9', null, 1847);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 10, '+', 'STXEU9', null, 1850);
strategy.addLeg('-', 'P', '27JUN19', 3000, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putLadder, STYLE.euro, 3179, 95, '+', 'STXEU9', null, 1851);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 48, '-', 'STXEU9', null, 1858);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 51, '-', 'STXEU9', null, 1859);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 86, '-', 'STXEU9', null, 1862);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 41, '-', 'STXEU9', null, 1863);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1866);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1867);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1870);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1871);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 50, '+', 'STXEU9', null, 1874);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 23, '+', 'STXEU9', null, 1875);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 18, '+', 'STXEU9', null, 1878);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCondor, STYLE.euro, 3179, 82, '+', 'STXEU9', null, 1879);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 35, '-', 'STXEU9', null, 1882);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 75, '-', 'STXEU9', null, 1883);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 40, '-', 'STXEU9', null, 1886);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 88, '-', 'STXEU9', null, 1887);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1890);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1891);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1894);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1895);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 47, '+', 'STXEU9', null, 1898);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 39, '+', 'STXEU9', null, 1899);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 98, '+', 'STXEU9', null, 1902);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCondor, STYLE.euro, 3179, 23, '+', 'STXEU9', null, 1903);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 42, '-', 'STXEU9', null, 1906);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 47, '-', 'STXEU9', null, 1907);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1914);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1915);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1918);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1919);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 76, '+', 'STXEU9', null, 1922);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironCondor, STYLE.euro, 3179, 66, '+', 'STXEU9', null, 1923);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 30, '-', 'STXEU9', null, 1930);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 1, '-', 'STXEU9', null, 1933);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1960);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 1963);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 85, '+', 'STXEU9', null, 1990);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callCalendarFly, STYLE.euro, 3179, 14, '+', 'STXEU9', null, 1993);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 36, '-', 'STXEU9', null, 2020);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 23, '-', 'STXEU9', null, 2023);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2050);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2053);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 5, '+', 'STXEU9', null, 2080);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendarFly, STYLE.euro, 3179, 31, '+', 'STXEU9', null, 2083);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 18, '-', 'STXEU9', null, 2110);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 64, '-', 'STXEU9', null, 2113);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'DEC19', 3400, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2146);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2149);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'DEC19', 3400, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 47, '+', 'STXEU9', null, 2182);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.riskySwap, STYLE.euro, 3179, 16, '+', 'STXEU9', null, 2185);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'DEC19', 3400, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 39, '-', 'STXEU9', null, 2218);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 34, '-', 'STXEU9', null, 2221);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2254);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2257);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 22, '+', 'STXEU9', null, 2290);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadSwap, STYLE.euro, 3179, 19, '+', 'STXEU9', null, 2293);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 90, '-', 'STXEU9', null, 2326);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 54, '-', 'STXEU9', null, 2329);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3200, 1);
strategy.addLeg('-', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2362);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2365);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3200, 1);
strategy.addLeg('-', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 85, '+', 'STXEU9', null, 2398);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSpreadSwap, STYLE.euro, 3179, 46, '+', 'STXEU9', null, 2401);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3200, 1);
strategy.addLeg('-', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 12, '-', 'STXEU9', null, 2434);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 44, '-', 'STXEU9', null, 2437);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2464);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2467);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 62, '+', 'STXEU9', null, 2494);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1.5);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3100, 1);
strategy.addLeg('+', 'P', 'DEC19', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleFly, STYLE.euro, 3179, 54, '+', 'STXEU9', null, 2497);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'DEC19', 3100, 1.5);
strategy.addLeg('-', 'P', 'DEC19', 3100, 1.5);
strategy.addLeg('+', 'C', 'JUN21', 3100, 1);
strategy.addLeg('+', 'P', 'JUN21', 3100, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 26, '-', 'STXEU9', null, 2524);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 76, '-', 'STXEU9', null, 2527);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2542);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2545);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 43, '+', 'STXEU9', null, 2560);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1.5);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangleSpread, STYLE.euro, 3179, 53, '+', 'STXEU9', null, 2563);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3300, 1.5);
strategy.addLeg('+', 'C', 'DEC19', 3400, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 63, '-', 'STXEU9', null, 2578);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1.5);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 29, '-', 'STXEU9', null, 2581);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'DEC19', 3000, 1.5);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2605);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1.5);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2608);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'DEC19', 3000, 1.5);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 31, '+', 'STXEU9', null, 2632);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3000, 1.5);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVStrangle, STYLE.euro, 3179, 66, '+', 'STXEU9', null, 2635);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'DEC19', 3000, 1.5);
strategy.addLeg('-', 'C', 'DEC19', 3450, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 65, '-', 'STXEU9', null, 2659);
strategy.addLeg('+', 'C', '27JUN19', 3000, 1);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 72, '-', 'STXEU9', null, 2662);
strategy.addLeg('+', 'C', 'SEP19', 3000, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2683);
strategy.addLeg('+', 'C', '27JUN19', 3000, 1);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2686);
strategy.addLeg('+', 'C', 'SEP19', 3000, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 47, '+', 'STXEU9', null, 2707);
strategy.addLeg('+', 'C', '27JUN19', 3000, 1);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1.5);
strategy.addLeg('+', 'P', '27JUN19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpreadVPutSpread, STYLE.euro, 3179, 40, '+', 'STXEU9', null, 2710);
strategy.addLeg('+', 'C', 'SEP19', 3000, 1);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3000, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 19, '-', 'STXEU9', null, 2731);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 60, '-', 'STXEU9', null, 2732);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2743);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2744);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2751);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3400, 1);
strategy.addLeg('-', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2752);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3400, 1);
strategy.addLeg('-', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 48, '+', 'STXEU9', null, 2755);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3200, 1);
strategy.addLeg('-', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3179, 63, '+', 'STXEU9', null, 2756);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('-', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 6, '-', 'STXEU9', null, 2766);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 6, '-', 'STXEU9', null, 2767);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 44, '-', 'STXEU9', null, 2769);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 44, '-', 'STXEU9', null, 2770);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2802);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2803);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2805);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2806);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2807);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 2);
strategy.addLeg('+', 'P', 'DEC19', 3200, 2);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 22, '+', 'STXEU9', null, 2838);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 22, '+', 'STXEU9', null, 2839);
strategy.addLeg('-', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3100, 1);
strategy.addLeg('+', 'C', 'SEP19', 3200, 1.5);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 42, '+', 'STXEU9', null, 2841);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleCalendar, STYLE.euro, 3179, 42, '+', 'STXEU9', null, 2842);
strategy.addLeg('-', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3100, 1);
strategy.addLeg('+', 'C', 'DEC19', 3200, 1.5);
strategy.addLeg('+', 'P', 'DEC19', 3200, 1.5);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 69, '-', 'STXEU9', null, 2875);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 61, '-', 'STXEU9', null, 2876);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2887);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2888);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2895);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategy.addLeg('-', 'C', '27JUN19', 3400, 1);
strategy.addLeg('+', 'C', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2896);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategy.addLeg('-', 'C', 'SEP19', 3400, 1);
strategy.addLeg('+', 'C', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 40, '+', 'STXEU9', null, 2899);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategy.addLeg('+', 'C', '27JUN19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSkinnyFly, STYLE.euro, 3179, 52, '+', 'STXEU9', null, 2900);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategy.addLeg('+', 'C', 'SEP19', 3300, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 81, '-', 'STXEU9', null, 2911);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 89, '-', 'STXEU9', null, 2912);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2923);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2924);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2927);
strategy.addLeg('+', 'P', '27JUN19', 3200, 1);
strategy.addLeg('-', 'P', '27JUN19', 3300, 1);
strategy.addLeg('+', 'P', '27JUN19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2928);
strategy.addLeg('+', 'P', 'SEP19', 3200, 1);
strategy.addLeg('-', 'P', 'SEP19', 3300, 1);
strategy.addLeg('+', 'P', 'SEP19', 3400, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 44, '+', 'STXEU9', null, 2935);
strategy.addLeg('+', 'P', '27JUN19', 3300, 1);
strategy.addLeg('-', 'P', '27JUN19', 3400, 1);
strategy.addLeg('+', 'P', '27JUN19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putSkinnyFly, STYLE.euro, 3179, 27, '+', 'STXEU9', null, 2936);
strategy.addLeg('+', 'P', 'SEP19', 3300, 1);
strategy.addLeg('-', 'P', 'SEP19', 3400, 1);
strategy.addLeg('+', 'P', 'SEP19', 3450, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 13, '-', 'STXEU9', null, 2947);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 4, '-', 'STXEU9', null, 2950);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2996);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 0, null, 'STXEU9', null, 2999);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 38, '+', 'STXEU9', null, 3043);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'C', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVCall, STYLE.euro, 3179, 43, '+', 'STXEU9', null, 3046);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'C', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 33, '-', 'STXEU9', null, 3091);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 80, '-', 'STXEU9', null, 3094);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 0, null, 'STXEU9', null, 3140);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 0, null, 'STXEU9', null, 3143);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 84, '+', 'STXEU9', null, 3187);
strategy.addLeg('+', 'C', '27JUN19', 3100, 1);
strategy.addLeg('+', 'P', '27JUN19', 3100, 1);
strategy.addLeg('-', 'P', '27JUN19', 3200, 1);
strategies.push(strategy);

strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.straddleVPut, STYLE.euro, 3179, 24, '+', 'STXEU9', null, 3190);
strategy.addLeg('+', 'C', 'SEP19', 3100, 1);
strategy.addLeg('+', 'P', 'SEP19', 3100, 1);
strategy.addLeg('-', 'P', 'SEP19', 3200, 1);
strategies.push(strategy);

export {strategies};

// Created from v190429.xlsx;
