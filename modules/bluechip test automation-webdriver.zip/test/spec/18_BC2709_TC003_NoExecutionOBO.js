/* eslint-disable max-len */
import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import TestCommons from '../../lib/TestCommons';
import {shellExec} from '../../utilities/framework/shell-exec';
import {Bootstrap} from '@fenics/fenics-test-core';
import ApiClient from '../../utilities/api/ApiClient';
import {expect} from 'chai';
import Rfs from '../../pages/child_windows/Rfs';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {join} from 'path';
const XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;


describe('BC2709 TC003: No longer invite Broking Users to participate in a VC instead show size traded so far to relevant brokers', function BC2709EndToEndTest () {
  const browser = global.browser;
  const decimalPlaces = 3;
  const defaultMidPrice = 100;
  let bootstrapper = null;
  let context = null;

  let common = null;
  let mainPageFrame = null;
  let logger = null;


  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2709 TC003: As a broker who initiated the rfs and is relevant to the trade I should not receive VC notifications and I should see VC price and I should see VC size in the market view when a trader initiates a VC by lifting or hitting resting rfs price from the order book', async () => {
    before(async () => {
      const refPrice = await getFuturePrice();
      strategy.referencePrice = 3499;
    });

    let brokerUser = null;
    let nlpTradeUser = null;
    let lpTradeUser = null;

    let nlpTradeClient = null;
    let lpTradeClient = null;

    let strategyId = null;
    let strategyFound = false;
    let strategyRow = null;
    let rfsWindow = null;

    const refPrice = null; // Reference price is pulled from fenics go stats page in the before method


    // TODO: Put method in different class so can be used by other features
    async function getFuturePrice () {
      async function httpGet (theUrl) {
        const xmlHttp = new XMLHttpRequest();
        xmlHttp.open('GET', theUrl, false); // False for synchronous request
        xmlHttp.send(null);


        return xmlHttp.responseText;
      }


      const str = await httpGet('https://go.qa.fenicsone.com/BlueChip/statistics');
      let n = str.lastIndexOf('STXEH0');
      let result = str.substring(n);
      n = result.lastIndexOf('align=right');
      result = result.substring(n + 12);
      let futurePrice = result.substr(0, result.indexOf('<'));
      futurePrice = futurePrice.substring(0, futurePrice.indexOf('.'));
      if (isNaN(futurePrice)) {
        // If stats page is down and returns bad data, this will just give a default price
        futurePrice = 3499;
      }

      return futurePrice;
    }

    const strike = 3000;
    let sellPrice = 0;
    let buyPrice = 0;
    const buyOffSet = 1;
    const sellOffSet = 2.5;
    const amount = 3000;
    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, refPrice, null, POLARITY.negative, null, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC23', strike, 1);

    it('Users should login', async () => {
      brokerUser = common.getBroker('AUTBR04');
      nlpTradeUser = common.getTrader('AUTTR10');
      lpTradeUser = common.getTrader('AUTTR01');
      await start(brokerUser);
      nlpTradeClient = new ApiClient(nlpTradeUser);
      await nlpTradeClient.login();
      lpTradeClient = new ApiClient(lpTradeUser);
      await lpTradeClient.login();
    });

    it('I should have a strategy to trade', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      strategy = await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound).to.equal(
        true,
        `Expected to find strategy ${strategy.rowDataName}`
      );
    });

    it('I should initiate an RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.clickMarketViewHeader();

      const table = await mainPageFrame
        .getMarketViewTab()
        .clickSubTab(MarketViewTabs.EUROSTOXX);

      strategyRow = await table.getTableRow(strategy);
      await strategyRow.clickStatus();
      logger.info('Found newly created strategy in Market View.');

      const marketDepth = await mainPageFrame
        .getMarketViewTab()
        .getMarketDepthTab();

      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();

      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();
      logger.info('Clicked request for quotes.');
    });

    it('I should see RFS window open', async () => {
      await nlpTradeClient.respondToRFS(strategyId);
      await lpTradeClient.respondToRFS(strategyId);

      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      rfsWindow = new Rfs(context);
      const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();

      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');

      const windowTitle = await rfsWindow.getTitle();

      expect(windowTitle)
        .to
        .equal(rfsWindowTitle, 'RFS window title');

      const delta = await rfsWindow.getDelta();

      expect(delta)
        .to
        .equal(strategy.getDisplayDelta().toString(), 'RFS window delta');

      const ref = await rfsWindow.getRef();

      expect(ref)
        .to
        .equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    it('LP trader should provide a quote', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      let midPrice = await lpTradeClient.getStrategyMidPrice(strategyId);

      if (!midPrice) {
        midPrice = defaultMidPrice;
      }

      midPrice = midPrice.toFixed(0);
      buyPrice = (Number(midPrice) + buyOffSet).toFixed(decimalPlaces);
      sellPrice = (Number(midPrice) + sellOffSet).toFixed(decimalPlaces);

      const quoteMsg = await lpTradeClient.rfsQuote(strategyId, buyPrice, sellPrice, amount);
      expect(quoteMsg.response[0])
        .to
        .equal('successful', 'LP trader did was unable to quote inside the timeout period');
    });

    it('I should see one responder in the RFS window in the Dark phase', async () => {
      await rfsWindow.waitUntilResponderCount(1, frameworkConfig.shortTimeout);
      const responded = await rfsWindow.getResponded();

      expect(responded)
        .to
        .include('1/', 'RFS window expected one rfs participants');
    });

    it('I should see the price spread quoted by the LP trader in the RFS window in the LIT phase', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const currentSpread = await rfsWindow.getCurrentSpread();
      const darkSpread = await rfsWindow.getDarkSpread();
      const expectedSpread = (sellPrice - buyPrice).toFixed(2);

      expect(currentSpread)
        .to
        .equal(expectedSpread.toString(), 'RFS current spread');

      expect(darkSpread)
        .to
        .equal(expectedSpread.toString(), 'RFS dark spread');
    });

    it('I should see RFS transition to Trading Phase', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const tradingPhase = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);
      const askSize = await bidOfferRowOne.getAskSize();
      const askPrice = await bidOfferRowOne.getAskPrice();
      const bidSize = await bidOfferRowOne.getBidSize();
      const bidPrice = await bidOfferRowOne.getBidPrice();

      expect(askSize)
        .to
        .equal(amount.toString(), 'RFS ask size');

      expect(askPrice)
        .to
        .equal(sellPrice.toString(), 'RFS top of market ask');

      expect(bidSize)
        .to
        .equal(amount.toString(), 'RFS bid size');

      expect(bidPrice)
        .to
        .equal(buyPrice.toString(), 'RFS top of market bid');

      expect(tradingPhase)
        .to
        .equal(true, 'Expected RFS to be in Trading phase');
    });

    it('I should see RFS end without a match', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const rfsTimedout = await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);

      expect(rfsTimedout)
        .to
        .equal(true, 'RFS should of timed out but it did not');

      await rfsWindow.btnOkClick();
    });

    it('NLP user should initiate a VC by matching the offer in the order book', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const order = [{price : sellPrice,
        side  : 'BUY',
        size  : amount}];

      const orderAddMsg = await nlpTradeClient.strategyOrderAdd(strategyId, false, true, false, false, order);

      expect(orderAddMsg.response[0].success)
        .to
        .equal(true, 'Order was added successfully to the orderbook.');
    });

    it('I should see pink VC status price and size against the strategy in the Market View', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await mainPageFrame.switchToWindow();
      await strategyRow.waitUntilStatus('VC', frameworkConfig.shortTimeout);
      const status = await strategyRow.getStatusText();

      expect(status)
        .to
        .equal('VC', 'Market View Strategy Status');

      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();
      const price = await strategyRow.getPrices();

      expect(bidSize)
        .to
        .equal(amount.toString(), 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal(amount.toString(), 'Market view strategy ask size');

      expect(price)
        .to
        .equal(sellPrice.toString(), 'Market view strategy price');
    });

    it('I should not see a VC notification alert', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const vcNotification = await notifications.getVC(strategy, buyPrice.toString());
      const found = await vcNotification.waitForExist(frameworkConfig.veryShortTimeout);

      expect(found)
        .to
        .equal(false, 'VC notification message should not exist but it does');
    });

    it('I should not see a VC toast message', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const toastMsg = new ToastNotification(context);
      const vcMesages = await toastMsg.getVcToastMsg(buyPrice.toString(), strategy);

      expect(vcMesages.length)
        .to
        .equal(0, 'Did not expect to find Responder toast message');
    });

    it('Traders should trade more volume in the VC', async () => {
      const sellInterest = 1500;
      const buyInterest = 2000;
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const lpInterest = await lpTradeClient.vcAddInterest(strategyId, 'SELL', sellInterest);
      const nlpInterest = await nlpTradeClient.vcAddInterest(strategyId, 'BUY', buyInterest);

      expect(lpInterest.response[0])
        .to
        .equal('successful', 'LP user should add VC interest');

      expect(nlpInterest.response[0])
        .to
        .equal('successful', 'NLP user should add VC interest');
    });

    it('I should see size update for the strategy in the Market View', async () => {
      await strategyRow.waitUntilSizeAndPrice('4500', '4500', sellPrice.toString());
      const bidSize = await strategyRow.getBidSize();
      const askSize = await strategyRow.getAskSize();
      const price = await strategyRow.getPrices();

      expect(bidSize)
        .to
        .equal('4500', 'Market view strategy bid size');

      expect(askSize)
        .to
        .equal('4500', 'Market view strategy ask size');

      expect(price)
        .to
        .equal(sellPrice.toString(), 'Market view strategy price');
    });

    it('I should not be able to open a VC window', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      await strategyRow.clickStatus();
      const vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      expect(foundWindow)
        .to
        .equal(false, 'VC window found, VC window should not exist');
    });

    it('Users should logout', async () => {
      await nlpTradeClient.logout();
      await lpTradeClient.logout();
    });
  });
});

