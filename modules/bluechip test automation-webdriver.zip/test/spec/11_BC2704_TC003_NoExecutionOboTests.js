/* eslint-disable max-lines,max-statements */
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, UNDERLYING, STRATEGY, POLARITY, STYLE, OPTION_TYPE} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import ApiClient from '../../utilities/api/ApiClient';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import MarketViewTabs from '../../constant/MarketViewTabs';


describe('BC2704 OBO RFS Tests', function BC2704EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let common = null;
  let mainPageFrame = null;

  before(() => {
    this.timeout(frameworkConfig.testMaxTime);
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }


  describe('BC2704 TC003: As a broker I should be able to activate NLP traders and follow the RFS flow', () => {
    let rfsWindow = null;
    let broker = {};
    let nlpTraderOne = {};
    let nlpTraderTwo = {};
    let nlpTraderThree = {};
    let lpTraderOne = {};
    let nlpClientOne = null;
    let nlpClientTwo = null;
    let nlpClientThree = null;
    let lpClientOne = null;
    const threeDp = 3;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 335, 12, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 200, 2.25);
    /* eslint-enable no-magic-numbers */

    let strategyId = null;
    let strategyRow = null;

    it('Setup users', async () => {
      broker = common.getBroker('AUTBR03');

      nlpTraderOne = common.getTrader('AUTTR02');
      nlpTraderOne.tradeQuoteOne = {
        buyPrice  : 1020,
        sellPrice : 1055,
        amount    : 5000
      };
      nlpTraderOne.tradeQuoteTwo = {
        buyPrice  : 1040.000,
        sellPrice : 1050.000,
        amount    : 5000
      };
      nlpTraderOne.tradeQuoteThree = {
        buyPrice  : 1041,
        sellPrice : 1049,
        amount    : 5000
      };

      nlpTraderTwo = common.getTrader('AUTTR06');
      nlpTraderTwo.tradeQuoteOne = {
        buyPrice  : 1022,
        sellPrice : 1056,
        amount    : 7500
      };

      nlpTraderThree = common.getTrader('AUTTR07');

      lpTraderOne = common.getTrader('AUTTR08');
      lpTraderOne.darkQuote = {
        buyPrice  : 1030.25,
        sellPrice : 1050.50,
        amount    : 10000
      };
      lpTraderOne.litQuote = {
        buyPrice  : 1030.25,
        sellPrice : 1047.50,
        amount    : 10000
      };
      lpTraderOne.tradeQuoteOne = {
        buyPrice  : 1033.25,
        sellPrice : 1050.50,
        amount    : 10000
      };
      lpTraderOne.tradeQuoteTwo = {
        buyPrice  : 1041.00,
        sellPrice : 1050.00,
        amount    : 5000
      };
      lpTraderOne.tradeQuoteThree = {
        buyPrice  : 1050,
        sellPrice : 1057,
        amount    : 5000
      };

      lpClientOne = new ApiClient(lpTraderOne);
      await lpClientOne.login();
      nlpClientOne = new ApiClient(nlpTraderOne);
      await nlpClientOne.login();
      nlpClientTwo = new ApiClient(nlpTraderTwo);
      await nlpClientTwo.login();
      nlpClientThree = new ApiClient(nlpTraderThree);
    });

    it('Broker should login', async () => {
      await start(broker);
      const username = await mainPageFrame.getUsername();
      expect(username)
        .to
        .equal(broker.fenicsGoUsername, 'Logged in username');
    });

    it('Broker should have a strategy to initiate an RFS on', async () => {
      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmitClick();
        const strategyFound = await common.waitUntilStrategyFound(strategy, frameworkConfig.mediumTimeout, MarketViewTabs.EUROSTOXX);
        if (strategyFound) {
          strategyId = await common.getStrategyId(strategy);
        }
      }
      const strategyExist = strategyId !== null;
      expect(strategyExist)
        .to
        .equal(true, 'Could not find Strategy.');
    });

    it('Broker should initiate an RFS', async () => {
      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab()
        .getEuroStoxxTable()
        .getTableRow(strategy);
      await strategyRow.clickStatus();
      logger.info('Found newly created strategy in Market View.');

      const marketDepth = await mainPageFrame.getMarketViewTab()
        .getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();
      logger.info('Clicked request for quotes.');
    });

    it('Traders should respond to the broker RFS', async () => {
      await lpClientOne.respondToRFS(strategyId);
      await nlpClientOne.respondToRFS(strategyId);
      await nlpClientTwo.respondToRFS(strategyId);
    });

    it('Broker should open the RFS window', async () => {
      rfsWindow = new Rfs(context);
      const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');

      const windowTitle = await rfsWindow.getTitle();
      expect(windowTitle)
        .to
        .equal(rfsWindowTitle, 'RFS window title');

      const delta = await rfsWindow.getDelta();
      expect(delta)
        .to
        .equal(strategy.getDisplayDelta()
          .toString(), 'RFS window delta');

      const ref = await rfsWindow.getRef();
      expect(ref)
        .to
        .equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    describe('At the start of the RFS the RFS window should show', () => {
      it('Phase should be DARK', async () => {
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('DARK', 'RFS window should be in DARK phase');
      });

      it('Activate trading user functionality should be disabled', async () => {
        const addTraderBtnEnabled = await rfsWindow.btnActivateEnabled();
        expect(addTraderBtnEnabled)
          .to
          .equal(false, 'RFS Button ACTIVATE should not be enabled in DARK phase');

        const ddTrader = await rfsWindow.ddActivateUser;

        const dropDownEnabled = await ddTrader.getDropDownEnabled();
        expect(dropDownEnabled)
          .to
          .equal(false, 'RFS activate traders drop down list should be disabled');
      });

      it('Responder count should be zero', async () => {
        const responded = await rfsWindow.getResponded();

        expect(responded)
          .to
          .include('0/', 'RFS window expected zero rfs participants');
      });

      it('LP trader should respond to the RFS with a quote', async () => {
        await lpClientOne.rfsQuote(
          strategyId,
          lpTraderOne.darkQuote.buyPrice,
          lpTraderOne.darkQuote.sellPrice,
          lpTraderOne.darkQuote.amount
        );
      });

      it('Responder count should be one', async () => {
        await rfsWindow.waitUntilResponderCount(1);
        const responded = await rfsWindow.getResponded();

        expect(responded)
          .to
          .include('1/', 'RFS window expected one rfs participants');
      });

      it('it should not show current or dark spread', async () => {
        const darkSpreadDisplayed = await rfsWindow.darkSpreadExists();
        expect(darkSpreadDisplayed)
          .to
          .equal(false, 'Dark spread should not be displayed in the RFS dark phase');

        const currentSpreadDisplayed = await rfsWindow.currentSpreadExists();
        expect(currentSpreadDisplayed)
          .to
          .equal(false, 'Current spread should not be displayed in the RFS lit phase');
      });

      it('At the end of the DARK phase the RFS should transition to LIT phase', async () => {
        const expectPhaseLit = await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        expect(expectPhaseLit)
          .to
          .equal(true, 'RFS phase should be LIT');
      });
    });

    describe('In the LIT phase the RFS window should show', () => {
      it('DARK phase countdown timer should be 0', async () => {
        const darkTimer = await rfsWindow.getDarkCountDownTimer();
        expect(darkTimer)
          .to
          .equal('0:00', 'Dark Timer should be 0:00');
      });

      it('Activate trading user functionality should be disabled during the LIT phase', async () => {
        const addTraderBtnEnabled = await rfsWindow.btnActivateEnabled();
        expect(addTraderBtnEnabled)
          .to
          .equal(false, 'RFS Button ACTIVATE should not be enabled in LIT phase');

        const ddTrader = await rfsWindow.ddActivateUser;
        const dropDownEnabled = await ddTrader.getDropDownEnabled();
        expect(dropDownEnabled)
          .to
          .equal(false, 'RFS activate traders drop down list should be disabled in the LIT phase');
      });

      it('Dark spread should be shown', async () => {
        const darkSpread = await rfsWindow.getDarkSpread();
        const expectedSpread = (lpTraderOne.darkQuote.sellPrice - lpTraderOne.darkQuote.buyPrice).toString();
        expect(darkSpread)
          .to
          .equal(expectedSpread, 'RFS dark spread during LIT phase');
      });

      it('Current spread should be shown', async () => {
        const currentSpread = await rfsWindow.getCurrentSpread();
        const expectedSpread = (lpTraderOne.darkQuote.sellPrice - lpTraderOne.darkQuote.buyPrice).toString();
        expect(currentSpread)
          .to
          .equal(expectedSpread, 'RFS dark spread during LIT phase');
      });

      it('Current spread should be updated when a trader submits a new quote', async () => {
        await lpClientOne.rfsQuote(
          strategyId,
          lpTraderOne.litQuote.buyPrice,
          lpTraderOne.litQuote.sellPrice,
          lpTraderOne.litQuote.amount
        );

        const expectedLitSpread = (lpTraderOne.litQuote.sellPrice - lpTraderOne.litQuote.buyPrice).toString();
        await rfsWindow.waitUntilCurrentSpread(expectedLitSpread);
        const currentSpread = await rfsWindow.getCurrentSpread();
        expect(currentSpread)
          .to
          .equal(expectedLitSpread, 'RFS current spread');
      });

      it('At the end of LIT phase the RFS should transition to TRADING phase', async () => {
        const inTradingPhase = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
        expect(inTradingPhase)
          .to
          .equal(true, 'RFS should be in TRADING phase');
      });
    });

    describe('In the TRADING phase the RFS window should show', () => {
      it('DARK and LIT phase countdown timer should be 0', async () => {
        const darkTimer = await rfsWindow.getDarkCountDownTimer();
        const litTimer = await rfsWindow.getLitCountDownTimer();
        expect(darkTimer)
          .to
          .equal('0:00', 'RFS dark timer should be 0 during TRADING phase');
        expect(litTimer)
          .to
          .equal('0:00', 'RFS lit timer should be 0 during TRADING phase');
      });

      it('Activate trading user functionality should be enabled for trading phase', async () => {
        const btnActivateEnabled = await rfsWindow.btnActivateEnabled();
        expect(btnActivateEnabled)
          .to
          .equal(false, 'ACTIVATE trader button should be disabled');

        const activateUsersList = await rfsWindow.ddActivateUser;
        const selectEnabled = await activateUsersList.getDropDownEnabled();
        expect(selectEnabled)
          .to
          .equal(true, 'ACTIVATE user dropdown list should be enabled');
      });

      it('Trading user drop down list should contain users the broker has permissions to activate', async () => {
        const activateUserList = await rfsWindow.ddActivateUser;
        const coveredTraders = await activateUserList.getSelections();
        const expectedUsers = ['CEA - TR02', 'DEA - TR06', 'DEA - TR07'];
        expect(coveredTraders)
          .to
          .deep
          .equal(expectedUsers);
      });

      it('RFS window should show current market depth in a table', async () => {
        const quoteRsp = await lpClientOne.rfsQuote(
          strategyId,
          lpTraderOne.tradeQuoteOne.buyPrice,
          lpTraderOne.tradeQuoteOne.sellPrice,
          lpTraderOne.tradeQuoteOne.amount
        );

        expect(quoteRsp.response[0])
          .to
          .equal('successful', 'API lpClient one quote failed.');

        const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);

        await bidOfferRowOne.waitUntilPrice(
          lpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp)
            .toString(),
          lpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp)
            .toString(),
          null,
          null,
          frameworkConfig.shortTimeout
        );

        const askTrader = await bidOfferRowOne.getAskTrader();
        const askSize = await bidOfferRowOne.getAskSize();
        const askPrice = await bidOfferRowOne.getAskPrice();
        const bidSize = await bidOfferRowOne.getBidSize();
        const bidPrice = await bidOfferRowOne.getBidPrice();
        const bidTrader = await bidOfferRowOne.getBidTrader();

        expect(askTrader)
          .to
          .equal('', 'RFS trader information should not be displayed');
        expect(askSize)
          .to
          .equal(lpTraderOne.tradeQuoteOne.amount.toString(), 'RFS ask size');
        expect(askPrice)
          .to
          .equal(lpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp).toString(), 'RFS top of market ask');
        expect(bidTrader)
          .to
          .equal('', 'RFS trader information should not be displayed');
        expect(bidSize)
          .to
          .equal(lpTraderOne.tradeQuoteOne.amount.toString(), 'RFS bid size');
        expect(bidPrice)
          .to
          .equal(lpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp).toString(), 'RFS top of market bid');
      });
    });

    describe('In the TRADING phase of a RFS the broker should be able to', () => {
      let nlpTraderOneShortId = '';
      let nlpTraderTwoShortId = '';
      let nlpTraderThreeShortId = '';

      it('Activate NLP trading user nlpTraderOne', async () => {
        nlpTraderOneShortId = nlpTraderOne.leShortCode.concat(' - ', nlpTraderOne.userShortName);
        const activateUserDropDown = await rfsWindow.ddActivateUser;
        await activateUserDropDown.setSelected(nlpTraderOneShortId);
        const btnEnabled = await rfsWindow.btnActivateEnabled();

        expect(btnEnabled)
          .to
          .equal(true, 'Activate user button should be enabled');

        await rfsWindow.btnActivateClick();
        await rfsWindow.waitUntilActivatedTraderExists(nlpTraderOneShortId);
      });

      it('Activated traders should be removed from the Select Trading User drop down list', async () => {
        const activateUserList = await rfsWindow.ddActivateUser;
        const coveredTraders = await activateUserList.getSelections();
        const expectedUsers = ['DEA - TR06', 'DEA - TR07'];

        expect(coveredTraders)
          .to
          .deep
          .equal(expectedUsers);
      });

      it('Activated trading users should be added to the bottom of the broker rfs window', async () => {
        const activatedUser = await rfsWindow.getActivatedTrader(nlpTraderOneShortId);
        expect(activatedUser)
          .to
          .equal(nlpTraderOneShortId, 'RFS activated trader');

        const tooltip = await rfsWindow.getActivatedTraderToolTip(nlpTraderOneShortId);
        const expectedToolTip = nlpTraderOne
          .firstName.concat(
            ' ', nlpTraderOne.lastName,
            ' - ', nlpTraderOne.desk,
            ' - ', nlpTraderOne.legalEntity
          );

        expect(tooltip)
          .to
          .equal(expectedToolTip, 'RFS activated trader tooltip');
      });

      it('Should not be able to activate a nlp trader (nlpTrader3) who is not logged in', async () => {
        nlpTraderThreeShortId = nlpTraderThree.leShortCode.concat(' - ', nlpTraderThree.userShortName);
        const activateUserDropDown = await rfsWindow.ddActivateUser;
        await activateUserDropDown.setSelected(nlpTraderThreeShortId);
        const btnEnabled = await rfsWindow.btnActivateEnabled();

        expect(btnEnabled)
          .to
          .equal(true, 'Activate user button should be enabled');

        await rfsWindow.btnActivateClick();
        const traderNotLoggedInMsgFound = await rfsWindow.waitUntilTraderNotLoggedInMsg();

        expect(traderNotLoggedInMsgFound)
          .to
          .equal(true, 'Expected to find trader not logged in message');
      });

      it('Should be able to activate a nlp trader (nlpTrader3) after he logs in', async () => {
        await nlpClientThree.login();
        nlpTraderThreeShortId = nlpTraderThree.leShortCode.concat(' - ', nlpTraderThree.userShortName);
        const activateUserDropDown = await rfsWindow.ddActivateUser;
        await activateUserDropDown.setSelected(nlpTraderThreeShortId);
        const btnEnabled = await rfsWindow.btnActivateEnabled();
        expect(btnEnabled)
          .to
          .equal(true, 'Activate user button should be enabled');

        await rfsWindow.btnActivateClick();
        const userFound = await rfsWindow.waitUntilActivatedTraderExists(nlpTraderThreeShortId);
        expect(userFound)
          .to
          .equal(true, `RFS trader ${nlpTraderThreeShortId} should be added to the RFS`);
      });

      it('should be able to activate another nlp trader nlpTraderTwo', async () => {
        nlpTraderTwoShortId = nlpTraderTwo.leShortCode.concat(' - ', nlpTraderTwo.userShortName);
        const activateUserDropDown = await rfsWindow.ddActivateUser;
        await activateUserDropDown.setSelected(nlpTraderTwoShortId);
        const btnEnabled = await rfsWindow.btnActivateEnabled();
        expect(btnEnabled)
          .to
          .equal(true, 'Activate user button should be enabled');

        await rfsWindow.btnActivateClick();
        const userFound = await rfsWindow.waitUntilActivatedTraderExists(nlpTraderTwoShortId);
        expect(userFound)
          .to
          .equal(true, `RFS trader ${nlpTraderTwoShortId} should be added to the RFS`);
      });
    });

    describe('In the TRADING phase of the RFS broker should see the market depth table updated when a trader submits a quote', () => {
      it('Traders should submit quotes', async () => {
        await nlpClientOne.rfsQuote(
          strategyId,
          nlpTraderOne.tradeQuoteOne.buyPrice,
          nlpTraderOne.tradeQuoteOne.sellPrice,
          nlpTraderOne.tradeQuoteOne.amount
        );

        await nlpClientTwo.rfsQuote(
          strategyId,
          nlpTraderTwo.tradeQuoteOne.buyPrice,
          nlpTraderTwo.tradeQuoteOne.sellPrice,
          nlpTraderTwo.tradeQuoteOne.amount
        );
      });

      it('RFS quotes table will be update to display orders in top of market order', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        let bidPrice = await rowOne.getBidPrice();
        let bidSize = await rowOne.getBidSize();
        let bidTrader = await rowOne.getBidTrader();
        let askPrice = await rowOne.getAskPrice();
        let askSize = await rowOne.getAskSize();
        let askTrader = await rowOne.getAskTrader();

        expect(bidPrice)
          .to
          .equal(lpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp).toString());
        expect(bidSize)
          .to
          .equal(lpTraderOne.tradeQuoteOne.amount.toString());
        expect(bidTrader)
          .to
          .equal('');
        expect(askPrice)
          .to
          .equal(lpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp).toString());
        expect(askSize)
          .to
          .equal(lpTraderOne.tradeQuoteOne.amount.toString());
        expect(askTrader)
          .to
          .equal('');

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        await rowTwo.waitUntilPrice(
          nlpTraderTwo.tradeQuoteOne.buyPrice.toFixed(threeDp)
            .toString(),
          nlpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp)
            .toString()
        );

        bidPrice = await rowTwo.getBidPrice();
        bidSize = await rowTwo.getBidSize();
        bidTrader = await rowTwo.getBidTrader();
        askPrice = await rowTwo.getAskPrice();
        askSize = await rowTwo.getAskSize();
        askTrader = await rowTwo.getAskTrader();
        expect(bidPrice)
          .to
          .equal(nlpTraderTwo.tradeQuoteOne.buyPrice.toFixed(threeDp).toString());
        expect(bidSize)
          .to
          .equal(nlpTraderTwo.tradeQuoteOne.amount.toString());
        expect(bidTrader)
          .to
          .equal(nlpTraderTwo.userDisplayId);
        expect(askPrice)
          .to
          .equal(nlpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp).toString());
        expect(askSize)
          .to
          .equal(nlpTraderOne.tradeQuoteOne.amount.toString());
        expect(askTrader)
          .to
          .equal(nlpTraderOne.userDisplayId);

        // eslint-disable-next-line no-magic-numbers
        const rowThree = await rfsWindow.getBidOfferRow(3);
        await rowThree.waitUntilPrice(
          nlpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp)
            .toString(),
          nlpTraderTwo.tradeQuoteOne.sellPrice.toFixed(threeDp)
            .toString()
        );

        bidPrice = await rowThree.getBidPrice();
        bidSize = await rowThree.getBidSize();
        bidTrader = await rowThree.getBidTrader();
        askPrice = await rowThree.getAskPrice();
        askSize = await rowThree.getAskSize();
        askTrader = await rowThree.getAskTrader();

        expect(bidPrice)
          .to
          .equal(nlpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp).toString());
        expect(bidSize)
          .to
          .equal(nlpTraderOne.tradeQuoteOne.amount.toString());
        expect(bidTrader)
          .to
          .equal(nlpTraderOne.userDisplayId);
        expect(askPrice)
          .to
          .equal(nlpTraderTwo.tradeQuoteOne.sellPrice.toFixed(threeDp).toString());
        expect(askSize)
          .to
          .equal(nlpTraderTwo.tradeQuoteOne.amount.toString());
        expect(askTrader)
          .to
          .equal(nlpTraderTwo.userDisplayId);

        // eslint-disable-next-line no-magic-numbers
        const rowFour = await rfsWindow.getBidOfferRow(4);
        const isEmptyRow = await rowFour.isEmptyRow();
        expect(isEmptyRow)
          .to
          .equal(true, 'RFS quotes table should not contain quotes on the 4th row');
      });

      it('RFS quotes table should be updated when a trader submits a new quote', async () => {
        await nlpClientOne.rfsQuote(
          strategyId,
          nlpTraderOne.tradeQuoteTwo.buyPrice,
          nlpTraderOne.tradeQuoteTwo.sellPrice,
          nlpTraderOne.tradeQuoteTwo.amount
        );

        const rowOne = await rfsWindow.getBidOfferRow(1);
        await rowOne.waitUntilPrice(
          nlpTraderOne.tradeQuoteTwo.buyPrice.toFixed(threeDp)
            .toString(),
          nlpTraderOne.tradeQuoteTwo.sellPrice.toFixed(threeDp)
            .toString()
        );

        let bidPrice = await rowOne.getBidPrice();
        let bidSize = await rowOne.getBidSize();
        let bidTrader = await rowOne.getBidTrader();
        let askPrice = await rowOne.getAskPrice();
        let askSize = await rowOne.getAskSize();
        let askTrader = await rowOne.getAskTrader();

        expect(bidPrice).to.equal(nlpTraderOne.tradeQuoteTwo.buyPrice.toFixed(threeDp).toString());
        expect(bidSize).to.equal(nlpTraderOne.tradeQuoteTwo.amount.toString());
        expect(bidTrader).to.equal(nlpTraderOne.userDisplayId);
        expect(askPrice).to.equal(nlpTraderOne.tradeQuoteTwo.sellPrice.toFixed(threeDp).toString());
        expect(askSize).to.equal(nlpTraderOne.tradeQuoteTwo.amount.toString());
        expect(askTrader).to.equal(nlpTraderOne.userDisplayId);

        const rowTwo = await rfsWindow.getBidOfferRow(2);
        await rowTwo.waitUntilPrice(
          lpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp)
            .toString(),
          lpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp)
            .toString()
        );

        bidPrice = await rowTwo.getBidPrice();
        bidSize = await rowTwo.getBidSize();
        bidTrader = await rowTwo.getBidTrader();
        askPrice = await rowTwo.getAskPrice();
        askSize = await rowTwo.getAskSize();
        askTrader = await rowTwo.getAskTrader();

        expect(bidPrice).to.equal(lpTraderOne.tradeQuoteOne.buyPrice.toFixed(threeDp).toString());
        expect(bidSize).to.equal(lpTraderOne.tradeQuoteOne.amount.toString());
        expect(bidTrader).to.equal('');
        expect(askPrice).to.equal(lpTraderOne.tradeQuoteOne.sellPrice.toFixed(threeDp).toString());
        expect(askSize).to.equal(lpTraderOne.tradeQuoteOne.amount.toString());
        expect(askTrader).to.equal('');

        // eslint-disable-next-line no-magic-numbers
        const rowThree = await rfsWindow.getBidOfferRow(3);
        await rowThree.waitUntilPrice(
          nlpTraderTwo.tradeQuoteOne.buyPrice.toFixed(threeDp)
            .toString(),
          nlpTraderTwo.tradeQuoteOne.sellPrice.toFixed(threeDp)
            .toString()
        );

        bidPrice = await rowThree.getBidPrice();
        bidSize = await rowThree.getBidSize();
        bidTrader = await rowThree.getBidTrader();
        askPrice = await rowThree.getAskPrice();
        askSize = await rowThree.getAskSize();
        askTrader = await rowThree.getAskTrader();

        expect(bidPrice).to.equal(nlpTraderTwo.tradeQuoteOne.buyPrice.toFixed(threeDp).toString());
        expect(bidSize).to.equal(nlpTraderTwo.tradeQuoteOne.amount.toString());
        expect(bidTrader).to.equal(nlpTraderTwo.userDisplayId);
        expect(askPrice).to.equal(nlpTraderTwo.tradeQuoteOne.sellPrice.toFixed(threeDp).toString());
        expect(askSize).to.equal(nlpTraderTwo.tradeQuoteOne.amount.toString());
        expect(askTrader).to.equal(nlpTraderTwo.userDisplayId);

        // eslint-disable-next-line no-magic-numbers
        const rowFour = await rfsWindow.getBidOfferRow(4);
        const isEmptyRow = await rowFour.isEmptyRow();
        expect(isEmptyRow).to.equal(true, 'RFS quotes table should not contain quotes on the 4th row');
      });

      it('RFS quotes table should show priority bid price for lpTraderOne', async () => {
        const response = await lpClientOne.rfsQuote(
          strategyId,
          lpTraderOne.tradeQuoteTwo.buyPrice,
          lpTraderOne.tradeQuoteTwo.sellPrice,
          lpTraderOne.tradeQuoteTwo.amount
        );

        const rowOne = await rfsWindow.getBidOfferRow(1);
        const rowOneCellBidValue = lpTraderOne.tradeQuoteTwo.buyPrice
          .toFixed(threeDp)
          .toString()
          .concat('\n*');

        await rowOne.waitUntilPrice(
          rowOneCellBidValue,
          lpTraderOne.tradeQuoteTwo.sellPrice.toFixed(threeDp)
            .toString()
        );

        const bidPrice = await rowOne.getBidPrice();
        const askPrice = await rowOne.getAskPrice();
        expect(bidPrice).to.equal(rowOneCellBidValue);
        expect(askPrice).to.equal(lpTraderOne.tradeQuoteTwo.sellPrice.toFixed(threeDp).toString());

        const priorityActive = await rfsWindow.waitUntilPriorityActive();
        expect(priorityActive).to.equal(true, 'RFS window PRIORITY should be active');

        const priorityInactive = await rfsWindow.waitUntilPriorityInactive();
        expect(priorityInactive).to.equal(true, 'RFS window PRIORITY should be inactive');
      });

      it('RFS quotes table should show priority ask price for nlpTraderOne', async () => {
        const response = await nlpClientOne.rfsQuote(
          strategyId,
          nlpTraderOne.tradeQuoteThree.buyPrice,
          nlpTraderOne.tradeQuoteThree.sellPrice,
          nlpTraderOne.tradeQuoteThree.amount
        );

        const askPricePriorityCell = nlpTraderOne
          .tradeQuoteThree
          .sellPrice
          .toFixed(threeDp)
          .toString()
          .concat('\n*');

        const rowOne = await rfsWindow.getBidOfferRow(1);

        await rowOne.waitUntilPrice(
          nlpTraderOne.tradeQuoteThree.buyPrice.toFixed(threeDp)
            .toString(),
          askPricePriorityCell
        );
        const bidPrice = await rowOne.getBidPrice();
        const askPrice = await rowOne.getAskPrice();

        expect(bidPrice)
          .to
          .equal(nlpTraderOne.tradeQuoteThree.buyPrice.toFixed(threeDp).toString());
        expect(askPrice)
          .to
          .equal(askPricePriorityCell);
      });
    });

    describe('In the TRADING phase when a order is matched the broker should see a RFS summary', () => {
      it('LP Trader summits a new quote that matches an NLP trader quote', async () => {
        const quoteMsg = await lpClientOne.rfsQuote(
          strategyId,
          lpTraderOne.tradeQuoteThree.buyPrice,
          lpTraderOne.tradeQuoteThree.sellPrice,
          lpTraderOne.tradeQuoteThree.amount
        );

        expect(quoteMsg.response[0])
          .to
          .equal('successful', 'API user failed to quote');
      });

      it('Summary window should display message "RFS Matches have occurred."', async () => {
        const matchesFound = await rfsWindow.waitUntilRfsMatchesHaveOccurred();
        expect(matchesFound)
          .to
          .equal(true, 'RFS matches should of occurred');
      });

      it('Summary window should display total amount matched', async () => {
        const totalMatchedInRFS = await rfsWindow.getSummaryTotalMatchedInRFS();
        const amountMatched = lpTraderOne
          .tradeQuoteThree
          .amount
          .toString()
          .concat(' L');

        expect(totalMatchedInRFS)
          .to
          .equal(amountMatched, 'RFS summary - Total Amount Matched in RFS');
      });
    });

    describe('Broker should see the RFS has transitioned to a VC', () => {
      // Need to double check this behaviour and fix test accordingly
      it('Broker should see pink VC status against the strategy in the Market View', async () => {
        await mainPageFrame.switchToWindow();
        await strategyRow.waitUntilStatus('VC');
        const status = await strategyRow.getStatusText();
        expect(status)
          .to
          .equal('VC', 'Market View strategy row status');

        const statusInactive = await strategyRow.statusHasInactiveFlag();
        expect(statusInactive)
          .to
          .equal(false, 'Market View strategy status should be active \'Pink\'');
      });

      it('Broker should not be able to participate in the VC', async () => {
        await strategyRow.clickStatus();
        const vcWindow = new VolumeClearing(context);
        const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
        expect(foundWindow)
          .to
          .equal(false, 'VC window should not be open');
      });

      it('Users should logout', async () => {
        await nlpClientOne.logout();
        await nlpClientTwo.logout();
        await nlpClientThree.logout();
        await lpClientOne.logout();
      });
    });
  });
});
