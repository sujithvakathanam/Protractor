/* eslint-disable no-magic-numbers */
import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {expect} from 'chai';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import ApiClient from '../../utilities/api/ApiClient';
import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';

import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';


describe('BC2700 Tidy up of Obo Broker', function bc2700EndToEndTest () {
  const browser = global.browser;
  const decimalPlaces = 3;
  let bootstrapper = null;
  let context = null;

  let mainPageFrame = null;
  let common = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2700 TC003: As a broker I should not be able to see the trader who owns an order in the Market Depth view', () => {
    let broker = null;
    let lpTrader = null;
    let lpTraderApi = null;
    let nlpTrader = null;
    let nlpTraderApi = null;
    let rfsWindow = null;

    let lpAskPrice = null;
    let lpBidPrice = null;
    const lpTradeSize = 2500;

    let nlpAskPrice = null;
    let nlpBidPrice = null;
    const nlpTradeSize = 3000;

    let strategyId = null;
    let strategyRow = null;
    let strategyFound = false;

    /* eslint-disable */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ironFly, STYLE.euro, 3700, 8, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 2100, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 2200, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2200, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 2300, 1);

    it('Users should login', async () => {
      broker = common.getUser('AUTBR07');
      lpTrader = common.getUser('AUTTR04');
      nlpTrader = common.getUser('AUTTR11');

      lpTraderApi = new ApiClient(lpTrader);
      nlpTraderApi = new ApiClient(nlpTrader);
      await start(broker);
      await lpTraderApi.login();
      await nlpTraderApi.login();

      const loggedInUser = await mainPageFrame.getUsername();
      expect(loggedInUser).to.equal(broker.fenicsGoUsername, 'Logged in username');
    });

    it('I should have a strategy to trade', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('I should initiate an RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      await mainPageFrame.clickMarketViewHeader();
      strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
        .getTableRow(strategy);
      await strategyRow.clickStatus();
      logger.info('Found newly created strategy in Market View.');

      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();
      logger.info('Clicked request for quotes.');
      await lpTraderApi.respondToRFS(strategyId);
      await nlpTraderApi.respondToRFS(strategyId);
    });

    it('I should see RFS notification for the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      // Get the notification
      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const rfsNotification = await notifications.getRfsResponderInvite(strategy);
      logger.info('Getting notification alerts.');

      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found)
        .to
        .equal(true, 'Expected to find RFS responder notification message');
    });

    it('I should see RFS Toast notification for the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const rfsNotification = await notifications.getRfsResponderInvite(strategy);
      logger.info('Getting notification alerts.');

      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found)
        .to
        .equal(true, 'Expected to find RFS responder notification message');
    });

    it('I should see Blue RFS label against the strategy in the market view', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      const actualStatus = await strategyRow.getStatusText();
      const expectedStatus = 'RFS';
      expect(actualStatus)
        .to
        .equal(expectedStatus, 'Expected the strategy status to be RFS'
      );

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
    });

    it('I should see RFS initiator window open', async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');
    });

    it('LP Trader should quote', async () => {
      expect(strategyFound).to.equal(true, 'Strategy should be found');
      let midPrice = 0;

      await browser.waitUntil(async () => {
        midPrice = await lpTraderApi.getStrategyMidPrice(strategyId);


        return midPrice !== null;
      }, frameworkConfig.shortTimeout
        , `Timed out after ${frameworkConfig.shortTimeout} strategy mid price could not be found`);

      midPrice = midPrice.toFixed(0);
      lpBidPrice = (Number(midPrice) + 1).toFixed(decimalPlaces);
      // eslint-disable-next-line no-magic-numbers
      lpAskPrice = (Number(midPrice) + 2.5).toFixed(decimalPlaces);
      nlpBidPrice = (Number(midPrice) - 1).toFixed(decimalPlaces);
      nlpAskPrice = (Number(midPrice) + 2).toFixed(decimalPlaces);

      const quotedMsg = await lpTraderApi.rfsQuote(strategyId, lpBidPrice, lpAskPrice, lpTradeSize);
      expect(quotedMsg.response[0])
        .to
        .equal('successful', 'LP should quote');

      logger.log(`LP user quoted bid:${lpBidPrice} ask:${lpAskPrice} size:${lpTradeSize}`);
    });

    it('I should activate the NLP trader', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const trading = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(trading)
        .to
        .equal(true, `RFS should be in trading phase, actual phase is ${phase}`);

      const nlpTraderShortId = nlpTrader.leShortCode.concat(' - ', nlpTrader.userShortName);
      const activateUserDropDown = await rfsWindow.ddActivateUser;
      await activateUserDropDown.setSelected(nlpTraderShortId);
      await rfsWindow.btnActivateClick();
    });

    it('NLP trader should quote', async () => {
      // eslint-disable-next-line no-return-await
      await browser.waitUntil(() => nlpTraderApi.userActivated(strategyId),
        frameworkConfig.shortTimeout,
        `Timed out after ${frameworkConfig.shortTimeout} API nlp trader did not receive activation message`);

      const quotedMsg = await nlpTraderApi.rfsQuote(strategyId, nlpBidPrice, nlpAskPrice, nlpTradeSize);
      expect(quotedMsg.response[0])
        .to
        .equal('successful', 'LP should quote');

      logger.log(`NLP user quoted bid:${nlpBidPrice} ask:${nlpAskPrice} size:${nlpTradeSize}`);
    });

    it('I should wait for the RFS to come to an end', async () => {
      const rfsTimeout = frameworkConfig.litPhaseTimeout + frameworkConfig.tradePhaseTimeout + frameworkConfig.shortTimeout;
      const timedOutMsg = await rfsWindow.waitUntilRfsTimedout(rfsTimeout);
      expect(timedOutMsg)
        .to
        .equal(true, 'Expected to find RFS timed out message');
    });

    it('I should see traders quote moved into the market depth view', async () => {
      await mainPageFrame.switchToWindow();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const lpDisplayedTradeSize = lpTradeSize.toString();
      const nlpDisplayedTradeSize = nlpTradeSize.toString();
      await browser.pause(frameworkConfig.veryShortTimeout);

      const askOne = await marketDepth.getAskByRow(1);
      expect(askOne.ask)
        .to
        .equal(nlpAskPrice.toString(), 'Market Depth row 1 ask');
      expect(askOne.size)
        .to
        .equal(nlpDisplayedTradeSize, 'Market Depth row 1 ask size');

      const askTwo = await marketDepth.getAskByRow(2);
      expect(askTwo.ask)
        .to
        .equal(lpAskPrice, 'Market Depth row 2 ask');
      expect(askTwo.size)
        .to
        .equal(lpDisplayedTradeSize, 'Market Depth row 1 ask size');

      const bidOne = await marketDepth.getBidByRow(1);
      expect(bidOne.bid)
        .to
        .equal(lpBidPrice.toString(), 'Market Depth row 1 bid');
      expect(bidOne.size)
        .to
        .equal(lpDisplayedTradeSize, 'Market Depth row 1 bid size');

      const bidTwo = await marketDepth.getBidByRow(2);
      expect(bidTwo.bid)
        .to
        .equal(nlpBidPrice.toString(), 'Market Depth row 2 ask');
      expect(bidTwo.size)
        .to
        .equal(nlpDisplayedTradeSize, 'Market Depth row 1 ask size');
    });

    it('I should not see buy or sell buttons when i hover over the ask and bid prices', async () => {
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const clickedBuy = await marketDepth.clickBuy(null, null, null);
      expect(clickedBuy)
        .to
        .equal(false, 'BUY button on market view exists when it should not');

      const clickedSell = await marketDepth.clickSell(null, null, null);
      expect(clickedSell)
        .to
        .equal(false, 'BUY button on market view exists when it should not');
    });

    it('I should not be able to see who owns the order in the market view', async () => {
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const foundNlpTrader = await marketDepth.textExistsInMarketDepthTable('TR11');
      const foundLpTrader = await marketDepth.textExistsInMarketDepthTable('TR04');

      expect(foundNlpTrader)
        .to
        .equal(false, 'Broker can see the trader in the Market Depth table in the Market View, he should not be able to see trader');
      expect(foundLpTrader)
        .to
        .equal(false, 'Broker can see the trader in the Market Depth table in the Market View, he should not be able to see trader');
    });

    it('Users should logout', async () => {
      await nlpTraderApi.logout();
      await lpTraderApi.logout();
    });
  });
});
