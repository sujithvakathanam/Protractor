import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {expect} from 'chai';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import ApiClient from '../../utilities/api/ApiClient';
import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import MarketViewTabs from '../../constant/MarketViewTabs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import Formatter from '../../lib/Formatter';

describe('BC2700 Tidy up of Obo Broker', function bc2700EndToEndTest () {
  const browser = global.browser;
  const decimalPlaces = 3;
  const defaultMidPrice = 100;
  let bootstrapper = null;
  let context = null;

  let mainPageFrame = null;
  let common = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2700 TC004: As a trader I should not see broker in the Matched Trades view and I should not see broker in the Trade Info popup and I should not see broker in the Market Depth view', () => {
    let broker = null;
    let lpTrader = null;
    let brokerApi = null;
    let nlpTrader = null;
    let nlpTraderApi = null;
    let rfsWindow = null;
    let vcWindow = null;

    let lpAskPrice = null;
    let lpBidPrice = null;
    const lpTradeSize = 2500;

    let nlpAskPrice = null;
    let nlpBidPrice = null;
    const nlpTradeSize = 3000;

    let strategyId = null;
    let strategyRow = null;
    let strategyFound = false;

    /* eslint-disable */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3700, 7, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2100, 1);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 2200, 1.5);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2500, 1);
    /* eslint-enable */

    it('Broker should have a strategy to trade', async () => {
      broker = common.getUser('AUTBR07');
      await start(broker);
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('User should login', async () => {
      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);

      lpTrader = common.getUser('AUTTR04');
      nlpTrader = common.getUser('AUTTR11');

      brokerApi = new ApiClient(broker);
      nlpTraderApi = new ApiClient(nlpTrader);
      const clearDownScript = await require.resolve(join('../../', frameworkConfig.clearDownScript));
      await shellExec(clearDownScript);
      await browser.reload();
      await start(lpTrader);

      await brokerApi.login();
      await nlpTraderApi.login();

      const loggedInUser = await mainPageFrame.getUsername();
      expect(loggedInUser)
        .to
        .equal(lpTrader.fenicsGoUsername, 'Logged in username');
    });

    it('Broker should initiate an RFS on the strategy', async () => {
      await brokerApi.initiateRFS(strategyId);
      await nlpTraderApi.respondToRFS(strategyId);
    });

    it('I should see RFS notification for the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      // Get the notification
      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const rfsNotification = await notifications.getRfsResponderInvite(strategy);
      logger.info('Getting notification alerts.');

      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found)
        .to
        .equal(true, 'Expected to find RFS responder notification message');
    });

    it('I should see RFS Toast notification for the strategy', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const rfsNotification = await notifications.getRfsResponderInvite(strategy);
      logger.info('Getting notification alerts.');

      const found = await rfsNotification.waitForExist(frameworkConfig.shortTimeout);
      expect(found)
        .to
        .equal(true, 'Expected to find RFS responder notification message');
    });

    it('I should see Blue RFS label against the strategy in the market view', async () => {
      strategyFound = await common.waitUntilStrategyFound(strategy, frameworkConfig.shortTimeout, MarketViewTabs.EUROSTOXX);

      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      const marketView = mainPageFrame.getMarketViewTab();
      const euroStoxx = marketView.getTable();
      strategyRow = await euroStoxx.getTableRow(strategy);
      await strategyRow.clickStatus();
      const actualStatus = await strategyRow.getStatusText();
      const expectedStatus = 'RFS';

      expect(actualStatus)
        .to
        .equal(expectedStatus, 'Expected the strategy status to be RFS');

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
    });

    it('I should see RFS responder window open', async () => {
      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('R', 'Expected RFS window letter to be R');
    });

    it('I should respond to the RFS and provide a quote', async () => {
      const lpAskPriceOffSet = 2.5;
      const lpBidPriceOffset = 1;
      const nlpBidPriceOffset = 1;
      const nlpAskPriceOffset = 2;

      expect(strategyFound)
        .to
        .equal(true, 'Strategy should be found');

      let midPrice = 0;
      await browser.waitUntil(async () => {
        midPrice = await brokerApi.getStrategyMidPrice(strategyId);

        return midPrice !== null;
      }, frameworkConfig.shortTimeout);

      if (!midPrice) {
        midPrice = defaultMidPrice;
      }

      midPrice = midPrice.toFixed(0);
      lpBidPrice = (Number(midPrice) + lpBidPriceOffset).toFixed(decimalPlaces);
      lpAskPrice = (Number(midPrice) + lpAskPriceOffSet).toFixed(decimalPlaces);
      nlpBidPrice = (Number(midPrice) - nlpBidPriceOffset).toFixed(decimalPlaces);
      nlpAskPrice = (Number(midPrice) + nlpAskPriceOffset).toFixed(decimalPlaces);

      await rfsWindow.quote(lpBidPrice, lpAskPrice, lpTradeSize);
    });

    it('broker should activate the NLP user in the trading phase of the RFS', async () => {
      const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout + frameworkConfig.shortTimeout;

      await browser.waitUntil(
        async () => {
          const phase = await brokerApi.getRfsPhase(strategyId);

          return phase === 'TRADING';
        },
        timeout
      );

      await brokerApi.rfsSelectTrader(strategyId, nlpTrader.userShortName);
    });

    it('NLP user should make an offer', async () => {
      await browser.waitUntil(() => nlpTraderApi.userActivated(strategyId), frameworkConfig.shortTimeout);

      const quotedMsg = await nlpTraderApi.rfsQuote(strategyId, nlpBidPrice, nlpAskPrice, nlpTradeSize);
      expect(quotedMsg.response[0])
        .to
        .equal('successful', 'LP should quote');

      logger.log(`NLP user quoted bid:${nlpBidPrice} ask:${nlpAskPrice} size:${nlpTradeSize}`);
    });

    it('I wait for the RFS to timeout', async () => {
      const rfsTimedOut = await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
      expect(rfsTimedOut)
        .to
        .equal(true, 'RFS should displayed timed out message.');
    });

    it('I should see all offers in the market depth in the market view for the strategy', async () => {
      await mainPageFrame.switchToWindow();
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const lpDisplayedTradeSize = lpTradeSize.toString();
      const nlpDisplayedTradeSize = nlpTradeSize.toString();

      await browser.waitUntil(
        async () => {
          const askOne = await marketDepth.getAskByRow(1);
          const askTwo = await marketDepth.getAskByRow(2);

          return askOne.ask === nlpAskPrice.toString() && askTwo.ask === lpAskPrice.toString();
        },
        frameworkConfig.shortTimeout
      );

      const askOne = await marketDepth.getAskByRow(1);
      expect(askOne.ask)
        .to
        .equal(nlpAskPrice.toString(), 'Market Depth row 1 ask');
      expect(askOne.size)
        .to
        .equal(nlpDisplayedTradeSize, 'Market Depth row 1 ask size');

      const askTwo = await marketDepth.getAskByRow(2);
      expect(askTwo.ask)
        .to
        .equal(lpAskPrice, 'Market Depth row 2 ask');
      expect(askTwo.size)
        .to
        .equal(lpDisplayedTradeSize, 'Market Depth row 1 ask size');

      const bidOne = await marketDepth.getBidByRow(1);
      expect(bidOne.bid)
        .to
        .equal(lpBidPrice.toString(), 'Market Depth row 1 bid');
      expect(bidOne.size)
        .to
        .equal(lpDisplayedTradeSize, 'Market Depth row 1 bid size');

      const bidTwo = await marketDepth.getBidByRow(2);
      expect(bidTwo.bid)
        .to
        .equal(nlpBidPrice.toString(), 'Market Depth row 2 ask');
      expect(bidTwo.size)
        .to
        .equal(nlpDisplayedTradeSize, 'Market Depth row 1 ask size');
    });

    it('I should not be able to see the broker or traders on the offers in the market view', async () => {
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const foundNlpTrader = await marketDepth.textExistsInMarketDepthTable(nlpTrader.shortName);
      const foundLpTrader = await marketDepth.textExistsInMarketDepthTable(lpTrader.shortName);
      const foundBroker = await marketDepth.textExistsInMarketDepthTable(broker.shortName);

      expect(foundNlpTrader)
        .to
        .equal(false, 'Trader can see the trader in the Market Depth table in the Market View, he should not be able to see trader');
      expect(foundLpTrader)
        .to
        .equal(false, 'Trader can see the trader in the Market Depth table in the Market View, he should not be able to see trader');
      expect(foundBroker)
        .to
        .equal(false, 'Trader can see the broker in the Market Depth table in the Market View, he should not be able to see trader');
    });

    it('I should be able to click BUY on the offer in the market view', async () => {
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const buyClicked = await marketDepth.clickBuy(null, null, 1);
      expect(buyClicked)
        .to
        .equal(true, 'Buy button was not found in the market depth for the strategy');
    });

    it('I should execute the trade in the order book', async () => {
      const orderBook = mainPageFrame.getMarketViewTab().getOrderBook();
      const askPrice = await orderBook.getBidPrice();

      const pricesMatch = Formatter.fmtPrice(askPrice) === nlpAskPrice;

      expect(pricesMatch)
        .to
        .equal(true, `Order book ask price ${askPrice} does not match expected ask price ${nlpAskPrice}`);

      await orderBook.enterBidSize(nlpTradeSize);
      await orderBook.btnSubmitClick();
    });

    it('I should see VC status against the strategy in the market view', async () => {
      const statusIsVc = await strategyRow.waitUntilStatus('VC', frameworkConfig.shortTimeout);
      const status = await strategyRow.getStatusText();
      expect(statusIsVc)
        .to
        .equal(true, `Strategy Status expected "VC" actual "${status}"`);

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.VC_COLOR);
    });

    it('I should see the VC Window open when I click on the strategy', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      expect(foundWindow)
        .to
        .equal(true, 'Expected to find the VC window');
    });

    it('I should see a summary page at the end of the VC', async () => {
      await vcWindow.waitForSummary();
      const vcTotalBought = await vcWindow.getSummaryTotalBought();
      const vcTotalSold = await vcWindow.getSummaryTotalSold();
      const vcTotalMatched = await vcWindow.getSummaryTotalMatched();
      expect(vcTotalBought)
        .to
        .equal(nlpTradeSize.toString(), 'VC My Total Bought Amount');
      expect(vcTotalSold)
        .to
        .equal('0', 'VC My Total Sold Amount');
      expect(vcTotalMatched)
        .to
        .equal(nlpTradeSize.toString(), 'VC Total Amount Matched');
    });

    it('I should see Trade entry in the matched trades view', async () => {
      await mainPageFrame.switchToWindow();
      await mainPageFrame.clickMatchedTradesHeader();
      const matchedTradesTab = mainPageFrame.getMatchedTradesTab();
      const tradesTable = await matchedTradesTab.clickMyTradesTab();
      const tradeRow = await tradesTable.getTradeWhenDisplayed(strategy, 'BUY', nlpTradeSize, nlpAskPrice);
      expect(tradeRow)
        .not
        .equal(null, 'Trade could not be found in My Trades Tab');

      const tradeDetailsPopup = await tradeRow.clickOnTrade();
      const traderName = await tradeDetailsPopup.getTrader();
      const foundTrader = traderName.includes(lpTrader.userShortName);
      expect(foundTrader)
        .to
        .equal(true, 'Trader name was not found for the trade');
    });

    it('Users should logout', async () => {
      await brokerApi.logout();
      await nlpTraderApi.logout();
    });
  });
});
