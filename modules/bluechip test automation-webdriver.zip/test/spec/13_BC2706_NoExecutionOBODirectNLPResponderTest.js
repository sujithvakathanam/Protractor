import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import TestCommons from '../../lib/TestCommons';
import Rfs from '../../pages/child_windows/Rfs';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import {expect} from 'chai';
import Strategy from '../../lib/Strategy';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import MarketViewTabs from '../../constant/MarketViewTabs';
import ApiClient from '../../utilities/api/ApiClient';


describe('BC2706 NLP user DIRECT RFS participation rules', function BC2706Test () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;
  let toastNotification = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser)
      .to
      .exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });


  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    toastNotification = new ToastNotification(context);
  }

  // As a NLP trader, when a RFS is launched in a market segment I am permissioned for then I should be invited to the RFS
  describe('BC2706 TC001: As a NLP trader, I should be able to respond to a DIRECT RFS', () => {
    let nlpTrader1 = {};
    let nlpTrader2 = {};
    let lpTrader3 = {};
    let nlpTrader1Client = null;
    let lpTrader3Client = null;
    let marketView = null;
    let strategyId = 0;
    let rfsWindow = null;
    let strategyRow = null;
    const refPrice = 221;
    const delta = 15;
    const strike1 = 700;

    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, refPrice, delta, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', strike1, null);
    strategy.addLeg(null, null, 'DEC26', null, null);
    /* eslint-enable no-magic-numbers */

    it('Setup', async () => {
      nlpTrader1 = await common.getTrader('AUTTR02');
      nlpTrader2 = await common.getTrader('AUTTR06');
      lpTrader3 = await common.getTrader('AUTTR08');
    });

    it('The trader should have a strategy to trade', async () => {
      await start(nlpTrader1);
      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmitClick();
        const foundStrategy = await common.waitUntilStrategyFound(strategy)

        expect(foundStrategy)
          .to
          .be
          .true;

        strategyId = await common.getStrategyId(strategy);
      }
    });

    it('The strategy should be tradeable', async () => {
      await mainPageFrame.clickMarketViewHeader();
      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await marketView.getTable().getTableRow(strategy);
      const isTradable = await strategyRow.isStrategyTradable();

      expect(isTradable)
        .to
        .be
        .true;
    });

    it('Initiating trader (API Client) and recipient traders (NLP - UI, LP - API) should log in', async () => {
      await start(nlpTrader2);
      await mainPageFrame.clickMarketViewHeader();
      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);

      nlpTrader1Client = new ApiClient(nlpTrader1);
      await nlpTrader1Client.login();

      lpTrader3Client = new ApiClient(lpTrader3);
      await lpTrader3Client.login();
    });

    it('NLP nlpTrader1 initiates an RFS', async () => {
      await nlpTrader1Client.initiateRFS(strategyId);
      await lpTrader3Client.respondToRFS(strategyId);
    });

    describe('When the DIRECT RFS is initiated another NLP trader should get notifications', () => {
      it('Market view should show a blue RFS label against the strategy being traded', async () => {
        const strategyFound = await common.waitUntilStrategyFound(strategy);
        expect(strategyFound)
          .to
          .be
          .true;

        strategyRow = await marketView.getTable().getTableRow(strategy);
        await strategyRow.waitUntilStatus('RFS', frameworkConfig.mediumTimeout);
        const strategyStatus = await strategyRow.getStatusText();

        expect(strategyStatus)
          .to
          .equal('RFS');
      });

      it('NLP user should receive a toast message for the RFS', async () => {
        const rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);

        expect(rfsToastMsgs.length)
          .to
          .not
          .equal(0, 'Trader should see RFS toast messages');
      });

      it('NLP user should receive an alert for the RFS', async () => {
        const notification = await mainPageFrame.notificationsPanel.notifications.getRfsResponderInvite(strategy);
        const notificationFound = await notification.waitForExist();

        expect(notificationFound)
          .to
          .equal(true);
      });

      it('Clicking on the toast notification should open the RFS Window', async () => {
        const rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);
        await rfsToastMsgs[0].click();

        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });
    });

    describe('NLP user DIRECT RFS window should initially show', () => {
      it('RFS window should be in DARK phase', async () => {
        const phase = await rfsWindow.getPhase();

        expect(phase)
          .to
          .equal('DARK', 'Expected RFS phase to be in dark phase');
      });

      it('LP trader should respond to the RFS and quote during DARK phase', async () => {
        await lpTrader3Client.rfsQuote(strategyId, 100, 105, 2500);
      });

      it('RFS should display message "Book building in progress"', async () => {
        const bookBuildingMessage = await rfsWindow.bookBuildingMessageExists();

        expect(bookBuildingMessage)
          .to
          .equal(true, 'Expected to find Book Building Message in the RFS window');
      });

      it('RFS should not display spread information', async () => {
        const currentSpreadShown = await rfsWindow.currentSpreadExists();
        const darkSpreadShown = await rfsWindow.darkSpreadExists();

        expect(currentSpreadShown)
          .to
          .equal(false, 'Current spread should not be displayed');

        expect(darkSpreadShown)
          .to
          .equal(false, 'Dark spread should not be displayed');
      });

      it('RFS bid, ask and size fields should be disabled', async () => {
        const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
        expect(submitBtnEnabled)
          .to
          .equal(false, 'RFS submit button should be disabled from NLP user during dark period of Direct RFS');

        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(false, 'Enter bid field should be disabled from NLP user during dark period of Direct RFS');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(false, 'Enter ask field should be disabled from NLP user during dark period of Direct RFS');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(false, 'Enter size field should be disabled from NLP user during dark period of Direct RFS');

        const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
        expect(subjectBtnEnabled)
          .to
          .equal(false, 'Subject button should be disabled from NLP user during dark period of Direct RFS');
      });

      it('RFS window should transition to LIT phase', async () => {
        await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        const phase = await rfsWindow.getPhase();

        expect(phase)
          .to
          .equal('LIT', 'RFS should be in LIT PHASE');
      });
    });

    describe('When the window when the DIRECT RFS transitions to the LIT phase', () => {
      it('RFS window DARK phase timer should be zero', async () => {
        const darkTimer = await rfsWindow.getDarkCountDownTimer();

        expect(darkTimer)
          .to
          .equal('0:00', 'Expected dark count down time to be zero in lit phase of RFS');
      });

      it('RFS window should show Current Spread and Dark Spread', async () => {
        const currentSpread = await rfsWindow.getCurrentSpread();
        const darkSpread = await rfsWindow.getDarkSpread();

        expect(currentSpread)
          .to
          .equal('5.00', 'Current Spread unexpected value');

        expect(darkSpread)
          .to
          .equal('5.00', 'Dark Spread unexpected value');
      });

      it('RFS window should still show message  "Book building in progress"', async () => {
        const bookBuildingMessage = await rfsWindow.bookBuildingMessageExists();

        expect(bookBuildingMessage)
          .to
          .equal(true, 'Expected to find Book Building Message in the RFS window');
      });

      it('RFS window all fields should still be disabled', async () => {
        const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
        expect(submitBtnEnabled)
          .to
          .equal(false, 'RFS submit button should be disabled from NLP user during lit period of Direct RFS');

        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(false, 'Enter bid field should be disabled from NLP user during lit period of Direct RFS');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(false, 'Enter ask field should be disabled from NLP user during lit period of Direct RFS');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(false, 'Enter size field should be disabled from NLP user during lit period of Direct RFS');

        const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
        expect(subjectBtnEnabled)
          .to
          .equal(false, 'Subject button should be disabled from NLP user during lit period of Direct RFS');
      });

      it('RFS window should transition to TRADING phase', async () => {
        await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);

        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('TRADING', 'RFS should be in TRADING PHASE');
      });
    });

    describe('When the DIRECT RFS transitions to the TRADING phase', () => {
      it('RFS window LIT and DARK phase timers should be zero', async () => {
        const darkTimer = await rfsWindow.getDarkCountDownTimer();
        expect(darkTimer)
          .to
          .equal('0:00', 'Expected dark count down time to be zero in trading phase of RFS');

        const litTimer = await rfsWindow.getLitCountDownTimer();
        expect(litTimer)
          .to
          .equal('0:00', 'Expected lit count down time to be zero in trading phase of RFS');
      });

      it('RFS window should show Enter Bid, Ask and Size fields have been enabled', async () => {
        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(true, 'Enter bid field should be enabled for NLP user during trading period of Direct RFS');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(true, 'Enter ask field should be enabled for NLP user during trading period of Direct RFS');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(true, 'Enter size field should be enabled for NLP user during trading period of Direct RFS');
      });

      it('NLP user should see best bid and ask price but should not see trade size', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const askPrice = await rowOne.getAskPrice();
        const askSize = await rowOne.getAskSize();
        const bidPrice = await rowOne.getBidPrice();
        const bidSize = await rowOne.getBidSize();

        expect(askPrice)
          .to
          .equal('105.000', 'RFS offers table showed unexpected ask price');

        expect(askSize)
          .to
          .equal('', 'RFS offers table showed unexpected ask size');

        expect(bidPrice)
          .to
          .equal('100.000', 'RFS offers table showed unexpected bid price');

        expect(bidSize)
          .to
          .equal('', 'RFS offers table showed unexpected bid size');
      });

      it('NLP user should be able to enter a quote', async () => {
        await rfsWindow.quote(101, null, 3000);
        const myBidDisplayedOk = await rfsWindow.waitUntilMyCurrentBid('101.000');

        expect(myBidDisplayedOk)
          .to
          .be
          .true;
      });

      it('RFS window should show updated best bid and ask price size should not be displayed', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const askPrice = await rowOne.getAskPrice();
        const askSize = await rowOne.getAskSize();
        const bidPrice = await rowOne.getBidPrice();
        const bidSize = await rowOne.getBidSize();

        expect(askPrice)
          .to
          .equal('105.000', 'RFS offers table showed unexpected ask price');

        expect(askSize)
          .to
          .equal('', 'RFS offers table showed unexpected ask size');

        expect(bidPrice)
          .to
          .equal('101.000', 'RFS offers table showed unexpected bid price');

        expect(bidSize)
          .to
          .equal('', 'RFS offers table showed unexpected bid size');
      });

      it('API users should logout', async () => {
        await lpTrader3Client.logout();
        await nlpTrader1Client.logout();
      });
    });
  });
});
