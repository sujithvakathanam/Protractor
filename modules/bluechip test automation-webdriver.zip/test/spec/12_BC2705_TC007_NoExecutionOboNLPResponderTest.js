/* eslint-disable max-lines */
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, STRATEGY, STYLE, UNDERLYING, POLARITY, OPTION_TYPE} from '../../constant/GenericType';
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import ApiClient from '../../utilities/api/ApiClient';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';

describe('BC2705 OBO RFS without interest Tests', function BC2705EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser)
      .to
      .exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2705 TC007: As a NLP trader who is participating in an OBO RFS without interest my quote can match another NLP traders who is in a different legal entity even when there are no LP quotes present', () => {
    let broker = null;
    let brokerClient = null;
    let nlpTraderOne = null;
    let nlpTraderTwo = null;
    let nlpTraderTwoClient = null;
    let strategyId = null;
    let rfsWindow = null;

    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 2340, 300, POLARITY.positive, null, null);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 700, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2100, 1);

    it('Should get the test users', async () => {
      broker = common.getBroker('AUTBR03');
      nlpTraderOne = common.getTrader('AUTTR02');
      nlpTraderTwo = common.getTrader('AUTTR07');
    });

    it('The broker should have a strategy to trade', async () => {
      await start(broker);
      strategyId = await common.getStrategyId(strategy);

      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmit.click();
        await common.waitUntilStrategyFound(strategy);
        strategyId = await common.getStrategyId(strategy);
      }

      expect(strategyId !== null)
        .to
        .equal(true, 'Could not find strategy');
    });

    it('Users should login', async () => {
      await start(nlpTraderOne);
      brokerClient = new ApiClient(broker);
      await brokerClient.login();
      nlpTraderTwoClient = new ApiClient(nlpTraderTwo);
      await nlpTraderTwoClient.login();
    });

    it('Broker should initiate an RFS', async () => {
      await brokerClient.initiateRFS(strategyId);
      await nlpTraderTwoClient.respondToRFS(strategyId);
    });

    it('I should open the RFS window', async () => {
      await mainPageFrame.switchToWindow();
      const marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickTabEuroStoxx();
      const strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
      await strategyRow.waitUntilStatus('RFS', frameworkConfig.shortTimeout);
      await strategyRow.clickStatus();
      rfsWindow = await new Rfs(context);
      const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

      expect(foundWindow)
        .to
        .equal(true, 'Expected to find the RFS window');
    });

    it('I should wait for the RFS to transition to trading phase', async () => {
      const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout;
      await rfsWindow.waitUntilPhase('TRADING', timeout);
      const rfsPhase = await rfsWindow.getPhase();

      expect(rfsPhase)
        .to
        .equal('TRADING', 'RFS should be in TRADING phase');
    });

    it('The broker should activate the trading users', async () => {
      await brokerClient.rfsSelectTrader(strategyId, nlpTraderOne.userShortName);
      await brokerClient.rfsSelectTrader(strategyId, nlpTraderTwo.userShortName);
      await browser.waitUntil(() => nlpTraderTwoClient.userActivated(strategyId), frameworkConfig.shortTimeout);
    });

    // Fails because BC-3405
    it('I should see the Activation overlay', async () => {
      await rfsWindow.verifyActivationOverlayAndDismiss(frameworkConfig.shortTimeout);
    });

    it('NLP trader should submit a quote', async () => {
      await nlpTraderTwoClient.rfsQuote(strategyId, 2000, 2020, 2500);
      const bidOfferRow = await rfsWindow.getBidOfferRow(1);
      const offerFound = await bidOfferRow.waitUntilPrice('2000.000', '2020.000', '2500', '2500');

      expect(offerFound)
        .to
        .equal(true, 'RFS window should display trader offer');
    });

    it('I be able to lift or hit the offer', async () => {
      const bidOfferRow = await rfsWindow.getBidOfferRow(1);
      const askPriceBtnEnabled = await bidOfferRow.isAskPriceBtnEnabled();
      const bidPriceBtnEnabled = await bidOfferRow.isBidPriceBtnEnabled();

      expect(askPriceBtnEnabled)
        .to
        .equal(true, 'User should be able to click on the top of market RFS ask price');

      expect(bidPriceBtnEnabled)
        .to
        .equal(true, 'User should be able to click on the top of market RFS bid price');
    });

    it('If I submit an offer that crosses the offer a match should occur during the RFS', async () => {
      await rfsWindow.quote(1980, 1990, 2500);
      const foundMatchesMsg = await rfsWindow.waitUntilRfsMatchesHaveOccurred(frameworkConfig.shortTimeout);

      expect(foundMatchesMsg)
        .to
        .equal(true, 'RFS should end with matches');
    });

    it('Users should logout', async () => {
      await brokerClient.logout();
      await nlpTraderTwoClient.logout();
    });
  });
});
