import Strategy from '../../lib/Strategy';
import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import {expect} from 'chai';
import ApiClient from '../../utilities/api/ApiClient';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import {Bootstrap} from '@fenics/fenics-test-core';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import ToastNotification from '../../pages/child_windows/ToastNotification';


// Framwework vars
const browser = global.browser;
let bootstrapper = null;
let context = null;
let logger = null;

// Page object vars
let mainPageFrame = null;
let mainWindowHandle = null;
let common = null;
let toastNotification = null;

before(() => {
  bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
  context = bootstrapper.getInstance();
  logger = context.getLogger();
  logger.info('Framework setup complete.');

  // Page object  setup.
  common = new TestCommons(context);

  expect(browser).to.exist;
});

after(() => {
  const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
  shellExec(clearDownScript);
});

async function start ({email, password}) {
  mainPageFrame = await common.login(email, password);
  mainWindowHandle = await browser.getCurrentTabId();
  toastNotification = await new ToastNotification(context);
}

describe('BC2705 TC003: As a LP user I should be able to participate in the RFS without interest if I respond in the book building period', () => {
  let broker = null;
  let brokerClient = null;
  let lpTraderOne = null;
  let lpTraderTwo = null;
  let lpTraderTwoClient = null;
  let nlpTrader = null;
  let nlpTraderClient = null;
  let strategyId = null;
  let rfsWindow = null;
  let strategyRow = null;

  /* eslint-disable no-magic-numbers */
  const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3000, 220, POLARITY.positive, null, null);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 3000, 1);
  strategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 3200, 1.75);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 3300, 1);
  /* eslint-enable no-magic-numbers */

  it('Get test users', () => {
    broker = common.getBroker('AUTBR04');

    lpTraderOne = common.getTrader('AUTTR01');
    lpTraderOne.darkQuote = {
      buyPrice  : 3000,
      sellPrice : 3050,
      amount    : 2500
    };
    lpTraderOne.litQuote = {
      buyPrice  : 3020,
      sellPrice : 3040,
      amount    : 2500
    };

    lpTraderTwo = common.getTrader('AUTTR04');
    lpTraderTwo.darkQuote = {
      buyPrice  : 3010,
      sellPrice : 3060,
      amount    : 3500
    };
    lpTraderTwo.tradeQuote = {
      buyPrice  : 3025,
      sellPrice : 3045,
      amount    : 2500
    };

    nlpTrader = common.getTrader('AUTTR10');
    nlpTrader.tradeQuote = {
      buyPrice  : 3026,
      sellPrice : null,
      amount    : 2500
    };
  });

  it('The broker should have a strategy to trade', async () => {
    await start(broker);
    strategyId = await common.getStrategyId(strategy);
    if (strategyId === null) {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmit.click();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
    }
    expect(strategyId !== null).to.equal(true, 'Could not find Strategy');
  });

  it('Users should login', async () => {
    await start(lpTraderOne);
    brokerClient = await new ApiClient(broker);
    nlpTraderClient = await new ApiClient(nlpTrader);
    lpTraderTwoClient = await new ApiClient(lpTraderTwo);
    await brokerClient.login();
    await nlpTraderClient.login();
    await lpTraderTwoClient.login();
  });

  describe('LP trader should receive notifications when a broker launches an RFS', () => {
    it('LP Trader should see correctly colored RFS status and the initiator against the strategy when the broker launches the RFS', async () => {
      await brokerClient.initiateRFS(strategyId);
      await nlpTraderClient.respondToRFS(strategyId);
      await lpTraderTwoClient.respondToRFS(strategyId);
      await mainPageFrame.clickMarketViewHeader();
      const marketView = await mainPageFrame.getMarketViewTab();
      await marketView.clickTabEuroStoxx();
      await common.waitUntilStrategyFound(strategy);
      strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
      await strategyRow.waitUntilStatus('RFS');
      const status = await strategyRow.getStatusText();
      const initiator = await strategyRow.getInitiator();
      expect(status).to.equal('RFS', 'Strategy status should be RFS');
      expect(initiator).to.equals(broker.leShortCode, 'Unexpected broker entity short code against strategy');
      await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
    });

    it('LP Trader should see an alert for the RFS', async () => {
      const notification = await mainPageFrame.notificationsPanel
        .notifications
        .getRfsResponderInvite(strategy);
      const notificationFound = await notification.waitForExist();
      expect(notificationFound).to.equal(true);
    });

    it('LP trader should not see any toast messages for the RFS', async () => {
      const rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);
      expect(rfsToastMsgs.length).to.equal(1, 'Trader should not see any RFS toast messages');
    });

    it('LP trader should be able to open the RFS by clicking on the RFS label on the strategy in the MarketView', async () => {
      await mainPageFrame.switchToWindow();
      const marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickTabEuroStoxx();
      strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
      await strategyRow.clickStatus();
      rfsWindow = await new Rfs(context);
      const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      expect(foundWindow).to.equal(true, 'Expected to find the RFS window');
    });
  });

  describe('LP trader should see RFS window', () => {
    it('RFS window should display strategy details', async () => {
      const windowLetter = await rfsWindow.getWindowLetter();
      const windowTitle = await rfsWindow.getTitle();
      const delta = await rfsWindow.getDelta();
      const ref = await rfsWindow.getRef();
      expect(windowLetter).to.equal('R', 'Expected RFS window letter to be R');
      const expectedWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      expect(windowTitle).to.equal(expectedWindowTitle, 'RFS window title');
      expect(delta).to.equal(strategy.getDisplayDelta().toString(), 'RFS window delta');
      expect(ref).to.equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    // Add colour detection
    it('RFS window should show grey broker label at the top of the RFS window', async () => {
      const brokerInactiveTxtLabel = await rfsWindow.getBrokerContact();
      expect(brokerInactiveTxtLabel).to.equal(broker.desk);
    });

    it('LP trader two should quote', async () => {
      await lpTraderTwoClient.rfsQuote(
        strategyId,
        lpTraderTwo.darkQuote.buyPrice,
        lpTraderTwo.darkQuote.sellPrice,
        lpTraderTwo.darkQuote.amount
      );
    });

    it('RFS should be in DARK phase', async () => {
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('DARK', 'Expected RFS phase to be in dark phase');
    });

    it('RFS bid, ask and size fields should be enabled', async () => {
      const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
      expect(submitBtnEnabled).to.equal(false, 'RFS submit button should be disabled for LP user during dark period of RFS without interest');
      const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
      expect(enterBidFldEnabled).to.equal(true, 'Enter bid field should be enabled for LP user during dark period of RFS without interest');
      const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
      expect(enterAskFldEnabled).to.equal(true, 'Enter ask field should be enabled for LP user during dark period of RFS without interest');
    });

    it('LP trader should respond to the RFS with a quote', async () => {
      await rfsWindow.quote(
        lpTraderOne.darkQuote.buyPrice,
        lpTraderOne.darkQuote.sellPrice,
        lpTraderOne.darkQuote.amount
      );

      await rfsWindow.verifyMyCurrentFields({
        myCurrentBid  : lpTraderOne.darkQuote.buyPrice,
        myCurrentAsk  : lpTraderOne.darkQuote.sellPrice,
        myCurrentSize : lpTraderOne.darkQuote.amount
      });
    });

    it('RFS screen quotes table should be empty', async () => {
      const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);
      const rowIsEmpty = await bidOfferRowOne.isEmptyRow();

      expect(rowIsEmpty).equals(true, 'RFS window orderbook row 1 should be empty');
    });
  });

  describe('When the RFS transitions to LIT phase LP trader should see the RFS window update', () => {
    it('RFS window should be in LIT phase', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('LIT', 'RFS should be in LIT PHASE');
    });

    it('RFS window should show zero seconds in DARK phase', async () => {
      const darkTimer = await rfsWindow.getDarkCountDownTimer();
      expect(darkTimer).to.equal('0:00', 'Expected dark count down time to be zero in lit phase of RFS');
    });

    it('RFS window should display top of market bid and offer in the bid/offer table', async () => {
      const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);

      await bidOfferRowOne.verifyRow({
        buyPrice     : lpTraderTwo.darkQuote.buyPrice,
        buyAmount    : '',
        buyPriority  : false,
        sellPrice    : lpTraderOne.darkQuote.sellPrice,
        sellAmount   : '',
        sellPriority : false
      });

      const bidOfferRowTwo = await rfsWindow.getBidOfferRow(2);
      const isEmpty = await bidOfferRowTwo.isEmptyRow();
      expect(isEmpty).to.equal(true, 'RFS table row 2 should be empty');
    });

    it('RFS window bid offer table should be updated when a new top of market offer is made', async () => {
      await rfsWindow.quote(
        lpTraderOne.litQuote.buyPrice,
        lpTraderOne.litQuote.sellPrice,
        lpTraderOne.litQuote.amount
      );

      const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);
      await bidOfferRowOne.verifyRow({buyPrice     : lpTraderOne.litQuote.buyPrice,
        buyAmount    : '',
        buyPriority  : false,
        sellPrice    : lpTraderOne.litQuote.sellPrice,
        sellAmount   : '',
        sellPriority : false});
    });
  });

  describe('When the RFS transitions to TRADING phase the LP trader RFS window should show', () => {
    it('RFS window should show DARK and LIT phase count down timers are zero', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const darkTimer = await rfsWindow.getDarkCountDownTimer();
      const litTimer = await rfsWindow.getLitCountDownTimer();
      expect(darkTimer).to.equal('0:00', 'RFS dark countdown timer should be zero');
      expect(litTimer).to.equal('0:00', 'RFS lit countdown timer should be  zero');
    });

    it('RFS window should be in TRADING phase', async () => {
      const phase = await rfsWindow.getPhase();
      expect(phase).to.equal('TRADING', 'RFS should be in TRADING phase');
    });

    it('RFS window should update market depth data when a LP trader submits a new offer', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);

      await rowOne.verifyRow({
        buyPrice     : lpTraderOne.litQuote.buyPrice,
        buyAmount    : '',
        buyPriority  : false,
        sellPrice    : lpTraderOne.litQuote.sellPrice,
        sellAmount   : '',
        sellPriority : false
      });
    });
  });

  describe('When the NLP trader is authorised and submits a Quote I LP Trader should be able to see the quote', () => {
    it('Broker should authorise NLP trader', async () => {
      const msg = await brokerClient.rfsSelectTrader(strategyId, nlpTrader.userShortName);
      const myTrader = msg.response.filter(trader => trader.code === nlpTrader.userShortName);

      expect(myTrader[0].activated)
        .to
        .equal(true, 'User activated is false, expected true');
    });

    it('NLP trader should submit an RFS quote', async () => {
      const rfsQuoteResponse = await nlpTraderClient.rfsQuote(
        strategyId,
        nlpTrader.tradeQuote.buyPrice,
        nlpTrader.tradeQuote.sellPrice,
        nlpTrader.tradeQuote.amount
      );

      expect(rfsQuoteResponse.response[0])
        .to
        .equal('successful', 'RFS quote for user failed');
    });

    // Check price colours
    it('I should see my ask at top of book and counterparty traders offer in blue and the price should be clickable', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);
      await rowOne.verifyRow({
        buyPrice     : nlpTrader.tradeQuote.buyPrice,
        buyPriority  : true,
        buyAmount    : '',
        sellPrice    : lpTraderOne.litQuote.sellPrice,
        sellPriority : false,
        sellAmount   : ''
      });
    });

    it('I should be able to click on the top of market Bid price and Hit the bid', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);
      const bidPriceBtnEnabled = await rowOne.isBidPriceBtnEnabled();
      const askPriceBtnEnabled = await rowOne.isAskPriceBtnEnabled();
      expect(bidPriceBtnEnabled).to.equal(true, 'User should be able to click on the top of the market bid');
      expect(askPriceBtnEnabled).to.equal(false, 'User should not be able to click on the top of the market ask price');
      await rowOne.clickBidPriceBtn();
      const liftBtnEnabled = await rfsWindow.btnHitEnabled();
      expect(liftBtnEnabled).to.equal(true, 'Lift button should be enabled in the RFS window');
      await rfsWindow.btnHitClick();
    });


    it('RFS window should show a summary screen', async () => {
      await rfsWindow.waitUntilRfsMatchesHaveOccurred();
      await rfsWindow.verifySummary({
        TotalMatched : lpTraderOne.litQuote.amount,
        TotalSold    : lpTraderOne.litQuote.amount,
        TotalBought  : 0
      });
    });
  });

  describe('LP Trader should see the RFS transition to a VC', () => {
    let vcWindow = null;
    it('Market View strategy status should be updated to VC', async () => {
      await browser.switchTab(mainWindowHandle);
      const statusFound = await strategyRow.waitUntilStatus('VC');
      expect(statusFound).to.equal(true, 'Trader should see Stratgey has status VC in MarketView');
    });

    it('LP trader should see a VC alert', async () => {
      const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC(strategy, '3026.000');
      const notificationExists = await vcNotification.waitForExist();
      expect(notificationExists).to.equal(true, 'VC notification');
    });

    it('LP trader should see a sell alert', async () => {
      const notification = await mainPageFrame.notificationsPanel
        .notifications
        .getFillSell(strategy, '3026.000', '2500 L');
      const notificationFound = await notification.waitForExist(frameworkConfig.shortTimeout);
      expect(notificationFound).to.equal(true, 'Trader should see sell notification alert');
    });

    it('LP trader should see a VC toast message', async () => {
      const vcToastMsgs = await toastNotification.getVcToastMsg('3026.000', strategy);
      expect(vcToastMsgs.length).to.equal(1, 'Trader should see VC toast message');
    });

    it('LP trader should see a sell toast message', async () => {
      const toastTitle = `${strategy.strategy.shortName} ${strategy.expiry}`;
      const sellToastMsgs = await toastNotification.getSellToastMsg('3026.000', '2500 L', toastTitle);
      expect(sellToastMsgs.length).to.equal(1, 'Sell toast message should exist');
    });

    it('NLP trader should open the VC message by clicking on the strategy row', async () => {
      await strategyRow.clickStatus();
      vcWindow = new VolumeClearing(context);
      const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      expect(foundWindow).to.equal(true, 'Expected to find the VC window');
    });

    it('VC window should show trader is priority seller', async () => {
      const prioritySeller = await vcWindow.isPrioritySeller();
      expect(prioritySeller).to.equal(true, 'Trader should be a priority seller in the VC');
    });

    it('VC window buy side of window should be disabled', async () => {
      const inputEnabled = await vcWindow.buyInterestInputEnabled();
      expect(inputEnabled).to.equal(false, 'VC Buy Interest Input should be disabled');
      const entitySellingMsg = await vcWindow.entitySellingMsgExists();
      expect(entitySellingMsg).to.equal(true, 'VC entity selling message should exist');
    });

    it('VC window sell side of window should be enabled', async () => {
      const inputEnabled = await vcWindow.sellInterestInputEnabled();
      expect(inputEnabled).to.equal(true, 'VC Sell Interest Input should be enabled');
      const entityBuyingMsg = await vcWindow.entityBuyingMsgExists();
      expect(entityBuyingMsg).to.equal(false, 'VC entity buying message should not exist');
    });

    it('VC window should transition from Priority to Open To All', async () => {
      const openToAll = await vcWindow.waitUntilOpenToAll();
      expect(openToAll).to.equal(true, 'VC should be open to all');
    });

    it('VC window will show a summary window at the end of the VC', async () => {
      await vcWindow.waitForSummary();
      const vcTotalBought = await vcWindow.getSummaryTotalBought();
      const vcTotalSold = await vcWindow.getSummaryTotalSold();
      const vcTotalMatched = await vcWindow.getSummaryTotalMatched();
      expect(vcTotalBought).to.equal('0', 'VC My Total Bought Amount');
      expect(vcTotalSold).to.equal('2500', 'VC My Total Sold Amount');
      expect(vcTotalMatched).to.equal('2500', 'VC Total Amount Matched');
    });

    it('API users should logout', async () => {
      await nlpTraderClient.logout();
      await lpTraderTwoClient.logout();
      await brokerClient.logout();
    });
  });
});
