import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {expect} from 'chai';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';
import ApiClient from '../../utilities/api/ApiClient';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import Strategy from '../../lib/Strategy';
import MarketViewTabs from '../../constant/MarketViewTabs';
import Rfs from '../../pages/child_windows/Rfs';
import ToastNotification from '../../pages/child_windows/ToastNotification';


describe('BC2711 No longer invite Broking Users to participate in a VC instead show size traded so far to relevant brokers', function bc2711EndToEndTest () {
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;

  let mainPageFrame = null;
  let common = null;
  let logger = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }

  describe('BC2711 TC001: As a broker I should no longer be able to view matched trades data and should not receive trade notifications', () => {
    let brokerUser = null;
    let nlpTraderOneUser = null;
    let nlpTraderTwoUser = null;
    let nlpTraderOneClient = null;
    let nlpTraderTwoClient = null;
    let strategyId = null;
    let strategyFound = false;
    let strategyRow = null;
    let rfsWindow = null;
    let marketView = null;
    let toastNotification = null;
    const nlpOneBid = 100;
    const nlpOneAsk = 105;
    const nlpOneSize = 2500;
    const nlpTwoBid = null;
    const nlpTwoAsk = 100;
    const nlpTwoSize = 2500;
    // eslint-disable-next-line no-magic-numbers
    const fmtTradePrice = nlpOneAsk.toFixed(3).toString();

    /* eslint-disable */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 325, 20, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 700, null);
    strategy.addLeg(null, null, 'DEC26', null, null);
    /* eslint-enable */

    it('Users should login', async () => {
      brokerUser = common.getBroker('AUTBR03');
      await start(brokerUser);

      nlpTraderOneUser = common.getTrader('AUTTR02');
      nlpTraderOneClient = new ApiClient(nlpTraderOneUser);
      await nlpTraderOneClient.login();

      nlpTraderTwoUser = common.getTrader('AUTTR07');
      nlpTraderTwoClient = new ApiClient(nlpTraderTwoUser);
      await nlpTraderTwoClient.login();
    });

    it('Broker should be logged in', async () => {
      const displayedUsername = await mainPageFrame.getUsername();
      expect(displayedUsername)
        .to
        .equal(brokerUser.fenicsGoUsername, 'Logged in Fenics Go Username');
    });

    it('Broker should not see the Matched Trades tab', async () => {
      const tabExists = await mainPageFrame.matchedTradesHeaderExists();
      expect(tabExists)
        .to
        .equal(false, 'Matched Trades Tab should not be visible to a broker');
    });

    it('Broker should have a strategy to trade', async () => {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmitClick();
      strategyId = await common.waitUntilStrategyId(strategy);
      strategyFound = strategyId !== -1;

      expect(strategyFound)
        .to
        .equal(true, `Expected to find strategy ${strategy.rowDataName}`);
    });

    it('Broker should initiate an RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await marketView.getTable().getTableRow(strategy);
      const isTradeable = await strategyRow.isStrategyTradable();
      expect(isTradeable)
        .to
        .be
        .true;

      await strategyRow.clickStatus();

      logger.info('Found newly created strategy in Market View.');
      const marketDepth = await mainPageFrame.getMarketViewTab().getMarketDepthTab();
      const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
      expect(btnEnabled)
        .to
        .equal(true, 'Request quotes button on Market Depth Tab.');

      await marketDepth.clickRequestQuotesBtn();
      await nlpTraderOneClient.respondToRFS(strategyId);
      await nlpTraderTwoClient.respondToRFS(strategyId);
      logger.info('Clicked request for quotes.');
    });

    it('I should see RFS window', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      rfsWindow = new Rfs(context);
      const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
      await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('R','Expected RFS window letter to be R');

      const windowTitle = await rfsWindow.getTitle();
      expect(windowTitle)
        .to
        .equal(rfsWindowTitle, 'RFS window title');

      const delta = await rfsWindow.getDelta();
      expect(delta)
        .to
        .equal(strategy.getDisplayDelta().toString(), 'RFS window delta');

      const ref = await rfsWindow.getRef();
      expect(ref)
        .to
        .equal(strategy.referencePrice.toString(), 'RFS window ref');
    });

    it('I should see RFS notification alert', async () => {
      await mainPageFrame.switchToWindow();
      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const rfsInvite = await notifications.getRfsResponderInvite(strategy);
      const found = await rfsInvite.waitForExist(frameworkConfig.shortTimeout);
      expect(found)
        .to
        .equal(true, 'Found the RFS message');
    });

    // Broker initiated RFS is displayed with an R hence we look for Responder RFS Toast message.
    it('I should see RFS toast notification', async () => {
      toastNotification = new ToastNotification(context);
      let toastMsgs = null;

      try {
        await browser.waitUntil(
          async () => {
            toastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);

            return toastMsgs.length > 0;
          }
          , frameworkConfig.shortTimeout
          , `Timed out after ${frameworkConfig.shortTimeout}ms, Could not find RFS responder toast message.`
        );
      } catch (err) {
        logger.info(err);
      }

      expect(toastMsgs.length)
        .to
        .equal(1, 'Expected to find Responder toast message');
    });

    it('I should see the RFS transition to trading phase', async () => {
      await rfsWindow.switchToWindow();
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      logger.info('Broker - Waiting for the RFS to transition to Trading phase');

      const litPhase = await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      expect(litPhase)
        .to
        .equal(true, 'RFS phase should be in LIT phase');

      const tradingPhase = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      expect(tradingPhase)
        .to
        .equal(true, 'RFS phase should be in TRADING phase');
    });

    it('I should activate the traders', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const nlpShortCode = nlpTraderOneUser.leShortCode.concat(' - ', nlpTraderOneUser.userShortName);
      const ddTrader = rfsWindow.ddActivateUser;
      await ddTrader.setSelected(nlpShortCode);
      await rfsWindow.btnActivateClick();
      await rfsWindow.waitUntilActivatedTraderExists(nlpShortCode);
      const nlpShortCodeTwo = nlpTraderTwoUser.leShortCode.concat(' - ', nlpTraderTwoUser.userShortName);
      await ddTrader.setSelected(nlpShortCodeTwo);
      await rfsWindow.btnActivateClick();
      await rfsWindow.waitUntilActivatedTraderExists(nlpShortCodeTwo);
    });

    it('Traders should respond to the RFS and match orders in the trading phase of the RFS', async () => {
      expect(strategyFound)
        .to
        .equal(true, 'Strategy was not found');

      const nlpOneActivated = await browser.waitUntil(() => nlpTraderOneClient.userActivated(strategyId), frameworkConfig.shortTimeout);
      expect(nlpOneActivated)
        .to
        .equal(true, 'NLP trader one should be activated.');

      const nlpTwoActivated = await browser.waitUntil(() => nlpTraderTwoClient.userActivated(strategyId), frameworkConfig.shortTimeout);
      expect(nlpTwoActivated)
        .to
        .equal(true, 'NLP trader two should be activated.');

      const rfsQuoteMsg = await browser.waitUntil(() => nlpTraderOneClient.rfsQuote(strategyId, nlpOneBid, nlpOneAsk, nlpOneSize), frameworkConfig.shortTimeout);
      expect(rfsQuoteMsg.response[0])
        .to
        .equal('successful', 'Trader should of quoted for the RFS');

      const acceptedMsg = await browser.waitUntil(() => nlpTraderTwoClient.rfsAccept(strategyId, nlpTwoBid, nlpTwoAsk, nlpTwoSize), frameworkConfig.shortTimeout);
      expect(acceptedMsg.response[0])
        .to
        .equal('successful', 'Expected RFS to be accepted');
    });

    it('Trader should wait until the end of the VC', async () => {
      await browser.waitUntil(async () => {
        const status = await nlpTraderOneClient.getVcStatus(strategyId);


        return status === 'TIMED_OUT';
      }, frameworkConfig.vcTimeout);
    });

    it('I should not see any trade notification', async () => {
      let toastMsgs = null;

      try {
        await browser.waitUntil(
          async () => {
            toastMsgs = await toastNotification.getBuyToastMsg(fmtTradePrice, nlpOneSize.toString(), strategy);

            return toastMsgs.length > 0;
          }
          , frameworkConfig.veryShortTimeout
          , `Timed out after ${frameworkConfig.veryShortTimeout}ms, Could not find RFS responder toast message.`
        );
      } catch (err) {
        logger.info(err);
      }

      expect(toastMsgs.length)
        .to
        .equal(0, 'Expected not to find Buy toast message');

      try {
        await browser.waitUntil(
          async () => {
            toastMsgs = await toastNotification.getSellToastMsg(fmtTradePrice, nlpOneSize.toString(), strategy);

            return toastMsgs.length > 0;
          }
          , frameworkConfig.veryShortTimeout
          , `Timed out after ${frameworkConfig.veryShortTimeout}ms, Could not find RFS responder toast message.`
        );
      } catch (err) {
        logger.info(err);
      }

      expect(toastMsgs.length)
        .to
        .equal(0, 'Expected not to find Sell toast message');

      await mainPageFrame.switchToWindow();
      const notifications = await mainPageFrame.notificationsPanel.notifications;
      const fmtSize = `${nlpOneSize}  L`;
      const sellNotification = await notifications.getFillSell(strategy, fmtTradePrice, fmtSize);
      const buyNotification = await notifications.getFillBuy(strategy, fmtTradePrice, fmtSize);

      const sellExists = await sellNotification.waitForExist(frameworkConfig.veryShortTimeout);
      const buyExists = await buyNotification.waitForExist(frameworkConfig.veryShortTimeout);
      expect(sellExists)
        .to
        .equal(false, 'I should not find any sell notifications');
      expect(buyExists)
        .to
        .equal(false, 'I should not find any buy notifications');
    });

    it('Users should log out', async () => {
      await nlpTraderOneClient.logout();
      await nlpTraderTwoClient.logout();
    });
  });
});
