/* eslint-disable max-lines */
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {MARKET, STRATEGY, STYLE, UNDERLYING, POLARITY, OPTION_TYPE, COLOR_PURPOSE} from '../../constant/GenericType';
import {expect} from 'chai';
import TestCommons from '../../lib/TestCommons';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import ApiClient from '../../utilities/api/ApiClient';
import Strategy from '../../lib/Strategy';
import Rfs from '../../pages/child_windows/Rfs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import ToastNotification from '../../pages/child_windows/ToastNotification';


describe('BC2705 OBO RFS without interest Tests', function BC2705EndToEndTest () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let mainWindowHandle = null;
  let common = null;
  let toastNotification = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
    mainWindowHandle = await browser.getCurrentTabId();
    toastNotification = await new ToastNotification(context);
  }

  /*
   * Requirements coverage:
   * BC2705 -
   * Requirement 1
   * Requirement 2 - For NLP users
   * Requirement 3
   * Requirement 4
   */
  // Improvements Follow on with VC
  describe('BC2705 TC001: As a broker covered NLP trader I should be able to respond to an OBO RFS', () => {
    let broker = {};
    let lpTrader = {};
    let nlpTrader = {};
    let brokerClient = null;
    let lpTraderClient = null;
    let strategyId = 0;
    let rfsWindow = null;
    let strategyRow = null;
    let expectedDarkSpread = 0;
    let expectedCurrentSpread = 0;

    /* eslint-disable no-magic-numbers */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 221, 17, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.negative, OPTION_TYPE.put, 'DEC25', 2300, 1);
    strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC26', 2300, 1);
    /* eslint-enable no-magic-numbers */

    it('Get test users', () => {
      broker = common.getBroker('AUTBR03');
      lpTrader = common.getTrader('AUTTR01');
      lpTrader.darkQuote = {
        buyPrice  : 100,
        sellPrice : 105,
        amount    : 2500
      };
      lpTrader.litQuote = {
        buyPrice  : 103,
        sellPrice : 105,
        amount    : 2500
      };
      lpTrader.tradeQuote = {
        buyPrice  : 103,
        sellPrice : 107,
        amount    : 2500
      };

      nlpTrader = common.getTrader('AUTTR07');
      nlpTrader.tradeQuoteOne = {
        buyPrice  : 99,
        sellPrice : 106,
        amount    : 3000
      };
    });

    it('The broker should have a strategy to trade', async () => {
      await start(broker);
      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmit.click();
        await common.waitUntilStrategyFound(strategy);
        strategyId = await common.getStrategyId(strategy);
      }
      expect(strategyId !== null)
        .to
        .equal(true, 'Could not find Strategy');
    });

    it('The strategy should be tradeable', async () => {
      await mainPageFrame.clickMarketViewHeader();
      const marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickTabEuroStoxx();

      strategyRow = await marketView
        .getEuroStoxxTable()
        .getTableRow(strategy);

      const isTradable = await strategyRow.isStrategyTradable();
      expect(isTradable).to.be.true;
    });

    describe('NLP trader should receive notifications when a broker launches an RFS', () => {
      it('Test users should login', async () => {
        await start(nlpTrader);
        const username = await mainPageFrame.getUsername();
        expect(username)
          .to
          .equal(nlpTrader.fenicsGoUsername, 'Unexpected username');

        brokerClient = new ApiClient(broker);
        await brokerClient.login();

        lpTraderClient = new ApiClient(lpTrader);
        await lpTraderClient.login();
      });

      it('NLP Trader should see blue RFS status and initiator desk short name against the strategy when the broker launches the RFS', async () => {
        await mainPageFrame.clickMarketViewHeader();
        const marketView = await mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
        await brokerClient.initiateRFS(strategyId);
        await common.waitUntilStrategyFound(strategy, frameworkConfig.mediumTimeout);
        strategyRow = await marketView.getEuroStoxxTable()
          .getTableRow(strategy);

        await strategyRow.waitUntilStatus('RFS', frameworkConfig.mediumTimeout);
        const status = await strategyRow.getStatusText();
        const initiator = await strategyRow.getInitiator();

        expect(status)
          .to
          .equal('RFS', 'Strategy status should be RFS');

        expect(initiator)
          .to
          .equals(broker.leShortCode, 'Unexpected broker desk short name against strategy');
      });

      it('NLP Trader should see an alert for the RFS', async () => {
        const notification = await mainPageFrame.notificationsPanel.notifications.getRfsResponderInvite(strategy);
        const notificationFound = await notification.waitForExist();
        expect(notificationFound)
          .to
          .equal(true);
      });

      /*
       * It('NLP trader should not see any toast messages for the RFS', async () => {
       *   const rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);
       *   expect(rfsToastMsgs.length).to.equal(0, 'Trader should not see any RFS toast messages');
       * });
       */

      it('NLP trader should be able to open the RFS by clicking on the RFS label on the strategy in the MarketView', async () => {
        await browser.switchTab(mainWindowHandle);
        const marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();
        strategyRow = await marketView.getEuroStoxxTable()
          .getTableRow(strategy);
        await strategyRow.clickStatus();
        rfsWindow = await new Rfs(context);
        const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the RFS window');
      });

      it('LP Trader should respond to the RFS', async () => {
        await lpTraderClient.respondToRFS(strategyId);
      });
    });

    describe('NLP trader should see RFS window', () => {
      it('RFS window should display strategy details', async () => {
        const windowLetter = await rfsWindow.getWindowLetter();
        const windowTitle = await rfsWindow.getTitle();
        const delta = await rfsWindow.getDelta();
        const ref = await rfsWindow.getRef();
        expect(windowLetter)
          .to
          .equal('R', 'Expected RFS window letter to be R');
        const expectedWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
        expect(windowTitle)
          .to
          .equal(expectedWindowTitle, 'RFS window title');

        expect(delta)
          .to
          .equal(strategy.getDisplayDelta()
            .toString(), 'RFS window delta');

        expect(ref)
          .to
          .equal(strategy.referencePrice.toString(), 'RFS window ref');
      });

      it('RFS window should show WATERMELON colour contact broker badge', async () => {
        const brokerContact = await rfsWindow.getBrokerContact();
        const expectedBrokerContact = 'CONTACT '.concat(broker.desk);

        expect(brokerContact)
          .to
          .equal(expectedBrokerContact, 'Unexpected broker contact found on RFS window');

        await rfsWindow.verifyBrokerBadgeColour(COLOR_PURPOSE.CONTACT_BROKER);
      });

      it('RFS should be in DARK phase', async () => {
        const phase = await rfsWindow.getPhase();

        expect(phase)
          .to
          .equal('DARK', 'Expected RFS phase to be in dark phase');
      });


      it('RFS should display message "Book building in progress"', async () => {
        const bookBuildingMessage = await rfsWindow.bookBuildingMessageExists();

        expect(bookBuildingMessage)
          .to
          .equal(true, 'Expected to find Book Building Message in the RFS window');
      });

      it('RFS should not display spread information', async () => {
        const currentSpreadShown = await rfsWindow.currentSpreadExists();
        const darkSpreadShown = await rfsWindow.darkSpreadExists();

        expect(currentSpreadShown)
          .to
          .equal(false, 'Current spread should not be displayed');

        expect(darkSpreadShown)
          .to
          .equal(false, 'Dark spread should not be displayed');
      });

      it('RFS bid, ask and size fields should be disabled', async () => {
        const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();

        expect(submitBtnEnabled)
          .to
          .equal(false, 'RFS submit button should be disabled from NLP user during dark period of RFS without interest');

        const submitBtnText = await rfsWindow.getQuoteBtnText();
        expect(submitBtnText)
          .to
          .equal('SUBMIT', 'RFS submit button text is not expected');

        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(false, 'Enter bid field should be disabled from NLP user during dark period of RFS without interest');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(false, 'Enter ask field should be disabled from NLP user during dark period of RFS without interest');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(false, 'Enter size field should be disabled from NLP user during dark period of RFS without interest');

        const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
        expect(subjectBtnEnabled)
          .to
          .equal(false, 'Subject button should be disabled from NLP user during dark period of RFS without interest');

        const subjectBtnText = await rfsWindow.getSubjectBtnText();
        expect(subjectBtnText)
          .to
          .equal('SUBJECT', 'RFS subject button text is not expected');
      });

      it('LP trader should respond to the RFS and quote', async () => {
        await lpTraderClient.rfsQuote(
          strategyId,
          lpTrader.darkQuote.buyPrice,
          lpTrader.darkQuote.sellPrice,
          lpTrader.darkQuote.amount
        );
      });
    });

    describe('When the RFS transitions to LIT phase NLP trader should see the RFS window update', () => {
      it('RFS window should be in LIT phase', async () => {
        await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
        const phase = await rfsWindow.getPhase();
        expect(phase)
          .to
          .equal('LIT', 'RFS should be in LIT PHASE');
      });

      it('RFS window should show WATERMELON contact broker button', async () => {
        const brokerContact = await rfsWindow.getBrokerContact();
        const expectedBrokerContact = 'CONTACT '.concat(broker.desk);

        expect(brokerContact)
          .to
          .equal(expectedBrokerContact, 'Unexpected broker contact found on RFS window');

        await rfsWindow.verifyBrokerBadgeColour(COLOR_PURPOSE.CONTACT_BROKER);
      });

      it('RFS window should show zero seconds in DARK phase', async () => {
        const darkTimer = await rfsWindow.getDarkCountDownTimer();

        expect(darkTimer)
          .to
          .equal('0:00', 'Expected dark period countdown timer to be zero when lit period starts in an RFS');
      });

      it('RFS window should display message "Book building in progress"', async () => {
        const bookBuildingMessage = await rfsWindow.bookBuildingMessageExists();

        expect(bookBuildingMessage).to.equal(true, 'Expected to find Book Building Message in the RFS window');
      });

      it('RFS window should display current spread and dark spread', async () => {
        expectedDarkSpread = (lpTrader.darkQuote.sellPrice - lpTrader.darkQuote.buyPrice)
          .toFixed(2)
          .toString();
        const currentSpread = await rfsWindow.getCurrentSpread();
        const darkSpread = await rfsWindow.getDarkSpread();

        expect(currentSpread)
          .to
          .equal(expectedDarkSpread, 'Current Spread unexpected value');

        expect(darkSpread)
          .to
          .equal(expectedDarkSpread, 'Dark Spread unexpected value');
      });

      it('RFS window current spread should update when a new quote is submitted by a LP trader', async () => {
        expectedCurrentSpread = (lpTrader.litQuote.sellPrice - lpTrader.litQuote.buyPrice)
          .toFixed(2)
          .toString();

        await lpTraderClient.rfsQuote(
          strategyId,
          lpTrader.litQuote.buyPrice,
          lpTrader.litQuote.sellPrice,
          lpTrader.litQuote.amount
        );

        await rfsWindow.waitUntilCurrentSpread(expectedCurrentSpread);
        const currentSpread = await rfsWindow.getCurrentSpread();
        const darkSpread = await rfsWindow.getDarkSpread();

        expect(currentSpread)
          .to
          .equal(expectedCurrentSpread, 'Current Spread unexpected value');

        expect(darkSpread)
          .to
          .equal(expectedDarkSpread, 'Dark Spread unexpected value');
      });
    });

    describe('When the RFS transitions to TRADING phase the NLP trader RFS window should show', () => {
      it('RFS window should show DARK and LIT phase count down timers are zero', async () => {
        await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
        const darkTimer = await rfsWindow.getDarkCountDownTimer();
        const litTimer = await rfsWindow.getLitCountDownTimer();

        expect(darkTimer)
          .to
          .equal('0:00', 'RFS dark countdown timer should be zero');

        expect(litTimer)
          .to
          .equal('0:00', 'RFS lit countdown timer should be  zero');
      });

      it('RFS window should show contact broker button', async () => {
        const brokerContact = await rfsWindow.getBrokerContact();
        const expectedBrokerContact = 'CONTACT '.concat(broker.desk);

        expect(brokerContact)
          .to
          .equal(expectedBrokerContact, 'Unexpected broker contact found on RFS window');
      });

      it('RFS window should be in TRADING phase', async () => {
        const phase = await rfsWindow.getPhase();

        expect(phase)
          .to
          .equal('TRADING', 'RFS should be in TRADING phase');
      });

      it('RFS window should show enter bid/ask/size fields and submit and subject buttons are disabled', async () => {
        const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
        expect(submitBtnEnabled)
          .to
          .equal(false, 'RFS submit button should be disabled for NLP user during dark period of RFS without interest');

        const submitBtnText = await rfsWindow.getQuoteBtnText();
        expect(submitBtnText)
          .to
          .equal('SUBMIT', 'RFS submit button text is not expected');

        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(false, 'Enter bid field should be disabled for NLP user during dark period of RFS without interest');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(false, 'Enter ask field should be disabled for NLP user during dark period of RFS without interest');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(false, 'Enter size field should be disabled for NLP user during dark period of RFS without interest');

        const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
        expect(subjectBtnEnabled)
          .to
          .equal(false, 'Subject button should be disabled from NLP user during dark period of RFS without interest');

        const subjectBtnText = await rfsWindow.getSubjectBtnText();
        expect(subjectBtnText)
          .to
          .equal('SUBJECT', 'RFS subject button text is not expected');
      });

      it('RFS window should show greyed out market depth data and no size information', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const bidButtonEnabled = await rowOne.isBidPriceBtnEnabled();
        const askButtonEnabled = await rowOne.isAskPriceBtnEnabled();
        const bidSize = await rowOne.getBidSize();
        const askSize = await rowOne.getAskSize();

        expect(bidButtonEnabled)
          .to
          .equal(false, 'RFS bid price should be disabled');

        expect(askButtonEnabled)
          .to
          .equal(false, 'RFS ask price should be disabled');

        expect(bidSize)
          .to
          .equal('', 'Trader should not see the Bid size when he is not activated');

        expect(askSize)
          .to
          .equal('', 'Trader should not see the Ask size when he is not activated');
      });

      it('RFS window should update market depth data when a LP trader submits a new offer', async () => {
        await lpTraderClient.rfsQuote(
          strategyId,
          lpTrader.tradeQuote.buyPrice,
          lpTrader.tradeQuote.sellPrice,
          lpTrader.tradeQuote.amount
        );

        const rowOne = await rfsWindow.getBidOfferRow(1);
        await rowOne.verifyRow({
          buyPrice     : lpTrader.tradeQuote.buyPrice,
          buyPriority  : false,
          buyAmount    : '',
          sellPrice    : lpTrader.tradeQuote.sellPrice,
          sellAmount   : '',
          sellPriority : false
        });
      });
    });

    describe('NLP trader should be allowed to interact with the RFS when authorised by a broker', () => {
      it('Broker should authorise NLP trader', async () => {
        await brokerClient.rfsSelectTrader(strategyId, nlpTrader.userShortName);
        await rfsWindow.waitUntilEnabled();
      });

      it('NLP trader should see the Activation overlay', async () => {
        await rfsWindow.verifyActivationOverlayAndDismiss(frameworkConfig.shortTimeout);
      });

      it('RFS window should show grey broker badge', async () => {
        const brokerContact = await rfsWindow.getBrokerContact();
        expect(brokerContact)
          .to
          .equal(broker.desk, 'Unexpected broker contact found on RFS window');

        await rfsWindow.verifyBrokerBadgeColour(COLOR_PURPOSE.INACTIVE_COLOR);
      });

      it('RFS window should show enter bid, ask and size fields are enabled, submit and subject buttons will be disabled', async () => {
        const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
        expect(submitBtnEnabled)
          .to
          .equal(false, 'RFS submit button should be disabled for NLP user until they enter an offer');

        const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
        expect(enterBidFldEnabled)
          .to
          .equal(true, 'Enter bid field should be enabled');

        const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
        expect(enterAskFldEnabled)
          .to
          .equal(true, 'Enter ask field should be enabled');

        const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
        expect(enterSizeFldEnabled)
          .to
          .equal(true, 'Enter size field should be enabled');

        const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
        expect(subjectBtnEnabled)
          .to
          .equal(false, 'Subject button should be disabled until a firm offer has been made');
      });

      it('RFS offers table should be enabled, NLP trader should see Bid/Offer and size data', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        await rowOne.verifyRow({
          buyPrice   : lpTrader.tradeQuote.buyPrice,
          buyAmount  : lpTrader.tradeQuote.amount,
          sellPrice  : lpTrader.tradeQuote.sellPrice,
          sellAmount : lpTrader.tradeQuote.amount
        });
      });

      it('NLP trader should be able to click on the top of market ask price to activate the lift button', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);

        const bidPriceBtnEnabled = await rowOne.isBidPriceBtnEnabled();
        expect(bidPriceBtnEnabled)
          .to
          .equal(true, 'User should but able to click on the top of the market bid');

        const askPriceBtnEnabled = await rowOne.isAskPriceBtnEnabled();
        expect(askPriceBtnEnabled)
          .to
          .equal(true, 'User should be able to click on the top of the market ask price');

        await rowOne.clickAskPriceBtn();

        const liftBtnEnabled = await rfsWindow.btnLiftEnabled();
        expect(liftBtnEnabled)
          .to
          .equal(true, 'Lift button should be enabled in the RFS window');
      });

      it('NLP trader should be able to click on the top of market bid price to activate the hit button', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        await rowOne.clickBidPriceBtn();

        const hitBtnExists = await rfsWindow.waitUntilBtnHitExists();
        expect(hitBtnExists)
          .to
          .equal(true, 'Hit button should be displayed in the RFS window');

        const hitBtnEnabled = await rfsWindow.btnHitEnabled();
        expect(hitBtnEnabled)
          .to
          .equal(true, 'Hit button should be enabled in the RFS window');
      });

      it('NLP trader should be able to submit an offer', async () => {
        await rfsWindow.quote(
          nlpTrader.tradeQuoteOne.buyPrice,
          nlpTrader.tradeQuoteOne.sellPrice,
          nlpTrader.tradeQuoteOne.amount
        );
      });

      it('NLP traders sell price should appear at the top of the market in the RFS window', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);

        await rowOne.verifyRow({
          buyPrice     : lpTrader.tradeQuote.buyPrice,
          buyAmount    : lpTrader.tradeQuote.amount,
          buyPriority  : false,
          sellPrice    : nlpTrader.tradeQuoteOne.sellPrice,
          sellAmount   : nlpTrader.tradeQuoteOne.amount,
          sellPriority : true
        });
      });

      it('NLP trader should see My Current Bid/Ask/Size fields updated', async () => {
        await rfsWindow.verifyMyCurrentFields({
          myCurrentBid  : nlpTrader.tradeQuoteOne.buyPrice,
          myCurrentAsk  : nlpTrader.tradeQuoteOne.sellPrice,
          myCurrentSize : nlpTrader.tradeQuoteOne.amount
        });
      });

      it('NLP trader should be able to subject his offer', async () => {
        await rfsWindow.btnSubjectClick();

        const rowOne = await rfsWindow.getBidOfferRow(1);

        await rowOne.verifyRow({
          buyPrice     : lpTrader.tradeQuote.buyPrice,
          buyAmount    : lpTrader.tradeQuote.amount,
          buyPriority  : false,
          sellPrice    : lpTrader.tradeQuote.sellPrice,
          sellAmount   : lpTrader.tradeQuote.amount,
          sellPriority : false
        });

        await rfsWindow.verifyMyCurrentFields({
          myCurrentBid  : nlpTrader.tradeQuoteOne.buyPrice,
          myCurrentAsk  : nlpTrader.tradeQuoteOne.sellPrice,
          myCurrentSize : nlpTrader.tradeQuoteOne.amount
        });
      });

      it('NLP trader should be able to hit the bid order', async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        await rowOne.clickBidPriceBtn();
        await rfsWindow.waitUntilBtnHitExists();
        await rfsWindow.btnHitClick();
      });

      it('RFS window should show a summary screen', async () => {
        await rfsWindow.waitUntilRfsMatchesHaveOccurred();
        await rfsWindow.verifySummary({
          totalMatched : lpTrader.tradeQuote.amount,
          totalBought  : 0,
          totalSold    : lpTrader.tradeQuote.amount
        });
      });
    });

    describe('NLP Trader should see the RFS transition to a VC', () => {
      let vcWindow = null;
      it('Market View strategy status should be updated to VC', async () => {
        await mainPageFrame.switchToWindow();
        const marketView = mainPageFrame.getMarketViewTab();
        await marketView.clickTabEuroStoxx();

        strategyRow = await marketView
          .getEuroStoxxTable()
          .getTableRow(strategy);

        const statusFound = await strategyRow.waitUntilStatus('VC');
        expect(statusFound)
          .to
          .equal(true, 'Trader should see Stratgey has status VC in MarketView');
      });

      it('NLP trader should see a VC alert', async () => {
        const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC(strategy, '103.000');
        const notificationExists = await vcNotification.waitForExist();
        expect(notificationExists)
          .to
          .equal(true, 'VC notification');
      });

      it('NLP trader should see a sell alert', async () => {
        const notification = await mainPageFrame.notificationsPanel
          .notifications
          .getFillSell(strategy, '103.000', '2500 L');

        const notificationFound = await notification.waitForExist();
        expect(notificationFound)
          .to
          .equal(true, 'Trader should see sell notification alert');
      });

      it('NLP trader should see an order cancellation alert message when unmatched volume that is smaller than minimum trade size remains at the end of the VC', async () => {
        const notification = await mainPageFrame.notificationsPanel
          .notifications
          .getCanceledOrder(strategy, '/103.000', '500');

        const notificationFound = await notification.waitForExist();
        expect(notificationFound)
          .to
          .equal(true, 'Trader should see order rejected notification alter');
      });

      it('NLP trader should see a VC toast message', async () => {
        const vcToastMsgs = await toastNotification.getVcToastMsg('103.000', strategy);
        expect(vcToastMsgs.length)
          .to
          .equal(1, 'Trader should see VC toast message');
      });

      it('NLP trader should see a sell toast message', async () => {
        const sellToastMsgs = await toastNotification.getSellToastMsg('103.000', '2500 L', strategy);
        expect(sellToastMsgs.length)
          .to
          .equal(1, 'Sell toast message should exist');
      });

      it('NLP trader should open the VC message by clicking on the strategy row', async () => {
        await strategyRow.clickStatus();
        vcWindow = new VolumeClearing(context);

        const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
        expect(foundWindow)
          .to
          .equal(true, 'Expected to find the VC window');
      });

      it('VC window should show trader is priority seller', async () => {
        const prioritySeller = await vcWindow.isPrioritySeller();
        expect(prioritySeller)
          .to
          .equal(true, 'Trader should be a priority seller in the VC');
      });

      it('VC window should transition from Priority to Open To All', async () => {
        const openToAll = await vcWindow.waitUntilOpenToAll();
        expect(openToAll)
          .to
          .equal(true, 'VC should be open to all');
      });

      it('VC window will show a summary window at the end of the VC', async () => {
        await vcWindow.waitForSummary();

        const vcTotalBought = await vcWindow.getSummaryTotalBought();
        const vcTotalSold = await vcWindow.getSummaryTotalSold();
        const vcTotalMatched = await vcWindow.getSummaryTotalMatched();

        expect(vcTotalBought)
          .to
          .equal('0', 'VC My Total Bought Amount');

        expect(vcTotalSold)
          .to
          .equal('2500', 'VC My Total Sold Amount');

        expect(vcTotalMatched)
          .to
          .equal('2500', 'VC Total Amount Matched');
      });

      it('API users should logout', async () => {
        await lpTraderClient.logout();
        await brokerClient.logout();
      });
    });
  });
});
