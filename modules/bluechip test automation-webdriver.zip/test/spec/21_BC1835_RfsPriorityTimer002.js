/* eslint-disable max-statements */
import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import Rfs from '../../pages/child_windows/Rfs';
import {expect} from 'chai';
import Strategy from '../../lib/Strategy';
import {MARKET, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import MarketViewTabs from '../../constant/MarketViewTabs';
import ApiClient from '../../utilities/api/ApiClient';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import TestCommons from '../../lib/TestCommons';


describe('BC1835 RFS Priority Timer', function BC2706Test () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;
  let toastNotification = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    toastNotification = new ToastNotification(context);

    expect(browser).to.exist;
  });

  after(() => {
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }


  describe('BC1835 TC002: For RFS Without Interest', () => {
    let brokerInitiator = {};
    let brokerUser2 = {};
    let lpResponder1 = {};
    let lpResponder2 = {};
    let lpResponder3 = {};
    let lpResponder4 = {};
    let nlpOboResponder1 = {};
    let nlpOboResponder2 = {};
    let nlpOboResponder3 = {};
    let brokerInitiatorClient = null;
    let brokerUser2Client = null;
    let lpResponder1Client = null;
    let lpResponder3Client = null;
    let lpResponder4Client = null;
    let nlpOboResponder1Client = null;
    let nlpOboResponder2Client = null;
    let nlpOboResponder3Client = null;
    let marketView = null;
    let strategyId = 0;
    let rfsWindow = null;
    let strategyRow = null;
    let priorityTimerValue = '0:00';

    /* eslint-disable */
    const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 325, 20, POLARITY.negative, null, null);
    strategy.addLeg(null, null, 'DEC25', 700, null);
    strategy.addLeg(null, null, 'DEC26', null, null);
    /* eslint-enable */

    it('Setup', () => {
      brokerInitiator = common.getBroker('AUTBR03');
      brokerUser2 = common.getBroker('AUTBR04');
      lpResponder1 = common.getTrader('AUTTR05');
      lpResponder2 = common.getTrader('AUTTR08');
      lpResponder3 = common.getTrader('AUTTR14');
      lpResponder4 = common.getTrader('AUTTR18');
      nlpOboResponder1 = common.getTrader('AUTTR02');
      nlpOboResponder2 = common.getTrader('AUTTR06');
      nlpOboResponder3 = common.getTrader('AUTTR10');
    });

    it('The broker initiator should login via the UI initially', async () => {
      await start(brokerInitiator);
      const username = await mainPageFrame.getUsername();
      expect(username).to.equal(brokerInitiator.fenicsGoUsername, 'Unexpected username on application window');
    });

    it('The broker initiator should have a strategy to trade', async () => {
      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmitClick();
        expect(await common.waitUntilStrategyFound(strategy)).to.be.true;
        strategyId = await common.getStrategyId(strategy);
      }
    });

    it('The strategy should be tradeable', async () => {
      await mainPageFrame.clickMarketViewHeader();
      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);
      strategyRow = await marketView.getTable().getTableRow(strategy);
      const isTradable = await strategyRow.isStrategyTradable();
      expect(isTradable).to.be.true;
    });

    it('Broker/Traders should all login and register for notifications as required', async () => {
      await start(lpResponder2);
      const username = await mainPageFrame.getUsername();
      expect(username).to.equal(lpResponder2.fenicsGoUsername, 'Unexpected username on application window');
      await mainPageFrame.clickMarketViewHeader();
      marketView = mainPageFrame.getMarketViewTab();
      await marketView.clickSubTab(MarketViewTabs.EUROSTOXX);

      brokerInitiatorClient = new ApiClient(brokerInitiator);
      await brokerInitiatorClient.login();
      brokerUser2Client = new ApiClient(brokerUser2);
      await brokerUser2Client.login();
      lpResponder1Client = new ApiClient(lpResponder1);
      await lpResponder1Client.login();
      lpResponder3Client = new ApiClient(lpResponder3);
      await lpResponder3Client.login();
      lpResponder4Client = new ApiClient(lpResponder4);
      await lpResponder4Client.login();
      nlpOboResponder1Client = new ApiClient(nlpOboResponder1);
      await nlpOboResponder1Client.login();
      nlpOboResponder2Client = new ApiClient(nlpOboResponder2);
      await nlpOboResponder2Client.login();
      nlpOboResponder3Client = new ApiClient(nlpOboResponder3);
      await nlpOboResponder3Client.login();
    });

    it('Broker initiates RFS', async () => {
      await brokerInitiatorClient.initiateRFS(strategyId);
      await brokerUser2Client.respondToRFS(strategyId);
      await brokerInitiatorClient.respondToRFS(strategyId);
      await lpResponder1Client.respondToRFS(strategyId);
      await lpResponder3Client.respondToRFS(strategyId);
      await lpResponder4Client.respondToRFS(strategyId);
      await nlpOboResponder1Client.respondToRFS(strategyId);
      await nlpOboResponder2Client.respondToRFS(strategyId);
      await nlpOboResponder3Client.respondToRFS(strategyId);
    });

    it('Clicking on the toast notification should open the RFS Window', async () => {
      const notificationTitle = `${strategy.strategy.shortName} ${strategy.expiry}`;
      let rfsToastMsgs = null;
      try {
        await browser.waitUntil(async () => {
          rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);

          return rfsToastMsgs.length > 0;
        }, frameworkConfig.mediumTimeout);
        await rfsToastMsgs[0].click();
      } catch (error) {
        expect(false)
          .to
          .equal(true, `Could not find toast notification for ${notificationTitle}`);
      }

      rfsWindow = await new Rfs(context);
      const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
      expect(foundWindow)
        .to
        .equal(true, 'Expected to find the RFS window');
    });

    it('RFS window should transition to LIT phase', async () => {
      await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(phase)
        .to
        .equal('LIT', 'RFS should be in LIT PHASE');
    });

    it('Direct Responders enter their orders during lit phase', async () => {
      await lpResponder1Client.rfsQuote(strategyId, 99, 103, 1000);

      // Responder 2
      await rfsWindow.quote(98, 102.5, 1000);
      await lpResponder3Client.rfsQuote(strategyId, 98, 104, 1000);
      await lpResponder4Client.rfsQuote(strategyId, 99, 101.5, 1000);
      await lpResponder4Client.rfsSubject(strategyId);
    });

    it('RFS window should transition to TRADING phase', async () => {
      await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
      const phase = await rfsWindow.getPhase();
      expect(phase)
        .to
        .equal('TRADING', 'RFS should be in TRADING PHASE');
    });

    it('Broker activates NLP responders', async () => {
      await brokerInitiatorClient.rfsSelectTrader(strategyId, nlpOboResponder1.userShortName);
      await brokerInitiatorClient.rfsSelectTrader(strategyId, nlpOboResponder2.userShortName);
      await brokerUser2Client.rfsSelectTrader(strategyId, nlpOboResponder3.userShortName);

      try {
        await browser.waitUntil(() => nlpOboResponder1Client.userActivated(strategyId), frameworkConfig.shortTimeout);
      } catch (error) {
        expect(false)
          .to
          .equal(true, 'nlpOboResponder1 Activation FAILED');
      }

      try {
        await browser.waitUntil(() => nlpOboResponder2Client.userActivated(strategyId), frameworkConfig.shortTimeout);
      } catch (error) {
        expect(false)
          .to
          .equal(true, 'nlpOboResponder2 Activation FAILED');
      }

      try {
        await browser.waitUntil(() => nlpOboResponder3Client.userActivated(strategyId), frameworkConfig.shortTimeout);
      } catch (error) {
        expect(false)
          .to
          .equal(true, 'nlpOboResponder3 Activation FAILED');
      }
    });

    it('Scenario #2.1: RFS window should show top of stack correctly', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);
      let bidPrice = await rowOne.getBidPrice();
      let askPrice = await rowOne.getAskPrice();
      expect(bidPrice)
        .to
        .equal('99.000', 'RFS offers row 1 showed unexpected bid price');
      expect(askPrice)
        .to
        .equal('102.500', 'RFS offers row 1 showed unexpected ask price');

      const rowTwo = await rfsWindow.getBidOfferRow(2);
      bidPrice = await rowTwo.getBidPrice();
      askPrice = await rowTwo.getAskPrice();
      expect(bidPrice)
        .to
        .equal('', 'RFS offers row 2 should not show prices');
      expect(askPrice)
        .to
        .equal('', 'RFS offers row 2 should not show prices');
    });

    it('Scenario #2.2: Direct Responder 3 improves bid', async () => {
      await lpResponder3Client.rfsQuote(strategyId, 100, 104, 1000);

      await browser.waitUntil(async () => {
        const rowOne = await rfsWindow.getBidOfferRow(1);
        const bidPrice = await rowOne.getBidPrice();

        return bidPrice === '100.000';
      }, frameworkConfig.shortTimeout);
    });

    it('Scenario #2.2: RFS window should show top of stack correctly', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);
      const bidPrice = await rowOne.getBidPrice();
      const askPrice = await rowOne.getAskPrice();
      expect(bidPrice)
        .to
        .equal('100.000', 'RFS offers row 1 showed unexpected bid price');
      expect(askPrice)
        .to
        .equal('102.500', 'RFS offers row 1 showed unexpected ask price');
    });

    it('Scenario #2.2: Priority timer should NOT be triggered', async () => {
      /*
       * Both of the participants at the top of stack are Direct Responders and an OBO Responder does not have an order at the same price as the resting order, so
       * they are not RFS Matchable, so no priority phase can start, despite the price improvement
       */
      const phase = await rfsWindow.getPhase();
      expect(phase)
        .to
        .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
    });

    it('Scenario #2.3, #2.4: Broker activated NLP users respond', async () => {
      await nlpOboResponder1Client.rfsQuote(strategyId, 98.5, null, 1000);
      await nlpOboResponder2Client.rfsQuote(strategyId, null, 103, 1000);
      await nlpOboResponder3Client.rfsQuote(strategyId, null, 103.5, 1000);
      await browser.pause(frameworkConfig.veryShortTimeout);
    });

    it('Scenario #2.4: RFS window should show top of stack correctly', async () => {
      const rowOne = await rfsWindow.getBidOfferRow(1);
      const bidPrice = await rowOne.getBidPrice();
      const askPrice = await rowOne.getAskPrice();
      expect(bidPrice)
        .to
        .equal('100.000', 'RFS offers row 1 showed unexpected bid price');
      expect(askPrice)
        .to
        .equal('102.500', 'RFS offers row 1 showed unexpected ask price');
    });

    it('Scenario #2.4: Priority timer should NOT be triggered', async () => {
      // No improvement to either top of stack price
      const phase = await rfsWindow.getPhase();
      expect(phase)
        .to
        .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
    });

    it('Scenario #2.5: NLP (broker activated) responder 1 matches top bid price', async () => {
      await nlpOboResponder1Client.rfsQuote(strategyId, 100, null, 1000);
      await browser.pause(frameworkConfig.veryShortTimeout);
    });

    it('Scenario #2.5: Priority timer should NOT be triggered', async () => {
      // No improvement to either top of stack price
      const phase = await rfsWindow.getPhase();
      expect(phase)
        .to
        .equal('TRADING', `RFS should be in plain TRADING phase, not ${phase} phase`);
    });

    it('Scenario #2.6: NLP (broker activated) responder 1 betters top bid price', async () => {
      await nlpOboResponder1Client.rfsQuote(strategyId, 100.5, null, 1000);
      let bidPrice = null;
      let askPrice = null;

      try {
        // P should be shown on the side of the improvement
        await browser.waitUntil(async () => {
          const rowOne = await rfsWindow.getBidOfferRow(1);
          bidPrice = await rowOne.getBidPrice();
          askPrice = await rowOne.getAskPrice();

          return bidPrice === '100.500\n*' && askPrice === '102.500';
        }, frameworkConfig.shortTimeout);
      } catch (error) {
        expect(false)
          .to
          .equal(true, `Expected row 1 bidPrice = '100.500\\n*' && askPrice === '102.500', found bidPrice = ${bidPrice}, askPrice = ${askPrice}`);
      }
    });

    it('Scenario #2.6: Priority phase starts, priority to direct responder 2', async () => {
      const phase = await rfsWindow.getPriorityPhaseType();
      expect(phase)
        .to
        .equal('PRIORITY-MINE', 'RFS should be in PRIORITY phase, priority to Direct (LP) Responder 2');

      priorityTimerValue = await rfsWindow.getPriorityCountDownTimer(true);
    });

    it('Scenario #2.6: Priority phase ends', async () => {
      const prioritySeconds = parseInt(priorityTimerValue.split(':')[1], 10);
      const timeout = (prioritySeconds + 10) * 1000;

      await browser.waitUntil(async () => {
        const phase = await rfsWindow.getPhase();

        return phase === 'TRADING';
      }, timeout);
    });

    it('Scenario #2.7: NLP (broker activated) responder 2 betters top ask price', async () => {
      await nlpOboResponder2Client.rfsQuote(strategyId, null, 102, 1000);
      let bidPrice = null;
      let askPrice = null;

      // P should be shown on the side of the improvement
      try {
        await browser.waitUntil(async () => {
          const rowOne = await rfsWindow.getBidOfferRow(1);
          bidPrice = await rowOne.getBidPrice();
          askPrice = await rowOne.getAskPrice();

          return bidPrice === '100.500' && askPrice === '102.000\n*';
        }, frameworkConfig.shortTimeout);
      } catch (error) {
        expect(false)
          .to
          .equal(true, `Expected row 1 bidPrice = '100.500' && askPrice === '102.000\\n*', found bidPrice = ${bidPrice}, askPrice = ${askPrice}`);
      }
    });

    it('Scenario #2.7: Priority phase starts, priority to NLP responder 1', async () => {
      const phase = await rfsWindow.getPriorityPhaseType();
      expect(phase)
        .to
        .equal('PRIORITY-OTHER', 'RFS should be in PRIORITY phase, priority to NLP Responder 1');
    });

    it('Users should make their prices subject to prevent them moving to the order book', async () => {
      await lpResponder1Client.rfsSubject(strategyId);
      await rfsWindow.btnSubjectClick();
      await lpResponder3Client.rfsSubject(strategyId);
      await lpResponder4Client.rfsSubject(strategyId);
      await nlpOboResponder1Client.rfsSubject(strategyId);
      await nlpOboResponder2Client.rfsSubject(strategyId);
      await nlpOboResponder3Client.rfsSubject(strategyId);
      await rfsWindow.waitUntilRfsTimedout(frameworkConfig.tradePhaseTimeout);
    });

    it('Users should logout', async () => {
      await brokerInitiatorClient.logout();
      await brokerUser2Client.logout();
      await lpResponder1Client.logout();
      await lpResponder3Client.logout();
      await lpResponder4Client.logout();
      await nlpOboResponder1Client.logout();
      await nlpOboResponder2Client.logout();
      await nlpOboResponder3Client.logout();
    });
  });
});
