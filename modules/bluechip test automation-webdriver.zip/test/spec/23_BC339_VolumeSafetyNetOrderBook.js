import {usersConfig} from '../../config/users.config';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {shellExec} from '../../utilities/framework/shell-exec';
import {join} from 'path';
import {expect} from 'chai';
import Rfs from '../../pages/child_windows/Rfs';
import {UNDERLYING, MARKET, POLARITY, STRATEGY, STYLE, COLOR_PURPOSE} from '../../constant/GenericType';
import ApiClient from '../../utilities/api/ApiClient';
import TestCommons from '../../lib/TestCommons';
import MainPageFrame from '../../pages/main_page/MainPageFrame';
import Preferences from '../../pages/Preferences';
import VolumeSafety from '../../lib/VolumeSafety';
import Strategy from '../../lib/Strategy';
import MarketDepth from '../../pages/main_page/marketview/MarketDepth';
import VolumeSafetyDialog from '../../pages/VolumeSafetyDialog';
import OrderBook from '../../pages/main_page/marketview/OrderBook';
import OrderTable from '../../pages/main_page/marketview/OrderTable';

describe('BC339 Volume Safety - Net Configuration', function BC339Test () {
  // Framwework vars
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let logger = null;

  // Page object vars
  let mainPageFrame = null;
  let common = null;
  let mainPage = null;
  let preferences = null;
  let marketDepth = null;
  let volumeSafetyDialog = null;
  let strategyRow = null;
  let orderBook = null;
  let orderTable = null;

  before(() => {
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
    context = bootstrapper.getInstance();
    logger = context.getLogger();
    logger.info('Framework setup complete.');

    // Page object  setup.
    common = new TestCommons(context);
    mainPage = new MainPageFrame(context);
    marketDepth = new MarketDepth(context);
    preferences = new Preferences(context);
    volumeSafetyDialog = new VolumeSafetyDialog(context);
    orderBook = new OrderBook(context);
    orderTable = new OrderTable(context);

    expect(browser).to.exist;
  });

  after(async () => {
    await mainPageFrame.switchToWindow();
    await mainPage.clickSettings();
    await preferences.removeVSConfiguration();
    const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
    shellExec(clearDownScript);
  });

  async function start ({email, password}) {
    mainPageFrame = await common.login(email, password);
  }


  describe('Volume safety trigger - net', () => {
    let trader = {};
    let lpResponder1 = {};
    let lpResponder1Client = null;
    let strategyId = 0;
    let rfsWindow = null;
    const delta = 59;
    const strike = 3100;
    const refPrice = 3700;
    const vsTriggerNetVol = 200;
    const vsTriggerTime = 10000;
    const rfsTimeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout + frameworkConfig.tradePhaseTimeout + frameworkConfig.shortTimeout;

    const volumeSafetyNetOnly = new VolumeSafety(UNDERLYING.sx5e, '', vsTriggerNetVol, '', vsTriggerTime);

    let strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, refPrice, delta, POLARITY.negative, null, null);
    strategy.addLeg(POLARITY.positive, 'C', 'DEC23', strike, 1);

    it('Setup', () => {
      trader = common.getTrader('AUTTR10');
      lpResponder1 = common.getTrader('AUTTR01');
    });

    it('The trader should login via the UI initially', async () => {
      await start(trader);
      const username = await mainPageFrame.getUsername();
      expect(username)
        .to
        .equal(trader.fenicsGoUsername, 'Unexpected username on application window');
    });

    it('The trader should be able to add a new volume safety configuration', async () => {
      await mainPage.clickSettings();
      await preferences.addVolumeSafetyConfiguration(volumeSafetyNetOnly);
      await preferences.submitVSConfiguration();
      await preferences.verifyVSExists();
    });

    it('The trader initiator should have a strategy to initiate', async () => {
      lpResponder1Client = new ApiClient(lpResponder1);
      await lpResponder1Client.login();

      strategyId = await common.getStrategyId(strategy);
      if (strategyId === null) {
        await mainPageFrame.clickCreateStrategyHeader();
        const strategyTab = await mainPageFrame.getCreateStrategyTab();
        strategy = await strategyTab.addNewStrategy(strategy);
        await strategyTab.btnSubmitClick();
        const strategyFound = await common.waitUntilStrategyFound(strategy);
        if (strategyFound) {
          strategyId = await common.getStrategyId(strategy);
        }
      }
      const strategyExist = strategyId !== null;
      expect(strategyExist).to.equal(
        true,
        'Could not find Strategy.'
      );
    });

    it('The traders should  see volume safety breach notifications for Order Book workflow', async () => {
      const priceOffset = 2.5;
      const rfsSize = 7500;

      strategyRow = await orderTable.getTableRow(strategy);
      await strategyRow.clickStatus();

      await marketDepth.clickRequestQuotesBtn();
      await lpResponder1Client.respondToRFS(strategyId);
      let midPrice = await lpResponder1Client.getStrategyMidPrice(strategyId);
      midPrice = parseInt(midPrice, 10);
      const rfsBid = midPrice;
      const rfsAsk = midPrice + priceOffset;

      rfsWindow = new Rfs(context);
      await rfsWindow.switchToWindow('Q', strategy.underlying, strategy.strategy.shortName, strategy.expiry)
      logger.info(`Switched to RFS window for ${strategy.underlying}`);

      const windowLetter = await rfsWindow.getWindowLetter();
      expect(windowLetter)
        .to
        .equal('Q', 'Expected RFS window letter to be Q');

      const phase = await rfsWindow.getPhase();
      logger.info(phase);
      await lpResponder1Client.rfsQuote(strategyId, rfsBid, rfsAsk, rfsSize);

      await rfsWindow.waitUntilResponderCount(1);
      const responded = await rfsWindow.getResponded();
      expect(responded)
        .to
        .include('1/', 'RFS window expected one rfs participants');

      await rfsWindow.waitUntilRfsTimedout(rfsTimeout);
      await rfsWindow.rfsTimedoutMsgExists();
      await rfsWindow.btnOkClick();
      await mainPageFrame.switchToWindow();


      await marketDepth.clickBuy(rfsAsk, rfsSize);
      await orderBook.enterBid(rfsAsk, rfsSize);

      await browser.waitUntil(() => orderBook.btnSubmitEnabled(), frameworkConfig.veryShortTimeout);
      await orderBook.btnSubmitClick();

      await volumeSafetyDialog.switchToDialogWindow();
      logger.info('Switched to volume safety trigger dialog window..');
      await volumeSafetyDialog.verifyDialogExists();
      await volumeSafetyDialog.verifyDialogTitle('net');
      await volumeSafetyDialog.verifyDialogInfo(strategy.underlying, strategy.strategy.shortName, strategy.expiry, strategy.strike, strategy.referencePrice, strategy.delta);
      await volumeSafetyDialog.clickCloseButton();

      await mainPageFrame.switchToWindow();
      strategyRow = await orderTable.getTableRow(strategy);
      const status = await strategyRow.getStatusText();
      logger.info(`Status of order is ${status}`);
      expect(status)
        .to
        .equal('VC', 'Market View Strategy Status');

      await strategyRow.verifyStatusColour(COLOR_PURPOSE.VC_COLOR);
    });

    it('users should logout', async () => {
      await lpResponder1Client.logout();
    });
  });
});
