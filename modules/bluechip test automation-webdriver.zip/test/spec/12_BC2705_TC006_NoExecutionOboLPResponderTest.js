import Strategy from '../../lib/Strategy';
import {MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import {expect} from 'chai';
import ApiClient from '../../utilities/api/ApiClient';
import Rfs from '../../pages/child_windows/Rfs';
import {frameworkConfig} from '../../config/framework.config';
import {Bootstrap} from '@fenics/fenics-test-core';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {join} from 'path';
import {shellExec} from '../../utilities/framework/shell-exec';

// Framwework vars
const browser = global.browser;
let bootstrapper = null;
let context = null;
let logger = null;

// Page object vars
let mainPageFrame = null;
let common = null;

before(() => {
  bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
  context = bootstrapper.getInstance();
  logger = context.getLogger();
  logger.info('Framework setup complete.');

  // Page object  setup.
  common = new TestCommons(context);

  expect(browser).to.exist;
});

after(() => {
  const clearDownScript = require.resolve(join('../../', frameworkConfig.clearDownScript));
  shellExec(clearDownScript);
});

async function start ({email, password}) {
  mainPageFrame = await common.login(email, password);
}

describe('BC2705 TC006: As a NLP trader who is participating in an OBO RFS without interest my quote should not match another NLP trader who belongs to the same legal entity', () => {
  let broker = null;
  let brokerClient = null;
  let nlpTraderOne = null;
  let nlpTraderTwo = null;
  let nlpTraderTwoClient = null;
  let strategyId = null;
  let rfsWindow = null;

  const strategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 2225, 300, POLARITY.positive, null, null);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 700, 1);
  strategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 2100, 1);

  it('Should get the test users', () => {
    broker = common.getBroker('AUTBR03');
    nlpTraderOne = common.getTrader('AUTTR06');
    nlpTraderTwo = common.getTrader('AUTTR07');
  });

  it('The broker should have a strategy to trade', async () => {
    await start(broker);
    strategyId = await common.getStrategyId(strategy);

    if (strategyId === null) {
      await mainPageFrame.clickCreateStrategyHeader();
      const strategyTab = await mainPageFrame.getCreateStrategyTab();
      await strategyTab.addNewStrategy(strategy);
      await strategyTab.btnSubmit.click();
      await common.waitUntilStrategyFound(strategy);
      strategyId = await common.getStrategyId(strategy);
    }

    const hasStrategyId = strategyId !== null;
    expect(hasStrategyId)
      .to
      .equal(true, 'Could not find strategy');
  });

  it('Users should login', async () => {
    await start(nlpTraderOne);

    brokerClient = new ApiClient(broker);
    await brokerClient.login();

    nlpTraderTwoClient = new ApiClient(nlpTraderTwo);
    await nlpTraderTwoClient.login();
  });

  it('Broker should initiate an RFS', async () => {
    await brokerClient.initiateRFS(strategyId);
    await nlpTraderTwoClient.respondToRFS(strategyId);
  });

  it('I should open the RFS window', async () => {
    await mainPageFrame.switchToWindow();
    const marketView = mainPageFrame.getMarketViewTab();
    await marketView.clickTabEuroStoxx();
    const strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
    await strategyRow.waitUntilStatus('RFS');
    await strategyRow.clickStatus();
    rfsWindow = await new Rfs(context);
    const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);

    expect(foundWindow)
      .to
      .equal(true, 'Expected to find the RFS window');
  });

  it('I should wait for the RFS to transition to trading phase', async () => {
    const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout;
    await rfsWindow.waitUntilPhase('TRADING', timeout);
    const rfsPhase = await rfsWindow.getPhase();

    expect(rfsPhase)
      .to
      .equal('TRADING', 'RFS should be in TRADING phase');
  });

  it('The broker should activate the trading users', async () => {
    await brokerClient.rfsSelectTrader(strategyId, nlpTraderTwo.userShortName);
  });

  it('My legal entity colleague should respond to the RFS with a quote', async () => {
    const activated = await browser.waitUntil(() => nlpTraderTwoClient.userActivated(strategyId), frameworkConfig.veryShortTimeout);

    expect(activated)
      .to
      .equal(true, 'User should be activated');

    await nlpTraderTwoClient.rfsQuote(strategyId, 100, 105, 3500);
  });

  it('I should be blocked from submitting a quote as a colleague has responded to the RFS', async () => {
    const colleagueResponded = await rfsWindow.waitUntilColleagueRespondedMsg(frameworkConfig.shortTimeout);
    expect(colleagueResponded).to.equal(true, 'Colleague has responded to the RFS therefore I should see RFS colleague responded message');
  });

  it('My legal entity colleague should subject the quote', async () => {
    await nlpTraderTwoClient.rfsSubject(strategyId);
  });

  it('Users should logout', async () => {
    await brokerClient.logout();
    await nlpTraderTwoClient.logout();
  });
});
