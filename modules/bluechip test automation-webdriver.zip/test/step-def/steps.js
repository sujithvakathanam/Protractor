import {Bootstrap} from '@fenics/fenics-test-core';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import TestCommons from '../../lib/TestCommons';
import {expect} from 'chai';
import {Given as given, When as when, Then as then} from 'cucumber';
import ApiClient from '../../utilities/api/ApiClient';
import ToastNotification from '../../pages/child_windows/ToastNotification';
import Strategy from '../../lib/Strategy';
import {COLOR_PURPOSE, MARKET, OPTION_TYPE, POLARITY, STRATEGY, STYLE, UNDERLYING} from '../../constant/GenericType';
import Rfs from '../../pages/child_windows/Rfs';
import VolumeClearing from '../../pages/child_windows/VolumeClearing';
import MarketViewTabs from '../../constant/MarketViewTabs';

const browser = global.browser;
let bootstrapper = null;
let context = null;
let logger = null;
let mainPageFrame = null;
let mainWindowHandle = null;
let common = null;
let toastNotification = null;
let broker = null;
let brokerClient = null;
let lpTraderClient = null;
let lpTrader = null;
let strategyId = null;
let strategy = null;
let strategyTitle = null;
let trader = null;
let traderClient = null;
let trader2 = null;
let trader2Client = null;
let trader3 = null;
let trader3Client = null;
let strategyRow = null;
let rfsWindow = null;
let tradersCovered = [];
let traderShortId = '';
const threeDp = 3;
let lpTraderDarkQuoteSellPrice = null;
let lpTraderDarkQuoteBuyPrice = null;
let lpTraderDarkQuoteSize = null;
let lpTraderLitQuoteBuyPrice = null;
let lpTraderLitQuoteSellPrice = null;
let lpTraderLitQuoteSize = null;
let lpTraderTradeQuoteBuyPrice = null;
let lpTraderTradeQuoteSellPrice = null;
let lpTraderTradeQuoteSize = null;
let tradeQuoteSize = null;
let nlpTraderTradeQuoteBuyPrice = null;
let nlpTraderTradeQuoteSellPrice = null;
let trader2TradeQuoteSize = null;
let nlpTrader2TradeQuoteBuyPrice = null;
let nlpTrader2TradeQuoteSellPrice = null;
let vcWindow = null;


/* eslint-disable no-magic-numbers */
const strangleStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.strangle, STYLE.euro, 515, 150, POLARITY.positive, null, null);
strangleStrategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC24', 700, 1);
strangleStrategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC24', 2100, 1);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const ratioRiskyStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 250, 5, POLARITY.positive, null, null);
ratioRiskyStrategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, 1);
ratioRiskyStrategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 200, 2.25);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const ratioRiskyStrategyWithDeltaOver100 = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.ratioRisky, STYLE.euro, 3350, 120, POLARITY.positive, null, null);
ratioRiskyStrategyWithDeltaOver100.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 100, 1);
ratioRiskyStrategyWithDeltaOver100.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 200, 2.25);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const putCalendarStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.putCalendar, STYLE.euro, 221, 15, POLARITY.negative, null, null);
putCalendarStrategy.addLeg(null, null, 'DEC25', 700, null);
putCalendarStrategy.addLeg(null, null, 'DEC26', null, null);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const callSpreadStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callSpread, STYLE.euro, 3213, 65, POLARITY.negative, null, null);
callSpreadStrategy.addLeg(null, null, 'DEC25', 700, null);
callSpreadStrategy.addLeg(null, null, 'DEC26', 2100, null);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const callStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.call, STYLE.euro, 200, 21, POLARITY.negative, null, null);
callStrategy.addLeg(POLARITY.positive, OPTION_TYPE.put, 'DEC25', 300, 1);
/* eslint-enable no-magic-numbers */

/* eslint-disable no-magic-numbers */
const callFlyStrategy = new Strategy(MARKET.euroSTOXX, UNDERLYING.sx5e, STRATEGY.callFly, STYLE.euro, 3000, 220, POLARITY.positive, null, null);
callFlyStrategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 3000, 1);
callFlyStrategy.addLeg(POLARITY.negative, OPTION_TYPE.call, 'DEC25', 3200, 1.75);
callFlyStrategy.addLeg(POLARITY.positive, OPTION_TYPE.call, 'DEC25', 3300, 1);
/* eslint-enable no-magic-numbers */


/**
 * Given definitions
 */
given('I launch Fenics GO', () => {
  bootstrapper = new Bootstrap([frameworkConfig, usersConfig]);
  context = bootstrapper.getInstance();
  logger = context.getLogger();
  logger.info('Framework setup complete.');

  // Page object  setup.
  common = new TestCommons(context);

  expect(browser).to.exist;
  logger.info(browser.sessionId);
});

async function start ({email, password}) {
  mainPageFrame = await common.login(email, password);
  mainWindowHandle = await browser.getCurrentTabId();
  toastNotification = await new ToastNotification(context);
}

given('I login as trader {string}', async user => {
  common = new TestCommons(context);
  trader = common.getTrader(user);
  await start(trader);
  logger.info(`Logged in with NLP trader user ${trader.email}.`);
});

given('I login as LP trader {string}', async user => {
  common = new TestCommons(context);
  lpTrader = common.getTrader(user);
  await start(lpTrader);
  logger.info(`Logged in with LP trader user ${lpTrader.email}.`);
});

given('I login as broker {string}', async user => {
  broker = common.getBroker(user);
  await start(broker);
  logger.info(`Logged in with broker user ${broker.email}.`);
});

given('I login as a broker client {string}', user => {
  broker = common.getBroker(user);
  brokerClient = new ApiClient(broker);
  logger.info(`Logged in with user via API ${broker.email}.`);
});

given('logged in {string} user UUID is displayed', async (userType) => {
  const actualUsername = await mainPageFrame.getUsername();
  if (userType === 'broker') {
    expect(actualUsername)
      .to
      .equal(
        broker.fenicsGoUsername,
        'Expected to find username of logged in user main page'
      );
  } else if (userType === 'NLP Trader') {
    expect(actualUsername)
      .to
      .equal(
        trader.fenicsGoUsername,
        'Expected to find username of logged in user main page'
      );
  }
});

given('I confirm logout {string}', async () => {
  logger.info('User logging out');
  await mainPageFrame.clickLogout();
  await mainPageFrame.clickLogoutConfirmOk();
});

given('I click {string} market view tab', async marketView => {
  const mvTab = await mainPageFrame.getMarketViewTab();
  await mainPageFrame.clickMarketViewHeader();
  if (marketView === 'EUROSTOXX') {
    logger.info('Clicking Eurostoxx tab');
    await mvTab.clickSubTab(MarketViewTabs.EUROSTOXX);
  }
});

given('a {string} strategy exists', async (strategyType) => {
  if (strategyType === 'RATIO RISKY DELTA OVER 100') {
    strategy = ratioRiskyStrategyWithDeltaOver100;
  } else if (strategyType === 'RATIO RISKY') {
    strategy = ratioRiskyStrategy;
  } else if (strategyType === 'CALL FLY') {
    strategy = callFlyStrategy;
  } else if (strategyType === 'PUT CALENDAR') {
    strategy = putCalendarStrategy;
  } else if (strategyType === 'CALL SPREAD') {
    strategy = callSpreadStrategy;
  } else if (strategyType === 'STRANGLE') {
    strategy = strangleStrategy;
  } else if (strategyType === 'CALL') {
    strategy = callStrategy;
  }
  strategyId = await common.getStrategyId(strategy);
  if (strategyId === null) {
    await mainPageFrame.clickCreateStrategyHeader();
    const strategyTab = await mainPageFrame.getCreateStrategyTab();
    await strategyTab.addNewStrategy(strategy);
    await strategyTab.btnSubmit.click();
    await common.waitUntilStrategyFound(strategy);
    strategyId = await common.getStrategyId(strategy);
  }
  expect(strategyId !== null).to.equal(true, 'Could not find strategy');
});

given('broker initiates an RFS', async () => {
  brokerClient = new ApiClient(broker);
  await brokerClient.login();
  await brokerClient.initiateRFS(strategyId);
});

given('LP trader {string} is a relevant responder', async traderUser => {
  lpTrader = common.getTrader(traderUser);
  lpTraderClient = new ApiClient(lpTrader);
  await lpTraderClient.login();
});

given('NLP trader {string} is a relevant responder', async traderUser => {
  trader = common.getTrader(traderUser);
  traderClient = new ApiClient(trader);
  await traderClient.login();
  await traderClient.respondToRFS(strategyId);
});

given('LP trader {string} responds to an ongoing direct RFS', async user => {
  lpTrader = common.getTrader(user);
  lpTraderClient = new ApiClient(lpTrader);
  logger.info(`Logged in with user via API ${lpTrader.email}.`);
  await lpTraderClient.login();

  traderClient = new ApiClient(trader);
  await traderClient.login();
  await traderClient.initiateRFS(strategyId);
});

given('LP trader {string} initiates an RFS', async user => {
  lpTrader = common.getTrader(user);
  lpTraderClient = new ApiClient(lpTrader);
  logger.info(`Logged in with user via API ${lpTrader.email}.`);

  await lpTraderClient.login();
  await lpTraderClient.initiateRFS(strategyId);
});

given('LP trader responds with a quote in dark phase {string} {string} {string}', async (darkQuoteBidPrice, darkQuoteAskPrice, darkQuoteAmount) => {
  lpTrader.darkQuote = {
    buyPrice  : darkQuoteBidPrice,
    sellPrice : darkQuoteAskPrice,
    amount    : darkQuoteAmount
  };
  await lpTraderClient.respondToRFS(strategyId);
  await browser.waitUntil(
    () => lpTraderClient.rfsQuote(
      strategyId,
      lpTrader.darkQuote.buyPrice,
      lpTrader.darkQuote.sellPrice,
      lpTrader.darkQuote.amount
    )
    ,
    frameworkConfig.mediumTimeout
  );

  lpTraderDarkQuoteBuyPrice = darkQuoteBidPrice;
  lpTraderDarkQuoteSellPrice = darkQuoteAskPrice;
  lpTraderDarkQuoteSize = darkQuoteAmount;

  logger.info(`Dark Quote Sell price is ${lpTraderDarkQuoteSellPrice}`);
  logger.info(`Dark Quote Buy price is ${lpTraderDarkQuoteBuyPrice}`);
  logger.info(`Dark Quote Size is ${lpTraderDarkQuoteSize}`);
});

given('LP trader responds with a quote in lit phase {string} {string} {string}', async (litQuoteBidPrice, litQuoteAskPrice, litQuoteAmount) => {
  lpTrader.litQuote = {
    buyPrice  : litQuoteBidPrice,
    sellPrice : litQuoteAskPrice,
    amount    : litQuoteAmount
  };
  await lpTraderClient.respondToRFS(strategyId);
  await browser.waitUntil(
    () => lpTraderClient.rfsQuote(
      strategyId,
      lpTrader.litQuote.buyPrice,
      lpTrader.litQuote.sellPrice,
      lpTrader.litQuote.amount
    ),
    frameworkConfig.shortTimeout
  );
  lpTraderLitQuoteBuyPrice = litQuoteBidPrice;
  lpTraderLitQuoteSellPrice = litQuoteAskPrice;
  lpTraderLitQuoteSize = litQuoteAmount;

  logger.info(`Lit Quote Sell price is ${lpTraderLitQuoteSellPrice}`);
  logger.info(`Lit Quote Buy price is ${lpTraderLitQuoteBuyPrice}`);
  logger.info(`Lit Quote Size is ${lpTraderLitQuoteSize}`);
});

given('LP trader responds with a quote in trading phase {string} {string} {string}', async (tradeQuoteBidPrice, tradeQuoteAskPrice, tradeQuoteAmount) => {
  await lpTraderClient.respondToRFS(strategyId);
  await browser.waitUntil(
    () => lpTraderClient.rfsQuote(
      strategyId,
      tradeQuoteBidPrice,
      tradeQuoteAskPrice,
      tradeQuoteAmount
    ),
    frameworkConfig.mediumTimeout
  );

  lpTraderTradeQuoteBuyPrice = tradeQuoteBidPrice;
  lpTraderTradeQuoteSellPrice = tradeQuoteAskPrice;
  lpTraderTradeQuoteSize = tradeQuoteAmount;

  logger.info(`Trade Quote Sell price is ${lpTraderTradeQuoteSellPrice}`);
  logger.info(`Trade Quote Buy price is ${lpTraderTradeQuoteBuyPrice}`);
  logger.info(`Trade Quote Size is ${lpTraderTradeQuoteSize}`);
});

given('I initiate RFS', async () => {
  await mainPageFrame.clickMarketViewHeader();
  strategyRow = await mainPageFrame.getMarketViewTab()
    .getEuroStoxxTable()
    .getTableRow(strategy);
  await strategyRow.clickStatus();
  logger.info('Found newly created strategy in Market View.');

  const marketDepth = await mainPageFrame.getMarketViewTab()
    .getMarketDepthTab();
  const btnEnabled = await marketDepth.requestQuotesBtnEnabled();
  expect(btnEnabled)
    .to
    .equal(true, 'Request quotes button on Market Depth Tab.');

  await marketDepth.clickRequestQuotesBtn();
  logger.info('Clicked request for quotes.');
});

given('market view displays LP Request flag', async () => {
  await strategyRow.waitUntilInitiator('LP', frameworkConfig.shortTimeout);
  const initiatorText = await strategyRow.getInitiatorBadgeText();
  const expectedInitiatorBadgeText = 'LP';
  expect(initiatorText)
    .to
    .equal(expectedInitiatorBadgeText, 'Expected the strategy initiator to be LP and LP flag to be displayed');
  logger.info('LP badge text and LP badge found in Market View.');

  await strategyRow.verifyInitiatorBadgeColour(COLOR_PURPOSE.LP_REQUEST);
});

given('market view does not display the LP Request flag', async () => {
  await strategyRow.waitUntilStatus('RFS');
  expect(strategyRow.getInitiatorBadgeText())
    .to
    .throw;
  logger.info('LP badge text and LP badge not found in Market View as expected.');
});

given('the RFS child window opens', async () => {
  rfsWindow = new Rfs(context);
  await rfsWindow.switchToWindow(strategy.underlying, strategy.strategy.shortName, strategy.expiry);
  const rfsWindowTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);
  logger.info(`Switched to RFS window for ${strategy.underlying} ${strategy.strategy.shortName} ${strategy.expiry}`);

  const windowTitle = await rfsWindow.getTitle();
  expect(windowTitle)
    .to
    .equal(rfsWindowTitle, 'RFS window title');

  const delta = await rfsWindow.getDelta();
  expect(delta)
    .to
    .equal(strategy.getDisplayDelta().toString(), 'RFS window delta');

  const ref = await rfsWindow.getRef();
  expect(ref)
    .to
    .equal(strategy.referencePrice.toString(), 'RFS window ref');
});

given('the RFS child window has window letter R', async () => {
  const windowLetter = await rfsWindow.getWindowLetter();
  expect(windowLetter)
    .to
    .equal('R', 'Expected RFS window letter to be R');
});

given('the RFS child window has window letter Q', async () => {
  const windowLetter = await rfsWindow.getWindowLetter();
  expect(windowLetter)
    .to
    .equal('Q', 'Expected RFS window letter to be Q');
});

given('I pause', async () => {
  await browser.pause(frameworkConfig.mediumTimeout);
});

given('market view displays an ongoing broker initiated RFS I can participate in', async () => {
  await mainPageFrame.clickMarketViewHeader();
  const marketView = await mainPageFrame.getMarketViewTab();
  await marketView.clickTabEuroStoxx();
  await common.waitUntilStrategyFound(strategy, frameworkConfig.mediumTimeout);
  strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
  await strategyRow.waitUntilStatus('RFS', frameworkConfig.mediumTimeout);
  const status = await strategyRow.getStatusText();
  const initiator = await strategyRow.getInitiator();
  await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
  expect(status)
    .to
    .equal('RFS', 'Strategy status should be RFS');
  expect(initiator)
    .to
    .equals(broker.leShortCode, 'Unexpected broker entity short code against strategy');
});

given('market view displays an ongoing LP initiated RFS I can participate in', async () => {
  await mainPageFrame.clickMarketViewHeader();
  const marketView = await mainPageFrame.getMarketViewTab();
  await marketView.clickTabEuroStoxx();
  await lpTraderClient.initiateRFS(strategyId);
  await common.waitUntilStrategyFound(strategy, frameworkConfig.mediumTimeout);
  strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
  await strategyRow.waitUntilStatus('RFS', frameworkConfig.mediumTimeout);
  const status = await strategyRow.getStatusText();
  await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
  expect(status)
    .to
    .equal('RFS', 'Strategy status should be RFS');
});


given('an ongoing RFS is displayed with a grey RFS status icon', async () => {
  const strategyFound = await common.waitUntilStrategyFound(strategy);
  expect(strategyFound)
    .to
    .equal(true, 'Strategy should be visible in Market View');
  strategyRow = await mainPageFrame.getMarketViewTab().getEuroStoxxTable()
    .getTableRow(strategy);
  logger.info('Found strategy in Market View.');
  await strategyRow.waitUntilStatus('RFS');
  const actualStatus = await strategyRow.getStatusText();
  const expectedStatus = 'RFS';
  expect(actualStatus)
    .to
    .equal(expectedStatus, 'Expected the strategy status to be RFS');
  logger.info('Status RFS found in Market View.');
  const flag = await strategyRow.statusHasInactiveFlag();
  expect(flag)
    .to
    .equal(true, 'Status inactive flag should exist');
  await strategyRow.verifyStatusColour(COLOR_PURPOSE.INACTIVE_COLOR);
  logger.info('Status has inactive flag');
});

given('market view displays RFS status icon in blue', async () => {
  const status = await strategyRow.waitUntilStatus('RFS', frameworkConfig.shortTimeout);
  expect(status)
    .to
    .equal(true, 'Strategy status in market view should be RFS');
  await strategyRow.verifyStatusColour(COLOR_PURPOSE.RFS_COLOR);
});

given('I receive an RFS toast message', async () => {
  const rfsToastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);
  expect(rfsToastMsgs.length)
    .to
    .equal(1, 'Trader should not see any RFS toast messages');
});

given('I do not receive an RFS toast message', async () => {
  let toastMsgs = null;
  strategyTitle = strategy.strategy.shortName.concat(' ', strategy.expiry);

  try {
    await browser.waitUntil(
      async () => {
        toastMsgs = await toastNotification.getRfsResponderToastMsg(strategy);

        return toastMsgs.length > 0;
      }
      , frameworkConfig.shortTimeout, `Timed out after ${frameworkConfig.shortTimeout}ms, Could not find RFS responder toast message.`
    );
  } catch (err) {
    logger.info(err);
  }

  expect(toastMsgs.length)
    .to
    .equal(0, 'Expected responder toast message to not exist');
});

given('I receive an RFS trade notification alert', async () => {
  const notification = await mainPageFrame.notificationsPanel
    .notifications
    .getRfsResponderInvite(strategy);
  const notificationFound = await notification.waitForExist();
  expect(notificationFound)
    .to
    .equal(true);
});

given('I do not receive an RFS trade notification alert', async () => {
  const notification = await mainPageFrame.notificationsPanel
    .notifications
    .getRfsResponderInvite(strategy);
  const notificationFound = await notification.waitForExist();
  expect(notificationFound)
    .to
    .equal(false);
});

given('I open the RFS child window via the RFS status icon', async () => {
  await mainPageFrame.switchToWindow();
  const marketView = mainPageFrame.getMarketViewTab();
  await marketView.clickTabEuroStoxx();
  strategyRow = await marketView.getEuroStoxxTable().getTableRow(strategy);
  await strategyRow.clickStatus();
  rfsWindow = await new Rfs(context);
  const foundWindow = await rfsWindow.switchToWindow('R', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
  expect(foundWindow)
    .to
    .equal(true, 'Expected to find the RFS window');
});

given('I cannot activate traders', async () => {
  const addTraderBtnEnabled = await rfsWindow.btnActivateEnabled();
  expect(addTraderBtnEnabled)
    .to
    .equal(false, 'RFS Button ACTIVATE should not be enabled');
  const ddTrader = await rfsWindow.ddActivateUser;
  const dropDownEnabled = await ddTrader.getDropDownEnabled();
  expect(dropDownEnabled)
    .to
    .equal(false, 'RFS activate traders drop down list should be disabled');
});

given('I can activate traders', async () => {
  const btnActivateEnabled = await rfsWindow.btnActivateEnabled();
  expect(btnActivateEnabled)
    .to
    .equal(false, 'ACTIVATE trader button should be disabled');
  const activateUsersList = await rfsWindow.ddActivateUser;
  const selectEnabled = await activateUsersList.getDropDownEnabled();
  expect(selectEnabled)
    .to
    .equal(true, 'ACTIVATE user dropdown list should be enabled');
});

given('broker activates a trader {string} using activation dropdown', async traderUser => {
  trader = common.getTrader(traderUser);
  traderClient = new ApiClient(trader);
  await traderClient.login();

  traderShortId = trader.leShortCode.concat(' - ', trader.userShortName);
  const activateUserDropDown = await rfsWindow.ddActivateUser;
  await activateUserDropDown.setSelected(traderShortId);
  const btnEnabled = await rfsWindow.btnActivateEnabled();
  expect(btnEnabled)
    .to
    .equal(true, 'Activate user button should be enabled');
  await rfsWindow.btnActivateClick();
  const userFound = await rfsWindow.waitUntilActivatedTraderExists(traderShortId);
  expect(userFound)
    .to
    .equal(true, `RFS trader ${traderShortId} should be added to the RFS`);
});

given('broker activates a second trader {string} using activation dropdown', async traderUser => {
  trader2 = common.getTrader(traderUser);
  trader2Client = new ApiClient(trader2);
  await trader2Client.login();

  traderShortId = trader2.leShortCode.concat(' - ', trader2.userShortName);
  const activateUserDropDown = await rfsWindow.ddActivateUser;
  await activateUserDropDown.setSelected(traderShortId);
  const btnEnabled = await rfsWindow.btnActivateEnabled();
  expect(btnEnabled)
    .to
    .equal(true, 'Activate user button should be enabled');
  await rfsWindow.btnActivateClick();
  const userFound = await rfsWindow.waitUntilActivatedTraderExists(traderShortId);
  expect(userFound)
    .to
    .equal(true, `RFS trader ${traderShortId} should be added to the RFS`);
});

given('broker activates a third trader {string} using activation dropdown', async traderUser => {
  trader3 = common.getTrader(traderUser);
  trader3Client = new ApiClient(trader3);
  await trader3Client.login();

  traderShortId = trader3.leShortCode.concat(' - ', trader3.userShortName);
  const activateUserDropDown = await rfsWindow.ddActivateUser;
  await activateUserDropDown.setSelected(traderShortId);
  const btnEnabled = await rfsWindow.btnActivateEnabled();
  expect(btnEnabled)
    .to
    .equal(true, 'Activate user button should be enabled');
  await rfsWindow.btnActivateClick();
  const userFound = await rfsWindow.waitUntilActivatedTraderExists(traderShortId);
  expect(userFound)
    .to
    .equal(true, `RFS trader ${traderShortId} should be added to the RFS`);
});

given('broker activates trader', async () => {
  await brokerClient.rfsSelectTrader(strategyId, trader.userShortName);
  await rfsWindow.waitUntilEnabled();
});

given('activation overlay is displayed', async () => {
  await rfsWindow.verifyActivationOverlayAndDismiss(frameworkConfig.shortTimeout);
});

given('activated trader {string} is removed from the activation list for broker {string}', async (activatedTrader, brokerUser) => {
  const activateUserList = await rfsWindow.ddActivateUser;
  const coveredTraders = await activateUserList.getSelections();
  if (activatedTrader === 'AUTTR02' && brokerUser === 'AUTBR03') {
    const expectedUsers = ['DEA - TR06', 'DEA - TR07'];
    expect(coveredTraders)
      .to
      .deep
      .equal(expectedUsers);
  }
});

given('activated trader is displayed on the RFS child window', async () => {
  const activatedUser = await rfsWindow.getActivatedTrader(traderShortId);
  expect(activatedUser)
    .to
    .equal(traderShortId, 'RFS activated trader');
  const tooltip = await rfsWindow.getActivatedTraderToolTip(traderShortId);
  const expectedToolTip = trader.firstName.concat(' ', trader.lastName, ' - ', trader.desk, ' - ', trader.legalEntity);
  expect(tooltip)
    .to
    .equal(expectedToolTip, 'RFS activated trader tooltip');
});

given('I cannot activate a trader that is not logged in {string}', async traderUser => {
  trader3 = common.getTrader(traderUser);
  trader3 = common.getTrader(traderUser);
  traderShortId = trader3.leShortCode.concat(' - ', trader3.userShortName);
  const activateUserDropDown = await rfsWindow.ddActivateUser;
  await activateUserDropDown.setSelected(traderShortId);
  const btnEnabled = await rfsWindow.btnActivateEnabled();
  expect(btnEnabled)
    .to
    .equal(true, 'Activate user button should be enabled');
  await rfsWindow.btnActivateClick();
  const traderNotLoggedInMsgFound = await rfsWindow.waitUntilTraderNotLoggedInMsg();
  expect(traderNotLoggedInMsgFound)
    .to
    .equal(true, 'Expected to find trader not logged in message');
});

given('RFS child window is updated when trader submits a new quote', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.waitUntilPrice(
    nlpTraderTradeQuoteBuyPrice.concat('.000'),
    nlpTraderTradeQuoteSellPrice.concat('.000')
  );
  let bidPrice = await rowOne.getBidPrice();
  let bidSize = await rowOne.getBidSize();
  let bidTrader = await rowOne.getBidTrader();
  let askPrice = await rowOne.getAskPrice();
  let askSize = await rowOne.getAskSize();
  let askTrader = await rowOne.getAskTrader();
  expect(bidPrice)
    .to
    .equal(nlpTraderTradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(tradeQuoteSize);
  expect(bidTrader)
    .to
    .equal(trader.userDisplayId);
  expect(askPrice)
    .to
    .equal(nlpTraderTradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(tradeQuoteSize);
  expect(askTrader)
    .to
    .equal(trader.userDisplayId);

  const rowTwo = await rfsWindow.getBidOfferRow(2);
  await rowTwo.waitUntilPrice(
    lpTraderTradeQuoteBuyPrice.concat('.000'),
    lpTraderTradeQuoteSellPrice.concat('.000')
  );
  bidPrice = await rowTwo.getBidPrice();
  bidSize = await rowTwo.getBidSize();
  bidTrader = await rowTwo.getBidTrader();
  askPrice = await rowTwo.getAskPrice();
  askSize = await rowTwo.getAskSize();
  askTrader = await rowTwo.getAskTrader();
  expect(bidPrice)
    .to
    .equal(lpTraderTradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(lpTraderTradeQuoteSize);
  expect(bidTrader)
    .to
    .equal('');
  expect(askPrice)
    .to
    .equal(lpTraderTradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(lpTraderTradeQuoteSize);
  expect(askTrader)
    .to
    .equal('');

  // eslint-disable-next-line no-magic-numbers
  const rowThree = await rfsWindow.getBidOfferRow(3);
  await rowThree.waitUntilPrice(
    nlpTrader2TradeQuoteBuyPrice.concat('.000'),
    nlpTrader2TradeQuoteSellPrice.concat('.000')
  );
  bidPrice = await rowThree.getBidPrice();
  bidSize = await rowThree.getBidSize();
  bidTrader = await rowThree.getBidTrader();
  askPrice = await rowThree.getAskPrice();
  askSize = await rowThree.getAskSize();
  askTrader = await rowThree.getAskTrader();
  expect(bidPrice)
    .to
    .equal(nlpTrader2TradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(trader2TradeQuoteSize);
  expect(bidTrader)
    .to
    .equal(trader2.userDisplayId);
  expect(askPrice)
    .to
    .equal(nlpTrader2TradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(trader2TradeQuoteSize);
  expect(askTrader)
    .to
    .equal(trader2.userDisplayId);

  // eslint-disable-next-line no-magic-numbers
  const rowFour = await rfsWindow.getBidOfferRow(4);
  const isEmptyRow = await rowFour.isEmptyRow();
  expect(isEmptyRow)
    .to
    .equal(true, 'RFS quotes table should not contain quotes on the 4th row');
});

given('priority LP bid price is displayed on top of child window market depth rows', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  const rowOneCellBidValue = lpTraderTradeQuoteBuyPrice
    .concat('.000\n*');
  await rowOne.waitUntilPrice(
    rowOneCellBidValue,
    lpTraderTradeQuoteSellPrice.concat('.000')
  );
  const bidPrice = await rowOne.getBidPrice();
  const askPrice = await rowOne.getAskPrice();
  expect(bidPrice)
    .to
    .equal(rowOneCellBidValue);
  expect(askPrice)
    .to
    .equal(lpTraderTradeQuoteSellPrice.concat('.000'));
  const priorityActive = await rfsWindow.waitUntilPriorityActive();
  expect(priorityActive)
    .to
    .equal(true, 'RFS window PRIORITY should be active');
  const priorityInactive = await rfsWindow.waitUntilPriorityInactive();
  expect(priorityInactive)
    .to
    .equal(true, 'RFS window PRIORITY should be inactive');
});

given('priority NLP ask price is displayed on top of child window market depth rows', async () => {
  const askPricePriorityCell = nlpTraderTradeQuoteSellPrice
    .concat('.000\n*');
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.waitUntilPrice(
    nlpTraderTradeQuoteBuyPrice.concat('.000'),
    askPricePriorityCell
  );
  const bidPrice = await rowOne.getBidPrice();
  const askPrice = await rowOne.getAskPrice();
  expect(bidPrice).to.equal(nlpTraderTradeQuoteBuyPrice.concat('.000'));
  expect(askPrice).to.equal(askPricePriorityCell);
});

given('market depth data on RFS child window updates with LP trader trading phase quote', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.verifyRow({
    buyPrice     : parseInt(lpTraderTradeQuoteBuyPrice, 10),
    buyPriority  : false,
    buyAmount    : '',
    sellPrice    : parseInt(lpTraderTradeQuoteSellPrice, 10),
    sellAmount   : '',
    sellPriority : false
  });
});

given('activate dropdown contains traders I have permission to activate {string}', async brokerUser => {
  if (brokerUser === 'AUTBR03') {
    tradersCovered = ['CEA - TR02', 'DEA - TR06', 'DEA - TR07'];
  }
  const activateUserList = await rfsWindow.ddActivateUser;
  const tradersInDropdown = await activateUserList.getSelections();
  expect(tradersInDropdown)
    .to
    .deep
    .equal(tradersCovered);
});

given('RFS child window displays a {string} broker badge', async (badgeColour) => {
  const brokerContact = await rfsWindow.getBrokerContact();
  expect(brokerContact)
    .to
    .equal(broker.desk, 'Unexpected broker contact found on RFS window');
  if (badgeColour === 'grey') {
    await rfsWindow.verifyBrokerBadgeColour(COLOR_PURPOSE.INACTIVE_COLOR);
  } else if (badgeColour === 'watermelon') {
    await rfsWindow.verifyBrokerBadgeColour(COLOR_PURPOSE.CONTACT_BROKER);
  }
});

given('RFS child window displays a broker badge', async () => {
  const brokerContact = await rfsWindow.getBrokerContact();
  const expectedBrokerContact = 'CONTACT '.concat(broker.desk);
  expect(brokerContact)
    .to
    .equal(expectedBrokerContact, 'Unexpected broker contact found on RFS window');
  const brokerInactiveTxtLabel = await rfsWindow.getBrokerContact();
  expect(brokerInactiveTxtLabel).to.equal(broker.desk);
});

given('RFS child window displays LP trader trade quote as top of market', async () => {
  const bidOfferRowOne = await rfsWindow.getBidOfferRow(1);
  await bidOfferRowOne.waitUntilPrice(
    lpTraderTradeQuoteSellPrice.concat('.000'),
    lpTraderTradeQuoteBuyPrice.concat('.000'),
    frameworkConfig.shortTimeout
  );
  const askTrader = await bidOfferRowOne.getAskTrader();
  const askSize = await bidOfferRowOne.getAskSize();
  const askPrice = await bidOfferRowOne.getAskPrice();
  const bidSize = await bidOfferRowOne.getBidSize();
  const bidPrice = await bidOfferRowOne.getBidPrice();
  const bidTrader = await bidOfferRowOne.getBidTrader();
  expect(askTrader)
    .to
    .equal('', 'RFS trader information should not be displayed');
  expect(askSize)
    .to
    .equal(lpTraderTradeQuoteSize, 'RFS ask size');
  expect(askPrice)
    .to
    .equal(lpTraderTradeQuoteSellPrice.concat('.000'), 'RFS top of market ask');
  expect(bidTrader)
    .to
    .equal('', 'RFS trader information should not be displayed');
  expect(bidSize)
    .to
    .equal(lpTraderTradeQuoteSize, 'RFS bid size');
  expect(bidPrice)
    .to
    .equal(lpTraderTradeQuoteBuyPrice.concat('.000'), 'RFS top of market bid');
});

given('responder count is 0', async () => {
  const responded = await rfsWindow.getResponded();
  expect(responded)
    .to
    .include('0/', 'RFS window expected zero rfs participants');
});

given('responder count is 1', async () => {
  await rfsWindow.waitUntilResponderCount(1);
  const responded = await rfsWindow.getResponded();
  expect(responded)
    .to
    .include('1/', 'RFS window expected one rfs participants');
});

given('there is no spread information displayed in dark phase', async () => {
  const darkSpreadDisplayed = await rfsWindow.darkSpreadExists();
  expect(darkSpreadDisplayed)
    .to
    .equal(false, 'Dark spread should not be displayed in the RFS dark phase');
  const currentSpreadDisplayed = await rfsWindow.currentSpreadExists();
  expect(currentSpreadDisplayed)
    .to
    .equal(false, 'Current spread should not be displayed in the RFS dark phase');
});

given('there is spread information displayed in lit phase', async () => {
  const darkSpread = await rfsWindow.getDarkSpread();
  const expectedSpread = (lpTraderDarkQuoteSellPrice - lpTraderDarkQuoteBuyPrice).toString().concat('.00');
  expect(darkSpread)
    .to
    .equal(expectedSpread, 'RFS dark spread during LIT phase');

  const currentSpread = await rfsWindow.getCurrentSpread();
  const expectedSpreadCurrent = (lpTraderDarkQuoteSellPrice - lpTraderDarkQuoteBuyPrice).toString().concat('.00');
  expect(currentSpread)
    .to
    .equal(expectedSpreadCurrent, 'RFS dark spread during LIT phase');
});

given('there is no global panic button to cancel my orders', async () => {
  const cxlMyOrdersExists = await mainPageFrame.cancelMyOrdersExists();
  expect(cxlMyOrdersExists)
    .to
    .equal(false, 'User should not see Cancel My Orders Link');
});

given('there is no global panic button to cancel desk orders', async () => {
  const cxlDeskOrdersExists = await mainPageFrame.cancelDeskOrdersExists();
  expect(cxlDeskOrdersExists)
    .to
    .equal(false, 'User should not see Cancel Desk Orders Link');
});

given('spread information is updated during lit phase', async () => {
  const expectedLitSpread = (lpTraderLitQuoteSellPrice - lpTraderLitQuoteBuyPrice).toString().concat('.00');
  await rfsWindow.waitUntilCurrentSpread(expectedLitSpread);
  const currentSpread = await rfsWindow.getCurrentSpread();
  expect(currentSpread)
    .to
    .equal(expectedLitSpread, 'RFS current spread');
});

given('there is no matched trades tab', async () => {
  const matchedPageTabExists = await mainPageFrame.matchedTradesTabExists();
  expect(matchedPageTabExists)
    .to
    .equal(false, 'User should not be able to see the Matched Trades tab');
});


/**
 * When definitions
 */
when('the RFS child window is enabled', async () => {
  const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
  expect(submitBtnEnabled)
    .to
    .equal(false, 'RFS submit button should be disabled for NLP user until they enter an offer');
  const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
  expect(enterBidFldEnabled)
    .to
    .equal(true, 'Enter bid field should be enabled');
  const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
  expect(enterAskFldEnabled)
    .to
    .equal(true, 'Enter ask field should be enabled');
  const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
  expect(enterSizeFldEnabled)
    .to
    .equal(true, 'Enter size field should be enabled');
  const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
  expect(subjectBtnEnabled)
    .to
    .equal(false, 'Subject button should be disabled until a firm offer has been made');
});

when('the RFS window displays greyed out market depth data and no size information', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  const bidButtonEnabled = await rowOne.isBidPriceBtnEnabled();
  const askButtonEnabled = await rowOne.isAskPriceBtnEnabled();
  const bidSize = await rowOne.getBidSize();
  const askSize = await rowOne.getAskSize();
  expect(bidButtonEnabled)
    .to
    .equal(false, 'RFS bid price should be disabled');
  expect(askButtonEnabled)
    .to
    .equal(false, 'RFS ask price should be disabled');
  expect(bidSize)
    .to
    .equal('', 'Trader should not see the Bid size when he is not activated');
  expect(askSize)
    .to
    .equal('', 'Trader should not see the Ask size when he is not activated');
});

when('NLP trader sees price and size data', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.verifyRow({
    buyPrice   : parseInt(lpTraderTradeQuoteBuyPrice, 10),
    buyAmount  : lpTraderTradeQuoteSize,
    sellPrice  : parseInt(lpTraderTradeQuoteSellPrice, 10),
    sellAmount : lpTraderTradeQuoteSize
  });
});

when('the lift button is enabled by clicking on an ask price', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  const askPriceBtnEnabled = await rowOne.isAskPriceBtnEnabled();
  expect(askPriceBtnEnabled)
    .to
    .equal(true, 'User should be able to click on the top of the market ask price');
  await rowOne.clickAskPriceBtn();
  const liftBtnEnabled = await rfsWindow.btnLiftEnabled();
  expect(liftBtnEnabled)
    .to
    .equal(true, 'Lift button should be enabled in the RFS window');
});

when('the hit button is enabled by clicking on a bid price', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  const bidPriceBtnEnabled = await rowOne.isBidPriceBtnEnabled();
  expect(bidPriceBtnEnabled)
    .to
    .equal(true, 'User should be able to click on the top of the market bid');
  await rowOne.clickBidPriceBtn();
  const hitBtnExists = await rfsWindow.waitUntilBtnHitExists();
  expect(hitBtnExists)
    .to
    .equal(true, 'Hit button should be displayed in the RFS window');
  const hitBtnEnabled = await rfsWindow.btnHitEnabled();
  expect(hitBtnEnabled)
    .to
    .equal(true, 'Hit button should be enabled in the RFS window');
});

when('NLP trader submits an offer via UI {string} {string} {string}', async (tradeQuoteBidPrice, tradeQuoteAskPrice, tradeQuoteAmount) => {
  trader.tradeQuoteOne = {
    buyPrice  : tradeQuoteBidPrice,
    sellPrice : tradeQuoteAskPrice,
    amount    : tradeQuoteAmount
  };
  await rfsWindow.quote(
    trader.tradeQuoteOne.buyPrice,
    trader.tradeQuoteOne.sellPrice,
    trader.tradeQuoteOne.amount
  );
  nlpTraderTradeQuoteBuyPrice = tradeQuoteBidPrice;
  nlpTraderTradeQuoteSellPrice = tradeQuoteAskPrice;
  tradeQuoteSize = tradeQuoteAmount;

  logger.info(`NLP Trader trade Quote Sell price is ${nlpTraderTradeQuoteSellPrice}`);
  logger.info(`NLP Trader trade Quote Buy price is ${nlpTraderTradeQuoteBuyPrice}`);
  logger.info(`NLP Trader trade Quote Size is ${tradeQuoteSize}`);
});

when('trader submits an offer {string} {string} {string}', async (tradeQuoteBidPrice, tradeQuoteAskPrice, tradeQuoteAmount) => {
  trader.offer = {
    buyPrice  : tradeQuoteBidPrice,
    sellPrice : tradeQuoteAskPrice,
    amount    : tradeQuoteAmount
  };
  await rfsWindow.quote(
    trader.offer.buyPrice,
    trader.offer.sellPrice,
    trader.offer.amount
  );
});

when('NLP trader submits an offer {string} {string} {string}', async (tradeQuoteBidPrice, tradeQuoteAskPrice, tradeQuoteAmount) => {
  nlpTraderTradeQuoteBuyPrice = tradeQuoteBidPrice;
  nlpTraderTradeQuoteSellPrice = tradeQuoteAskPrice;
  tradeQuoteSize = tradeQuoteAmount;
  await traderClient.rfsQuote(
    strategyId,
    tradeQuoteBidPrice,
    tradeQuoteAskPrice,
    tradeQuoteAmount
  );

  logger.info(`NLP Trader trade Quote Sell price is ${nlpTraderTradeQuoteSellPrice}`);
  logger.info(`NLP Trader trade Quote Buy price is ${nlpTraderTradeQuoteBuyPrice}`);
  logger.info(`NLP Trader trade Quote Size is ${tradeQuoteSize}`);
});

when('NLP trader two submits an offer {string} {string} {string}', async (tradeQuoteBidPrice, tradeQuoteAskPrice, tradeQuoteAmount) => {
  nlpTrader2TradeQuoteBuyPrice = tradeQuoteBidPrice;
  nlpTrader2TradeQuoteSellPrice = tradeQuoteAskPrice;
  trader2TradeQuoteSize = tradeQuoteAmount;
  await trader2Client.rfsQuote(
    strategyId,
    tradeQuoteBidPrice,
    tradeQuoteAskPrice,
    tradeQuoteAmount
  );

  logger.info(`NLP Trader 2 trade Quote Sell price is ${nlpTrader2TradeQuoteSellPrice}`);
  logger.info(`NLP Trader 2 trade Quote Buy price is ${nlpTrader2TradeQuoteBuyPrice}`);
  logger.info(`NLP Trader 2 trade Quote Size is ${trader2TradeQuoteSize}`);
});

given('RFS child window is updated with orders in order of best quote', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  let bidPrice = await rowOne.getBidPrice();
  let bidSize = await rowOne.getBidSize();
  let bidTrader = await rowOne.getBidTrader();
  let askPrice = await rowOne.getAskPrice();
  let askSize = await rowOne.getAskSize();
  let askTrader = await rowOne.getAskTrader();
  expect(bidPrice)
    .to
    .equal(lpTraderTradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(lpTraderTradeQuoteSize);
  expect(bidTrader)
    .to
    .equal('');
  expect(askPrice)
    .to
    .equal(lpTraderTradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(lpTraderTradeQuoteSize);
  expect(askTrader)
    .to
    .equal('');

  const rowTwo = await rfsWindow.getBidOfferRow(2);
  await rowTwo.waitUntilPrice(
    nlpTrader2TradeQuoteBuyPrice.concat('.000'),
    nlpTraderTradeQuoteSellPrice.concat('.000')
  );
  bidPrice = await rowTwo.getBidPrice();
  bidSize = await rowTwo.getBidSize();
  bidTrader = await rowTwo.getBidTrader();
  askPrice = await rowTwo.getAskPrice();
  askSize = await rowTwo.getAskSize();
  askTrader = await rowTwo.getAskTrader();
  expect(bidPrice)
    .to
    .equal(nlpTrader2TradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(trader2TradeQuoteSize);
  expect(bidTrader)
    .to
    .equal(trader2.userDisplayId);
  expect(askPrice)
    .to
    .equal(nlpTraderTradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(tradeQuoteSize);
  expect(askTrader)
    .to
    .equal(trader.userDisplayId);

  // eslint-disable-next-line no-magic-numbers
  const rowThree = await rfsWindow.getBidOfferRow(3);
  await rowThree.waitUntilPrice(
    nlpTraderTradeQuoteBuyPrice.concat('.000'),
    nlpTrader2TradeQuoteSellPrice.concat('.000')
  );
  bidPrice = await rowThree.getBidPrice();
  bidSize = await rowThree.getBidSize();
  bidTrader = await rowThree.getBidTrader();
  askPrice = await rowThree.getAskPrice();
  askSize = await rowThree.getAskSize();
  askTrader = await rowThree.getAskTrader();
  expect(bidPrice)
    .to
    .equal(nlpTraderTradeQuoteBuyPrice.concat('.000'));
  expect(bidSize)
    .to
    .equal(tradeQuoteSize);
  expect(bidTrader)
    .to
    .equal(trader.userDisplayId);
  expect(askPrice)
    .to
    .equal(nlpTrader2TradeQuoteSellPrice.concat('.000'));
  expect(askSize)
    .to
    .equal(trader2TradeQuoteSize);
  expect(askTrader)
    .to
    .equal(trader2.userDisplayId);

  // eslint-disable-next-line no-magic-numbers
  const rowFour = await rfsWindow.getBidOfferRow(4);
  const isEmptyRow = await rowFour.isEmptyRow();
  expect(isEmptyRow)
    .to
    .equal(true, 'RFS quotes table should not contain quotes on the 4th row');
});

when('NLP trader ask price appears at the top of the market in the RFS window', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.verifyRow({
    buyPrice     : parseInt(lpTraderTradeQuoteBuyPrice, 10),
    buyAmount    : lpTraderTradeQuoteSize,
    buyPriority  : false,
    sellPrice    : parseInt(nlpTraderTradeQuoteSellPrice, 10),
    sellAmount   : tradeQuoteSize,
    sellPriority : true
  });
});

when('NLP trader My current fields are updated', async () => {
  await rfsWindow.verifyMyCurrentFields({
    myCurrentBid  : nlpTraderTradeQuoteBuyPrice,
    myCurrentAsk  : nlpTraderTradeQuoteSellPrice,
    myCurrentSize : tradeQuoteSize
  });
});

when('NLP trader subjects offer', async () => {
  await rfsWindow.btnSubjectClick();
  const rowOne = await rfsWindow.getBidOfferRow(1);

  await rowOne.verifyRow({
    buyPrice     : parseInt(lpTraderTradeQuoteBuyPrice, 10),
    buyAmount    : lpTraderTradeQuoteSize,
    buyPriority  : false,
    sellPrice    : parseInt(lpTraderTradeQuoteSellPrice, 10),
    sellAmount   : lpTraderTradeQuoteSize,
    sellPriority : false
  });

  await rfsWindow.verifyMyCurrentFields({
    myCurrentBid  : nlpTraderTradeQuoteBuyPrice,
    myCurrentAsk  : nlpTraderTradeQuoteSellPrice,
    myCurrentSize : tradeQuoteSize
  });
});

when('the bid is HIT', async () => {
  const rowOne = await rfsWindow.getBidOfferRow(1);
  await rowOne.clickBidPriceBtn();
  await rfsWindow.waitUntilBtnHitExists();
  await rfsWindow.btnHitClick();
});

when('the RFS child window fields are disabled', async () => {
  const submitBtnEnabled = await rfsWindow.btnSubmitEnabled();
  expect(submitBtnEnabled)
    .to
    .equal(false, 'RFS submit button should be disabled from NLP user during dark period of RFS without interest');
  const submitBtnText = await rfsWindow.getQuoteBtnText();
  expect(submitBtnText)
    .to
    .equal('SUBMIT', 'RFS submit button text is not expected');
  const enterBidFldEnabled = await rfsWindow.fldEnterBidEnabled();
  expect(enterBidFldEnabled)
    .to
    .equal(false, 'Enter bid field should be disabled from NLP user during dark period of RFS without interest');
  const enterAskFldEnabled = await rfsWindow.fldEnterAskEnabled();
  expect(enterAskFldEnabled)
    .to
    .equal(false, 'Enter ask field should be disabled from NLP user during dark period of RFS without interest');
  const enterSizeFldEnabled = await rfsWindow.fldEnterSizeEnabled();
  expect(enterSizeFldEnabled)
    .to
    .equal(false, 'Enter size field should be disabled from NLP user during dark period of RFS without interest');
  const subjectBtnEnabled = await rfsWindow.btnSubjectEnabled();
  expect(subjectBtnEnabled)
    .to
    .equal(false, 'Subject button should be disabled from NLP user during dark period of RFS without interest');
  const subjectBtnText = await rfsWindow.getSubjectBtnText();
  expect(subjectBtnText)
    .to
    .equal('SUBJECT', 'RFS subject button text is not expected');
});

when('the RFS is in dark phase', async () => {
  const phase = await rfsWindow.getPhase();
  expect(phase)
    .to
    .equal('DARK', 'RFS should be in DARK phase');
});

when('the RFS transitions to lit phase', async () => {
  await rfsWindow.waitUntilPhase('LIT', frameworkConfig.darkPhaseTimeout);
  const phase = await rfsWindow.getPhase();
  expect(phase)
    .to
    .equal('LIT', 'RFS should be in LIT phase');
});

when('the RFS transitions to trading phase', async () => {
  const inTradingPhase = await rfsWindow.waitUntilPhase('TRADING', frameworkConfig.litPhaseTimeout);
  expect(inTradingPhase)
    .to
    .equal(true, 'RFS should be in TRADING phase');
});

when('countdown timer for dark phase is complete', async () => {
  const darkTimer = await rfsWindow.getDarkCountDownTimer();
  expect(darkTimer)
    .to
    .equal('0:00', 'Dark Timer should be 0:00');
});

when('countdown timer for lit phase is complete', async () => {
  const litTimer = await rfsWindow.getLitCountDownTimer();
  expect(litTimer)
    .to
    .equal('0:00', 'RFS lit timer should be 0 during TRADING phase');
});

when('RFS match summary window displays an RFS match message', async () => {
  const matchesFound = await rfsWindow.waitUntilRfsMatchesHaveOccurred();
  expect(matchesFound)
    .to
    .equal(true, 'RFS matches should of occurred');
});

when('RFS match summary window displays total amount matched', async () => {
  const totalMatchedInRFS = await rfsWindow.getSummaryTotalMatchedInRFS();
  const amountMatched = lpTraderTradeQuoteSize
    .concat(' L');
  expect(totalMatchedInRFS)
    .to
    .equal(amountMatched, 'RFS summary - Total Amount Matched in RFS');
});

when('RFS match summary window displays match detail', async () => {
  await rfsWindow.waitUntilRfsMatchesHaveOccurred();
  await rfsWindow.verifySummary({
    totalMatched : lpTraderTradeQuoteSize,
    totalBought  : 0,
    totalSold    : lpTraderTradeQuoteSize
  });
});

/**
 * Then definitions
 */
then('the RFS timed out message is displayed when RFS times out', async () => {
  const summaryTimeout = frameworkConfig.tradePhaseTimeout + frameworkConfig.shortTimeout;
  const rfsTimedOut = await rfsWindow.waitUntilRfsTimedout(summaryTimeout);
  expect(rfsTimedOut)
    .to
    .equal(true, 'RFS should of timed out');
});

then('I cannot participate when the lit phase has ended', async () => {
  const lockedOut = await rfsWindow.waitUntilLpTraderLockedOutMsg();
  expect(lockedOut)
    .to
    .equal(true, 'LP trader should be locked out of RFS because he did not respond in the book building period');
});

then('RFS displays book building in progress message', async () => {
  const bookBuildingMessage = await rfsWindow.bookBuildingMessageExists();
  expect(bookBuildingMessage)
    .to
    .equal(true, 'Expected to find Book Building Message in the RFS window');
});


then('LP trader subjects quote via API', async () => {
  await lpTraderClient.rfsSubject(strategyId);
});

then('the RFS transitions to VC', async () => {
  await mainPageFrame.switchToWindow();
  await strategyRow.waitUntilStatus('VC');
  const status = await strategyRow.getStatusText();
  expect(status)
    .to
    .equal('VC', 'Market View strategy row status');
});

then('VC status icon is displayed in pink', async () => {
  await strategyRow.verifyStatusColour(COLOR_PURPOSE.VC_COLOR);
});

then('VC trade notification is received with price {string}', async vcTradePrice => {
  const vcNotification = await mainPageFrame.notificationsPanel.notifications.getVC(strategy, vcTradePrice);
  const notificationExists = await vcNotification.waitForExist();
  expect(notificationExists)
    .to
    .equal(true, 'VC notification');
});

then('VC toast message is received with price {string}', async vcTradePrice => {
  const vcToastMsgs = await toastNotification.getVcToastMsg(vcTradePrice, strategy);
  expect(vcToastMsgs.length)
    .to
    .equal(1, 'Trader should see VC toast message');
});

then('VC child window can be opened by clicking on the VC status icon', async () => {
  await strategyRow.clickStatus();
  vcWindow = new VolumeClearing(context);
  const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
  expect(foundWindow)
    .to
    .equal(true, 'Expected to find the VC window');
});

then('VC window should show trader is priority seller', async () => {
  const prioritySeller = await vcWindow.isPrioritySeller();
  expect(prioritySeller)
    .to
    .equal(true, 'Trader should be a priority seller in the VC');
});

then('VC window transitions from Priority to Open To All', async () => {
  const openToAll = await vcWindow.waitUntilOpenToAll();
  expect(openToAll)
    .to
    .equal(true, 'VC should be open to all');
});

then('VC window displays a summary at the end of the VC {string} {string} {string}', async (boughtVolume, soldVolume, totalVolume) => {
  await vcWindow.waitForSummary();
  const vcTotalBought = await vcWindow.getSummaryTotalBought();
  const vcTotalSold = await vcWindow.getSummaryTotalSold();
  const vcTotalMatched = await vcWindow.getSummaryTotalMatched();
  expect(vcTotalBought).to.equal(boughtVolume, 'VC My Total Bought Amount');
  expect(vcTotalSold).to.equal(soldVolume, 'VC My Total Sold Amount');
  expect(vcTotalMatched).to.equal(totalVolume, 'VC Total Amount Matched');
});

then('VC child window cannot be opened', async () => {
  const statusInactive = await strategyRow.statusHasInactiveFlag();
  expect(statusInactive)
    .to
    .equal(false, 'Market View strategy status should be inactive');
  await strategyRow.clickStatus();
  vcWindow = new VolumeClearing(context);
  const foundWindow = await vcWindow.switchToWindow('V', strategy.underlying, strategy.strategy.shortName, strategy.expiry);
  expect(foundWindow)
    .to
    .equal(false, 'VC window should not be open');
});

then('sell toast message is received with price {string} and size {string}', async (sellTradePrice, sellSize) => {
  const sellToastMsgs = await toastNotification.getSellToastMsg(sellTradePrice, sellSize, strategy);
  expect(sellToastMsgs.length)
    .to
    .equal(1, 'Sell toast message should exist');
});

then('sell trade notification is received with price {string} and size {string}', async (sellTradePrice, sellSize) => {
  const notification = await mainPageFrame.notificationsPanel
    .notifications
    .getFillSell(strategy, sellTradePrice, sellSize);
  const notificationFound = await notification.waitForExist();
  expect(notificationFound)
    .to
    .equal(true, 'Trader should see sell notification alert');
});

then('an order cancellation alert message is received for sub min cancellation of {string} at the end of the VC with price {string}', async (sizeCancelled, tradePrice) => {
  const notification = await mainPageFrame.notificationsPanel
    .notifications
    .getCanceledOrder(strategy, tradePrice, sizeCancelled);
  const notificationFound = await notification.waitForExist();
  expect(notificationFound)
    .to
    .equal(true, 'Trader should see order rejected notification alter');
});
