# bluechip-test-framework
> End-to-end regression test automation framework for Blue Chip Fenics GO (Global Options).

## Preparation
1. Ensure that v10.17.0 of node is installed. MSI package can be found here: https://nodejs.org/download/release/v10.17.0/node-v10.17.0-x64.msi
2. Ensure that the VS2017 build tools for C++ are installed. Download available here: blob:https://visualstudio.microsoft.com/0e68891b-a9ff-4b96-83c9-f8d53fdff792
3. Run `npm install` in the project folder

## Usage
1. Ensure that the Blue Chip application **is not running**.
2. Change directory to project and start Chrome driver in terminal, e.g. via GitBash

```
cd ./bluechip-test-framework
./chromedriver_2.34.exe
```

## Run Mocha tests
1. Check `\config\wdio.mocha.config.js`  file to specify tests to run. If there is no test specified all tests will be run.
2. Run command `npm test`

## Run Cucumber Feature tests
1. Check `\config\wdio.cucumber.config.js` file to specify features to run. If there is no test specified all feature files will be run.
2. Run command `npm run-script test-cucumber`

## Run Mocha tests and generate an Allure report
1. Run command `npm run-script testWithAllureReport`
2. Check locally that an allure-results folder has been generated
3. Check locally that an allure-report folder has been generated. If not, run command `allure generate`
4. Go to project folder and open allure-report html file with Firefox

## Run Cucumber tests and generate an Allure report
1. Run command `npm run-script testCucumberWithAllureReport`
2. Check locally that an allure-results folder has been generated
3. Check locally that an allure-report folder has been generated. If not, run command `allure generate`
4. Go to project folder and open allure-report html file with Firefox

## Run FIX tests
1. Ensure you download the openfix-1.2.20 jar file which can be found here:
https://embonds.atlassian.net/wiki/spaces/BLUEC/pages/1346863121/Fenics+GO+FIX+API
2. In the same folder, copy over the following files stored here:
    a. transactions.xml - all of the fix transactions currently available
    b. batchScripts.xml - all of the fix automated batch scripts currently available for regression purposes
2. Open openfix-1.2.20
3. You should see the batch scripts and transactions in their relevant tabs Transaction/Batch

For a list of test cases/regression tests and users see documentation here:
http://bgcamer/sites/BGCTechnology/_layouts/15/WopiFrame.aspx?sourcedoc=/sites/BGCTechnology/Shared%20Documents/06%20Front%20Office%20Development/Client%20Facing%20Technology/04%20Team%20Areas/QA/API%20FIX/FIX%20QA%20Testing%20and%20Test%20Cases.docx&action=default


## Notes
See Cucumber steps matrix:

|Launch and Login Steps                                                      |                                                                   |   
|:---------------------------------------------------------------------------|-------------------------------------------------------------------:|
| Given I launch Fenics GO                                                  |Launch Fenics GO application                                       |
| And I login as trader "Trader UUID"                              |Login as a trader (pass in trader UUID, e.g. AUTTR10)              |
| And I login as broker "Broker UUID"                              |Login as a broker (pass in broker UUID, e.g. AUTBR03)              |
| And logged in "userType" user UUID is displayed                               |Verify logged in user UUID is displayed                     |
|And I click "MARKET VIEW" market view tab                                  |Click given market view tab, e.g. And I click “EUROSTOXX” market view tab     |                                               


|Create Strategy Steps                                                      |                                                               | 
|:--------------------------------------------------------------------------|---------------------------------------------------------------:|
| And a "strategyType" strategy exists                              |Check to see if strategy exists<br>Click Create Strategy<br>Create and submit a given strategy<br>Get strategy ID|

|Alerts and Notifications Steps                                              |                                                            |   
|:---------------------------------------------------------------------------|-------------------------------------------------------------------:|
| And I receive an RFS trade notification alert                             |Verify there is a responder trade notification displayed with expected information |
| And I receive an RFS toast message                                        |Get strategy being used in test<br>Ensure there is 1 RFS responder toast messages displayed with expected strategy information|
| And I do not receive an RFS toast message                                 |Get strategy being used in test<br>Ensure there is 0 RFS responder toast messages displayed |
| And I do not receive an RFS trade notification alert                      |Verify there is no responder trade notifications displayed                     |


|Initiate an RFS Steps                                                      |                                                               | 
|:--------------------------------------------------------------------------|---------------------------------------------------------------:|
| And I initiate RFS                                                        |Click Market View Header<br>Get strategy<br>Check REQUEST QUOTES button is enabled<br>Click Request Quotes button |
| And LP trader "LP Trader UUID" initiates an RFS                           |Initiate an RFS via API with given LP trader|
| And broker initiates an RFS                                               |Login with a broker via API<br>Initiate an RFS via API with broker client|

|Respond to RFS Steps                                                       |                                                               | 
|:--------------------------------------------------------------------------|---------------------------------------------------------------:|
|When LP trader "Trader UUID" is a relevant responder                       |Set a trader up to respond to an RFS via API<br>Respond to an RFS (at the moment this is executed before initiating the RFS)  |
|Given LP trader responds with a quote in dark phase "bidPrice" "askPrice" "amount" |Respond to an RFS as an LP trader via API in dark phase with given prices and amount                      |
|When LP trader responds with a quote in lit phase "bidPrice" "askPrice" "amount"  |Respond to an RFS as an LP trader via API in lit phase with given prices and amount       |
|And LP trader responds with a quote in trading phase "bidPrice" "askPrice" "amount"  |Respond to an RFS as an LP trader via API in trading phase with given prices and amount  |
|Then I cannot participate when the lit phase has ended                     |Verify LP trader cannot respond to the RFS<br>LP trader can no longer respond overlay is displayed   |
|Then NLP trader submits an offer "bidPrice" "askPrice" "amount"                    |Submit quote via API as an NLP trader  |
|Then NLP trader submits an offer via UI "bidPrice" "askPrice" "amount"                    |Submit quote via UI RFS child window  |

|RFS Common Steps                                                           |                                                               | 
|:--------------------------------------------------------------------------|---------------------------------------------------------------:|
|And I open the RFS child window via the RFS status icon                    |Open RFS child window by clicking on RFS status icon for a specific strategy |
|And market view displays RFS status icon in blue                           |Verify RFS status icon is displayed in active RFS colour (blue)   |
|Then the RFS child window opens                                            |Verify when an RFS is initiated an RFS child window is opened<br>Switch to RFS child window<br>Verify strategy short name, expiry, title, delta, ref is displayed |
|And the RFS child window has window letter R                               |Verify Responder child window letter R is displayed|
|And the RFS child window has window letter Q                               |Verify Initiator child window letter Q is displayed|
|And the RFS child window is enabled                                        |Verify submit and subject buttons are not enabled<br>Verify enter bid, enter ask, enter size fields are enabled|
|And the RFS child window fields are disabled                               |Verify submit and subject buttons are not enabled<br>Verify enter bid, enter ask, enter size fields are not enabled|
|Given the RFS is in dark phase                                             |Get RFS phase<br>Verify RFS is in dark phase                               |
|And RFS displays book building in progress message                         |Verify book building message exists on RFS child window           |
|And there is no spread information displayed in dark phase                 |Verify that there is no dark spread information displayed<br>Verify that no current spread information is displayed    |
|And responder count is 0                                                   |Get RFS child window responded information<br>Verify responder count is 0                                |
|Then responder count is 1                                                  |Get RFS child window responded information<br>Verify responder count is 1                            |
|And countdown timer for dark phase is complete                             |Get dark phase countdown timer<br>Verify dark phase countdown timer is 0:00             |
|Given the RFS transitions to lit phase                                     |Wait until dark phase has timed out<br>Get RFS phase<br>Verify RFS is in lit phase         |
|Given there is spread information displayed in lit phase                   |Verify that there is dark spread information displayed<br>Verify that current spread information is displayed|
|Then spread information is updated during lit phase                        |Verify current spread is updated during lit phase when a new quote is submitted by an LP trader|
|Given the RFS transitions to trading phase                                 |Wait until lit phase has timed out<br>Get RFS phase<br>Verify RFS is in trading phase|
|And countdown timer for lit phase is complete                              |Get lit phase countdown timer<br>Verify lit phase countdown timer is 0:00|
|And the RFS window displays greyed out market depth data and no size information | Get row one of RFS child window market depth<br>Verify prices are greyed out and prices cannot be clicked|    
|And market depth data on RFS child window updates with LP trader trading phase quote | Get row one of RFS child window market depth<br>Verify prices are greyed out but updated when an LP trader sends in a new quote|                                                        
|And RFS match summary window displays an RFS match message                 |Check RFS matches have occurred message overlay exists in RFS child window|
|And RFS match summary window displays total amount matched                 |Check RFS matches have occurred message overlay displays total amount matched|
|And RFS match summary window displays match detail               |Check RFS matches have occurred message overlay displays LP trader quote amount matched|
|Then an ongoing RFS is displayed with a grey RFS status icon              |Get strategy and verify it is visible in market view<br>Verify RFS status icon is visible and status text = RFS<br>Verify status icon has an inactive flag set against it<br>Verify status icon is displayed in grey    |
|And LP trader subjects quote via API                                       |Subject LP trader prices via API|
|Then the RFS timed out message is displayed when RFS times out             |Verify RFS timed out message is displayed after trading phase has ended with no responders|
|And NLP trader sees price and size data                                       |Verify RFS child window displays prices and sizes submitted by an LP trader|
|And the lift button is enabled by clicking on an ask price                  |Click on an ask price and ensure lift button is enabled|
|And the hit button is enabled by clicking on a bid price                  |Click on a bid price and ensure hit button is enabled|
|And NLP trader ask price appears at the top of the market in the RFS window              |Verify NLP trader ask price appears as top of book in the RFS child window|
|And NLP trader subjects offer           |Subject offer via RFS child window by clicking on the SUBJECT button|
|And the bid is HIT          |Match a trader by clicking on the HIT button on a bid price on the RFS child window|
|And sell trade notification is received with price "sellPrice" and size "sellAmount L"                 |Verify sell trade notification is displayed with given trade price and size|
|And sell toast message is received with price "sellPrice" and size "sellAmount L"      |Verify sell toast notification is displayed with given trade price and size|
|And an order cancellation alert message is received for sub min cancellation of "sizeCancelled" at the end of the VC with price "/tradePrice"| Verify cancellation alert is displayed with given size cancelled and price|

|RFS Without Interest Steps                                                  |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|And RFS child window displays a "colour" broker badge                     |Verify RFS child window displays a given colour broker badge for an RFS without interest, e.g. watermelon, grey|
|When market view displays an ongoing broker initiated RFS I can participate in|Click Market View header<br>Initiate an RFS with a broker via API<br>Wait until status of strategy is RFS<br>Check broker initiator desk short name is displayed in market view against the strategy<br>Verify RFS status icon is in blue|
|Then I cannot activate traders                                              |Verify there is no activate button enabled<br>Verify there is no activation dropdown field enabled|
|And broker activates trader                                                 |Activate a trader already logged in using broker client<br>|
|Then I can activate traders                                                 |Verify activate button is not enabled<br>Verify there is an activation dropdown field enabled|
|And activate dropdown contains traders I have permission to activate "Trader UUID"|Get list of users in activation dropdown field<br>Verify traders in list are expected for traders covered by given broker |
|And broker activates trader "Trader UUID" using activation dropdown          |<br>Activate given trader as a broker via UI<br>Verify trader short ID is displayed, selected and activate button is enabled for the broker<br>Click activate button<br>Verify trader information is displayed on RFS child window |
|And activated trader "Trader UUID" is removed from the activation list for broker "Broker UUID"|Get list of users from activation dropdown<br>Check that for given broker and given trader already activated only a specific users remain in list|
|And activated trader is displayed on the RFS child window                   |Get activated trader with trader short ID already set in previous step<br>Verify trader short ID is displayed on RFS child window<br>Verify trader first name, last name, desk and legal entity are displayed in a specific format on tooltip |
|And I cannot activate a trader that is not logged in "Trader UUID"          |Check that for a given trader that is not logged in when selected by broker and activate button is clicked, trader not logged in message is displayed  |
|And I can activate a trader that has logged in                              |Check that for a trader previously not logged in (previous step) once logged in (via API) they can be selected and activated by the broker|
|And broker activates a third trader "Trader UUID"                           |Activate a given third trader to participate in an RFS without interest|
|And activated traders submit quotes in trading phase                        |Using 2 activated traders activated in a previous step submit quotes|
|And RFS child window is updated with orders in order of best quote          |Get RFS child window quotes row one, two and three<br>Ensure that expected prices submitted in a previous step are displayed in RFS child window with 3 d.p. and expected amounts with trader short name as expected<br>Ensure that there is an empty row where prices were not submitted and expected |
|And RFS child window is updated when trader submits a new quote             |Using the first NLP trader to respond, update prices via the API<br>Verify rows in RFS child window are updated with 3 d.p. and expected amounts with trader short name as expected|
|And priority bid price is displayed on top of child window market depth rows|Using the LP trader that has previously responded to RFS without interest, submit top of book prices via API<br>Ensure prices and rows are updated to reflect top of book prices in RFS child window<br>Ensure priority phase is sparked and price has a * against it<br>Wait until priority phase has ended|
|And priority ask price is displayed on top of child window market depth rows|Using the first NLP trader that has previously responded to RFS without interest, submit top of book prices via API<br>Ensure prices and rows are updated to reflect top of book prices in RFS child window<br>Ensure priority phase is sparked and price has a * against it|
|When a trader submits a quote that matches a live order in trading phase|Using the LP trader that has previously responded to RFS without interest, submit prices that will match a live price via API|
|And activation overlay is displayed                           |Verify once a trader is activated, an activation overlay is displayed on RFS child window|
                                                                 
|Direct RFS Specific Steps                                                   |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|When LP trader "Trader UUID" responds to an ongoing direct RFS              |Get trader and login with an LP trader via API<br>Initiate direct RFS as an NLP trader|


|LP Request Steps                                                            |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|And market view displays LP Request flag                                    |Get strategy row with initiator LP<br>Verify Initiator Badge exists and text is LP<br>Verify LP flag badge colour is orange/tangerine|
|And market view does not display the LP Request flag                        |Get strategy row with initiator LP<br>Verify Initiator Badge does not exist<br>Verify RFS status icon exists|


|Volume Clearing Steps                                                       |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|Then the RFS transitions to VC                                              |Switch window to focus on main application window<br>Wait until VC status icon is visible<br>Get status text and verify status text is VC for a specific strategy|
|And VC status icon is displayed in pink                                     |Verify VC status icon is displayed in pink|
|And VC child window cannot be opened                                        |Verify VC status has an inactive flag set against it and clicking on the VC status does not open a VC child window|
|And VC trade notification is received with price "vcPrice"                  |Verify VC trade notification is displayed with given trade price|
|And VC toast message is received with price "vcPrice"                      |Verify VC toast notification is displayed with given trade price|
|And VC child window can be opened by clicking on the VC status icon         |Open VC child window by clicking on the VC status icon in market view|
|And VC window should show trader is priority seller                          |Verify price is displayed to trader with initial workup tag indicating they are priority seller|
|And VC window transitions from Priority to Open To All                       |Verify initial workup phase is complete and VC window no longer displays tag indicating VC is now open to all|
|Then VC window displays a summary at the end of the VC "boughtVolume" "soldVolume" "totalVolume" |Verify VC summary is displayed at the end of the VC with correct bought, sold and total matched values|


|Panic Button Steps                                                          |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|And there is no global panic button to cancel my orders                     |Check that there is no global panic button to cancel users orders|
|And there is no global panic button to cancel desk orders                   |Check that there is no global panic button to cancel desk users orders|


|Matched Trades Steps                                                        |                                                               | 
|:---------------------------------------------------------------------------|---------------------------------------------------------------:|
|And there is no matched trades tab                                          |Verify there is no matched trades tab|
