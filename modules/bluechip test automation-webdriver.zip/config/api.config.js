const TARGET_ENV = process.env.TARGET_ENV ? process.env.TARGET_ENV : 'qa';
const application = 'go';
const appDomain = `${TARGET_ENV}.fenicsone.com`;

export const apiConfig = {
  wssEndpointUrl : `wss://${application}.${appDomain}/BlueChip/socket/1.0`,
  appUrl         : `https://${application}.${appDomain}`,
  appHost        : `${application}.${appDomain}`,
  appDomin       : appDomain,
  apiShortRetryDelay : 500,
  apiRequestTimeout : 10000,
  apiMsgRecheckDelay: 500
};
