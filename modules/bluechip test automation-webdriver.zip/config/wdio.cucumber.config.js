const {spawnSync} = require('child_process');
const TARGET_ENV = process.env.TARGET_ENV ? process.env.TARGET_ENV : 'qa';
const DOMAIN = `https://fenics-api.${TARGET_ENV}.fenicsone.com`;
const CONFIG_URL = process.env.CONFIG_URL || `${DOMAIN}/v1/openfin-manifest?openFinApplication=fenics%2Ffenics-shell-app`;

exports.config = {
  specs : [
    'test/feature/test-automation/*.feature'
  ],
  exclude : [
    /* Test suites to be excluded go here.  */
  ],
  capabilities : [
    {
      browserName   : 'chrome',
      chromeOptions : {
        extensions : [],
        binary     : 'RunOpenFin.bat',
        args       : [
          `--config=${CONFIG_URL}`,
          '--allow-insecure-localhost',
          '--allow-running-insecure-content',
          '--disable-web-security',
          '--noerrdialogs',
          '--v=1',
          '--ignore-certificate-errors',
          '--remember-cert-error-decisions',
          '--disk-cache-size=1'
        ]
      }
    }
  ],
  maxInstances   : 1,
  sync           : false,
  host           : 'localhost',
  port           : 9515,
  path           : '/',
  loglevel       : 'debug',
  coloredLogs    : true,
  framework      : 'cucumber',
  waitforTimeout : 20000,
  cucumberOpts   : {
    backtrace : true,
    compiler  : [
      'js:babel-register'
    ],
    failAmbiguousDefinitions   : true,
    failFast                   : false,
    ignoreUndefinedDefinitions : false,
    name                       : [],
    snippets                   : true,
    source                     : true,
    format                     : ['pretty', 'progress'],
    profile                    : [],
    require                    : [
      'test/step-def/*.js'
    ],
    strict        : true,
    tagExpression : '@smoke and not @Pending and not @manual',
    tagsInTitle   : false,
    timeout       : 500000
  },
  reporters       : ['allure'],
  reporterOptions : {
    captureStandardOutput : true,
    flowId                : true,
    message               : '[title]'
  },
  afterFeature : () => {
    spawnSync(`${process.env.INIT_CWD}/TerminateOpenfin.bat`);
  },
  onComplete : () => {
    spawnSync(`${process.env.INIT_CWD}/TerminateOpenfin.bat`);
  }
};
