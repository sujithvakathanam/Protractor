import Page from './Page';
import DropDownHelper from '../lib/DropDownHelper';

const chaiAsPromised = require('chai-as-promised');
const chai = require('chai');
chai.use(chaiAsPromised);
const assert = chai.expect;

export default class Preferences extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.vsConfigTitle = '.settings-page-title';
    this.segmentUnderlyingElement = '#segment';
    this.grossVolumeElement = '#gross-volume';
    this.netVolumeElement = '#net-volume';
    this.directionVolumeElement = '#directional-volume';
    this.intervalElement = '#interval';
    this.addButtonElement = '.settings-page button[data-id="BTN_SAVE"]';
    this.vsListItem = '.volume-safety-table-container .table-row';
    this.removeVS = '.settings-page [data-id="BTN_DELETE"]';
    this.editVS = '.settings-page [data-id="BTN_EDIT"]';
    this.save = '.settings-page [data-id="BTN_SAVE"]';
    this.cancel = '.settings-page [data-id="BTN_CANCEL"]';


    this.pauseLength = 2000;
  }

  get addButtonSelector () {
    return this.addButtonElement;
  }

  get addButton () {
    return this.browser.element(this.addButtonSelector);
  }

  get ddUnderlying () {
    return new DropDownHelper(this.context, this.segmentUnderlyingElement);
  }

  get vsItem () {
    return this.browser.element(this.vsListItem);
  }

  async addVolumeSafetyConfiguration (volumeSafety) {
    await this.pageHasLoaded(this.vsConfigTitle);

    await this.browser.element(this.grossVolumeElement).click;
    await this.browser.setValue(this.grossVolumeElement, volumeSafety.grossVolume);

    await this.browser.element(this.netVolumeElement).click;
    await this.browser.setValue(this.netVolumeElement, volumeSafety.netVolume);

    await this.browser.element(this.directionVolumeElement).click;
    await this.browser.setValue(this.directionVolumeElement, volumeSafety.directionVolume);

    await this.browser.element(this.intervalElement).click;
    await this.browser.setValue(this.intervalElement, volumeSafety.interval);

    const selectBox = this.ddUnderlying;
    await selectBox.setSelected(volumeSafety.underlyingSegment);
  }

  async submitVSConfiguration () {
    await this.addButton.click();
  }

  async waitUntilVSFound (volumeSafety, timeout = this.configuration.shortTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(async () => {
        await this.vsListItem;
      }, timeout);
    } catch (error) {
      this.logger.error(`Timed out after ${timeout}ms waiting for volume safety trigger in volume safety list`);
    }

    return found;
  }

  async removeVSConfiguration () {
    await this.browser.pause(this.pauseLength);
    await this.browser.click(this.removeVS);
  }

  async editVSConfiguration () {
    await this.browser.pause(this.pauseLength);
    await this.browser.click(this.editVS);
    await this.browser.setValue(this.intervalElement, '10000');
  }

  async saveEdit () {
    await this.browser.click(this.save);
  }

  async cancelEdit () {
    await this.browser.click(this.cancel);
  }

  async verifyVSExists () {
    await this.browser.elementActive(this.vsListItem);
  }

  async verifyDuplicateVSDisallowed (volumeSafety) {
    const sameVS = this.addVolumeSafetyConfiguration(volumeSafety);
    await assert(sameVS).to.be.rejected;
  }
}
