export default class Page {
  constructor (context) {
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.logger = context.getLogger();
  }

  pageHasLoaded (selector, timeout = this.configuration.shortTimeout) {
    return this.browser.waitForExist(selector, timeout);
  }

  async found (element) {
    await element;
    let found = null;
    try {
      found = await this.browser.waitForExist(element.selector, this.configuration.veryShortTimeout);
    } catch (err) {
      if (err.type === 'WaitUntilTimeoutError') {
        found = false;
      } else {
        throw err;
      }
    }

    return found;
  }

  async clickIfFound (element) {
    const myElement = await element;
    if (myElement.value !== null) {
      await this.browser.elementIdClick(myElement.value.ELEMENT);

      return true;
    }

    return false;
  }

  async clickAll (elements) {
    if (Array.isArray(elements)) {
      for (let el = 0; el < elements.length; el += 1) {
        try {
          /* eslint-disable */
          const element = await elements[el];
          await this.browser.click(element.selector);
        } catch (err) {
          this.logger.info(err);
        }
      }
    } else {
      const element = await elements;
      await this.browser.click(element.selector);
    }
  }

  async compareElementText (element, expectedText) {
    const elementText = await element.getText();
    if (elementText === expectedText) {
      return true;
    }

    return false;
  }

  async getCssValue (elementSelector, cssProperty) {
    const cssElement = await this.browser.getCssProperty(elementSelector, cssProperty);

    return JSON.stringify(cssElement);
  }

  async getCssColorValues (elementSelector, cssProperty) {
    const cssElement = await this.browser.getCssProperty(elementSelector, cssProperty);

    if (cssElement && cssElement.parsed) {
      return {
        hex  : cssElement.parsed.hex && cssElement.parsed.hex.toUpperCase() || undefined,
        rgba : cssElement.parsed.rgba
      }
    }

    return undefined;
  }

  async compareCssColorValues (elementSelector, cssProperty, expectedColor) {
    const foundColor = await this.getCssColorValues(elementSelector, cssProperty);
    const hexMatch = foundColor.hex && expectedColor.hex && expectedColor.hex.toUpperCase() === foundColor.hex;
    const rgbaMatch = foundColor.rgba && expectedColor.rgba && expectedColor.rgba === foundColor.rgba;

    return hexMatch || rgbaMatch;
  }
}
