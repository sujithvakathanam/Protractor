import Page from './Page.js';
import {hasTabOpen} from '../utilities/webdriverHelper/tabsHelper';

export class FenicsLaunchBar extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.spinnerSelector = '//article[@class="loading-spinner-wrap svelte-1obqx4g"]';
  }

  getApplicaionSelector (applicationName) {
    return `//li[descendant::figcaption[text()="${applicationName}"]]`;
  }

  async waitUntilWindowOpened () {
    return this.browser.waitUntil(() => hasTabOpen(this.browser, 'Fenics Launchbar'), this.configuration.mediumTimeout);
  }

  getApplicationButton (applicationName) {
    const selector = this.getApplicaionSelector(applicationName);


    return this.browser.element(selector);
  }

  async openApplication (applicationName) {
    // Wait until spinner does not exist and the application button does
    await this.browser.waitUntil(async () => {
      const btnSelector = this.getApplicaionSelector(applicationName);
      const spinnerExists = await this.browser.isExisting(this.spinnerSelector);
      const goBtnExists = await this.browser.isExisting(btnSelector);

      return spinnerExists === false && goBtnExists === true;
    }, this.configuration.shortTimeout);

    return this.getApplicationButton(applicationName).click();
  }
}
