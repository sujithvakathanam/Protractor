import Page from '../../Page.js';

export default class EditUserPage extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.loginInput = '//input[@ng-model="scp.currentItem.login"]';
    this.userType = '//select[@ng-model="scp.currentItem.userType"]';
    this.legalEntity = '//select[@ng-model="scp.currentItem.legalEntity"]';
    this.desk = '//select[@ng-model="scp.currentItem.desk"]';
    this.firstName = '//input[@ng-model="scp.currentItem.firstName"]';
    this.lastName = '//input[@ng-model="scp.currentItem.lastName"]';
    this.shortName = '//input[@ng-model="scp.currentItem.code"]';
    this.cmUserId = '//input[@ng-model="scp.currentItem.cmUserId"]';
    this.oktaId = '//input[@ng-model="scp.currentItem.oktaId"]';
    this.phoneNumber = '//input[@ng-model="scp.currentItem.phoneNumber"]';
    this.email = '//input[@ng-model="scp.currentItem.email"]';
    this.saveChanges = '//button[i[@class ="fa fa-check"]]';
    this.revertChanges = '//button[i[@class="fa fa-undo"]]';
    this.cancel = '//button[i[@class="fa fa-times"]]';
    this.confirm = '//button[i[@class="fa fa-save"]]';
    this.lock = '//button[i[@class="fa fa-lock"]]';
    this.unlock = '//button[i[@class="fa fa-unlock"]]';
    this.back = '//button[i[@class="fa fa-chevron-left"]]';
    this.marketSegmentRow = `//tr[starts-with(@ng-repeat,"item in scp.segmentList") and td[normalize-space(text()) = '${segmentName}']]`;
  }


  get inputLogin () {
    return this.browser.element(this.loginInput);
  }

  get selectUserType () {
    return this.browser.element(this.userType);
  }

  get selectLegalEntity () {
    return this.browser.element(this.legalEntity);
  }

  get selectDesk () {
    return this.browser.element(this.desk);
  }

  get inputFirstName () {
    return this.browser.element(this.firstName);
  }

  get inputLastName () {
    return this.browser.element(this.lastName);
  }

  get inputShortName () {
    return this.browser.element(this.shortName);
  }

  get inputCmUserId () {
    return this.browser.elemen(this.cmUserId);
  }

  get inputOktaId () {
    return this.browser.element(this.oktaId);
  }

  get inputPhone () {
    return this.browser.element(this.phoneNumber);
  }

  get inputEmail () {
    return this.browser.element(this.email);
  }

  get btnSaveChanges () {
    return this.browser.element(this.saveChanges);
  }

  clickBtnSaveChanges () {
    return this.btnSaveChanges.click();
  }

  get btnRevertChanges () {
    return this.browser.element(this.revertChanges);
  }

  clickBtnRevertChanges () {
    return this.btnRevertChanges.click();
  }

  get btnCancel () {
    return this.browser.element(this.cancel);
  }

  clickBtnCancel () {
    return this.btnCancel.click();
  }

  get btnConfirmChanges () {
    return this.browser.element(this.confirm);
  }

  clickBtnConfirmChanges () {
    return this.btnConfirmChanges.click();
  }

  get btnLock () {
    return this.browser.element(this.lock);
  }

  clickBtnLock () {
    return this.btnLock.click();
  }

  get btnUnlock () {
    return this.browser.element(this.unlock);
  }

  clickBtnUnlock () {
    return this.btnUnlock.click();
  }

  get btnBackToUserList () {
    return this.browser.element(this.back);
  }

  clickBtnBackToUserList () {
    return this.btnBackToUserList.click();
  }

  getMarketSegmentRow (segmentName) {
    return this.browser.element(this.marketSegmentRow);
  }

  /**
   * Returns table row from the market segment list
   * @param segmentName
   */
  async selectMarketSegment (segmentName) {
    const trMarketSegment = await this.getMarketSegmentRow(segmentName);

    return this.browser.elementIdElement(trMarketSegment.value.ELEMENT, './td[2]').click();
  }

  async selectTradingUser (userName) {
    const tdUser = await this.browser.element(`//td[text()="${userName}"]`);

    return tdUser.click();
  }


  /**
   * Edit user details
   * @param userDetails {UserDetails}
   * @return {promise<void>}
   */
  async editUser (userDetails) {
    if (userDetails.loginName !== null) {
      await this.inputLogin.setValue(userDetails.loginName);
    }
    if (userDetails.userType !== null) {
      await this.selectUserType.selectByVisibleText(userDetails.userType);
    }
    if (userDetails.firstName !== null) {
      await this.inputFirstName.setValue(userDetails.firstName);
    }
    if (userDetails.lastName !== null) {
      await this.inputLastName.setValue(userDetails.lastName);
    }
    if (userDetails.shortName !== null) {
      await this.inputShortName.setValue(userDetails.shortName);
    }
    if (userDetails.cmUserId !== null) {
      await this.inputCmUserId.setValue(userDetails.cmUserId);
    }
    if (userDetails.oktaId !== null) {
      await this.inputOktaId.setValue(userDetails.oktaId);
    }
    if (userDetails.phone !== null) {
      await this.inputPhone.setValue(userDetails.phone);
    }
    if (userDetails.email !== null) {
      await this.inputEmail.setValue(userDetails.email);
    }
    if (userDetails.legalEntity !== null) {
      await this.selectLegalEntity.selectByVisibleText(userDetails.legalEntity);
    }
    if (userDetails.desk !== null) {
      await this.selectDesk.selectByVisibleText(userDetails.desk);
    }
    if (userDetails.marketSegmentList !== null) {
      await this.selectMarketSegments(userDetails);
    }
  }

  /**
   * Add User
   * @param userDetails {UserDetails}
   * @return {Promise<void>}
   */
  addUser (userDetails) {
    return this.editUser(userDetails);
  }

  /**
   * Check the market segment radio buttons
   * @param userDetails {UserDetails}
   * @return {Promise<void>}
   */
  async selectMarketSegments (userDetails) {
    if (userDetails.marketSegmentList === null) {
      return;
    }
    const userType = await this.selectUserType.getValue();
    for (let type = 0; type < userDetails.marketSegmentList.length; type += 1) {
      const segment = userDetails.marketSegmentList[type];
      if (userType === 'string:BROKER') {
        this.selectTradingUser(segment[0]);
      }
      for (let mrktSeg = 1; mrktSeg < segment.length; mrktSeg += 1) {
        this.selectMarketSegment(segment[mrktSeg]);
      }
    }
  }
}
