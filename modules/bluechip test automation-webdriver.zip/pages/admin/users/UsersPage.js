import UserDetails from '../../../lib/admin/UserDetails';
import EditUserPage from './EditUserPage';
import Page from '../../Page.js';

export default class UsersPage extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.pageBack = '//a[@ng-click="setCurrent(pagination.current - 1)"]';
    this.pageFrwd = '//a[@ng-click="setCurrent(pagination.current + 1)"]';
    this.pageFirst = '//a[@ng-click="setCurrent(1)"]';
    this.pageLast = '//a[@ng-click="setCurrent(pagination.last)"]';
    this.addUser = '//button[contains(text(),"New User")]';
    this.search = '//input[@ng-model="scp.search"]';
    this.users = '//tr[starts-with(@ng-repeat,"user in scp.userList")]';
    this.popOver = '//div[@class="popover-content"]';
    this.editPencil = './/i[@class="fa fa-pencil"]';
    this.rowEllip = './/i[@class="fa fa-ellipsis-h"]';
  }

  pageHasLoaded () {
    return super.pageHasLoaded(this.search);
  }

  get btnPageBack () {
    return this.browser.element(this.pageBack);
  }

  get btnPageForward () {
    return this.browser.element(this.pageFrwd);
  }

  get btnPageFirst () {
    return this.browser.element(this.pageFirst);
  }

  get btnPageLast () {
    return this.browser.element(this.pageLast);
  }

  get btnAddNewUser () {
    return this.browser.element(this.addUser);
  }

  async clickAddNewUserBtn () {
    await this.btnAddNewUser.click();

    return new EditUserPage(this.browser);
  }

  get inputSearch () {
    return this.browser.element(this.search);
  }

  get users () {
    return this.browser.elements(this.users);
  }

  get popoverContent () {
    return this.browser.element(this.popOver);
  }

  enterSearch (searchValue) {
    return this.inputSearch.setValue(searchValue);
  }

  async getUserRow (userLogin) {
    const users = await this.users;
    for (let user = 0; user < users.value.length; user += 1) {
      const loginName = this.browser.elementIdElement(users.value[user].ELEMENT, './td[1]').getText();
      if (userLogin === loginName) {
        return users.value[user];
      }
    }

    return null;
  }

  async editUser (userLogin) {
    const userRow = await this.getUserRow(userLogin);
    if (userRow === null) {
      return null;
    }
    await this.browser.elementIdElement(userRow.ELEMENT, this.editPencil).click();

    return new EditUserPage(this.browser);
  }

  async clickRowBtnPopover (userRow) {
    await userRow;
    if (userRow === null) {
      this.logger.info('user row is null');
    }

    return this.browser.elementIdElement(userRow.ELEMENT, this.rowEllip).click();
  }


  async getUserRowDetails (userLogin) {
    const userRow = await this.getUserRow(userLogin);
    if (userRow === null) {
      return null;
    }
    const userDetails = new UserDetails();
    userDetails.loginName = await this.browser.elementIdElement(userRow.ELEMENT, './td[1]').getText();
    let name = await this.browser.elementIdElement(userRow.ELEMENT, './td[2]').getText();
    name = name.split(' ');
    userDetails.firstName = name[0];
    userDetails.lastName = name[1];
    userDetails.email = await this.browser.elementIdElement(userRow.ELEMENT, './td[3]').getText();
    await this.clickRowBtnPopover(userRow);
    const popover = await this.popoverContent;
    userDetails.phone = await this.browser.elementIdElement(popover.value.ELEMENT, './ul/li[2]').getText();
    userDetails.userType = await this.browser.elementIdElement(popover.value.ELEMENT, './ul/li[3]').getText();

    return userDetails;
  }
}

