import UsersPage from './users/UsersPage';
import Page from '../Page.js';
import {hasTabOpen} from '../../utilities/webdriverHelper/tabsHelper';
import MarketsPage from './MarketsPage';

export default class MainPage extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.markets = '//li/a/span[text() = "Markets"]';
    this.strategy = '//li/a/span[text() = "Strategy"]';
    this.strategyTypes = '//li/a/span[text() = "Strategy Types"]';
    this.countries = '//li/a/span[text() = "Countries"]';
    this.currencies = '//li/a/span[text() = "Currencies"]';
    this.exchange = '//li/a/span[text() = "Exchange"]';
    this.users = '//li/a/span[text() = "Users"]';
    this.market = '//li/a/span[text() = "Market"]';
    this.transactionBlotters = '//li/a/span[text() = "Transaction Blotters"]';
    this.marketViews = '//li/a/span[text() = "MarketViews"]';
    this.marketScheduler = '//li/a/span[text() = "Market Scheduler"]';
    this.strategy = '//li/a/span[text() = "Strategy"]';
    this.halt = '//span[text()="Halt Trading System"]';
    this.titleText = 'Fenics - bluechip/bluechip-operator-app';
  }

  get title () {
    return this.titleText;
  }

  switchToWindow () {
    return this.browser.waitUntil(() => hasTabOpen(this.browser, this.title), this.configuration.shortTimeout);
  }

  pageHasLoaded () {
    return super.pageHasLoaded(this.markets);
  }

  get marketsMenuItem () {
    return this.browser.element(this.markets);
  }

  async clickMarketMenuItem () {
    await this.marketMenuItem.click();

    return new MarketsPage(this.context);
  }

  get strategyMenuItem () {
    return this.browser.element(this.strategy);
  }

  get strategyTypesMenuItem () {
    return this.browser.element(this.strategyTypes);
  }

  get countriesMenuItem () {
    return this.browser.element(this.countries);
  }

  get currenciesMenuItem () {
    return this.browser.element(this.currencies);
  }

  get exchangeMenuItem () {
    return this.browser.element(this.exchange);
  }

  get usersMenuItem () {
    return this.browser.element(this.users);
  }

  async clickUsersMenuItem () {
    await this.usersMenuItem.click();

    return new UsersPage(this.context);
  }

  get transactionBlotterMenuItem () {
    return this.browser.element(this.transactionBlotters);
  }

  get marketMenuItem () {
    return this.browser.element(this.market);
  }

  get marketViewsMenuItem () {
    return this.browser.element(this.marketViews);
  }

  get marketSchedulerMenuItem () {
    return this.browser.element(this.marketScheduler);
  }

  get marketSegmentsMenuItem () {
    return this.browser.element(this.strategy);
  }

  get auditLogsMenuItem () {
    return this.browser.element(this.strategy);
  }

  get globalSettinsMenuItem () {
    return this.browser.element(this.strategy);
  }

  get legalEntitiesMenuItem () {
    return this.browser.element(this.strategy);
  }

  get desksMenuItem () {
    return this.browser.element(this.strategy);
  }

  get haltTradingSystemMenuItem () {
    return this.browser.element(this.halt);
  }
}
