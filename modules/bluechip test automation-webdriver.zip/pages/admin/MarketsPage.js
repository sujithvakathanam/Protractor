import Page from '../Page.js';

export default class MarketsPage extends Page {
  constructor (context) {
    super(context);
    this.browser = global.browser;
  }

  marketTab (title) {
    return this.browser(`//a[text()="${title}"]`);
  }

  clickMarketTab (title) {
    return this.marketTab(title).click();
  }

  getMarketRow (marketRow) {
    if (typeof marketRow !== 'MarketRow') {
      throw new Error(this.error);
    }
  }
}

export class MarketRow {
  constructor (underlying, strategy, expiry, strikes, ratio, bid, ask, ref, delta, wDelta) {
    this.underlying = underlying;
    this.strategy = strategy;
    this.expiry = expiry;
    this.strikes = strikes;
    this.ratio = ratio;
    this.bid = bid;
    this.ask = ask;
    this.ref = ref;
    this.delta = delta;
    this.wDelta = wDelta;
    this.error = `getMarketRow expects parameter of type MarketRow found type ${typeof marketRow}`;
  }
}

