import Page from '../../Page';
import {FILL_TYPE, TIME_TYPE} from '../../../constant/GenericType';
import DropDownHelper from '../../../lib/DropDownHelper';

export default class OrderBook extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.buttonOk = 'button[data-id="BTN_OK"]';
    this.buttonConfirm = 'button[data-id="BTN_CONFIRM"]';
    this.strategyFldBidPrice = '//input[@id="newBidPrice" or @id="bidPrice"]';
    this.strategyFldBidSize = '//input[@id="newBidSize" or @id="bidSize"]';
    this.strategyFldOfferPrice = '//input[@id="newOfferPrice" or @id="offerPrice"]';
    this.strategyFldOfferSize = '//input[@id="newOfferSize" or @id="offerSize"]';
    this.strategyConfirmOfferSize = '//span[../label[text()="Offer Size"]]';
    this.strategyConfirmBidSize = '//span[../label[text()="Bid Size"]]';
    this.strategyConfirmOfferPrice = '//span[../label[text()="Offer Price"]]';
    this.strategyConfirmBidPrice = '//span[../label[text()="Bid Price"]]';
    this.confirmOrderTime = '//span[../label="Time"]';
    this.confirmOrderFill = '//span[../label="Fill"]';
    this.vcInProgress = '//span[text()="VOLUME CLEARING IN PROGRESS"]';
    this.submitButtonSelector = 'button[data-id="BTN_SUBMIT"]';
    this.updateButton = 'button[data-id="BTN_UPDATE"]';
    this.timeInForceDD = '//div[@id="timeInForce"]';
    this.fillConditionDD = '//div[@id="fillCondition"]';
    this.tradingUserSelect = '//select[./option[@label="Select Trading User"]]';
    this.enterOfferSelector = '//span[normalize-space(text()) = "ENTER OFFER"]';
  }

  get fldBidPrice () {
    return this.browser.element(this.strategyFldBidPrice);
  }

  get fldBidSize () {
    return this.browser.element(this.strategyFldBidSize);
  }

  get fldOfferPrice () {
    return this.browser.element(this.strategyFldOfferPrice);
  }

  get fldOfferSize () {
    return this.browser.element(this.strategyFldOfferSize);
  }

  get confirmOfferSizeValue () {
    return this.browser.element(this.strategyConfirmOfferSize);
  }

  get confirmBidSizeValue () {
    return this.browser.element(this.strategyConfirmBidSize);
  }

  get confirmOfferPriceValue () {
    return this.browser.element(this.strategyConfirmOfferPrice);
  }

  get confirmBidPriceValue () {
    return this.browser.element(this.strategyConfirmBidPrice);
  }

  get confirmOrderTimeValue () {
    return this.browser.element(this.confirmOrderTime);
  }

  get confirmOrderFillTypeValue () {
    return this.browser.element(this.confirmOrderFill);
  }

  get volumeClearing () {
    return this.browser.element(this.vcInProgress);
  }

  get btnUpdate () {
    return this.browser.element(this.updateButton);
  }

  get btnOkSelector () {
    return this.buttonOk;
  }

  get enterOfferButton () {
    return this.browser.element(this.enterOfferSelector);
  }

  get btnOK () {
    return this.browser.element(this.btnOkSelector);
  }

  btnOkExists () {
    return this.browser.isExisting(this.btnOkSelector);
  }

  get btnConfirmSelector () {
    return this.buttonConfirm;
  }

  get confirmBtn () {
    return this.browser.element(this.btnConfirmSelector);
  }

  btnConfirmExists () {
    return this.browser.isExisting(this.btnConfirmSelector);
  }

  btnConfirmClick () {
    return this.confirmBtn.click();
  }

  btnOkClick () {
    return this.btnOk.click();
  }

  get ddTimeInForce () {
    const ddHelper = new DropDownHelper(this.context, this.timeInForceDD);

    return ddHelper;
  }

  get ddFillCondition () {
    const ddHelper = new DropDownHelper(this.context, this.fillConditionDD);

    return ddHelper;
  }

  async enterBidPrice (price) {
    await this.fldBidPrice.setValue(price);
  }

  getBidPrice () {
    return this.fldBidPrice.getValue();
  }

  getBidSize () {
    return this.fldBidSize.getValue();
  }

  enterBidSize (size) {
    return this.fldBidSize.setValue(size);
  }

  enterOfferPrice (price) {
    return this.fldOfferPrice.setValue(price);
  }

  getOfferPrice () {
    return this.fldOfferPrice.getValue();
  }


  enterOfferSize (size) {
    return this.fldOfferSize.setValue(size);
  }

  getOfferSize () {
    return this.fldOfferSize.getValue();
  }

  async enterOffer (price, size, timeInForce = TIME_TYPE.day, fillCondition = FILL_TYPE.partial) {
    await this.enterOfferPrice(price);

    await this.browser.waitUntil(async () => {
      const sizeValue = await this.getOfferSize();

      return sizeValue !== '';
    }, this.configuration.shortTimeout);

    await this.browser.pause(this.configuration.veryShortTimeout);
    await this.enterOfferSize('');
    await this.browser.pause(this.configuration.veryShortTimeout);
    await this.enterOfferSize(size);
    await this.selectTimeInForce(timeInForce);

    if (timeInForce === TIME_TYPE.immediate) {
      await this.selectFillCondition(fillCondition);
    }
  }

  async enterBid (price, size, timeInForce = TIME_TYPE.day, fillCondition = FILL_TYPE.partial) {
    await this.enterBidPrice(price);

    await this.browser.waitUntil(async () => {
      const sizeValue = await this.getBidSize();

      return sizeValue !== '';
    }, this.configuration.shortTimeout);

    await this.browser.pause(this.configuration.veryShortTimeout);
    await this.enterBidSize('');
    await this.browser.pause(this.configuration.veryShortTimeout);
    await this.enterBidSize(size);

    await this.selectTimeInForce(timeInForce);

    if (timeInForce === TIME_TYPE.immediate) {
      await this.selectFillCondition(fillCondition);
    }
  }

  async btnEnterOfferDoubleClick () {
    await this.enterOfferButton.doubleClick();
  }

  async selectTimeInForce (timeInForce = TIME_TYPE.day) {
    await this.ddTimeInForce.setSelected(timeInForce);
  }

  async selectFillCondition (fillCondition = FILL_TYPE.partial) {
    await this.ddFillCondition.setSelected(fillCondition);
  }

  get btnSubmit () {
    return this.browser.element(this.submitButtonSelector);
  }

  async btnSubmitClick () {
    await this.btnSubmit.click();
  }

  async btnUpdateClick () {
    await this.btnUpdate.click();
  }

  async btnOkClick () {
    await this.btnOK.click();
  }

  async vcOverlayDisplayed () {
    return this.found(await this.volumeClearing);
  }

  async disabled () {
    const disabled = await this.fldBidPriceEnabled() | await this.fldBidSizeEnabled() | await this.fldOfferPriceEnabled() | await this.fldOfferSizeEnabled() | await this.btnSubmitEnabled();

    return !disabled;
  }

  btnEnterOfferEnabled () {
    return this.enterOfferButton.isEnabled();
  }

  btnUpdateEnabled () {
    return this.btnUpdate.isEnabled();
  }

  btnSubmitEnabled () {
    return this.btnSubmit.isEnabled();
  }

  btnSubmitVisible () {
    return this.btnSubmit.isVisible();
  }

  fldBidPriceVisible () {
    return this.fldBidPrice.isVisible();
  }

  fldBidPriceEnabled () {
    return this.fldBidPrice.isEnabled();
  }

  fldBidSizeVisible () {
    return this.fldBidSize.isVisible();
  }

  fldBidSizeEnabled () {
    return this.fldBidSize.isEnabled();
  }

  fldOfferPriceVisible () {
    return this.fldOfferPrice.isVisible();
  }

  fldOfferPriceEnabled () {
    return this.fldOfferPrice.isEnabled();
  }

  fldOfferSizeVisible () {
    return this.fldOfferSize.isVisible();
  }

  fldOfferSizeEnabled () {
    return this.fldOfferSize.isEnabled();
  }

  getConfirmationBidSize () {
    return this.confirmBidSizeValue.getText();
  }

  getConfirmationOfferSize () {
    return this.confirmOfferSizeValue.getText();
  }

  getConfirmationOfferPrice () {
    return this.confirmOfferPriceValue.getText();
  }

  getConfirmationBidPrice () {
    return this.confirmBidPriceValue.getText();
  }

  getConfirmationOrderFillType () {
    return this.confirmOrderFillTypeValue.getText();
  }

  getConfirmationOrderTime () {
    return this.confirmOrderTimeValue.getText();
  }
}
