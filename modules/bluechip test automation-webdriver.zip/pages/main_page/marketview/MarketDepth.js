import Page from '../../Page';
import Formatter from '../../../lib/Formatter';


export default class MarketDepth extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.strategyTitle = '#marketDepthArea [data-id="PROMPT_SELECT_STRATEGY"]';
    this.strategyDelta = '#marketDepthArea [data-id="DELTA"]';
    this.strategyRef = '#marketDepthArea [data-id="REF"]';
    this.strategyStrikes = '#marketDepthArea [data-id="STRIKES"]';
    this.onGoingRfsMsgSelector = '#marketDepthArea [data-id="RFS_ERROR"]';
    this.okBtnSelector = '#marketDepthArea button[data-id="BTN_OK"]';
    this.rfsBtnSelector = '#marketDepthArea button[data-id="BTN_RFS"]';
    this.marketDepthTblSelector = '.market-depth-list';
  }

  get title () {
    return this.browser.element(this.strategyTitle);
  }

  get delta () {
    return this.browser.element(this.strategyDelta);
  }

  get ref () {
    return this.browser.element(this.strategyRef);
  }

  get strikes () {
    return this.browser.element(this.strategyStrikes);
  }

  get requestQuotesBtn () {
    return this.browser.element(this.rfsBtnSelector);
  }

  requestQuotesBtnExists () {
    return this.browser.isExisting(this.rfsBtnSelector);
  }

  get onGoingRfsMsg () {
    return this.browser.element(this.onGoingRfsMsgSelector);
  }

  onGoingRfsMsgExists () {
    return this.browser.isExisting(this.onGoingRfsMsgSelector);
  }

  get okBtn () {
    return this.browser.element(this.okBtnSelector);
  }

  clickOkBtn () {
    return this.okBtn.click();
  }

  getTitle () {
    return this.title.getText();
  }

  getDelta () {
    return this.delta.getText();
  }

  getRef () {
    return this.ref.getText();
  }

  getStrikes () {
    return this.strikes.getText();
  }

  expectedTitle (instrument) {
    return `${instrument.underlying} ${instrument.strategy} ${instrument.expiry}`;
  }

  // Buy and sell
  tblXpath (price, size, rowNumber = null, side) {
    const buyOrSell = side === 'BUY' ? 'SELL' : 'BUY';
    const formatedPrice = Formatter.fmtPrice(price);
    let xpath = `(//div[@class="market-depth-list-row" and @data-side="${side}"`;
    xpath += size === null ? '' : ` and div[@data-name='SIZE' and normalize-space(text())='${size}']`;
    xpath += price === null ? '' : ` and div[@data-name='PRICE' and div/button/span[normalize-space(text()) = '${formatedPrice}' | normalize-space(text()) = ${buyOrSell}]]`;
    xpath += '])';
    xpath += rowNumber === null ? '' : `[${rowNumber}]`;

    this.logger.debug(`MarketDepth - tblXPath - xpath: ${xpath}`);

    return {
      edit () {
        xpath += '/div/button/i[text()="create"]';

        return xpath;
      },

      cancel () {
        xpath += '/div/button/i[text()="delete"]';

        return xpath;
      },

      size () {
        xpath += '/div[@data-name="SIZE"]';

        return xpath;
      },

      divPrice () {
        xpath += '/div[@data-name="PRICE"]/div';

        return xpath;
      },

      price () {
        xpath += '/div[@data-name="PRICE"]/div/button';

        return xpath;
      }

    };
  }

  async clickBuy (ask, askSize, rowNumber = null) {
    let text = '';
    const askXpath = this.tblXpath(ask, askSize, rowNumber, 'SELL').price();
    await this.browser.waitForExist(askXpath, this.configuration.veryShortTimeout);

    try {
      await this.browser.waitUntil(async () => {
        text = await this.browser.moveToObject(askXpath).getText(askXpath);

        return text.includes('BUY');
      }, this.configuration.veryShortTimeout);
    } catch (err) {
      this.logger.info('MarketDepth clickBuy - Could not click on buy.');
    }

    if (text.includes('BUY')) {
      return this.clickIfFound(this.browser.element(askXpath));
    }

    return false;
  }

  async clickSell (bid, bidSize, rowNumber = null) {
    let text = '';
    const bidXpath = this.tblXpath(bid, bidSize, rowNumber, 'BUY').price();
    await this.browser.waitForExist(bidXpath, this.configuration.veryShortTimeout);

    try {
      await this.browser.waitUntil(async () => {
        text = await this.browser.moveToObject(bidXpath).getText(bidXpath);

        return text.includes('SELL');
      }, this.configuration.veryShortTimeout);
    } catch (err) {
      // Do nothing
    }

    if (text.includes('SELL')) {
      return this.clickIfFound(this.browser.element(bidXpath));
    }

    return false;
  }

  async clickEditBid (bid, bidSize, rowNumber = null) {
    const xpath = await this.tblXpath(bid, bidSize, rowNumber, 'BUY').edit();

    return this.clickIfFound(await this.browser.element(xpath));
  }

  async clickDeleteBid (bid, bidSize, rowNumber = null) {
    const xpath = await this.tblXpath(bid, bidSize, rowNumber, 'BUY').cancel();

    return this.clickIfFound(await this.browser.element(xpath));
  }

  async clickEditAsk (ask, size, rowNumber = null) {
    const xpath = await this.tblXpath(ask, size, rowNumber, 'SELL').edit();

    return this.clickIfFound(await this.browser.element(xpath));
  }

  async clickDeleteAsk (ask, size, rowNumber = null) {
    const xpath = await this.tblXpath(ask, size, rowNumber, 'SELL').cancel();

    return this.clickIfFound(await this.browser.element(xpath));
  }

  async askFound (ask, size, rowNumber = null) {
    const xpath = await this.tblXpath(ask, size, rowNumber, 'SELL').edit();


    return this.found(await this.browser.element(xpath));
  }

  async bidFound (bid, size, rowNumber = null) {
    const xpath = await this.tblXpath(bid, size, rowNumber, 'BUY').edit();

    return this.found(await this.browser.element(xpath));
  }

  async clickRequestQuotesBtn () {
    return this.clickIfFound(await this.requestQuotesBtn);
  }

  requestQuotesBtnEnabled () {
    return this.requestQuotesBtn.isEnabled();
  }

  async textExistsInMarketDepthTable (text) {
    const innerHtml = await this.browser.getHTML(this.marketDepthTblSelector);

    return innerHtml.includes(text);
  }

  async getBidByRow (rowNumber) {
    const bidXpath = await this.tblXpath(null, null, rowNumber, 'BUY').price();
    const sizeXpath = await this.tblXpath(null, null, rowNumber, 'BUY').size();
    const bid = await this.browser.element(bidXpath).getText();
    const size = await this.browser.element(sizeXpath).getText();
    const returnVal = {bid,
      size};

    return returnVal;
  }

  async getAskByRow (rowNumber) {
    const askXpath = await this.tblXpath(null, null, rowNumber, 'SELL').price();
    const sizeXpath = await this.tblXpath(null, null, rowNumber, 'SELL').size();

    const ask = await this.browser.element(askXpath).getText();
    const size = await this.browser.element(sizeXpath).getText();

    const returnVal = {ask,
      size};

    return returnVal;
  }
}
