import Page from '../../Page';
import {COLUMNS} from '../../../constant/column';
const chaiAsPromised = require('chai-as-promised');
const chai = require('chai');
chai.use(chaiAsPromised);
const expect = chai.expect;
import {COLOR_PURPOSE} from '../../../constant/GenericType';
import {frameworkConfig} from '../../../config/framework.config';

export default class OrderTable extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.shortPause = 2000;
  }

  get clearFiltersLink () {
    return this.browser.element('#MarketViewContainer button[data-id="CLEAR_FILTERS"]');
  }

  clickClearFiltersLink () {
    return this.clearFiltersLink.click();
  }

  get filterStatus () {
    return this.browser.element('//div[input[@name="status"]]');
  }

  get filterUnderlying () {
    return this.browser.element('//div[input[@name="underlying"]]');
  }

  get filterStrategy () {
    return this.browser.element('//div[input[@name="strategy"]]');
  }

  get filterExpiry () {
    return this.browser.element('//div[input[@name="expiry"]]');
  }

  get filterStrikes () {
    return this.browser.element('//div[input[@name="strike"]]');
  }

  get filterRatio () {
    return this.browser.element('//div[input[@name="ratio"]]');
  }

  get filterRef () {
    return this.browser.element('//div[input[@name="ref"]]');
  }

  get filterDelta () {
    return this.browser.element('//div[input[@name="delta"]]');
  }

  get filterBidSize () {
    return this.browser.element('//div[input[@name="bidSize"]]');
  }

  get filterBid () {
    return this.browser.element('//div[input[@name="bid"]]');
  }

  get filterAskSize () {
    return this.browser.element('//div[input[@name="askSize"]]');
  }

  get filterLast () {
    return this.browser.element('//div[input[@name="last"]]');
  }

  get filterTime () {
    return this.browser.element('//div[input[@name="time"]]');
  }

  async setFilter (filter, value) {
    await filter.click();
    if (value === '' || value === null) {
      for (let val = 0; val < 30; val++) {
        await this.browser.keys('Backspace');
      }
      await this.browser.keys('Enter');
    } else {
      await this.browser.element(`//li/span[text()="${value}"]`).click();
    }
  }

  get sortByUnderlying () {
    return this.browser.element('//th[normalize-space(text()) = "Underlying"]');
  }

  clickSortByUnderlying () {
    return this.sortByUnderlying.click();
  }

  get sortByStrategy () {
    return this.browser.element('//th[normalize-space(text()) = "Strategy"]');
  }

  clickSortByStrategy () {
    return this.sortByStrategy.click();
  }

  get sortByExpiry () {
    return this.browser.element('//th[normalize-space(text()) = "Expiry"]');
  }

  clickSortByExpiry () {
    return this.sortByExpiry.click();
  }

  get sortByStrikes () {
    return this.browser.element('//th[normalize-space(text()) = "Strikes"]');
  }

  clickSortByStrikes () {
    return this.sortByStrikes.click();
  }

  get sortByRatio () {
    return this.browser.element('//th[normalize-space(text()) = "Ratio"]');
  }

  clickSortByRatio () {
    return this.sortByRatio.click();
  }

  get sortByRef () {
    return this.browser.element('//th[normalize-space(text()) = "Ref"]');
  }

  clickSortByRef () {
    return this.sortByRef.click();
  }

  get sortByDelta () {
    return this.browser.element('//th[normalize-space(text()) = "Delta"]');
  }

  clickSortByDelta () {
    return this.sortByDelta.click();
  }

  get sortByBidSize () {
    return this.browser.element('//th[normalize-space(text()) = "Size (lots)" and contains(@ng-class,"info.buy.size")]');
  }

  clickSortByBidSize () {
    return this.sortByBidSize.click();
  }

  get sortByBid () {
    return this.browser.element('//th[normalize-space(text()) = "Bid"]');
  }

  clickSortByBid () {
    return this.sortByBid.click();
  }

  get sortByAsk () {
    return this.browser.element('//th[normalize-space(text()) = "Ask"]');
  }

  clickSortByAsk () {
    return this.sortByAsk.click();
  }

  get sortByAskSize () {
    return this.browser.element('//th[normalize-space(text()) = "Size (lots)" and contains(@ng-class,"info.sell.size")]');
  }

  clickSortByAskSize () {
    return this.sortByAskSize.click();
  }

  get sortByLast () {
    return this.browser.element('//th[normalize-space(text()) = "Last"]');
  }

  clickSortByLast () {
    return this.sortByLast.click();
  }

  get sortByTime () {
    return this.browser.element('//th[normalize-space(text()) = "Time"]');
  }

  clickSortByTime () {
    return this.sortByTime.click();
  }

  get tblScrollbar () {
    return this.browser.element('//div[@id="marketViewScrollbar"]');
  }

  get tblScrollbbarStyle () {
    return this.browser.element('//div[@id="marketViewScrollbar"]/div[starts-with(@class,"scrollbar-scroll")]');
  }

  tblOrdersRowSelector (strategy) {
    return `.market-view-list-row[data-name="${strategy.rowDataName}"]`;
  }

  tblOrdersRow (strategy) {
    return this.browser.element(`.market-view-list-row[data-name="${strategy.rowDataName}"]`);
  }

  async scrollToTableEnd (tdHandler) {
    let scroll = true;
    let data = 'x';
    await tdHandler.firstRow.click();
    while (scroll) {
      await this.tblScrollbar.keys('End');
      const currentData = await this.tblScrollbbarStyle.getAttribute('style');
      if (currentData !== data) {
        data = currentData;
      } else {
        scroll = false;
      }
    }
  }

  async getTableRow (strategy) {
    const rowSelector = await this.tblOrdersRowSelector(strategy);
    this.logger.debug(`Searching for table row using selector: '${rowSelector}'`);

    return new TdHandler(rowSelector, this.context);
  }
}

class TdHandler extends Page {
  constructor (rowSelector, context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.rowSelector = rowSelector;
  }

  get strategyId () {
    return this.browser.getAttribute(this.rowSelector, 'data-id');
  }

  getStrategyId () {
    return this.strategyId;
  }

  get statusSelector () {
    return `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.STATUS}"]`;
  }

  get statusBtnSelector () {
    const btnSelector = `${this.statusSelector} button`;

    return btnSelector;
  }

  get statusBadgeSelector () {
    return `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.STATUS}"] .status-badge`;
  }

  get initiatorBadgeSelector () {
    return `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.INITIATOR}"] .status-badge.status-badge-lp`;
  }

  get status () {
    return this.browser.element(this.statusBadgeSelector);
  }

  get initiatorBadge () {
    return this.browser.element(this.initiatorBadgeSelector);
  }

  getInitiatorBadgeText () {
    return this.initiatorBadge.getText();
  }

  get statusCell () {
    return this.browser.element(this.statusSelector);
  }

  getStatusButtonText () {
    return this.browser.element(this.statusBtnSelector).getText();
  }

  async getStatusText () {
    const statusBtnExists = await this.browser.isExisting(this.statusBtnSelector);

    if (statusBtnExists) {
      return this.getStatusButtonText();
    }

    return this.statusCell.getText();
  }

  async verifyStatusColour (expectedColour) {
    const isMatch = await super.compareCssColorValues(this.statusBadgeSelector, 'background-color', expectedColour);
    expect(isMatch).to.equal(true, `Expected status badge color to match ${JSON.stringify(expectedColour)}`);
  }

  async verifyInitiatorBadgeColour (expectedColour) {
    const isMatch = await super.compareCssColorValues(this.initiatorBadgeSelector, 'background-color', expectedColour);
    expect(isMatch).to.equal(true, `Expected status badge color to match ${JSON.stringify(expectedColour)}`);
  }

  async waitUntilSizeAndPrice (bidSize, askSize, price, timeout = context.shortTimeout) {
    let matched = false;
    let currentBidSize = '';
    let currentAskSize = '';
    let currentPrice = '';
    const decimalPlaces = 3;

    try {
      matched = await this.browser.waitUntil(
        async () => {
          currentBidSize = await this.getBidSize();
          currentAskSize = await this.getAskSize();
          currentPrice = await this.getPrices();

          matched = parseInt(currentBidSize, 10) === parseInt(bidSize, 10)
          && parseInt(currentAskSize, 10) === parseInt(askSize, 10)
          && currentPrice === parseFloat(price).toFixed(decimalPlaces);

          this.logger.debug(`OrderTable waitUntilSizeAndPrice - Matched: ${matched} expected bid size:${bidSize} ask size:${askSize} price:${price} actual bid size:${currentBidSize} ask size:${currentAskSize} price:${currentPrice}`);

          return matched;
        },
        timeout,
        `Timed out after ${timeout}ms, Market View strategy row Bid Size, Ask Size, Price expected: ${bidSize}, ${askSize}, ${price} actual:${currentBidSize}, ${currentAskSize}, ${currentPrice}`
      );
    } catch (error) {
      this.logger.debug(error);
    }

    return matched;
  }

  async waitUntilStatus (strategyStatus, timeout = context.shortTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(
        async () => {
          const status = await this.getStatusText();

          return status === strategyStatus;
        }
        , timeout
      );
    } catch (err) {
      found = false;
    }

    return found;
  }

  async waitUntilInitiator (strategyInitiator, timeout = context.shortTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(
        async () => {
          const status = await this.getInitiatorBadgeText();

          return status === strategyInitiator;
        }
        , timeout
      );
    } catch (err) {
      found = false;
    }

    return found;
  }

  clickStatus () {
    return this.statusCell.click();
  }

  async statusHasInactiveFlag () {
    let inactiveFlag = false;
    const statusBadgeExists = await this.browser.isExisting(this.statusBadgeSelector);

    if (statusBadgeExists) {
      const attributeClass = await this.browser.getAttribute(this.statusBadgeSelector, 'class');
      if (attributeClass) {
        inactiveFlag = attributeClass.includes('status-badge-inactive');
      }
    }

    return inactiveFlag;
  }

  async isStrategyTradable () {
    const isEnabled = true;
    // ToDo - debug and fix, currently CSS selector is not working with fenics front end reskin.
    /*
    const isEnabled = await super.compareCssColorValues(
      `${this.rowSelector} [data-name="UNDERLYING"]`,
      'color',
      COLOR_PURPOSE.PRIMARY_TEXT
    );
    */

    if (isEnabled) {
      const timeout = frameworkConfig.darkPhaseTimeout + frameworkConfig.litPhaseTimeout + frameworkConfig.tradePhaseTimeout + frameworkConfig.mediumTimeout;
      await this.waitUntilStatus('', timeout);
      const strategyStatus = await this.getStatusText();

      return !strategyStatus;
    }

    return false;
  }

  get initiator () {
    return this.browser.element(`${this.rowSelector} [data-name="INITIATOR"]`);
  }

  getInitiator () {
    return this.initiator.getText();
  }

  get underlying () {
    return this.browser.element(`${this.rowSelector} [data-name="UNDERLYING"]`);
  }

  clickUnderlying () {
    return this.underlying.click();
  }

  getUnderlying () {
    return this.underlying.getText();
  }

  get strategy () {
    return this.browser.element(`${this.rowSelector} [data-name="STRATEGY"]`);
  }

  getStrategy () {
    return this.strategy.getText();
  }

  get expiry () {
    return this.browser.element(`${this.rowSelector} [data-name="EXPIRY"]`);
  }

  getExpiry () {
    return this.expiry.getText();
  }

  get strikes () {
    return this.browser.element(`${this.rowSelector} [data-name="STRIKES"]`);
  }

  getStrikes () {
    return this.strikes.getText();
  }

  get ratio () {
    return this.browser.element(`${this.rowSelector} [data-name="RATIO"]`);
  }

  getRatio () {
    return this.ratio.getText();
  }

  get ref () {
    return this.browser.element(`${this.rowSelector} [data-name="REF"]`);
  }

  getRef () {
    return this.ref.getText();
  }

  get delta () {
    return this.browser.element(`${this.rowSelector} [data-name="DELTA"]`);
  }

  getDelta () {
    return this.delta.getText();
  }

  get bidSize () {
    return this.browser.element(`${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.BID_SIZE}"]`);
  }

  getBidSize () {
    return this.bidSize.getText();
  }

  get askSize () {
    return this.browser.element(`${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.ASK_SIZE}"]`);
  }

  getAskSize () {
    return this.askSize.getText();
  }

  get bidPrice () {
    const baseSelector = `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.BID_PRICE}"]`;
    const selector = `${baseSelector} span, ${baseSelector} button`;

    return this.browser.element(selector);
  }

  getBidPrice () {
    return this.bidPrice.getText();
  }

  clickBidPrice () {
    return this.bidPrice.click();
  }

  get askPrice () {
    const baseSelector = `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.ASK_PRICE}"]`;
    const selector = `${baseSelector} span, ${baseSelector} button`;

    return this.browser.element(selector);
  }

  getAskPrice () {
    return this.askPrice.getText();
  }

  get prices () {
    const selector = `${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.VC_PRICE}"] span`;

    return this.browser.element(selector);
  }

  getPrices () {
    return this.prices.getText();
  }

  clickAskPrice () {
    return this.askPrice.click();
  }

  get last () {
    return this.browser.element(`${this.rowSelector} [data-name="${COLUMNS.MARKET_VIEW_COLUMNS.COLUMN_NAMES.LAST}"] span`);
  }

  getLast () {
    return this.last.getText();
  }

  get firstRow () {
    const firstRowSelector = '.market-view-row-selector:first-of-type';

    return this.browser.element(firstRowSelector);
  }
}
