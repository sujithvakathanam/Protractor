import Page from '../../Page';


export default class StrategyInfo extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    this.titleSelector = '[data-id="PROMPT_SELECT_STRATEGY"]';
    this.underlyingSelector = '[data-id="UNDERLYING"]';
    this.refSelector = '[data-id="REF"]';
    this.ccySelector = '[data-id="CCY"]';
    this.deltaSelector = '[data-id="DELTA"]';
    this.withDeltaSelector = '[data-id="W_DELTA"]';
    this.exchangeSelector = '[data-id="EXCHANGE"]';
    this.futureSelector = '[data-id="FUTURE"]';
    this.futureExpirySelector = '[data-id="FUTURE_EXPIRY"]';
    this.minBlockSizeSelector = '[data-id="MIN_BLOCK_SIZE"]';
    this.legsSelector = '.strategy-info-table-row';
  }

  async getTitle () {
    const title = await this.browser.element(this.titleSelector).getText();

    return title.trim();
  }

  getUnderlying () {
    return this.browser.element(this.underlyingSelector).getText();
  }

  getRef () {
    return this.browser.element(this.refSelector).getText();
  }

  getCurrency () {
    return this.browser.element(this.ccySelector).getText();
  }

  getDelta () {
    return this.browser.element(this.deltaSelector).getText();
  }

  getExchange () {
    return this.browser.element(this.exchangeSelector).getText();
  }

  getWDelta () {
    return this.browser.element(this.withDeltaSelector).getText();
  }

  getFuture () {
    return this.browser.element(this.futureSelector).getText();
  }

  getFutureExp () {
    return this.browser.element(this.futureExpirySelector).getText();
  }

  getMinBlockSize () {
    return this.browser.element(this.minBlockSizeSelector).getText();
  }

  async getLegCount () {
    const legs = await this.browser.elements(this.legsSelector);

    return legs.value.length;
  }

  async getLeg (legNumber) {
    const leg = await this.browser.element(`${this.legsSelector}:nth-child(${legNumber})`);

    return new LegHelper(this.context, leg);
  }
}

class LegHelper {
  constructor (context, leg) {
    this.leg = leg;
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  getPolarity () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_POLARITY"]').getText();
  }

  getLegType () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_TYPE"]').getText();
  }

  getExpiry () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_EXPIRY"]').getText();
  }

  getStrike () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_STRIKE"]').getText();
  }

  getRef () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_REF"]').getText();
  }

  getRatio () {
    return this.browser.elementIdElement(this.leg.value.ELEMENT, '[data-id="LEG_RATIO"]').getText();
  }
}
