import Page from '../../Page';

export default class TradeInfo extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  get title () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TITLE"]');
  }

  getTitle () {
    return this.title.getText();
  }

  get exchangeIds () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="EXCHANGE_IDS"]');
  }

  getExchangeIds () {
    return this.exchangeIds.getText();
  }

  get transactionStatus () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_STATUS"]');
  }

  getTransactionStatus () {
    return this.transactionStatus.getText();
  }

  get exchange () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="EXCHANGE"]');
  }

  getExchange () {
    return this.exchange.getText();
  }

  get fenicsGoId () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_ID"]');
  }

  getFencisGoId () {
    return this.fenicsGoId.getText();
  }

  get time () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_TIME"]');
  }

  getTime () {
    return this.time.getText();
  }

  get tradeDate () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_DATE"]');
  }

  getTradeDate () {
    return this.tradeDate.getText();
  }

  get direction () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_DIRECTION"]');
  }

  getDirection () {
    return this.direction.getText();
  }

  get strategyPx () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_PRICE"]');
  }

  getStrategyPx () {
    return this.strategyPx.getText();
  }

  get refPx () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_REF"]');
  }

  getRefPx () {
    return this.refPx.getText();
  }

  get delta () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="DELTA"]');
  }

  getDelta () {
    return this.delta.getText();
  }

  get future () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="FUTURE"]');
  }

  getFuture () {
    return this.future.getText();
  }

  get underlying () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="UNDERLYING"]');
  }

  getUnderlying () {
    return this.underlying.getText();
  }

  get trader () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADER"]');
  }

  getTrader () {
    return this.trader.getText();
  }

  get currency () {
    return this.browser.element('.fenics-popover:not(.fenics-popover-hidden) [data-id="CCY"]');
  }

  getCurrency () {
    this.currency.getText();
  }

  async getLegs () {
    const legs = await this.browser.elements('.fenics-popover:not(.fenics-popover-hidden) [data-id="TRADE_LEG"]');

    return new legHelper(legs, this.browser);
  }
}

class legHelper extends Page {
  constructor (legs, context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  getLeg (legNumber) {
    if (legNumber <= 0) {
      throw new Error('getLeg(legNumber):- legNumber minimum value is 1');
    }
    const index = legNumber - 1;

    return this.legs.value[index];
  }

  getDirection (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="DIRECTION"]').getText();
  }

  getSize (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="SIZE"]').getText();
  }

  getType (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="LEG_TYPE"]').getText();
  }

  getExpiry (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="EXPIRY"]').getText();
  }

  getStrike (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="STRIKE"]').getText();
  }

  getLegPx (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="PRICE"]').getText();
  }

  getStatus (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="STATUS"]').getText();
  }

  getExchId (legNumber) {
    const leg = this.getLeg(legNumber);

    return this.browser.elementIdElement(leg.ELEMENT, '[data-id="EXCHANGE_ID"]').getText();
  }
}
