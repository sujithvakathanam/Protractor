import Page from '../../Page';
import TradesTable from './TradesTable';
import TradeInfo from './TradeInfo';

export default class MatchedTradesTab extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // selectors
    this.myTradesTabSelector = 'li[data-id="MY_TRADES"]';
    this.myDeskTabSelector =  'li[data-id="DESK_TRADES"]';
  }

  get myTradesTab () {
    return this.browser.element(this.myTradesTabSelector);
  }

  async clickMyTradesTab () {
    await this.myTradesTab.click();

    return new TradesTable(this.context, this.myTradesTabSelector);
  }

  get deskTradesTab () {
    return this.browser.element(this.myDeskTabSelector);
  }

  async clickDeskTradesTab () {
    await this.deskTradesTab.click();

    return new TradesTable(this.context, this.myDeskTabSelector);
  }

  getTradeInfoTab () {
    return new TradeInfo(this.context);
  }
}
