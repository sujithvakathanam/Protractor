import Page from '../../Page';
import TradeInfo from './TradeInfo';

export default class TradesTable extends Page {
  constructor (context, parentPageSelector) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.parentPageSelector = parentPageSelector;

    // Selectors
    this.exchStatus = '[data-id="HEADER_BTN_STATUS"]';
    this.strategyTH = '[data-id="HEADER_BTN_STRATEGY"]';
    this.hedgeTH = '[data-id="HEADER_BTN_HEDGE"]';
    this.filter = '[data-id="HEADER_BTN_FILTER"]';
    this.matchPxTH = '[data-id="HEADER_BTN_PRICE"]';
    this.sizeTH = '[data-id="HEADER_BTN_SIZE"]';
    this.traderTH = '[data-id="HEADER_BTN_TRADER"]';
    this.brokerTH = '[data-id="TRADER"]';
    this.tradeTH = '[data-id="HEADER_BTN_DATE"]';
  }

  get thExStatus () {
    return this.browser.element(this.exchStatus);
  }

  get thStrategy () {
    return this.browser.element(this.strategyTH);
  }

  get thHedge () {
    return this.browser.element(this.hedgeTH);
  }

  get thBuySellFilter () {
    return this.browser.element(this.filter);
  }

  get thMatchPx () {
    return this.browser.element(this.matchPxTH);
  }

  get thSize () {
    return this.browser.element(this.sizeTH);
  }

  get thTrader () {
    return this.browser.element(this.traderTH);
  }

  get thBroker () {
    return this.browser.element(this.brokerTH);
  }

  get thTradeDt () {
    return this.browser.element(this.tradeTH);
  }

  clickSortByStatus () {
    return this.thExStatus.click();
  }

  clickSortByStrategy () {
    return this.thStrategy.click();
  }

  clickSortByHedge () {
    return this.thHedge.click();
  }

  clickFilterBuySell () {
    return this.thBuySellFilter.click();
  }

  clickSortByMatchPx () {
    return this.thMatchPx.click();
  }

  clickSortBySize () {
    return this.thSize.click();
  }

  clickSortByTrader () {
    return this.thTrader.click();
  }

  clickSortByBroker () {
    return this.thBroker.click();
  }

  clickSortByTradeDt () {
    return this.thTradeDt.click();
  }

  async getTradeCount () {
    const tblRows = await this.browser.elements('.matched-trades-list-row');

    return tblRows.value.length;
  }

  async getTradeById (tradeId) {
    const tradeCount = await this.getTradeCount();

    for (let iTrade = 1; iTrade <= tradeCount; iTrade += 1) {
      const trade = await this.getTradeByRow(iTrade);
      await trade.clickOnTrade();
      const popover = await trade.getTradePopover();

      if (popover.tradeId === tradeId) {
        return trade;
      }

      await trade.dismissPopup();
    }

    return null;
  }

  async getFirstMatchingTrade (strategy, direction, matchedPx, size, trader, broker, tradeDt) {
    const tradeCount = await this.getTradeCount();

    for (let iTrade = 1; iTrade <= tradeCount; iTrade += 1) {
      const trade = await this.getTradeByRow(iTrade);
      let match = true;
      if (strategy !== null && match === true) {
        const tStrategy = await trade.getStrategy();
        match === tStrategy.trim === this.getTradeTitle(strategy);
      }
      if (direction !== null && match === true) {
        const bsIndication = await trade.getBuySellIndicator();
        match = bsIndication.trim() === direction;
      }
      if (matchedPx !== null && match === true) {
        const tMatchedPx = await trade.getMatchPx();
        match = tMatchedPx.trim() === parseFloat(matchedPx).toFixed(3);
      }
      if (size !== null && match === true) {
        const tSize = await trade.getSize();
        match = parseInt(tSize.trim(), 10) === parseInt(size, 10);
      }
      if (trader !== null && match === true) {
        const tTrader = await trade.getTrader();
        match = tTrader.trim() === trader;
      }
      if (broker !== null && match === true) {
        const tBroker = await trade.getBroker();
        match = tBroker.trim() === broker;
      }
      if (tradeDt !== null && match === true) {
        const tTradeDt = await trade.getTradeDt();
        match = tTradeDt.trim() === tradeDt;
      }
      if (match) {
        return trade;
      }
    }

    return null;
  }

  getTradeTitle (strategy) {
    let title = strategy.underlying.concat(
      ' ',
      strategy.strategy.shortName,
      ' ',
      strategy.expiry,
      ' ',
      strategy.strike,
      ' ',
      strategy.ratio,
      ' r',
      strategy.referencePrice,
      ' d',
      strategy.getDisplayDelta(),
      '%'
    );

    title = title.trim();
    title = title.replace('  ', ' ');

    return title;
  }

  async getTradeByRow (rowNumber) {
    const tradeRow = await this.browser.element(`.matched-trades-list-row:nth-child(${rowNumber})`);

    return new TradesHelper(this.context, tradeRow, this.parentPageSelector);
  }

  // Returns trade or null.
  async getTradeWhenDisplayed (strategy, tradeSide, tradeSize, tradePrice, timeout = this.configuration.shortTimeout) {
    let tradeHelper = null;
    let tradeStrategyTitle = this.getTradeTitle(strategy);

    const found = await this.browser.waitUntil(
      async () => {
        tradeHelper = await this.getTradeByRow(1);
        let strategyTitleInView = await tradeHelper.getStrategy();
        const sizeInView = await tradeHelper.getSize();
        const priceInView = await tradeHelper.getMatchPx();
        const sideInView = await tradeHelper.getBuySellIndicator();

        strategyTitleInView = strategyTitleInView.trim();
        strategyTitleInView = strategyTitleInView.replace('  ', ' ');
        tradeStrategyTitle = strategyTitleInView.trim();
        tradeStrategyTitle = tradeStrategyTitle.replace('  ', ' ');

        const titleMatched = tradeStrategyTitle === strategyTitleInView;
        const sizeMatched = parseInt(tradeSize) === parseInt(sizeInView);
        const priceMatched = parseFloat(tradePrice).toFixed(3) === parseFloat(priceInView).toFixed(3);
        const sideMatched = tradeSide === sideInView;

        const matched = titleMatched
          && sizeMatched
          && priceMatched
          && sideMatched;

        return matched;
      },
      timeout,
      `Timed out after ${timeout}, looking for trade in matched trader Title ${tradeStrategyTitle}, size ${tradeSize}, side ${tradeSide} and price ${tradePrice}`
    );

    if (!found) {
      tradeHelper = null;
    }

    return tradeHelper;
  }
}

class TradesHelper extends Page {
  constructor (context, tradeRow, parentPageSelector) {
    super(context);
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.trade = tradeRow;
    this.parentPageSelector = parentPageSelector;

    // selectors
    this.popupSelector = '.fenics-popover:not(.fenics-popover-hidden) span[data-id="TRADE_STATUS"] div';
  }

  get exchangeStatus () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="STATUS"]');
  }

  getExchangeStatus () {
    return this.exchangeStatus.getText();
  }

  get strategy () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="STRATEGY"]');
  }

  getStrategy () {
    return this.strategy.getText();
  }

  get hedge () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="HEDGE"]');
  }

  async isHedgeTicked () {
    const hedgeElem = this.hedge;
    const icon = this.browser.elementIdElement(hedgeElem.value.ELEMENT, '.fenics-icon');
    const iconType = icon.getText();
    if (iconType === 'check_circle') {
      return true;
    }

    return false;
  }

  get buySellIndicator () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="FILTER"]');
  }

  getBuySellIndicator () {
    return this.buySellIndicator.getText();
  }

  get matchPx () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="PRICE"]');
  }

  getMatchPx () {
    return this.matchPx.getText();
  }

  get size () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="SIZE"]');
  }

  getSize () {
    return this.size.getText();
  }

  get trader () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="TRADER"]');
  }

  getTrader () {
    return this.trader.getText();
  }

  get tradeDt () {
    return this.browser.elementIdElement(this.trade.value.ELEMENT, '[data-name="DATE"]');
  }

  getTradeDt () {
    return this.tradeDt.getText();
  }

  async clickOnTrade () {
    await this.exchangeStatus.moveToObject();
    await this.browser.waitForExist(this.popupSelector, this.configuration.shortTimeout);
    await this.exchangeStatus.click();

    return new TradeInfo(this.context);
  }

  async dismissPopup () {
    await this.browser.element(this.parentPageSelector).click();
    await this.browser.waitForExist(this.popupSelector, this.configuration.shortTimeout, true);
  }
}

