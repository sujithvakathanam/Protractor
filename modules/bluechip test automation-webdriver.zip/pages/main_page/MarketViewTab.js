import OrderTable from './marketview/OrderTable';
import OrderBook from './marketview/OrderBook';
import Page from '../Page';
import MarketDepth from './marketview/MarketDepth';
import StrategyInfo from './marketview/StrategyInfo';
import MarketViewTabs from '../../constant/MarketViewTabs';

export default class MarketViewTab extends Page {
  constructor (context, parentElement) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    this.parentElement = parentElement;
  }

  async clickTo () {
    await super.clickAll(this.parentElement);
  }

  findTab (tabId) {
    return this.browser.element(`[data-id="${tabId}"]`);
  }

  get tabMyOrders () {
    return this.findTab(MarketViewTabs.MY_ORDERS);
  }

  get tabDeskOrders () {
    return this.findTab(MarketViewTabs.DESK_ORDERS);
  }

  get tabEuroStoxx () {
    return this.findTab(MarketViewTabs.EUROSTOXX);
  }

  async clickTabEuroStoxx () {
    await this.tabEuroStoxx.click();


    return this.getEuroStoxxTable();
  }

  async clickSubTab (tabId) {
    await this.findTab(tabId).click();


    return this.getTable();
  }

  async clickTabMyOrders () {
    await this.tabMyOrders.click();


    return this.getTable();
  }

  async clickTabDeskOrders () {
    await this.tabDeskOrders.click();


    return this.getTable();
  }

  get tabMarketDepth () {
    return this.browser.element('#marketDepthArea [data-id="MARKET_DEPTH"]');
  }

  get tabStrategyInfo () {
    return this.browser.element('#marketDepthArea [data-id="STRATEGY_INFO"]');
  }

  async clickTab () {
    await this.parentElement.click();
  }

  getTable () {
    return new OrderTable(this.context);
  }

  getOrderBook () {
    return new OrderBook(this.context);
  }

  getEuroStoxxTable () {
    return this.getTable();
  }

  getMarketDepthTab () {
    return new MarketDepth(this.context);
  }

  getStrategyInfo () {
    return new StrategyInfo(this.context);
  }

  async clickStrategyInfoHeader () {
    await this.tabStrategyInfo.click();


    return this.getStrategyInfo();
  }

  async clickMarketDepthHeader () {
    await this.tabMarketDepth.click();


    return this.getMarketDepthTab();
  }
}
