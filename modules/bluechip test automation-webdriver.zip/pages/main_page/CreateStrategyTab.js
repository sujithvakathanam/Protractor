import Page from '../Page';
import WaitForHelper from '../../utilities/webdriverHelper/waitForHelper';
import DropDownHelper from '../../lib/DropDownHelper';

export default class CreateStrategyTab extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.waitForHelper = new WaitForHelper(context);

    // Selectors
    this.submit = '#product-builder-container [data-id="SUBMIT"]';
    this.errorMessage = '#product-builder-error';
    this.ddMarketElement = '#product-builder-market';
    this.ddUnderlyingElement = '#product-builder-underlying';
    this.productBuildStrategy = '#product-builder-strategy';
    this.ddStyleLocator = '#product-builder-style';
    this.refPrice = '#product-builder-hedge-reference-price';
    this.deltaInput = '#product-builder-hedge-delta';
    this.hedgeDD = '#product-builder-hedge-polarity';
    this.hedgeFuture = '#product-builder-hedge-future';
    this.atuProductBuilder = '#product-builder-atu';
  }

  async pageHasLoaded () {
    const marketDropDown = this.ddMarket;
    let ddEnabled = false;
    try {
      ddEnabled = await this.browser.waitUntil(() => marketDropDown.getDropDownEnabled(), this.configuration.shortTimeout);
    } catch (err) {
      ddEnabled = false;
    }

    return ddEnabled;
  }

  get errorMsg () {
    return this.browser.element(this.errorMessage);
  }

  get ddMarket () {
    return new DropDownHelper(this.context, this.ddMarketElement);
  }

  get ddUnderlying () {
    return new DropDownHelper(this.context, this.ddUnderlyingElement);
  }

  get ddStrategy () {
    return new DropDownHelper(this.context, this.productBuildStrategy);
  }

  get ddStyle () {
    return new DropDownHelper(this.context, this.ddStyleLocator);
  }

  get inputReferencePrice () {
    return new InputHelper(this.context, this.refPrice);
  }

  inputReferencePriceExists () {
    return this.browser.isExisting(this.refPrice);
  }

  get inputDelta () {
    return new InputHelper(this.context, this.deltaInput);
  }

  inputDeltaExists () {
    return this.browser.isExisting(this.deltaInput);
  }

  get deltaValue () {
    return this.inputDelta.getValue();
  }

  setDeltaValue (value) {
    return this.inputDelta.setValue(value);
  }

  get ddHedgePolarity () {
    return new DropDownHelper(this.context, this.hedgeDD);
  }

  ddHedgePolarityExists () {
    return this.browser.isExisting(this.hedgeDD);
  }

  get ddFuture () {
    return new DropDownHelper(this.context, this.hedgeFuture);
  }

  ddFutureExists () {
    return this.browser.isExisting(this.hedgeFuture);
  }

  getLegRowHelpers (legs) {
    const trSelector = '//table[1]/tbody/tr';
    const helpers = [];
    for (let legRow = 0; legRow < legs.length; legRow += 1) {
      helpers.push(new LegRowHelper(this.context, `${trSelector}[${legRow + 1}]`));
    }

    return helpers;
  }

  get associatedTradingUser () {
    return new DropDownHelper(this.context, this.atuProductBuilder);
  }

  get btnSubmitSelector () {
    return this.submit;
  }

  get btnSubmit () {
    return this.browser.element(this.btnSubmitSelector);
  }

  async btnSubmitClick () {
    const isEnabled = await this.waitForHelper.browserWaitForEnabled(this.btnSubmitSelector);
    let clicked = false;
    if (isEnabled === false) {
      this.logger.warn(`Submit button disabled after waiting ${this.configuration.veryShortTimeout}ms, Product Builder may be in error state?`);
    } else {
      await this.btnSubmit.click();
      await this.pageHasLoaded();
      clicked = true;
    }

    return clicked;
  }

  async addLegs (legs) {
    const legRowHelpers = this.getLegRowHelpers(legs);
    if (legRowHelpers.length !== legs.length) {
      throw new Error('Error creating LegRow helpers!');
    }

    for (let numberOfLegs = 0; numberOfLegs < legs.length; numberOfLegs += 1) {
      if (legs[numberOfLegs].expiry) {
        await legRowHelpers[numberOfLegs].expiry.setSelected(legs[numberOfLegs].expiry);
      }
      if (legs[numberOfLegs].strike) {
        await legRowHelpers[numberOfLegs].strike.setValue(legs[numberOfLegs].strike);
      }
      if (legs[numberOfLegs].ratio) {
        await legRowHelpers[numberOfLegs].ratio.setSelected(legs[numberOfLegs].ratio);
      }
    }
  }

  async hasStrategy (strategyName) {
    const strategyDropDown = await this.ddStrategy;
    const selections = await strategyDropDown.getSelections();
    const index = selections.indexOf(strategyName);

    return index !== -1;
  }

  async addNewStrategy (strategy) {
    await this.pageHasLoaded();

    if (strategy.market) {
      await this.ddMarket.setSelected(strategy.market);
    }


    if (strategy.underlying) {
      const underlyingDropDown = this.ddUnderlying;
      await this.browser.waitUntil(() => underlyingDropDown.getDropDownEnabled(), this.configuration.shortTimeout);
      await this.ddUnderlying.setSelected(strategy.underlying);
    }

    if (strategy.strategy) {
      const strategyDropDown = this.ddStrategy;
      await this.browser.waitUntil(() => strategyDropDown.getDropDownEnabled(), this.configuration.shortTimeout);
      await this.ddStrategy.setSelected(strategy.strategy.name);
    }

    if (strategy.style) {
      await this.waitForHelper.waitForExist(this.ddStyleLocator);
      await this.ddStyle.setSelected(strategy.style);
    }

    if (strategy.referencePrice) {
      await this.waitForHelper.waitForExist(this.refPrice);
      await this.inputReferencePrice.setValue(strategy.referencePrice);
    }

    if (strategy.hedgePolarity) {
      await this.ddHedgePolarity.setSelected(strategy.hedgePolarity);
    }

    if (strategy.strategy.hasFuture) {
      await this.ddFuture.setSelected(strategy.futureCode);
    }

    if (strategy.tradingUser) {
      await this.associatedTradingUser.setSelected(strategy.tradingUser);
    }

    if (strategy.legs && strategy.legs !== []) {
      await this.addLegs(strategy.legs);
    }

    if (strategy.delta !== null) {
      await this.waitForSuggestedDelta();
      await this.inputDelta.setValue(strategy.delta);
    } else if (strategy.delta === null && strategy.strategy.hasFuture) {
      const foundDelta = await this.waitForSuggestedDelta(this.configuration.shortTimeout);

      if (foundDelta) {
        const returnedDelta = await this.inputDelta.getValue();
        //TODO: dev needs to fix tags - workaround
        if (returnedDelta === '0') {
          console.log('Delta has been overwritten to 1 from 0 - temp fix for BC-4672')
          strategy.delta = 1;
          await this.inputDelta.setValue(strategy.delta);
        } else {
          strategy.delta = returnedDelta;
        }
      }
    }

    return strategy;
  }

  async waitForSuggestedDelta (timeout = this.configuration.shortTimeout) {
    let deltaFound = false;
    try {
      deltaFound = await this.browser.waitUntil(
        async () => {
          const deltaValue = await this.inputDelta.getValue();

          if (deltaValue !== '') {
            await this.browser.pause(this.context.veryShortTimeout);

            return true;
          }

          return false;
        },
        timeout
      );
    } catch (err) {
      this.logger.error(`Suggested delta is not being displayed: ${err}`);
    }

    return deltaFound;
  }

  async validatePage (strategy) {
    let pageValid = true;

    const pageMarket = await this.ddMarket.getSelected();
    if (pageMarket != strategy.market) {
      pageValid = false;
      this.logger.log(`CreateStrategyTab validatePage - Expected Market: ${strategy.market} Actual Market: ${pageMarket}`);
    }

    const pageUnderlying = await this.ddUnderlying.getSelected();
    if (pageUnderlying != strategy.underlying) {
      pageValid = false;
      this.logger.log(`CreateStrategyTab validatePage - Expected Underlying: ${strategy.underlying} Actual Underlying: ${pageUnderlying}`);
    }

    const pageStrategy = await this.ddStrategy.getSelected();
    if (pageStrategy != strategy.strategy.name) {
      pageValid = false;
      this.logger.log(`CreateStrategyTab validatePage - Expected Strategy: ${strategy.strategy.name} Actual Strategy: ${pageStrategy}`);
    }

    const pageStyle = await this.ddStyle.getSelected();
    if (pageStyle != strategy.style) {
      pageValid = false;
      this.logger.log(`CreateStrategyTab validatePage - Expected Style: ${strategy.style} Actual Style: ${pageStyle}`);
    }

    if (strategy.referencePrice === null || strategy.referencePrice === '') {
      const inputPriceExists = await this.inputReferencePriceExists();
      if (inputPriceExists === true) {
        pageValid = false;
        this.logger.log('CreateStrategyTab validatePage - Reference price field displayed, field should not be displayed on page');
      }
    } else {
      let pageReferencePrice = await this.inputReferencePrice.getValue();
      pageReferencePrice = pageReferencePrice.replace(/,/g, '');
      if (pageReferencePrice != strategy.referencePrice) {
        pageValid = false;
        this.logger.log(`CreateStrategyTab validatePage - Expected Reference Price: ${strategy.referencePrice} Actual Reference Price: ${pageReferencePrice}`);
      }
    }

    if (strategy.hedgePolarity) {
      const pageHedgePolarity = await this.ddHedgePolarity.getSelected();
      if (pageHedgePolarity != strategy.hedgePolarity) {
        pageValid = false;
        this.logger.log(`CreateStrategyTab validatePage - Expected Hedge Polarity: ${strategy.hedgePolarity} Actual Hedge Polarity: ${pageHedgePolarity}`);
      }
    }

    if (!strategy.strategy.hasFuture) {
      const ddFutureExists = await this.ddFutureExists();
      if (ddFutureExists == true) {
        pageValid = false;
        this.logger.log('CreateStrategyTab validatePage - Future Drop Down displayed, drop down should not be displayed on page');
      }
    } else {
      const pageFuture = await this.ddFuture.getSelected();
      if (pageFuture !== strategy.futureCode) {
        pageValid = false;
        this.logger.log(`CreateStrategyTab validatePage - Expected Future: ${strategy.future} Actual Hedge Polarity: ${pageFuture}`);
      }
    }

    if (strategy.legs && strategy.legs !== []) {
      const legsValid = await this.validateLegs(strategy.legs);
      if (legsValid == false) {
        pageValid = false;
      }
    }

    if (strategy.delta == null || strategy.delta === '') {
      const inputDeltaExists = await this.inputDeltaExists();
      if (inputDeltaExists == true) {
        pageValid = false;
        this.logger.log('CreateStrategyTab validatePage - Field Delta displayed, field should not be displayed on page');
      }
    } else {
      const inputDeltaVal = await this.inputDelta.getValue();
      if (strategy.delta != inputDeltaVal) {
        pageValid = false;
        this.logger.log(`CreateStrategyTab validatePage - Expected delta: ${strategy.delta} Actual delta: ${inputDeltaVal}`);
      }
    }

    return pageValid;
  }

  async validateLegs (legs) {
    let legsValid = true;
    const legRowHelpers = this.getLegRowHelpers(legs);

    if (legRowHelpers.length !== legs.length) {
      legsValid = false;
      this.logger.log('Number of legs on page does not match the number of legs defined in the strategy');
    }

    for (let i = 0; i < legs.length; i++) {
      const legnum = i + 1;
      if (legs[i].polarity) {
        const legPolarity = await legRowHelpers[i].polarity.getSelected();
        if (legPolarity != legs[i].polarity) {
          legsValid = false;
          this.logger.log(`CreateStrategyTab validateLegs - Leg ${legnum} polarity expected ${legs[i].polarity} actual ${legPolarity}`);
        }
      }

      const callPutVal = await legRowHelpers[i].callPut.getSelected();
      if (callPutVal != legs[i].callPut) {
        legsValid = false;
        this.logger.log(`CreateStrategyTab validateLegs - Leg ${legnum} C/P expected ${legs[i].callPut} actual ${callPutVal}`);
      }

      let expiryVal = await legRowHelpers[i].expiry.getSelected(legs[i].expiry);
      if (expiryVal.length > 7) {
        expiryVal = expiryVal.substring(0, 7);
      }
      if (expiryVal != legs[i].expiry) {
        legsValid = false;
        this.logger.log(`CreateStrategyTab validateLegs - Leg ${legnum} expiry expected ${legs[i].expiry} actual ${expiryVal}`);
      }

      let strikeVal = await legRowHelpers[i].strike.getValue(legs[i].strike);
      strikeVal = strikeVal.replace(/,/g, '');
      if (strikeVal != legs[i].strike) {
        legsValid = false;
        this.logger.log(`CreateStrategyTab validateLegs - Leg ${legnum} strike expected ${legs[i].strike} actual ${strikeVal}`);
      }

      const ratioVal = await legRowHelpers[i].ratio.getSelected(legs[i].ratio);
      if (ratioVal != legs[i].ratio) {
        legsValid = false;
        this.logger.log(`CreateStrategyTab validateLegs - Leg ${legnum} ratio expected ${legs[i].ratio} actual ${ratioVal}`);
      }
    }

    return legsValid;
  }
}

class LegRowHelper {
  constructor (context, rowSelector) {
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.rowSelector = rowSelector;

    // Selectors
    this.productBuilderPolarity = '//div[@id="product-builder-leg-polarity"]';
    this.productBuilderUnderlying = '//div[@id="product-builder-leg-underlying"]';
    this.productBuilderCallPut = '//div[@id="product-builder-leg-put-call"]';
    this.productBuilderLegExpiry = '//div[@id="product-builder-leg-expiry"]';
    this.productBuilderLegStrike = '//input[@id="product-builder-leg-strike"]';
    this.productBuilderLegRatio = '//div[@id="product-builder-leg-ratio"]';
  }

  get polarity () {
    return new DropDownHelper(this.context, this.rowSelector + this.productBuilderPolarity);
  }

  get underlying () {
    return new DropDownHelper(this.context, this.rowSelector + this.productBuilderUnderlying);
  }

  get callPut () {
    return new DropDownHelper(this.context, this.rowSelector + this.productBuilderCallPut);
  }

  get expiry () {
    return new DropDownHelper(this.context, this.rowSelector + this.productBuilderLegExpiry);
  }

  get strike () {
    return new InputHelper(this.context, this.rowSelector + this.productBuilderLegStrike);
  }

  get ratio () {
    return new DropDownHelper(this.context, this.rowSelector + this.productBuilderLegRatio);
  }
}

class InputHelper {
  constructor (context, parentSelector) {
    this.context = context;
    this.configuration = context.getConfiguration();
    this.parentSelector = parentSelector;
    this.browser = global.browser;
  }

  get inputSelector () {
    /*
     * TODO: This will change when we update CustomFinput to fenics-components InputNumber.
     * Input will then be contained in DOM tree inside parent
     */
    return this.parentSelector;
  }

  get input () {
    return this.browser.element(this.inputSelector);
  }

  getValue () {
    return this.input.getValue();
  }

  async setValue (newVal) {
    const isDisabled = await this.input.getAttribute('disabled');
    if (!isDisabled) {
      await this.input.setValue('');
      await this.input.setValue(newVal);
    }
  }
}
