import Page from '../Page';
import MarketViewTab from './MarketViewTab';
import CreateStrategyTab from './CreateStrategyTab';
import NotificationsPanel from './NotificationsPanel';
import MatchedTradesTab from './matchedtrades/MatchedTradesTab';
import {hasTabOpen} from '../../utilities/webdriverHelper/tabsHelper';
const chaiAsPromised = require('chai-as-promised');
const chai = require('chai');
chai.use(chaiAsPromised);
const expect = chai.expect;

export default class MainPageFrame extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this._windowHandle = null;

    // Selectors
    this.marketViewTab = '.fenics-menu-item[data-id="MARKET_VIEW"]';
    this.matchedTradesTab = '.fenics-menu-item[data-id="MATCHED_TRADES"]';
    this.createStrategyTab = '.fenics-menu-item[data-id="CREATE_STRATEGY"]';
    this.username = '.footer-item[data-id="USER_ID"]';
    this.settings = '.footer-button[data-id="BTN_USER_SETTINGS"]';

    this.logout = '.fenics-window__header__controls .window-control-icon:last-of-type';
    this.confirm = '.fenics-modal-confirm-body span.fenics-modal-confirm-title';
    this.description = '.fenics-modal-confirm-body div.fenics-modal-confirm-content';

    this.confirmLogout = '.fenics-modal-confirm-btns .ant-btn.ant-btn-primary';
    this.cancelLogout = '.fenics-modal-confirm-btns .ant-btn:not(.ant-btn-primary)';
    this.loadingOverlay = '.splash-loading';
    this.cancelMyOrdersSelector = '#panic-button-container button[data-id="CXL_MINE"]';
    this.cancelDeskOrdersSelector = '#panic-button-container button[data-id="CXL_DESK"]';
  }

  waitUntilWindowOpened () {
    const found = this.browser.waitUntil(() => hasTabOpen(this.browser, 'Fenics GO'), this.configuration.longTimeout);

    if (!found) {
      this.logger.error('Failed to find application window');
    }

    return found;
  }

  get notificationsPanel () {
    return new NotificationsPanel(this.context);
  }

  get tabMainHeaderMarketViewItem () {
    return this.browser.element(this.marketViewTab);
  }

  get tabMainHeaderMatchedTrades () {
    return this.browser.element(this.matchedTradesTab);
  }

  get tabMainHeaderStrategyListItem () {
    return this.browser.element(this.createStrategyTab);
  }

  get txtUserName () {
    return this.browser.element(this.username);
  }

  get btnLogout () {
    return this.browser.element(this.logout);
  }

  get btnSettings () {
    return this.browser.element(this.settings);
  }

  get txtConfirmLogout () {
    return this.browser.element(this.confirm);
  }

  get txtConfirmLogoutDescription () {
    return this.browser.element(this.description);
  }

  get btnLogoutConfirmOk () {
    return this.browser.element(this.confirmLogout);
  }

  get btnLogoutConfirmCancel () {
    return this.browser.element(this.cancelLogout);
  }

  set windowHandle (handle) {
    this._windowHandle = handle;
  }

  get windowHandle () {
    return this._windowHandle;
  }

  async pageHasLoaded () {
    try {
      const found = await this.browser.waitForExist(this.loadingOverlay, this.configuration.veryShortTimeout);

      if (!found) {
        this.logger.error('Timed out waiting for "Loading" overlay to appear');
      }
    } catch (error) {
      this.logger.error('Timed out waiting for "Loading" overlay to appear');
      throw error;
    }

    // Wait until the loading overlay is NOT present
    try {
      const found = await this.browser.waitForExist(this.loadingOverlay, this.configuration.veryLongTimeout, true);

      if (!found) {
        this.logger.error('Timed out waiting for "Loading" overlay to disappear');
      }
    } catch (error) {
      this.logger.error('Timed out waiting for "Loading" overlay to disappear');
      throw error;
    }

    try {
      const found = await this.browser.waitForExist(this.marketViewTab, this.configuration.longTimeout);

      if (!found) {
        this.logger.error('Failed to find Market View tab');
      }
    } catch (error) {
      this.logger.error('Failed to find Market View tab');
      throw error;
    }

    try {
      const found = await this.browser.waitForExist(this.createStrategyTab, this.configuration.mediumTimeout);

      if (!found) {
        this.logger.error('Failed to find Create Strategy tab');
      }
    } catch (error) {
      this.logger.error('Failed to find Create Strategy tab');
      throw error;
    }

    this.windowHandle = await this.browser.getCurrentTabId();

    let result;
    try {
      result = this.browser.waitForExist(this.username, this.configuration.mediumTimeout);
    } catch (error) {
      this.logger.error('Failed to find username in page footer');
      throw error;
    }

    return result;
  }

  clickMarketViewHeader () {
    return this.tabMainHeaderMarketViewItem.click();
  }

  clickCreateStrategyHeader () {
    return this.tabMainHeaderStrategyListItem.click();
  }

  clickMatchedTradesHeader () {
    return this.tabMainHeaderMatchedTrades.click();
  }

  matchedTradesHeaderExists () {
    return this.browser.isExisting(this.matchedTradesTab);
  }

  getMatchedTradesTab () {
    return new MatchedTradesTab(this.context);
  }

  getMarketViewTab () {
    return new MarketViewTab(this.context, this.tabMainHeaderMarketViewItem);
  }

  getCreateStrategyTab () {
    return new CreateStrategyTab(this.context);
  }

  getUsername () {
    return this.txtUserName.getText();
  }

  async switchToWindow () {
    let switched = false;
    if (this.windowHandle) {
      await this.browser.switchTab(this.windowHandle);
      switched = true;
    }

    return switched;
  }

  clickLogout () {
    return this.btnLogout.click();
  }

  clickSettings () {
    return this.btnSettings.click();
  }

  clickLogoutConfirmOk () {
    return this.btnLogoutConfirmOk.click();
  }

  clickLogoutConfirmCancel () {
    return this.btnLogoutConfirmCancel.click();
  }

  async clickAlertsTab () {
    const nPanel = new NotificationsPanel(this.context);
    await nPanel.tabAlerts.click();

    return nPanel.notifications;
  }

  async clickErrorsTab () {
    const nPanel = new NotificationsPanel(this.context);
    await nPanel.tabErrors.click();

    return nPanel.notifications;
  }

  async clickMktHistTab () {
    const nPanel = new NotificationsPanel(this.context);
    await nPanel.tabMktHistory.click();

    return nPanel.mktHistory;
  }

  clickCancelMyOrders () {
    return this.browser.element(this.cancelMyOrdersSelector).click();
  }

  clickCancelDeskOrders () {
    return this.browser.element(this.cancelDeskOrdersSelector).click();
  }

  cancelMyOrdersExists () {
    return this.browser.isExisting(this.cancelMyOrdersSelector);
  }

  cancelDeskOrdersExists () {
    return this.browser.isExisting(this.cancelDeskOrdersSelector);
  }

  matchedTradesTabExists () {
    return this.browser.isExisting(this.matchedTradesTab);
  }
}
