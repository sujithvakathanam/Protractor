import Page from '../Page';

export default class MarketHistory extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  async getMrktHistByTitle (title, strike) {
    const items = [];
    const histItems = await this.browser.elements('//li[starts-with(@ng-repeat,"item in mhc.marketHistoryList")]');
    for (let index = 1; index <= histItems.value.length; index += 1) {
      const histItem = await this.getMrktHistoryByRow(index);
      const mhItemTitle = await histItem.getTitle();
      const mhItemStrike = await histItem.getStrike();
      if (mhItemTitle === title && mhItemStrike === strike) {
        items.push(histItem);
      }
    }

    return items;
  }

  async getMrktHistoryByRow (rowNumber) {
    const historyItem = await this.browser.element(`#notificationArea .market-history-list .market-history-list-row:nth-child(${rowNumber})`);

    return new MarketHistoryItem(this.context, historyItem);
  }
}

class MarketHistoryItem {
  constructor (context, marketItemElement) {
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  getTitle () {
    return this.browser.elementIdElement(this.element.value.ELEMENT, './/span[@class="market-history-item-title ng-binding"]').getText();
  }

  getPxValue () {
    return this.browser.elementIdElement(this.element.value.ELEMENT, './/div[span[text()="Strk"]]/span[3]').getText();
  }

  getStrike () {
    return this.browser.elementIdElement(this.element.value.ELEMENT, './/div[span[text()="Strk"]]/span[2]').getText();
  }

  async isPositive () {
    const element = await this.browser.elementIdElement(this.element.value.ELEMENT, './/i');
    const attribute = await this.browser.elementIdAttribute(element.value.ELEMENT, 'class');
    if (attribute.value.includes('positive')) {
      return true;
    }

    return false;
  }
}

