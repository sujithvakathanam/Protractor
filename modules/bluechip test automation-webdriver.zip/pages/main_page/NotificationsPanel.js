import Page from '../Page';
import {NotificationPanelStrategy} from '../../lib/notfication/NotificationPanelStrategy';
import MarketHistory from './MarketHistory';

export default class NotificationsPanel extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.clear = '#notificationArea [data-id="NOTIFICATIONS_CLEAR"]';
    this.confirm = '#notificationArea [data-id="CONFIRM_CLEAR"]';
    this.alerts = '#notificationArea [data-id="ALERT"]';
    this.errors = '#notificationArea [data-id="ERRORS"]';
    this.history = '#notificationArea [data-id="HISTORY"]';
  }

  get notifications () {
    return new NotificationPanelStrategy(this.context);
  }

  get mktHistory () {
    return new MarketHistory(this.context);
  }

  get btnClear () {
    return this.browser.element(this.clear);
  }

  get btnConfirm () {
    return this.browser.element(this.confirm);
  }

  async clearAlerts () {
    await this.btnClear.click();

    return this.btnConfirm.click();
  }

  get tabAlerts () {
    return this.browser.element(this.alerts);
  }

  get tabErrors () {
    return this.browser.element(this.errors);
  }

  get tabMktHistory () {
    return this.browser.element(this.mktHistory);
  }
}
