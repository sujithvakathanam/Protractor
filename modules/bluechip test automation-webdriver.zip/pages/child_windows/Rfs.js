/* eslint-disable max-lines */
import Page from '../Page';
import DropDownHelper from '../../lib/DropDownHelper';
import {switchToTab} from '../../utilities/webdriverHelper/tabsHelper';
import WaitForHelper from '../../utilities/webdriverHelper/waitForHelper';
import {frameworkConfig} from '../../config/framework.config';
const chaiAsPromised = require('chai-as-promised');
const chai = require('chai');
chai.use(chaiAsPromised);
const expect = chai.expect;

export default class Rfs extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.waitForHelper = new WaitForHelper(context);
    this.rfsWindowHandle = null;

    // Selectors
    this.windowLett = '[data-id="INDICATOR"]';
    this.under = '[data-id="UNDERLYING"]';
    this.titleElement = '(//div[@class="rfs-banner-row"])[1]/div/span[2]';
    this.broker = '[data-id="CONTACT_BROKER"] span';
    this.brokerCss = '[data-id="CONTACT_BROKER"]';
    this.bookBuildingMsgText = '//span[text()="Book building in progress"]';
    this.countdown = '//count-down[1]';
    this.darkCountdown = '#dark-period div.countdown-timer';
    this.darkLiveCountdown = '#dark-period div.countdown-timer count-down';
    this.litCountdown = '#lit-period div.countdown-timer';
    this.litLiveCountdown = '#lit-period div.countdown-timer count-down';
    this.tradingCountdown = '#trading-period div.countdown-timer';
    this.tradingLiveCountdown = '#trading-period div.countdown-timer count-down';
    this.priorityCountdown = '#priority-period div.countdown-timer';
    this.priorityLiveCountdown = '#priority-period div.countdown-timer count-down';
    this.dark = '#dark-period .info-lozenge';
    this.lit = '#lit-period .info-lozenge';
    this.trading = '#trading-period .info-lozenge';
    this.priorityIn = '#priority-period .info-lozenge';
    this.noResponse = '//p[text()="No responses: RFS over."]';
    this.referenceData = '[data-id="REF_PRICE"]';
    this.deltaData = '[data-id="DELTA"]';
    this.strikesData = '[data-id="STRIKES"]';
    this.respondedData = '[data-id="RESPONDER_COUNT"]';
    this.currentSpreadData = '[data-id="CURRENT_SPREAD"]';
    this.darkSpreadData = '[data-id="DARK_SPREAD"]';
    this.prioSelector = '//div[./div[text()="NEW CTR"]]';
    this.activate = '[data-id="BTN_ACTIVATE"]';
    this.bidPriceCellButton = '[data-name="bidPrice"] .clickable-quote-price';
    this.ratioData = '[data-id="RATIOS"]';
    this.myCurrentBid = '[data-id="MY_CURRENT_BID"]';
    this.myCurrentAsk = '[data-id="MY_CURRENT_ASK"]';
    this.myCurrentSize = '[data-id="MY_CURRENT_SIZE"]';
    this.newBidFld = '//input[@id="newBid"]';
    this.newAskFld = '//input[@id="newAsk"]';
    this.newSizeFld = '//input[@id="newSize"]';
    this.notificationTextElement = '#end-notification p';
    this.endNotification = '#end-notification';
    this.notificationOk = '#end-notification button';
    this.subject = '#btn-subject';
    this.tradingUser = '//div[@id="trading-users"]';
    this.submit = '//button[@id="btn-quote" and ./span[text()="SUBMIT"]]';
    this.update = '//button[@id="btn-quote" and ./span[text()="UPDATE"]]';
    this.ok = '#btn-ok';
    this.lift = '#btn-lift';
    this.hit = '#btn-hit';
    this.cancel = '#btn-cancel';
    this.priceRows = '.rfs-order-book-list-row';
    this.bidSize = '//div[@data-name="bidSize"]';
    this.askSize = '//div[@data-name="askSize"]';
    this.quoteRows = '.rfs-order-book-list-row';
    this.bidPrice = '.rfs-order-book.list-row-item[data-name="bidPrice"].span.quote-price.live-quote-price.clickable-quote-price';
    this.askPrice = '.rfs-order-book.list-row-item[data-name="askPrice"].span.quote-price.live-quote-price.clickable-quote-price';
    this.summaryTotal = '[data-id="RFS_TOTAL_MATCHED"]';
    this.summaryTotalSoldElement = '[data-id="RFS_TOTAL_SOLD"]';
    this.firm = '#btn-firm';
    this.activation = '//p[text()="You have been Activated"]';
    this.activationMsg = '//span[@class="review-message"]';
    this.totalMatched = '[data-id="RFS_TOTAL_MATCHED"]';
  }

  async switchToWindow (letter, index, strategyShortCode, strategyExpiry) {
    let found = false;
    const windowSelector = `//div[contains(@class, "rfs-banner-indicator") and text()="${letter}" and //span[text()="${index}"] and (//span[text()="${strategyShortCode}" and text()= "${strategyExpiry}"] or //span[text()="${strategyShortCode} ${strategyExpiry}"])]`;
    if (this.rfsWindowHandle === null) {
      try {
        found = await this.browser.waitUntil(() => switchToTab(this.browser, windowSelector), this.configuration.shortTimeout);
        if (found) {
          this.rfsWindowHandle = await this.browser.getCurrentTabId();
        }
      } catch (error) {
        this.logger.info(error);
      }
    } else {
      found = true;
      await this.browser.switchTab(this.rfsWindowHandle);
    }

    await this.browser.waitForExist(this.windowLett, this.configuration.shortTimeout);

    return found;
  }

  get windowLetter () {
    return this.browser.element(this.windowLett);
  }

  get underlying () {
    return this.browser.element(this.under);
  }

  get title () {
    return this.browser.element(this.titleElement);
  }

  get brokerContact () {
    return this.browser.element(this.broker);
  }

  brokerContactExists () {
    return this.browser.isExisting(this.broker);
  }

  bookBuildingMessageExists () {
    return this.browser.isExisting(this.bookBuildingMsgText);
  }


  getBrokerContact () {
    return this.brokerContact.getText();
  }

  async verifyBrokerBadgeColour (expectedColour) {
    const isMatch = await super.compareCssColorValues(this.brokerCss, 'background-color', expectedColour);
    expect(isMatch).to.equal(true, `Expected broker badge color to match ${JSON.stringify(expectedColour)}`);
  }

  get rfsCountDownTimer () {
    return this.browser.element(this.countdown);
  }

  get darkCountDownTimer () {
    return this.browser.element(this.darkCountdown);
  }

  get darkLiveCountDownTimer () {
    return this.browser.element(this.darkLiveCountdown);
  }

  getDarkCountDownTimer (isRunning) {
    return isRunning ? this.darkLiveCountDownTimer.getText() : this.darkCountDownTimer.getText();
  }

  get litCountDownTimer () {
    return this.browser.element(this.litCountdown);
  }

  get litLiveCountDownTimer () {
    return this.browser.element(this.litLiveCountdown);
  }

  getLitCountDownTimer (isRunning) {
    return isRunning ? this.litLiveCountDownTimer.getText() : this.litCountDownTimer.getText();
  }

  get tradingCountDownTimer () {
    return this.browser.element(this.tradingCountdown);
  }

  get tradingLiveCountDownTimer () {
    return this.browser.element(this.tradingLiveCountdown);
  }

  getTradingCountDownTimer (isRunning) {
    return isRunning ? this.tradingLiveCountDownTimer.getText() : this.tradingCountDownTimer.getText();
  }

  get priorityCountDownTimer () {
    return this.browser.element(this.priorityCountdown);
  }

  get priorityLiveCountDownTimer () {
    return this.browser.element(this.priorityLiveCountdown);
  }

  getPriorityCountDownTimer (isRunning) {
    return isRunning ? this.priorityLiveCountDownTimer.getText() : this.priorityCountDownTimer.getText();
  }

  get darkIndicator () {
    return this.browser.element(this.dark);
  }

  get litIndicator () {
    return this.browser.element(this.lit);
  }

  get tradingIndicator () {
    return this.browser.element(this.trading);
  }

  get priorityIndicator () {
    return this.browser.element(this.priorityIn);
  }

  get noResponseMsg () {
    return this.browser.element(this.noResponse);
  }

  get ref () {
    return this.browser.element(this.referenceData);
  }

  getRef () {
    return this.ref.getText();
  }

  get delta () {
    return this.browser.element(this.deltaData);
  }

  getDelta () {
    return this.delta.getText();
  }

  get strikes () {
    return this.browser.element(this.strikesData);
  }

  get responded () {
    return this.browser.element(this.respondedData);
  }

  getResponded () {
    return this.responded.getText();
  }

  get currentSpread () {
    return this.browser.element(this.currentSpreadData);
  }

  currentSpreadExists () {
    return this.browser.isExisting(this.currentSpreadData);
  }

  getCurrentSpread () {
    return this.currentSpread.getText();
  }

  get darkSpread () {
    return this.browser.element(this.darkSpreadData);
  }

  darkSpreadExists () {
    return this.browser.isExisting(this.darkSpreadData);
  }

  getDarkSpread () {
    return this.darkSpread.getText();
  }

  get ratios () {
    return this.browser.element(this.ratioData);
  }

  get fldMyCurrentBid () {
    return this.browser.element(this.myCurrentBid);
  }

  getMyCurrentBid () {
    return this.fldMyCurrentBid.getText();
  }

  get fldMyCurrentAsk () {
    return this.browser.element(this.myCurrentAsk);
  }

  getMyCurrentAsk () {
    return this.fldMyCurrentAsk.getText();
  }

  get fldMyCurrentSize () {
    return this.browser.element(this.myCurrentSize);
  }

  getMyCurrentSize () {
    return this.fldMyCurrentSize.getText();
  }

  get fldEnterBid () {
    return this.browser.element(this.newBidFld);
  }

  fldEnterBidEnabled () {
    return this.fldEnterBid.isEnabled();
  }

  get fldEnterAsk () {
    return this.browser.element(this.newAskFld);
  }

  fldEnterAskEnabled () {
    return this.fldEnterBid.isEnabled();
  }

  get fldEnterSize () {
    return this.browser.element(this.newSizeFld);
  }

  fldEnterSizeEnabled () {
    return this.fldEnterSize.isEnabled();
  }

  get btnSubject () {
    return this.browser.element(this.subject);
  }

  btnSubjectClick () {
    return this.btnSubject.click();
  }

  btnSubjectExists () {
    return this.browser.isExisting(this.subject);
  }

  btnSubjectEnabled () {
    return this.btnSubject.isEnabled();
  }

  getSubjectBtnText () {
    return this.btnSubject.getText();
  }

  get btnActivateSelector () {
    return this.activate;
  }

  btnActivateExists () {
    return this.browser.isExisting(this.btnActivateSelector);
  }

  btnActivateEnabled () {
    return this.browser.isEnabled(this.btnActivateSelector);
  }

  btnActivateClick () {
    return this.browser.element(this.btnActivateSelector).click();
  }

  async clickBid () {
    await this.browser.click(this.bidPriceCellButton);
  }

  get priceTblRows () {
    return this.browser.elements(this.priceRows);
  }

  async getBidOfferRow (rowNumber) {
    const priceRows = await this.priceTblRows;
    const priceRow = priceRows.value[rowNumber - 1];

    return new RowHandler(this.context, priceRow);
  }

  get ddActivateUser () {
    return new DropDownHelper(this.context, this.tradingUser);
  }

  getActivatedUserSelector (trader) {
    return `//p[text()="${trader}"]`;
  }

  getActivatedTrader (trader) {
    const selector = this.getActivatedUserSelector(trader);

    return this.browser.element(selector).getText();
  }

  getActivatedTraderToolTip (trader) {
    const selector = this.getActivatedUserSelector(trader);

    return this.browser.getAttribute(selector, 'title');
  }

  waitUntilActivatedTraderExists (trader) {
    const selector = this.getActivatedUserSelector(trader);

    return this.browser.waitForExist(selector, this.configuration.veryShortTimeout);
  }

  get notificationTextSelector () {
    return this.notificationTextElement;
  }

  get notificationOkSelector () {
    return this.notificationOk;
  }

  get notificationText () {
    return this.browser.element(this.notificationTextSelector).getText();
  }

  waitUntilNotificationOverlay (timeout = this.configuration.shortTimeout) {
    return this.waitForHelper.waitForExist(this.endNotification, timeout);
  }

  async notificationExists (notificationMsg, timeout = this.configuration.shortTimeout) {
    try {
      await this.waitUntilNotificationOverlay(timeout);
    } catch (error) {
      return false;
    }
    const displayedMsg = await this.notificationText;

    return displayedMsg === notificationMsg;
  }

  async getNotificationMsg (timeout = this.configuration.veryShortTimeout) {
    try {
      await this.waitUntilNotificationOverlay(timeout);
    } catch (error) {
      return '';
    }

    return this.notificationText;
  }

  clickNotificationOk () {
    return this.browser.element(this.notificationOkSelector).click();
  }

  colleagueTradingMsgExists () {
    return this.browser.isExisting('//p[text()="Your colleague has responded."]');
  }

  async rfsTimedoutMsgExists () {
    return this.browser.isExisting('//p[text()="This RFS has timed out. Remaining firm orders have moved to the Order Book."]');
  }

  rfsLPTraderLockedOutMsgExists () {
    return this.browser.isExisting('//p[text()="You did not respond during the book-building period. You can no longer participate in the RFS."]');
  }

  async waitUntilLpTraderLockedOutMsg (timeout = this.configuration.litPhaseTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(() => this.rfsLPTraderLockedOutMsgExists(), timeout);
    } catch (err) {
      found = false;
    }

    return found;
  }

  get bidSizeElement () {
    return this.browser.element(this.bidSize);
  }

  getBidOfferSize () {
    return this.bidSizeElement.getText();
  }

  get quoteRow () {
    return this.browser.elements(this.quoteRows);
  }

  verifyClickableBidPrice () {
    return this.browser.isExisting(this.bidPrice);
  }

  verifyClickableAskPrice () {
    return this.browser.isExisting(this.askPrice);
  }

  get askSizeElement () {
    return this.browser.element(this.askSize);
  }

  getAskOfferSize () {
    return this.askSizeElement.getText();
  }

  get btnSubmit () {
    return this.browser.element(this.submit);
  }

  get askPriceBtn () {
    return this.browser.element(this.askPrice);
  }

  get bidPriceBtn () {
    return this.browser.element(this.bidPrice);
  }

  clickEnabledAskPrice () {
    return this.askPriceBtn().click();
  }

  clickEnabledBidPrice () {
    return this.bidPriceBtn().click();
  }

  btnSubmitEnabled () {
    return this.btnSubmit.isEnabled();
  }

  btnSubmitClick () {
    return this.btnSubmit.click();
  }

  getQuoteBtnText () {
    return this.btnSubmit.getText();
  }

  get btnUpdate () {
    return this.browser.element(this.update);
  }

  btnUpdateEnabled () {
    return this.btnUpdate.isEnabled();
  }

  btnUpdateExists () {
    return this.browser.isExisting(this.update);
  }

  btnUpdateClick () {
    return this.btnUpdate.click();
  }

  get btnOk () {
    return this.browser.element(this.ok);
  }

  btnOkClick () {
    return this.btnOk.click();
  }

  btnOkExists () {
    return this.browser.isExisting(this.ok);
  }

  get btnLift () {
    return this.browser.element(this.lift);
  }

  btnLiftExists () {
    return this.browser.isExisting(this.lift);
  }

  btnLiftEnabled () {
    return this.btnLift.isEnabled();
  }

  btnLiftClick () {
    return this.btnLift.click();
  }

  get btnHit () {
    return this.browser.element(this.hit);
  }

  btnHitExists () {
    return this.browser.isExisting(this.hit);
  }

  async waitUntilBtnHitExists (timeout = this.configuration.veryShortTimeout) {
    let exists = null;
    try {
      exists = await this.browser.waitUntil(() => this.btnHitExists(), timeout);
    } catch (err) {
      exists = false;
    }

    return exists;
  }

  btnHitEnabled () {
    return this.btnHit.isEnabled();
  }

  btnHitClick () {
    return this.btnHit.click();
  }

  get btnCancelRfs () {
    return this.browser.element(this.cancel);
  }

  btnCancelRfsClick () {
    return this.btnCancelRfs.click();
  }

  get btnBack () {
    return this.browser.element();
  }

  btnBackClick () {
    return this.btnBack.click();
  }

  get summaryTotalBought () {
    return this.browser.element(this.summaryTotal);
  }

  getSummaryTotalBought () {
    return this.summaryTotalBought.getText();
  }

  summaryTotalBoughtExists () {
    return this.browser.isExisting(this.summaryTotal);
  }

  get summaryTotalSold () {
    return this.browser.element(this.summaryTotalSoldElement);
  }

  getSummaryTotalSold () {
    return this.summaryTotalSold.getText();
  }

  summaryTotalSoldExists () {
    return this.browser.isExisting(this.summaryTotalSoldElement);
  }

  get btnFirmUp () {
    return this.browser.element(this.firm);
  }

  btnFirmUpExists () {
    return this.btnFirmUp.isExisting();
  }

  btnFirmUpEnabled () {
    return this.btnFirmUp.isEnabled();
  }

  get prioritySelector () {
    return this.prioSelector;
  }

  get priority () {
    const selector = this.prioritySelector.concat('/div[1]');

    return this.browser.element(selector);
  }

  getPriorityTime () {
    const selector = this.prioritySelector.concat('/div[2]');

    return this.browser.element(selector).getText();
  }

  // Dupe function - check the one being used before deleting
  getPriorityCountDownTimer () {
    const selector = this.prioritySelector.concat('/div[2]/count-down');

    return this.browser.element(selector).getText();
  }

  async waitUntilPriorityActive (timeout = this.configuration.shortTimeout) {
    let active = false;
    try {
      active = await this.browser.waitUntil(async () => {
        const phase = await this.getPhase();


        return phase === 'PRIORITY';
      }, timeout);
    } catch (err) {
      this.logger.info(err);
    }

    return active;
  }

  async waitUntilPriorityInactive (timeout = this.configuration.priorityTimeout + this.configuration.shortTimeout) {
    let inActive = false;
    try {
      inActive = await this.browser.waitUntil(async () => {
        const phase = await this.getPhase();


        return phase !== 'PRIORITY';
      }, timeout);
    } catch (err) {
      this.logger.info(err);
    }

    return inActive;
  }


  async waitUntilBtnFirmUpExists (timeout = this.configuration.veryShortTimeout) {
    let exists = false;
    try {
      exists = await this.browser.waitUntil(() => this.btnFirmUpExists(), timeout);
    } catch (err) {
      exists = false;
    }

    return exists;
  }

  async waitUntilBtnFirmUpEnabled (timeout = this.configuration.veryShortTimeout) {
    let enabled = null;
    try {
      enabled = await this.browser.waitUntil(() => this.btnFirmUpEnabled(), timeout);
    } catch (err) {
      enabled = false;
    }

    return enabled;
  }

  btnFirmUpClick () {
    return this.btnFirmUp.click();
  }

  get summaryTotalMatchedInRFS () {
    return this.browser.element(this.totalMatched);
  }

  getSummaryTotalMatchedInRFS () {
    return this.summaryTotalMatchedInRFS.getText();
  }

  summaryTotalMatchedInRFSExists () {
    return this.browser.isExisting(this.totalMatched);
  }

  traderNotLoggedInMsgExists () {
    return this.browser.isExisting('//span[text()="Trader not logged in"]');
  }

  get btnConfirm () {
    return this.browser.element('#btn-confirm');
  }

  btnConfirmClick () {
    return this.btnConfirm.click();
  }

  btnConfirmEnabled () {
    return this.btnConfirm.isEnabled();
  }

  get btnRevise () {
    return this.browser.element('#btn-revise');
  }

  btnUserExists (user) {
    return this.browser.isExisting(`//button[text()="${user}"]`);
  }

  btnUserClick (user) {
    return this.btnUser(user).click();
  }

  async addTradingUser (user) {
    await this.ddTradingUser.setSelected(user);
    await this.btnAddTradingUser.click();

    return this.waitUntilBtnUserExists(user);
  }

  async getPhase () {
    const dark = await this.darkIndicator.getAttribute('class');
    const lit = await this.litIndicator.getAttribute('class');
    const trading = await this.tradingIndicator.getAttribute('class');
    const priority = await this.priorityIndicator.getAttribute('class');

    if (dark.includes('is-active')) {
      return 'DARK';
    }
    if (lit.includes('is-active')) {
      return 'LIT';
    }
    if (priority.includes('is-active')) {
      return 'PRIORITY';
    }
    if (trading.includes('is-active')) {
      return 'TRADING';
    }

    return '';
  }

  async getPriorityPhaseType () {
    const priority = await this.priorityIndicator.getAttribute('class');
    if (priority.includes('is-active')) {
      if (priority.includes('priority-mine')) {
        return 'PRIORITY-MINE';
      }
      if (priority.includes('priority-other')) {
        return 'PRIORITY-OTHER';
      }

      return 'PRIORITY-BROKER';
    }

    return 'PRIORITY-NONE';
  }

  getTitle () {
    return this.title.getText();
  }

  getWindowLetter () {
    return this.windowLetter.getText();
  }

  getUnderlying () {
    return this.underlying.getText();
  }

  async cancelRfs () {
    await this.btnCancelRfs.click();


    return this.btnOk.click();
  }

  async quote (bid, ask, size) {
    if (bid !== null) {
      await this.fldEnterBid.setValue(bid.toString());
    }
    if (ask !== null) {
      await this.fldEnterAsk.setValue(ask.toString());
    }
    if (size !== null) {
      await this.fldEnterSize.setValue(size.toString());
    }
    const submitBtn = await this.btnSubmit;
    if (submitBtn.value !== null && await this.btnSubmitEnabled()) {
      await this.btnSubmitClick();
    }
    const updateBtn = await this.btnUpdate;
    if (updateBtn.value !== null && await this.btnUpdateEnabled()) {
      await this.btnUpdateClick();
    }
    const confirmBtn = await this.btnConfirm;
    if (confirmBtn.value !== null && await this.btnConfirmEnabled()) {
      await this.btnConfirmClick();
    }
  }

  async quoteOnOrder (bid, ask, size) {
    if (bid !== null) {
      await this.fldEnterBid.setValue(bid);
    }
    if (ask !== null) {
      await this.fldEnterAsk.setValue(ask);
    }
    if (size !== null) {
      await this.fldEnterSize.setValue(size);
    }
    const submitBtn = await this.btnSubmit;
    if (submitBtn.value !== null && await this.btnSubmit.isEnabled()) {
      await this.btnSubmitClick();
    }
    const updateBtn = await this.btnUpdate;
    if (updateBtn.value !== null && await this.btnUpdate.isEnabled()) {
      await this.btnUpdateClick();
    }
    const confirmBtn = await this.btnConfirm;
    if (confirmBtn.value !== null && await this.btnConfirm.isEnabled()) {
      await this.btnConfirmClick();
    }
  }

  async waitUntilMyCurrentBid (value, timeout = this.configuration.shortTimeout) {
    let matched = false;
    let bid = null;
    try {
      matched = await this.browser.waitUntil(async () => {
        bid = await this.getMyCurrentBid();

        return value === bid;
      }, timeout, `Timed out after ${timeout}ms, RFS window responder My Current Bid did not match expected: ${value} actual:${bid}`);
    } catch (err) {
      this.logger.info(err);
    }

    return matched;
  }

  async waitUntilMyCurrentAsk (value, timeout = this.configuration.shortTimeout) {
    let matched = false;
    let ask = null;
    try {
      matched = await this.browser.waitUntil(async () => {
        ask = await this.getMyCurrentAsk();

        return value === ask;
      }, timeout, `Timed out after ${timeout}ms, RFS window responder My Current Ask did not match expected: ${value} actual:${ask}`);
    } catch (err) {
      this.logger.info(err);
    }

    return matched;
  }

  async waitUntilResponderCount (count, timeout = this.configuration.shortTimeout) {
    let countMatches = false;
    let responded = null;
    try {
      countMatches = await this.browser.waitUntil(async () => {
        responded = await this.getResponded();

        return responded.includes(`${count}/`);
      }, timeout, `Timed out after ${timeout}ms, RFS window responder count did not match expected: ${count} actual:${responded}`);
    } catch (err) {
      this.logger.info(err);
    }

    return countMatches;
  }

  async waitUntilPhase (phase, timeout = this.configuration.shortTimeout) {
    let phaseFound = false;
    let currentPhase = null;
    try {
      phaseFound = await this.browser.waitUntil(async () => {
        currentPhase = await this.getPhase();

        return currentPhase === phase;
      }, timeout, `Timed out after ${timeout}ms, RFS window phase did not match expected: ${phase} actual:${currentPhase}`);
    } catch (err) {
      this.logger.info(err);
    }


    return phaseFound;
  }

  async waitUntilCurrentSpread (ticks, timeout = this.configuration.shortTimeout) {
    let ticksMatched = false;
    let ticksValue = null;
    try {
      ticksMatched = await this.browser.waitUntil(async () => {
        ticksValue = await this.getCurrentSpread();

        return ticksValue === ticks;
      }, timeout, `Timed out after ${timeout}ms, RFS window current spread ticks did not match expected: ${ticks} actual:${ticksValue}`);
    } catch (err) {
      this.logger.info(err);
    }

    return ticksMatched;
  }

  async waitUntilRfsMatchesHaveOccurred (timeout = this.configuration.shortTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(async () => this.browser.isExisting('//span[text()="RFS Matches have occurred."]'), timeout, `Timed out after ${timeout}ms, RFS window did not display RFS Matches occurred message`);
    } catch (err) {
      this.logger.info(err);
    }

    return found;
  }

  async waitUntilRfsTimedout (timeout = this.configuration.mediumTimeout) {
    let found = false;
    try {
      found = await this.browser.waitUntil(async () => this.rfsTimedoutMsgExists(), timeout, `Timed out after ${timeout}ms, RFS window did not display timed out message`);
    } catch (err) {
      this.logger.info(err);
    }

    return found;
  }

  async waitUntilEnabled (timeout = this.configuration.veryShortTimeout) {
    let enabled = false;
    try {
      enabled = await this.browser.waitUntil(async () => await this.fldEnterAskEnabled()
          && await this.fldEnterSizeEnabled()
          && await this.fldEnterBidEnabled(), timeout, `Timed out after ${timeout}ms, RFS window has not been enabled`);
    } catch (err) {
      this.logger.info(err);
    }

    return enabled;
  }

  async waitUntilColleagueRespondedMsg (timeout = this.configuration.veryShortTimeout) {
    let msgFound = false;
    try {
      msgFound = await this.browser.waitUntil(async () => await this.colleagueTradingMsgExists() === true, timeout, `Timed out after ${timeout}ms, RFS window did not display Colleague has responded message`);
    } catch (err) {
      this.logger.info(err);
    }

    return msgFound;
  }

  async waitUntilTraderNotLoggedInMsg (timeout = this.configuration.veryShortTimeout) {
    let msgFound = false;
    try {
      msgFound = await this.browser.waitUntil(async () => await this.traderNotLoggedInMsgExists() === true, timeout, `Timed out after ${timeout}ms, RFS window did not display Trader not logged in`);
    } catch (err) {
      this.logger.info(err);
    }

    return msgFound;
  }

  activatedOverlayExists () {
    return this.browser.isExisting(this.activation);
  }

  async waitForActivationOverlay (timeout = this.configuration.shortTimeout) {
    let msgFound = false;
    try {
      msgFound = await this.browser.waitUntil(async () => await this.activatedOverlayExists() === true, timeout, `Timed out after ${timeout}ms, RFS window did not display "You have been activated"`);
    } catch (err) {
      this.logger.info(err);
    }

    return msgFound;
  }

  async verifyActivationOverlayAndDismiss (timeout = frameworkConfig.shortTimeout) {
    let overlayFound = await this.waitForActivationOverlay(timeout);
    expect(overlayFound).to.equal(true, 'Activated trader did not see Activation overlay');
    const msgText = await this.browser.element(this.activationMsg).getText();
    expect(msgText).to.equal('Review strategy details prior to trading');
    const okBtnFound = await this.btnOkExists();
    expect(okBtnFound).to.equal(true, 'Trader should see OK button');
    await this.btnOkClick();
    overlayFound = await this.activatedOverlayExists();
    expect(overlayFound).to.equal(false, 'Activated overlay was not dismissed after clicking on OK');
  }

  async verifyMyCurrentFields ({myCurrentBid, myCurrentAsk, myCurrentSize}, timeout = this.configuration.veryShortTimeout) {
    const decimals = 3;
    if (myCurrentBid === '' || myCurrentBid) {
      const expectedCurrentBid = parseFloat(myCurrentBid)
        .toFixed(decimals)
        .toString();

      await this.waitUntilMyCurrentBid(expectedCurrentBid, timeout);
      const actualCurrentBid = await this.getMyCurrentBid();
      expect(actualCurrentBid).to.equal(expectedCurrentBid, 'RFS Window My Current Bid');
    }

    if (myCurrentAsk === '' || myCurrentAsk) {
      const expectedCurrentAsk = parseFloat(myCurrentAsk)
        .toFixed(decimals)
        .toString();

      await this.waitUntilMyCurrentAsk(expectedCurrentAsk, timeout);
      const actualCurrentAsk = await this.getMyCurrentAsk();
      expect(actualCurrentAsk).to.equal(expectedCurrentAsk, 'RFS Window My Current Ask');
    }

    if (myCurrentSize) {
      const expectedCurrentSize = myCurrentSize.toString();
      const actualCurrentSize = await this.getMyCurrentSize();
      expect(actualCurrentSize).to.equal(`${expectedCurrentSize} L`, 'RFS Window My Current Size');
    }
  }

  async verifySummary ({totalMatched, totalBought, totalSold}) {
    if (totalMatched) {
      const expectedTotalMatched = totalMatched
        .toString()
        .concat(' L');

      const actualTotalMatched = await this.getSummaryTotalMatchedInRFS();
      expect(actualTotalMatched).to.equal(expectedTotalMatched, 'RFS summary window - Total Matched in RFS');
    }

    if (totalBought) {
      const expectedTotalBought = totalBought
        .toString()
        .concat(' L');

      const actualTotalBought = await this.getSummaryTotalBought();
      expect(actualTotalBought).to.equal(expectedTotalBought, 'RFS summary window - Total Bought');
    }

    if (totalSold) {
      const expectedTotalSold = totalSold
        .toString()
        .concat(' L');

      const actualTotalSold = await this.getSummaryTotalSold();
      expect(actualTotalSold).to.equal(expectedTotalSold, 'RFS summary window - Total Sold');
    }
  }
}

class RowHandler {
  constructor (context, row) {
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.row = row;

    this.quoteRowBidTrader = '[data-name="bidTrader"]';
    this.quoteRowAskTrader = '[data-name="askTrader"]';
    this.quoteRowBidSize = '[data-name="bidSize"]';
    this.quoteRowAskSize = '[data-name="askSize"]';
    this.quoteRowBidPrice = '[data-name="bidPrice"] span.quote-price';
    this.quoteRowAskPrice = '[data-name="askPrice"] span.quote-price';
    this.quoteRowClickableBidPrice = '[data-name="bidPrice"] span.quote-price.clickable-quote-price';
    this.quoteRowClickableAskPrice = '[data-name="askPrice"] span.quote-price.clickable-quote-price';
  }

  get tdBidTrader () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowBidTrader);
  }

  get tdAskTrader () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowAskTrader);
  }

  get tdBidSize () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowBidSize);
  }

  get tdAskSize () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowAskSize);
  }

  get btnBidPrice () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowBidPrice);
  }

  get btnAskPrice () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowAskPrice);
  }

  get btnClickableBidPrice () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowClickableBidPrice);
  }

  get btnClickableAskPrice () {
    return this.browser.elementIdElement(this.row.ELEMENT, this.quoteRowClickableAskPrice);
  }

  tdBidPriceClick () {
    return this.btnBidPrice.click();
  }

  tdAskPriceClick () {
    return this.btnAskPrice.click();
  }

  getBidSize () {
    return this.tdBidSize.getText();
  }

  async getBidPrice () {
    let text = '';
    try {
      text = await this.btnBidPrice.getText();
    } catch (err) {
      this.logger.info(err);
    }

    return text;
  }

  async getAskPrice () {
    let text = '';
    try {
      text = await this.btnAskPrice.getText();
    } catch (err) {
      this.logger.info(err);
    }

    return text;
  }

  getAskSize () {
    return this.tdAskSize.getText();
  }

  getBidTrader () {
    return this.tdBidTrader.getText();
  }

  getAskTrader () {
    return this.tdAskTrader.getText();
  }

  clickAskPriceBtn () {
    return this.btnAskPrice.click();
  }

  clickBidPriceBtn () {
    return this.btnBidPrice.click();
  }

  async isBidPriceBtnEnabled () {
    const enabledBtn = await this.btnClickableBidPrice;

    return Boolean(enabledBtn.value);
  }

  async isAskPriceBtnEnabled () {
    const enabledBtn = await this.btnClickableAskPrice;

    return Boolean(enabledBtn.value);
  }

  async isEmptyRow () {
    const value = ''.concat(await this.getBidPrice())
      .concat(await this.getAskPrice())
      .concat(await this.getBidSize())
      .concat(await this.getAskSize());

    if (value === '') {
      return true;
    }


    return false;
  }

  async waitUntilPrice (bidPrice, askPrice, bidSize = null, askSize = null, timeout = this.configuration.shortTimeout) {
    let found = false;
    let bidP = '';
    let askP = '';
    let bidS = '';
    let askS = '';

    try {
      found = await this.browser.waitUntil(async () => {
        bidP = await this.getBidPrice();
        askP = await this.getAskPrice();

        let matchedBidSize = true;
        if (bidSize) {
          bidS = await this.getBidSize();
          matchedBidSize = bidSize === bidS;
        }

        let matchedAskSize = true;
        if (askSize) {
          askS = await this.getAskSize();
          matchedAskSize = askSize === askS;
        }

        const matched = bidP === bidPrice
          && askP === askPrice
          && matchedBidSize
          && matchedAskSize;

        this.logger.debug(`Rfs - RowHandler - waitUntilPrice bid price: ${bidP} ask price: ${askP} bid size: ${bidS} ask size: ${askS}`);

        return matched;
      }, timeout, `Timed out after ${timeout}ms, RFS window bid and ask price did not update expected bid price: ${bidPrice} bid size: ${bidSize} ask price: ${askPrice} ask size ${askSize}, actual bid price: ${bidP} bid size: ${bidS} ask price: ${askP} ask size: ${askS}`);
    } catch (err) {
      this.logger.info(err);
    }

    return found;
  }

  async verifyRow ({buySideTrader, buyPrice, buyAmount, buyPriority, sellSideTrader, sellPrice, sellAmount, sellPriority}, timeout = this.configuration.shortTimeout) {
    const decimalPlaces = 3;

    if (typeof buyPrice !== 'number' && typeof sellPrice !== 'number') {
      throw new Error('buyPrice and sellPrice must be valid');
    }

    let expectedBuyPrice = buyPrice.toFixed(decimalPlaces).toString();

    if (buyPriority) {
      expectedBuyPrice = expectedBuyPrice.concat('\n*');
    }

    let expectedSellPrice = sellPrice.toFixed(decimalPlaces).toString();

    if (sellPriority) {
      expectedSellPrice = expectedSellPrice.concat('\n*');
    }

    const pricesFound = await this.waitUntilPrice(
      expectedBuyPrice,
      expectedSellPrice,
      buyAmount.toString(),
      sellAmount.toString(),
      timeout
    );

    const actualBidPrice = await this.getBidPrice();
    const actualAskPrice = await this.getAskPrice();

    expect(pricesFound).to.equal(true, `RFS window expected Buy price :${expectedBuyPrice} found :${actualBidPrice}, expected Sell:${expectedSellPrice} found :${actualAskPrice}`);

    if (buySideTrader === '' || buySideTrader) {
      const actualBuyTrader = await this.getBidTrader();
      expect(actualBuyTrader).to.equal(buySideTrader, 'RFS Bid Trader');
    }

    if (buyAmount === '' || buyAmount) {
      const expectBuyAmount = buyAmount.toString();
      const actualBuyAmount = await this.getBidSize();
      expect(actualBuyAmount).to.equal(expectBuyAmount, 'RFS Ask Amount');
    }

    if (sellSideTrader === '' || sellSideTrader) {
      const actualSellTrader = await this.getAskTrader();
      expect(actualSellTrader).to.equal(sellSideTrader, 'RFS Ask Trader');
    }

    if (sellAmount === '' || sellAmount) {
      const expectedSellAmount = sellAmount.toString();
      const actualSellAmount = await this.getAskSize();
      expect(actualSellAmount).to.equal(expectedSellAmount, 'RFS Bid Amount');
    }
  }
}
