import Page from '../Page';
import {switchToTab} from '../../utilities/webdriverHelper/tabsHelper';
import DropDownHelper from '../../lib/DropDownHelper';

export default class VolumeClearing extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    this.vcWindowHandle = null;
  }

  async switchToWindow (letter, index, strategyShortCode, strategyExpiry) {
    let found = false;
    const windowSelector = `//div[contains(@class, "vc-banner-indicator") and text()="${letter}" and //span[text()="${index}"] and (//span[text()="${strategyShortCode}" and text()= "${strategyExpiry}"] or //span[text()="${strategyShortCode} ${strategyExpiry}"])]`;

    if (this.vcWindowHandle === null) {
      try {
        found = await this.browser.waitUntil(() => switchToTab(this.browser, windowSelector), this.configuration.shortTimeout);
      } catch (err) {
        this.logger.debug(err);
      }
      if (found) {
        this.vcWindowHandle = this.browser.getCurrentTabId();
      }
    } else {
      await this.browser.switchTab(this.vcWindowHandle);
    }

    return found;
  }

  get vcId () {
    return this.browser.getAttribute('//volume-clearing', 'id');
  }

  get windowLetter () {
    return this.browser.element('[data-id="INDICATOR"]');
  }


  getWindowLetter () {
    return this.windowLetter.getText();
  }

  get countDown () {
    return this.browser.element('count-down[data-id="VC_TIMER"]');
  }

  getCountDown () {
    return this.countDown.getText();
  }

  entitySellingMsgExists () {
    return this.browser.isExisting('//div[text()="ENTITY SELLING"]');
  }

  entityBuyingMsgExists () {
    return this.browser.isExisting('//div[text()="ENTITY BUYING"]');
  }

  get ref () {
    return this.browser.element('[data-id="REF_PRICE"]');
  }

  getRef () {
    return this.ref.getText();
  }

  get delta () {
    return this.browser.element('[data-id="DELTA"]');
  }

  getDelta () {
    return this.delta.getText();
  }

  get instrumentTitle () {
    return this.browser.element('[data-id="STRATEGY_TITLE"]');
  }

  getInstrumentTitle () {
    return this.instrumentTitle.getText();
  }

  get pxValue () {
    return this.browser.element('.vc-info-price[data-id="PRICE"]');
  }

  getPxValue () {
    return this.pxValue.getText();
  }

  get strikes () {
    return this.browser.element('[data-id="STRIKES"]');
  }

  getStrikes () {
    return this.strikes.getText();
  }

  get ratio () {
    return this.browser.element('[data-id="RATIOS"]');
  }

  getRatio () {
    return this.ratio.getText();
  }

  get vcMinSize () {
    return this.browser.element('[data-id="MIN_SIZE"]');
  }

  get vcStatusBadge () {
    return this.browser.element('.vc-status-badge');
  }

  isPriorityBuyer () {
    return this.browser.isExisting('//div[text()="INITIAL WORKUP"]');
  }

  isPrioritySeller () {
    return this.browser.isExisting('//div[text()="INITIAL WORKUP"]');
  }

  isNonPriority () {
    return this.browser.isExisting('//div[text()="PRICE PENDING"]');
  }

  get priorityTimer () {
    return this.browser.element('count-down[data-id="PRIORITY_TIMER"]');
  }

  get myLiveBuyInterest () {
    return this.browser.element('[data-id="MY_LIVE_BUY"]');
  }

  getMyLiveBuyInterest () {
    return this.myLiveBuyInterest.getText();
  }

  get myLiveSellInterest () {
    return this.browser.element('[data-id="MY_LIVE_SELL"]');
  }

  getMyLiveSellInterest () {
    return this.myLiveSellInterest.getText();
  }

  get myBuyInterestInput () {
    return this.browser.element('//input[@id="volumeBuySize"]');
  }

  buyInterestInputEnabled () {
    return this.myBuyInterestInput.isEnabled();
  }

  get mySellInterestInput () {
    return this.browser.element('//input[@id="volumeSellSize"]');
  }

  sellInterestInputEnabled () {
    return this.mySellInterestInput.isEnabled();
  }

  get bidsAndOffersTblRows () {
    return this.browser.elements('//table[contains(@class,"order-table")]//tr[td]');
  }

  hadBidOfferTblRows () {
    return this.browser.isExisting('//table[contains(@class,"order-table")]//tr[td]');
  }

  get buyMinusBtn () {
    return this.browser.element('//button[./i[text()="remove"]][1]');
  }

  get buyPlusBtn () {
    return this.browser.element('//button[./i[text()="add"]][1]');
  }

  get sellMinusBtn () {
    return this.browser.element('//button[./i[text()="remove"]][2]');
  }

  get sellPlusBtn () {
    return this.browser.element('//button[./i[text()="add"]][2]');
  }

  get confirmBtn () {
    return this.browser.element('[data-id="BTN_CONFIRM"]');
  }

  get reviseBtn () {
    return this.browser.element('[data-id="BTN_REVISE"]');
  }

  get updateBtn () {
    return this.browser.element('[data-id="BTN_UPDATE"]');
  }

  btnUpdateClick () {
    return this.updateBtn.click();
  }

  get submitBtn () {
    return this.browser.element('[data-id="BTN_SUBMIT"]');
  }

  btnSubmitClick () {
    return this.submitBtn.click();
  }

  get cancelBtn () {
    return this.browser.element('[data-id="BTN_CANCEL"]');
  }

  btnCancelClick () {
    return this.cancelBtn.click();
  }

  get totBoughtAmount () {
    return this.browser.element('[data-id="TOTAL_BOUGHT"]');
  }

  get totSoldAmount () {
    return this.browser.element('[data-id="TOTAL_SOLD"]');
  }

  getTotalSoldAmount () {
    return this.totSoldAmount.getText();
  }

  getTotalBoughtAmount () {
    return this.totBoughtAmount.getText();
  }

  // Complete - summary message at end of VC
  get okBtn () {
    return this.browser.element('//button[text()="OK"]');
  }

  btnOkClick () {
    return this.okBtn.click();
  }

  get summaryTotalBought () {
    return this.browser.element('[data-id="TOTAL_BOUGHT"]');
  }

  getSummaryTotalBought () {
    return this.totBoughtAmount.getText();
  }

  get summaryTotalSold () {
    return this.browser.element('[data-id="TOTAL_SOLD"]');
  }

  getSummaryTotalSold () {
    return this.totSoldAmount.getText();
  }

  get summaryTotalMatched () {
    return this.browser.element('[data-id="TOTAL_MATCHED"]');
  }

  getSummaryTotalMatched () {
    return this.summaryTotalMatched.getText();
  }

  get ddTradingUser () {
    return new DropDownHelper(this.context, '//div[starts-with(@class,"Select ")]');
  }

  get btnAddTradingUser () {
    return this.browser.element('//button[starts-with(text(),"Add ")]');
  }

  btnUser (user) {
    return this.browser.element(`//button[text()="${user}"]`);
  }

  btnUserExists (user) {
    return this.browser.isExisting(`//button[text()="${user}"]`);
  }

  btnUserClick (user) {
    return this.btnUser(user).click();
  }

  userParticipatingMsgExists () {
    return this.browser.isExisting('//span[text() = "USER ALREADY PARTICIPATING"]');
  }

  async addTradingUser (user) {
    await this.ddTradingUser.setSelected(user);
    await this.btnAddTradingUser.click();

    return this.waitUntilUserBtnExists(user);
  }


  async setMyBuyInterestInput (amount) {
    await this.myBuyInterestInput.setValue(amount);
  }

  async setMySellInterestInput (amount) {
    await this.mySellInterestInput.setValue(amount);
  }

  async addMinusBuyInterest (amount) {
    let interest = parseInt(await this.myLiveBuyInterest.getText()) || 0;
    while (interest !== amount) {
      if (interest > amount) {
        await this.buyMinusBtn.click();
      } else if (interest < amount) {
        await this.buyPlusBtn.click();
      }
      interest = parseInt(await this.myBuyInterestInput.getAttribute('value')) || 0;
    }
  }

  async addMinusSellInterest (amount) {
    let interest = parseInt(await this.myLiveSellInterest.getText()) || 0;
    while (interest !== amount) {
      if (interest > amount) {
        await this.sellMinusBtn.click();
      } else if (interest < amount) {
        await this.sellPlusBtn.click();
      }
      interest = parseInt(await this.mySellInterestInput.getAttribute('value')) || 0;
    }
  }

  async getBidOfferRowCount () {
    const rows = await this.bidsAndOffersTblRows;

    return rows.value.length;
  }

  async getBidOfferRow (rowIndex) {
    const rows = await this.bidsAndOffersTblRows;
    const myRow = rows.value[rowIndex - 1];

    return {
      getBid : async () => {
        if (myRow !== null) {
          const td = await this.browser.elementIdElement(myRow.ELEMENT, './td[1]');

          return new TdHandler(this.context, td);
        }

        return null;
      },
      getOffer : async () => {
        if (myRow !== null) {
          const td = await this.browser.elementIdElement(myRow.ELEMENT, './td[2]');

          return new TdHandler(this.context, td);
        }

        return null;
      }
    };
  }

  waitUntilUserBtnExists (user) {
    return this.browser.waitUntil(() => this.btnUserExists(user));
  }

  waitUntilOffers (rowCount, timeout = this.configuration.veryShortTimeout) {
    return this.browser.waitUntil(async () => {
      const count = await this.getBidOfferRowCount();

      return count === rowCount;
    }, timeout);
  }

  async waitForSummary (timeout = this.configuration.vcTimeout) {
    const found = await this.browser.waitForExist('[data-id="CONFIRMATION_MSG"]', timeout);

    return found;
  }

  waitUntilOpenToAll (timeout = this.configuration.vcTimeout) {
    return this.browser.waitUntil(() => this.isOpenToAll(), timeout);
  }

  async isOpenToAll () {
    const element = await this.vcStatusBadge;
    if (element.value === null) {
      return true;
    }

    return false;
  }
}


class TdHandler {
  constructor (context, td) {
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
    this.td = td;
  }

  async getText () {
    const element = await this.browser.elementIdText(this.td.value.ELEMENT);

    return element.value;
  }

  async hasSolidOrangeTriangle () {
    const element = await this.browser.elementIdAttribute(this.td.value.ELEMENT, 'class');
    if (element.value === 'bass-border-white triangle bass-casablanca bass-border-casablanca') {
      return true;
    }

    return false;
  }

  async isINT () {
    const element = await this.browser.elementIdText(this.td.value.ELEMENT);
    if (element.value === 'INT') {
      return true;
    }

    return false;
  }


  async hasHollowOrangeTriangle () {
    const element = await this.browser.elementIdAttribute(this.td.value.ELEMENT, 'class');
    if (element.value === 'bass-border-white triangle hollow triangle-casablanca bass-border-casablanca') {
      return true;
    }

    return false;
  }

  waitUntilTdText (tdText, timeout = this.configuration.shortTimeout) {
    return this.browser.waitUntil(() => tdText === this.getText(), timeout);
  }
}
