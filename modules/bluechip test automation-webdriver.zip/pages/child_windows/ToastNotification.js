import Page from '../Page';
import Strategy from '../../lib/strategy';

export default class ToastNotification extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  async getToastMsgs (selector) {
    const parentWindowHandle = await this.browser.getCurrentTabId();
    const toastMsgArray = [];
    const allWindowsHandles = await this.browser.getTabIds();

    for (let win = 0; win < allWindowsHandles.length; win += 1) {
      await this.browser.switchTab(allWindowsHandles[win]);
      const isToastMsg = await this.browser.isExisting(selector);

      if (isToastMsg) {
        const toastMsg = new ToastMsg(this.context, allWindowsHandles[win], parentWindowHandle, selector);
        toastMsgArray.push(toastMsg);

        break;
      }
    }

    await this.browser.switchTab(parentWindowHandle);

    return toastMsgArray;
  }

  getVcToastMsg (pxValue, strategy) {
    let selector = `[data-name="${strategy.rowDataName}"][data-indicator="V"]`;
    selector += `[data-price="${pxValue}"]`;
    this.logger.debug(`Searching for VC toast notification using selector '${selector}'`);

    return this.getToastMsgs(selector);
  }

  getBuyToastMsg (pxValue, size, strategy, traderName = '') {
    let selector = `[data-name="${strategy.rowDataName}"][data-indicator="B"]`;
    if (traderName) {
      selector += `[data-user="${traderName}"]`;
    }
    selector += `[data-price="${pxValue}"]`;
    selector += `[data-size="${size}"]`;
    this.logger.debug(`Searching for BUY toast notification using selector '${selector}'`);

    return this.getToastMsgs(selector);
  }

  getSellToastMsg (pxValue, size, strategy, traderName = '') {
    let selector = `[data-name="${strategy.rowDataName}"][data-indicator="S"]`;
    if (traderName) {
      selector += `[data-user="${traderName}"]`;
    }
    selector += `[data-price="${pxValue}"]`;
    selector += `[data-size="${size}"]`;
    this.logger.debug(`Searching for SELL toast notification using selector '${selector}'`);

    return this.getToastMsgs(selector);
  }

  getRfsResponderToastMsg (strategy) {
    const selector = `[data-name="${strategy.rowDataName}"][data-indicator="R"]`;
    this.logger.debug(`Searching for RFS Responder toast notification using selector '${selector}'`);

    return this.getToastMsgs(selector);
  }

  getMoreToastsMsg () {
    const selector = '//body/div/span[@id="num-pending"]';

    return this.getToastMsgs(selector);
  }
}

class ToastMsg {
  constructor (context, toastWindowHandle, parentWindowHandle, selector) {
    this.context = context;
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    this.parentWindowHandle = parentWindowHandle;
    this.toastWindowHandle = toastWindowHandle;
    this.selector = selector;
  }

  async click () {
    await this.browser.switchTab(this.toastWindowHandle);
    const found = await this.browser.isExisting(this.selector);
    let result = false;
    if (found) {
      await this.browser.element(this.selector).click();
      result = true;
    }
    await this.browser.switchTab(this.parentWindowHandle);

    return result;
  }

  async exists () {
    await this.browser.switchTab(this.toastWindowHandle);
    const found = await this.browser.isExisting(this.selector);
    await this.browser.switchTab(this.parentWindowHandle);

    return found;
  }
}
