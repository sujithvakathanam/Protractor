import {FenicsLaunchBar} from './FenicsLaunchBar';
import Page from './Page';
import {hasTabOpen} from '../utilities/webdriverHelper/tabsHelper';

export default class UserLogin extends Page {
  constructor (context) {
    super(context);
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;

    // Selectors
    this.usernameBox = '.fenics-input.fenics-input-lg.login__form__row__control';
    this.passwordBox = '#okta-signin-password';
    this.checkboxRemember = '.fenics-checkbox-input';
    this.forgotUser = '.login__form__row.login__form__row--extra-mt.text-cta';
    this.next = '.fenics-btn.login__form__row__cta.fenics-btn-primary';
    this.errMessage = '.login__form__row.login__form__row--error';
    this.signinError = '.okta-form-infobox-error.infobox infobox-error';
    this.submit = '#okta-signin-submit';
    this.spinnerSelector = '.loading-spinner-wrap.svelte-1obqx4g';
  }

  async login (username, password) {
    await this.waitUntilWindowOpened();
    await this.waitForLoginPageLoad(this.configuration.veryShortTimeout);
    await this.selectRememberUsername();
    await this.enterUsername(username);
    await this.clickNext();
    await this.waitForPasswordPageLoad(this.configuration.veryShortTimeout);
    await this.enterPassword(password);
    await this.clickSignIn();
    const fenicsToolBar = new FenicsLaunchBar(this.context);
    await fenicsToolBar.waitUntilWindowOpened();

    return fenicsToolBar;
  }


  waitUntilWindowOpened () {
    return this.browser.waitUntil(() => hasTabOpen(this.browser, 'Fenics Login'), this.configuration.mediumTimeout);
  }

  get txtboxUsername () {
    return this.browser.element(this.usernameBox);
  }

  get txtboxPassword () {
    return this.browser.element(this.passwordBox);
  }

  get chkboxRememberUsername () {
    return this.browser.element(this.checkboxRemember);
  }

  get txtfldForgotUsername () {
    return this.browser.element(this.forgotUser);
  }

  get btnNext () {
    return this.browser.element(this.next);
  }

  get errorMessage () {
    return this.browser.element(this.errMessage);
  }

  get signInErrorMessage () {
    return this.browser.element(this.signinError);
  }

  get btnSignIn () {
    return this.browser.element(this.submit);
  }

  pageHasLoaded () {
    return super.pageHasLoaded(this.txtboxUsername);
  }

  waitForLoginPageLoad (timeout) {
    /*
     * We should use the following statement instead but will be fixed in webdriverio v5
     *
     *   return this.txtboxUsername.waitForVisible(timeout);
     *
     * https://github.com/webdriverio/webdriverio/issues/2208
     */
    return this.browser.waitUntil(() => this.txtboxUsername.isVisible(), timeout);
  }

  waitForPasswordPageLoad (timeout) {
    // Same bug as in waitForLoginPageLoad
    return this.browser.waitUntil(() => this.txtboxPassword.isVisible(), timeout);
  }

  waitForLoginFailMessage (timeout) {
    // Same bug as in waitForLoginPageLoad
    return this.browser.waitUntil(() => this.signInErrorMessage.isVisible(), timeout);
  }

  enterUsername (text) {
    return this.txtboxUsername.setValue(text);
  }

  enterPassword (text) {
    return this.txtboxPassword.setValue(text);
  }

  selectRememberUsername () {
    this.chkboxRememberUsername.click();
  }

  clickForgotUsername () {
    this.txtfldForgotUsername.click();
  }

  async clickNext () {
    await this.browser.waitUntil(async () => {
      const spinnerExists = await this.browser.isExisting(this.spinnerSelector);
      const goBtnExists = await this.browser.isExisting(this.next);


      return spinnerExists === false && goBtnExists === true;
    }, this.configuration.shortTimeout, `Timed out after ${this.configuration.shortTimeout}ms could not find Next button on the Fenics user login`);

    return this.btnNext.click();
  }

  async clickSignIn () {
    await this.browser.waitUntil(async () => {
      const spinnerExists = await this.browser.isExisting(this.spinnerSelector);
      const goBtnExists = await this.browser.isExisting(this.submit);


      return spinnerExists === false && goBtnExists === true;
    }, this.configuration.shortTimeout, `Timed out after ${this.configuration.shortTimeout}ms could not find SignIn button on the Fenics user login`);

    return this.btnSignIn.click();
  }
}
