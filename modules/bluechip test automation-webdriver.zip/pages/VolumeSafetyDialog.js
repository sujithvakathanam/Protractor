import Page from './Page';
import {switchToTab} from './../utilities/webdriverHelper/tabsHelper';
const chaiAsPromised = require('chai-as-promised');
const chai = require('chai');
chai.use(chaiAsPromised);
const expect = chai.expect;

export default class VolumeSafetyDialog extends Page {
  constructor (context) {
    super(context);
    this.configuration = context.getConfiguration();
    this.logger = context.getLogger();
    this.browser = global.browser;
    this.vsTriggerDialogWindowHandle = null;

    // Selectors
    this.volumeSafetyTriggerPopUp = '.fenics-modal-content';
    this.volumeSafetyTitle = '.fenics-modal-title';
    this.closeButton = '.fenics-modal-content button';
    this.strategyInfo = '.fenics-modal-content [data-id="STRATEGY_INFO"]';
    this.vsTriggerTime = '.fenics-modal-content [data-id="TRIGGER_TIME"]';
  }

  async switchToDialogWindow () {
    let found = false;
    const windowSelector = this.volumeSafetyTitle;

    if (this.vsTriggerDialogWindowHandle === null) {
      try {
        found = await this.browser.waitUntil(() => switchToTab(this.browser, windowSelector), this.configuration.shortTimeout);
        if (found) {
          this.vsTriggerDialogWindowHandle = await this.browser.getCurrentTabId();
        }
      } catch (error) {
        this.logger.info(error);
      }
    } else {
      found = true;
      await this.browser.switchTab(this.vsTriggerDialogWindowHandle);
    }

    return found;
  }

  async verifyDialogExists () {
    await this.browser.elementActive(this.volumeSafetyTriggerPopUp);
  }

  async verifyDialogTitle (volumeSafetyTrigger) {
    const title = await this.browser.getText(this.volumeSafetyTitle);
    const expectedTitleText = await title.trim();
    if (volumeSafetyTrigger === 'gross') {
      expect(expectedTitleText).to.equal('Gross Volume Safety Trigger');
    } else if (volumeSafetyTrigger === 'net') {
      expect(expectedTitleText).to.equal('Net Volume Safety Trigger');
    } else if (volumeSafetyTrigger === 'directional') {
      expect(expectedTitleText).to.equal('Directional Volume Safety Trigger');
    }
  }

  async verifyDialogInfo (strategyUnderlying, strategyShortName, strategyExpiry, strike, refPrice, delta) {
    await this.browser.getText(this.vsTriggerTime);
    const stratInfo = `${strategyUnderlying} ${strategyShortName} ${strategyExpiry} ${strike} ${refPrice} ${delta}`;
    const strategyInfoUIText = await this.browser.getText(this.strategyInfo);
    expect(strategyInfoUIText).to.equal(stratInfo);
  }

  async clickCloseButton () {
    await this.browser.click(this.closeButton);
  }
}
