/* eslint-disable max-params,require-await,object-shorthand,no-warning-comments,max-len,arrow-body-style */
import {apiConfig} from '../../config/api.config';
import {OktaAuthentication, HttpsHandler, WsClient} from '@fenics/fenics-test-core';
import {RFS_TIMER_PHASE, SERVICE_MSG_TYPE} from '../../constant/GenericType';

export default class ApiClient {
  constructor (user) {
    this.logger = global.context.logger;
    this.context = global.context;
    this.configuration = global.context.configuration;
    this.pSequence = 0;
    this.user = user;
    this.data = {};
    this.ws = null;
    this.serviceMessages = {messages : []};
    this.requestResponseMessage = {};
  }


  /**
   * WaitForResponseMsg - internal usage - returns response that matches the request, throws exception in the event of timeout.
   * @param requestMsg
   * @return {Promise<any>}
   */
  waitForResponseMsg (requestMsg) {
    return new Promise((resolve, reject) => {
      const interval = setInterval(() => {
        const request = this.requestResponseMessage.request;

        if (request.sequenceNumber === requestMsg.sequenceNumber) {
          clearInterval(interval);
          resolve(this.requestResponseMessage);
        }

        setTimeout(() => {
          clearInterval(interval);
          reject(new Error(`API - waitForResponseMsg for request: ${JSON.stringify(requestMsg)} found response ${JSON.stringify(this.requestResponseMessage)}`));
        }, this.configuration.apiMsgRecheckTimeout);
      }, this.configuration.apiMsgRecheckDelay);
    });
  }

  /**
   * FindServiceMsgIndex - returns matching service message
   * @param strategyId [int}
   * @param serviceMsgType {string}
   * @return {*}
   */
  findServiceMsgIndex (strategyId, serviceMsgType) {
    for (let index = 0; index < this.serviceMessages.messages.length; index += 1) {
      const serviceMsgStrategyId = parseInt(this.serviceMessages.messages[index].details.strategy.id, 10);
      const msgType = this.serviceMessages.messages[index].service;
      const searchingForStrategyId = parseInt(strategyId, 10);
      if (serviceMsgStrategyId === searchingForStrategyId && msgType === serviceMsgType) {
        return index;
      }
    }

    return null;
  }

  /**
   * WaitForServiceMsg - waits until service message is found and returns it or throws error
   * @param strategyId
   * @param serviceMsgType
   * @return {Promise<any>}
   */
  waitForServiceMsg (strategyId, serviceMsgType) {
    return new Promise((resolve, reject) => {
      const interval = setInterval(() => {
        const index = this.findServiceMsgIndex(strategyId, serviceMsgType);
        if (index !== null) {
          clearInterval(interval);
          resolve(this.serviceMessages.messages[index]);
        }

        setTimeout(() => {
          clearInterval(interval);
          reject(new Error(`API - waitForServiceMsg did not receive service message for strategy id ${strategyId} service message type ${serviceMsgType}`));
        }, this.configuration.apiMsgRecheckTimeout);
      }, this.configuration.apiMsgRecheckDelay);
    });
  }

  /**
   * SaverServiceMsg - internal usage - saves service message based on strategyId
   * @param serviceMsg
   */
  saveServiceMsg (serviceMsg) {
    const index = this.findServiceMsgIndex(serviceMsg.details.strategy.id, serviceMsg.service);

    if (index === null) {
      this.serviceMessages.messages.push(serviceMsg);
    } else {
      this.serviceMessages.messages[index] = serviceMsg;
    }
  }

  /**
   * GetVcStatus - returns current VC status or error if VC could not be found
   * @param strategyId {int}
   * @return {String}
   */
  async getVcStatus (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.VC);

    return serviceMsg.details.status;
  }

  get wsOpen () {
    let open = false;
    if (this.ws.readyState === 1) {
      open = true;
    }

    return open;
  }

  get sequence () {
    this.pSequence += 1;

    return this.pSequence;
  }


  /**
   * GetRfsPhase - returns current rfs phase for given strategyId or error if the RFS is not found
   * @param strategyId
   * @return {string}
   */
  async getRfsPhase (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);
    const phase = serviceMsg.details.timerPhase;
    const phaseLookup = RFS_TIMER_PHASE[phase];

    return phaseLookup;
  }

  /**
   * GetStrategyMidPrice returns strategy mid price that is only available during an RFS if the Rfs is not found an error will be thrown
   * @param strategyId
   * @return {float}
   */
  async getStrategyMidPrice (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);
    const midPrice = serviceMsg.details.strategyMidPrice;

    return midPrice;
  }

  get userData () {
    return this.data;
  }

  async login () {
    let response = await this.oktaSignIn(this.user.email, this.user.password, this.user.role);
    response = JSON.parse(response);
    this.logger.debug(`response was: ${JSON.stringify(response)}`);
    this.data = await response.response[0];
    await this.openWss();
  }

  // eslint-disable-next-line class-methods-use-this
  async oktaSignIn (username, password, role) {
    const httpsHandler = new HttpsHandler();
    const oktaAuth = new OktaAuthentication();
    const userDetails = await oktaAuth.authenticate(username, password);

    let postData = {'user-token' : userDetails.token.value,
      role};
    postData = JSON.stringify(postData);

    const headers = {
      Accept           : 'application/json',
      'Content-Type'   : 'application/json',
      'Content-Length' : Buffer.byteLength(postData),
      Connection       : 'keep-alive'
    };

    const options = {
      hostname : apiConfig.appHost,
      path     : '/BlueChip/http?action=tokenLogin',
      method   : 'POST',
      headers
    };

    const data = await httpsHandler.request(options, postData, returnData => {
      const response = returnData;

      return response;
    });

    return data;
  }

  logout () {
    try {
      this.ws.closeWss();
    } catch (err) {
      this.logger.error('TraderAPI error occurred on logout', err);
    }
  }

  openWss () {
    this.ws = new WsClient('access_token', this.data.token, apiConfig.wssEndpointUrl);

    return this.ws.openWss(message => this.msgProcessor(message), async () => {
      await this.marketSubscribe();
      await this.rfsSubscribe();
      await this.vcSubscribe();
      await this.rfsEndWarningSubscribe();
      await this.rfsResponseStatSubscribe();
    });
  }

  /**
   * SendData sends ws request and returns response
   * @param data{{action: string, details: {rfsId: *, traderId: *}, token: *, sequenceNumber: *}}
   */
  sendData (data) {
    const jsonString = JSON.stringify(data);
    this.logger.debug(`ApiClient - SendData  - User ${this.user.fenicsGoUsername}: ${jsonString}`);
    this.ws.sendData(jsonString);

    return this.waitForResponseMsg(data);
  }

  /**
   * RfsSelectTrader - Activates specified trader for specified strategy
   * @param strategyId {int}
   * @param traderShortCode {string}
   * @return {Promise<*>}
   */
  async rfsSelectTrader (strategyId, traderShortCode) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);
    const traders = serviceMsg.details.traders;
    const traderId = traders.filter(trader => trader.code === traderShortCode)
      .map(trader => trader.id)[0];

    const action = {action  : 'rfs/select/trader',
      details : {rfsId : serviceMsg.details.id,
        traderId},
      token          : this.data.token,
      sequenceNumber : this.sequence};

    return this.sendData(action);
  }

  /**
   * StrategyOrderAdd - Adds order to orderbook type strategy
   * @param strategyId {int}
   * @param allOrNone {boolean}
   * @param anonymous {boolean}
   * @param fillOrKill {boolean}
   * @param orders {[{price: float, side: string, size: float}]}
   * @param aggressing {boolean}
   * @return {Promise<*>}
   */
  // eslint-disable-next-line max-params
  strategyOrderAdd (strategyId, allOrNone, anonymous, fillOrKill, aggressing, orders) {
    const action = {
      action  : 'strategy/order/add',
      details : {
        allOrNone,
        anonymous,
        fillOrKill,
        aggressing,
        live : true,
        orders,
        strategyId
      },
      token : this.data.token
    };

    return this.sendData(action);
  }

  strategyOrderUpdate (id, allOrNone, anonymous, fillOrKill, live, price, size) {
    const action = {
      action  : 'strategy/order/update',
      details : {
        allOrNone,
        anonymous,
        fillOrKill,
        id,
        live : true,
        price,
        size
      },
      token : this.data.token
    };

    return this.sendData(action);
  }


  /**
   * VsSubscribe - internal use only - subscribes to vc alerts.
   * @return {Promise<*>}
   */
  vcSubscribe () {
    const action = {action  : 'volumeclearing/subscribe',
      details : {overwrite   : true,
        notifyOnAdd : true,
        type        : 'subscribe',
        all         : false},
      token          : this.data.token,
      sequenceNumber : this.sequence};

    return this.sendData(action);
  }

  /**
   * MarketSubscribe - internal use only - subscribes to market
   * @return {Promise<*>}
   */
  marketSubscribe () {
    const action = {action  : 'market/subscribe',
      details : {ids         : [],
        type        : 'subscribe',
        overwrite   : false,
        notifyOnAdd : false,
        all         : false},
      sequenceNumber : this.sequence,
      token          : this.data.token};

    return this.sendData(action);
  }

  /**
   * VcAddInterest adds interest to VC for a particular strategy
   * @param direction
   * @param quantity
   * @return {Promise<*>}
   */
  async vcAddInterest (strategyId, direction, quantity) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.VC);

    const action = {
      action  : 'volumeclearing/interest',
      details : {id : serviceMsg.details.id,
        direction,
        quantity},
      token          : this.data.token,
      sequenceNumber : this.sequence
    };

    return this.sendData(action);
  }

  /**
   * VcCancelInterest cancels interest for a particular VC returns server response or throws error if VC not found.
   * @param strategyId {int}
   * @return {Promise<*>}
   */
  async vcCancelInterest (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.VC);

    const action = {
      action         : 'volumeclearing/interest/cancel',
      details        : {id : serviceMsg.details.id},
      token          : this.data.token,
      sequenceNumber : this.sequence
    };

    return this.sendData(action);
  }

  /**
   * RfsInitial - internal use only - sends rfs/initial message for a given strategyid and returns server response
   * @param strategyId {int}
   * @return {Promise<*>}
   */
  rfsInitial (strategyId) {
    const action = {
      action         : 'rfs/initial',
      details        : {strategyId},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }


  /**
   * SendRfsGet gets the rfs for a given session, returns
   * @param sessionId {string}
   * @return {Promise<*>}
   */
  sendRfsGet (sessionId) {
    if (sessionId) {
      const action = {
        action         : 'rfs/get',
        details        : {sessionId},
        sequenceNumber : this.sequence,
        token          : this.data.token
      };

      return this.sendData(action);
    }

    throw new Error('Api - SendRfsGet session id was undefined.');
  }

  /**
   * RfsSubscribe - internal use only - subscribes to rfs messages
   * @return {Promise<*>}
   */
  rfsSubscribe () {
    const action = {
      action  : 'rfs/subscribe',
      details : {notifyOnAdd : true,
        overwrite   : true,
        type        : 'subscribe',
        all         : false},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsReponseStatSubscribe - internal use only - Subscribes to the rfs stats service and returns server response
   * @return {Promise<*>}
   */
  rfsResponseStatSubscribe () {
    const action = {
      action  : 'rfs/responseStat/subscribe',
      details : {notifyOnAdd : 'true',
        overwrite   : 'true',
        type        : 'subscribe',
        all         : false},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsEndWarningSubscribe - internal use only - Subscribes to the rfs end warning service and returns server response.
   * @return {Promise<*>}
   */
  rfsEndWarningSubscribe () {
    const action = {
      action  : 'rfs/endWarning/subscribe',
      details : {overwrite   : true,
        notifyOnAdd : true,
        type        : 'subscribe',
        all         : false},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsAccept accepts the rfs offer for a given strategy, returns server response or error if the rfs could not be found.
   * @param strategyId {int}
   * @param buyLevel {float}
   * @param sellLevel {float}
   * @param amount {int}
   * @return {Promise<*>}
   */
  async rfsAccept (strategyId, buyLevel, sellLevel, amount) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    const action = {
      action  : 'rfs/accept',
      details : {rfsId : serviceMsg.details.id,
        buyLevel,
        sellLevel,
        amount},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsQuote will submit a user quote and return server response or throw an error if the rfs details could not be found.
   * @param strategyId {int} id of strategy
   * @param buyLevel {float}
   * @param sellLevel {float}
   * @param amount {int}
   * @return {Promise<*>}
   */
  async rfsQuote (strategyId, buyLevel, sellLevel, amount) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    const action = {
      action  : 'rfs/quote',
      details : {
        rfsId : serviceMsg.details.id,
        buyLevel,
        sellLevel,
        amount
      },
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsSubject will subject users quote and return server response or throw an error if the rfs details could not be found.
   * @param strategyId {int}
   * @return {Promise<*>}
   */
  async rfsSubject (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    const action = {
      action         : 'rfs/subject',
      details        : {rfsId : serviceMsg.details.id},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * RfsFirm will firm users quotes and return server response or throw an error if the rfs details could not be found.
   * @param strategyId {int}
   * @param buyLevel {float}
   * @param sellLevel {float}
   * @param amount {int}
   * @return {Promise<*>}
   */
  async rfsFirm (strategyId, buyLevel, sellLevel, amount) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    const action = {
      action  : 'rfs/firm',
      details : {rfsId : serviceMsg.details.id,
        buyLevel,
        sellLevel,
        amount},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  /**
   * InitiateRFS initiates rfs and gets the rfs for the give strategyId
   * @param strategyId {int}
   * @return {Promise<*|void>}
   */
  async initiateRFS (strategyId) {
    const response = await this.rfsInitial(strategyId);

    if (response.errors) {
      return response;
    }

    const msg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    return this.sendRfsGet(msg.details.sessionId);
  }

  /**
   * RespondToRFS responds to rfs on a give strategy or throws an error if the rfs could not be found
   * @param strategyId {int}
   * @return {Promise<*|void>}
   */
  async respondToRFS (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);

    return this.sendRfsGet(serviceMsg.details.sessionId);
  }

  static getService (data, key, value) {
    for (let index = 0; index < data.length; index += 1) {
      if (Reflect.has(data[index], key)) {
        if (data[index][key] === value) {
          return data[index];
        }
      }
    }

    return null;
  }

  /**
   * GetOrderId will return orderMessage and return server response or throw an error if the rfs details could not be found.
   * @param strategyId {int}
   * @return {Promise<*>}
   */
  async getOrderMessage (strategyId) {
    const action = {
      action  : 'strategy/order/get',
      details : {strategyId : strategyId},
      token   : this.data.token
    };

    return this.sendData(action);
  }

  async cancelOrder (orderId) {
    const action = {
      action  : 'strategy/order/cancel',
      details : {id : orderId},
      token   : this.data.token
    };

    return this.sendData(action);
  }


  async getBuyOrderID (strategyId) {
    const orderMessage = await this.getOrderMessage(strategyId);
    const buyOrder = orderMessage.response[0].buy.filter(order => {
      return order.type === 'OWN';
    });

    return buyOrder[0].id;
  }

  async getSellOrderID (strategyId) {
    const orderMessage = await this.getOrderMessage(strategyId);
    const sellOrder = orderMessage.response[0].sell.filter(order => {
      return order.type === 'OWN';
    });

    return sellOrder[0].id;
  }

  async getOpeningHoursList () {
    const action = {
      action  : 'openinghours/list/get',
      details : {},
      token   : this.data.token
    };

    return this.sendData(action);
  }

  async getMarketSegmentID () {
    const getList = await this.getOpeningHoursList();
    const marketID = getList.response[0].id;

    this.logger.info(marketID);

    return marketID;
  }

  async updateOpeningHours (marketID) {
    const action = {
      action  : 'openinghours/update',
      details : {id       : marketID,
        timezone : 'Europe/London',
        dst      : false,
        days     : [true, true, true, true, true, true, true],
        sessions : ['']},
      token : this.data.token
    };

    return this.sendData(action);
  }


  /**
   * UserActivated if user is activated and rfs is running for a given strategy returns true else false
   * error will be thrown if the RFS cannot be found
   * @param strategyId {int}
   * @return {Promise<boolean>}
   */
  async userActivated (strategyId) {
    const serviceMsg = await this.waitForServiceMsg(strategyId, SERVICE_MSG_TYPE.RFS);
    const activated = serviceMsg.details.activated;

    return activated;
  }

  /**
   * MsgProcessor - Internal use only - processes websocket response messages
   * @param data
   * @return {Promise<void>}
   */
  msgProcessor (data) {
    const message = JSON.parse(data);
    if (message.messages) {
      this.processMessages(message);
    }

    if (message.request) {
      this.requestResponseMessage = message;
      this.logger.debug(`ApiClient - msgProcessor - User ${this.user.fenicsGoUsername} Received message : ${JSON.stringify(this.requestResponseMessage)}`);
    }
  }

  /**
   * ProcessMessages - internal use only - extracts VC and RFS service messages
   * @param message
   */
  processMessages (message) {
    if (message.messages[0].service !== 'heartbeat') {
      this.logger.debug(`ApiClient - msgProcessor - User ${this.user.fenicsGoUsername} Received message: ${JSON.stringify(message)}`);
      const rfsServiceMsg = ApiClient.getService(message.messages, 'service', SERVICE_MSG_TYPE.RFS);

      if (rfsServiceMsg !== null) {
        this.saveServiceMsg(rfsServiceMsg);
      }

      const vcServiceMsg = ApiClient.getService(message.messages, 'service', SERVICE_MSG_TYPE.VC);
      if (vcServiceMsg !== null) {
        this.saveServiceMsg(vcServiceMsg);
      }
    }
  }

  async searchActivityLog (dateFrom, dateTo) {
    const action = {
      action  : 'activitylog/search',
      details : {dateFrom : dateFrom,
        dateTo   : dateTo},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  async runLpRankingQuery (date, productGroupId) {
    const action = {
      action  : 'lpranking/query',
      details : {productGroupId : productGroupId,
        date           : date},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  async executeLpRankingDatabaseOperation (requestId, deskType, deskName) {
    // TODO: Desks need to be configured as per which users are used
    const query = `SELECT darkPoints, litPoints, adjPoints, tradingPoints, counterPoint, orderBookPoints, TotalPoints from rankresponse where requestid = (SELECT id from rankrequest where quoterequestid = '${requestId}') and deskType = '${deskType}' and deskName = '${deskName}';`;
    const action = {
      action         : 'databaseoperation/execute',
      details        : {query : query},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };
    this.logger.info(`query is ${query}`);

    return this.sendData(action);
  }

  async getDayScoreForDesk (requestDate, product, deskId) {
    // TODO: Desks need to be configured as per which users are used
    const query = `SELECT dayScore from rankscore where DATE(requestDate) = '${requestDate}' and product = '${product}' and deskid = '${deskId}'`;
    const action = {
      action         : 'databaseoperation/execute',
      details        : {query : query},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  async executeLpRankingDatabaseOperationWithStrategyType (requestId, deskType, deskName) {
    // TODO: Desks need to be configured as per which users are used
    const query = `SELECT strategyType from rankresponse where requestid = (SELECT id from rankrequest where quoterequestid = '${requestId}') and deskType = '${deskType}' and deskName = '${deskName}';`;
    const action = {
      action         : 'databaseoperation/execute',
      details        : {query : query},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }


  // TODO: above method needs to change with this added, then all expects need to be updated
  async executeLpRankingDatabaseOperationWithValidResponse (requestId, deskType, deskName) {
    // TODO: Desks need to be configured as per which users are used
    const query = `SELECT validResponse from rankresponse where requestid = (SELECT id from rankrequest where quoterequestid = '${requestId}') and deskType = '${deskType}' and deskName = '${deskName}';`;
    const action = {
      action         : 'databaseoperation/execute',
      details        : {query : query},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  async addFastMarkets (dateFrom, dateTo, marketSegment) {
    const action = {
      action  : 'fastmarket/add',
      details : {segmentId : marketSegment,
        dateFrom  : dateFrom,
        dateTo    : dateTo},
      sequenceNumber : this.sequence,
      token          : this.data.token
    };

    return this.sendData(action);
  }

  async getAllMarketSegments () {
    const action = {
      action  : 'marketsegment/get',
      details : {},
      token   : this.data.token
    };

    return this.sendData(action);
  }

  async getMarketSegment (marketSegmentId) {
    const marketSegments = await this.getAllMarketSegments();
    const filteredSegment = marketSegments.response.filter(ms => {
      return ms.id === marketSegmentId;
    });

    return filteredSegment;
  }

  async updateMarketSegment (marketSegmentDetails) {
    // The below settings are not needed in the update
    delete marketSegmentDetails.rfsSettings;
    delete marketSegmentDetails.volumeClearingSettings;
    delete marketSegmentDetails.fatFingerSettings;
    const action = {
      action  : 'marketsegment/update',
      details : marketSegmentDetails,
      token   : this.data.token
    };

    return this.sendData(action);
  }
}
