export default class WaitForHelper {
  constructor (context) {
    this.context = context;
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  waitForNotVisible (element) {
    this.browser.waitUntil(
      () => {
        try {
          return !element.isVisible();
        } catch (error) {
          return true;
        }
      }, this.configuration.veryShortTimeout
      , `${element}, element has not disapeared.`
    );
  }

  waitForEnabled (element) {
    return element.waitForEnabled(this.configuration.veryShortTimeout);
  }

  async browserWaitForEnabled (xPath) {
    let isEnabled = false;
    try {
      isEnabled = await this.browser.isEnabled(xPath);
      if (!isEnabled) {
        await this.browser.waitForEnabled(xPath, this.configuration.veryShortTimeout);
        isEnabled = await this.browser.isEnabled(xPath);
      }
    } catch (error) {
      isEnabled = false;
    }

    return isEnabled;
  }

  waitForExist (cssSelector, timeout = this.configuration.shortTimeout) {
    return this.browser.waitForExist(cssSelector, timeout);
  }

  async waitForInteractable (selector) {
    try {
      await this.browser.getText(selector);
    } catch (err) {
      return false;
    }

    return true;
  }
}
