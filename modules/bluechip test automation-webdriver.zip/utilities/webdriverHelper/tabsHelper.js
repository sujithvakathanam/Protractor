export const hasTabOpen = async (client, tabTitleSearched) => {
  const ids = await client.getTabIds();
  for (let id = 0; id < ids.length; id += 1) {
    try {
      await client.switchTab(ids[id]);
      const title = await client.getTitle();
      if (title === tabTitleSearched) {
        return true;
      }
    } catch (err) {
      // Log error using core logging
      if (err.type === 'RuntimeError') {
        await client.close();
      }
      throw err;
    }
  }


  return false;
};

export const switchToTab = async (client, selector) => {
  const ids = await client.getTabIds();

  for (let id = 0; id < ids.length; id += 1) {
    try {
      await client.switchTab(ids[id]);
      const found = await client.isExisting(selector);
      if (found) {
        return true;
      }
    } catch (err) {
      // Log error using core logging
    }
  }

  return false;
};

export const reloadDom = client => client.execute('return window.location.reload()');
