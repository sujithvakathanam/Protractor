'use-strict';

import {spawnSync} from 'child_process';

export const shellExec = script => {
  spawnSync(script);
};
