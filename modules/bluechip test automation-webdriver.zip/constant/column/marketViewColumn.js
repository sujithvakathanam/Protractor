const MARKET_VIEW_COLUMNS = {
  COLUMN_NAMES : {
    STATUS        : 'STATUS',
    INITIATOR     : 'INITIATOR',
    UNDERLYING    : 'UNDERLYING',
    STRATEGY      : 'STRATEGY',
    EXPIRY        : 'EXPIRY',
    EXPIRY_BROKER : 'EXPIRY_BROKER',
    STRIKES       : 'STRIKES',
    RATIO         : 'RATIO',
    REF           : 'REF',
    DELTA         : 'DELTA',
    BID_SIZE      : 'BID_SIZE',
    BID_PRICE     : 'BID_PRICE',
    VC_PRICE      : 'VC_PRICE',
    ASK_SIZE      : 'ASK_SIZE',
    ASK_PRICE     : 'ASK_PRICE',
    LAST          : 'LAST',
    TIME          : 'TIME'
  },
  COLUMN_WIDTHS : {
    STATUS        : 58,
    INITIATOR     : 50,
    UNDERLYING    : 50,
    STRATEGY      : 60,
    EXPIRY        : 180,
    EXPIRY_BROKER : 230,
    STRIKES       : 175,
    RATIO         : 105,
    REF           : 55,
    DELTA         : 45,
    BID_SIZE      : 64,
    BID_PRICE     : 80,
    ASK_SIZE      : 64,
    ASK_PRICE     : 80,
    VC_PRICE      : 160,
    LAST          : 80,
    TIME          : 55
  },
  STATUS_TYPES : {
    RFS : 'RFS',
    VC  : 'VC'
  },
  SORTING_KEY : {
    STATUS        : 'sI.workflow',
    INITIATOR     : 'sI.initiator.entityInfo',
    UNDERLYING    : 'o.i',
    STRATEGY      : 'o.n',
    EXPIRY        : 'o.firstLegMaturity',
    EXPIRY_FILTER : 'o.m',
    STRIKES       : 'o.s',
    RATIO         : 'o.rt',
    REF           : 'o.r',
    DELTA         : 'o.d',
    BID_SIZE      : 'buy.size',
    BID_PRICE     : 'buy.price',
    ASK_SIZE      : 'sell.size',
    ASK_PRICE     : 'sell.price',
    LAST          : 'lP.lP',
    TIME          : 'o.lmt'
  }
};

export default MARKET_VIEW_COLUMNS;
