const MARKET_DEPTH_COLUMNS = {
  COLUMN_NAMES : {
    PRICE  : 'PRICE',
    SIZE   : 'SIZE',
    ACTION : 'ACTION'
  },
  COLUMN_WIDTHS : {
    PRICE  : 109,
    SIZE   : 102,
    ACTION : 144
  }
};

export default MARKET_DEPTH_COLUMNS;
