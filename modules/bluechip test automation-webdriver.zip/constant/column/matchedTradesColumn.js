const MATCHED_TRADES_COLUMNS = {
  COLUMN_NAMES : {
    STATUS   : 'STATUS',
    STRATEGY : 'STRATEGY',
    HEDGE    : 'HEDGE',
    FILTER   : 'FILTER',
    PRICE    : 'PRICE',
    SIZE     : 'SIZE',
    TRADER   : 'TRADER',
    DATE     : 'DATE'
  },
  COLUMN_WIDTHS : {
    STATUS   : 140,
    STRATEGY : 640,
    HEDGE    : 40,
    FILTER   : 50,
    PRICE    : 75,
    SIZE     : 75,
    TRADER   : 110,
    DATE     : 70
  },
  SORTING_KEY : {
    STATUS   : 'trade.state',
    STRATEGY : 'strategy.name',
    HEDGE    : 'strategy.hedge',
    FILTER   : '',
    PRICE    : 'trade.price',
    SIZE     : 'trade.qty',
    TRADER   : 'owner.code',
    DATE     : 'trade.executionTime'
  }
};

export default MATCHED_TRADES_COLUMNS;
