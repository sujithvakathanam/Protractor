const MarketSegmentIds = {
  SX5E : 1,
  NKYO : 25,
  NKYS : 26
};

export default MarketSegmentIds;
