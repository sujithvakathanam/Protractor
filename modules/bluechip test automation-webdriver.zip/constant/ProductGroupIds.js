const ProductGroupIds = {
  SX5E  : 1,
  OSAKA : 3,
  SGX   : 4,
  SX7E  : 9
};

export default ProductGroupIds;
