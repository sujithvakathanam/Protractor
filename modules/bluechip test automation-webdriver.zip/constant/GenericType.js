export const FILL_TYPE = {
  partial   : 'Partial',
  allOrNone : 'All Or None'
};

export const TIME_TYPE = {
  day       : 'Day',
  immediate : 'Immediate'
};

export const ORDER_TYPE = {
  bid : 'Bid',
  ask : 'Ask'
};

export const MARKET = {
  euroSTOXX : 'Euro STOXX',
  nikkei    : 'Nikkei'
};

export const UNDERLYING = {
  sx5e : 'SX5E',
  nkyo : 'NKYO',
  nkys : 'NKYS'
};

export const STRATEGY_WORKFLOW = {
  orderBook : 'ORDERBOOK',
  rfs       : 'RFS'
};

export const STRATEGY = {
  boxSpread : {name      : 'Box Spread',
    shortName : 'BOX',
    workflow  : STRATEGY_WORKFLOW.orderBook,
    hasFuture : true},
  call : {name      : 'Call',
    shortName : 'C',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callCalendar : {name      : 'Call Calendar',
    shortName : 'CC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callCalendarFly : {name      : 'Call Calendar Fly',
    shortName : 'CCFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callCalendarRatio : {name      : 'Call Calendar Ratio',
    shortName : 'CCR',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callCondor : {name      : 'Call Condor',
    shortName : 'CCON',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callDiagonalCalendar : {name      : 'Call Diagonal Calendar',
    shortName : 'DCC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callFly : {name      : 'Call Fly',
    shortName : 'CFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callLadder : {name      : 'Call Ladder',
    shortName : 'CLAD',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callRatioSpread : {name      : 'Call Ratio',
    shortName : 'CR',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSkinnyFly : {name      : 'Call Skinny Fly',
    shortName : 'CSFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpread : {name      : 'Call Spread',
    shortName : 'CS',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpreadSwap : {name      : 'Call Spread Swap',
    shortName : 'CSSWP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpreadvPut : {name      : 'Call Spread v Put',
    shortName : 'CSVP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpreadvPutSpread : {name      : 'Call Spread v Put Spread',
    shortName : 'CSVPS',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  ironCondor : {name      : 'Iron Condor',
    shortName : 'ICON',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  ironFly : {name      : 'Iron Fly',
    shortName : 'IFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  jellyRoll : {name      : 'Jelly Roll',
    shortName : 'JR',
    workflow  : STRATEGY_WORKFLOW.orderBook,
    hasFuture : false},
  put : {name      : 'Put',
    shortName : 'P',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putCalendar : {name      : 'Put Calendar',
    shortName : 'PC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putCalendarFly : {name      : 'Put Calendar Fly',
    shortName : 'PCFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putCalendarRatio : {name      : 'Put Calendar Ratio',
    shortName : 'PCR',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putCondor : {name      : 'Put Condor',
    shortName : 'PCON',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putDiagonalCalendar : {name      : 'Put Diagonal Calendar',
    shortName : 'DPC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putFly : {name      : 'Put Fly',
    shortName : 'PFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putLadder : {name      : 'Put Ladder',
    shortName : 'PLAD',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putRatioSpread : {name      : 'Put Ratio',
    shortName : 'PR',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putSkinnyFly : {name      : 'Put Skinny Fly',
    shortName : 'PSFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putSpread : {name      : 'Put Spread',
    shortName : 'PS',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putSpreadSwap : {name      : 'Put Spread Swap',
    shortName : 'PSSWP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putSpreadvCall : {name      : 'Put Spread v Call',
    shortName : 'PSVC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  ratioRisky : {name      : 'Ratio Risky',
    shortName : 'RRR P+',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  riskyPplus : {name      : 'Risky P+',
    shortName : 'RR P+',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  riskyCplus : {name      : 'Risky C+',
    shortName : 'RR C+',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  riskySwap : {name      : 'Risky Swap',
    shortName : 'RRS C+',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  riskyTimeSpread : {name      : 'Risky Time Spread',
    shortName : 'RRT P+',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  roll : {name      : 'Roll',
    shortName : 'ROLL',
    workflow  : STRATEGY_WORKFLOW.orderBook,
    hasFuture : false},
  straddle : {name      : 'Straddle',
    shortName : 'SD',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddleCalendar : {name      : 'Straddle Calendar',
    shortName : 'SDCAL',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddleFly : {name      : 'Straddle Fly',
    shortName : 'SDFLY',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddleSpread : {name      : 'Straddle Spread',
    shortName : 'SDSPD',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddlevCall : {name      : 'Straddle v Call',
    shortName : 'SDVC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddlevPut : {name      : 'Straddle v Put',
    shortName : 'SDVP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddlevStrangle : {name      : 'Straddle v Strangle',
    shortName : 'SDVSG',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  strangle : {name      : 'Strangle',
    shortName : 'SG',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  strangleSpread : {name      : 'Strangle Spread',
    shortName : 'SGSPD',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  syntheticPplus : {name      : 'Synthetic P+',
    shortName : 'SYN P+',
    workflow  : STRATEGY_WORKFLOW.orderBook,
    hasFuture : true},
  syntheticCplus : {name      : 'Synthetic C+',
    shortName : 'SYN C+',
    workflow  : STRATEGY_WORKFLOW.orderBook,
    hasFuture : true},
  straddleVCall : {name      : 'Straddle v Call',
    shortName : 'SDVC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddleVPut : {name      : 'Straddle v Put',
    shortName : 'SDVP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  straddleVStrangle : {name      : 'Straddle v Strangle',
    shortName : 'SDVSG',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpreadVPut : {name      : 'Call Spread v Put',
    shortName : 'CSVP',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  callSpreadVPutSpread : {name      : 'Call Spread v Put Spread',
    shortName : 'CSVPS',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true},
  putSpreadVCall : {name      : 'Put Spread v Call',
    shortName : 'PSVC',
    workflow  : STRATEGY_WORKFLOW.rfs,
    hasFuture : true}
};

export const POLARITY = {
  positive : '+',
  negative : '-'
};

export const OPTION_TYPE = {
  call : 'C',
  put  : 'P'
};

export const STYLE = {
  euro : 'European'
};

export const ROLE = {
  trader : 'TRADER',
  broker : 'BROKER',
  admin  : 'ADMIN'
};

export const COLOR_CODES = {
  BANANA : {
    hex  : '#FFDE54',
    rgba : 'rgba(255, 222, 84, 1)'
  },
  BRAND_BLUE : {
    hex  : '#0053B8',
    rgba : 'rgba(0, 83, 184, 1)'
  },
  DARK_GREY_3 : {
    hex  : '#596776',
    rgba : 'rgba(89,103,118,1)'
  },
  SALMON : {
    hex  : '#EEA7A5',
    rgba : 'rgba(238,167,165,1)'
  },
  TANGERINE : {
    hex  : '#FF8E4F',
    rgba : 'rgba(255,142,79,1)'
  },
  WATERMELON : {
    hex  : '#FF5D73',
    rgba : 'rgba(255, 142, 79, 1)'
  },
  WHITE : {
    hex  : '#FFFFFF',
    rgba : 'rgba(255, 355, 255, 1)'
  }
};

export const COLOR_PURPOSE = {
  VC_COLOR       : COLOR_CODES.SALMON,
  RFS_COLOR      : COLOR_CODES.BRAND_BLUE,
  INACTIVE_COLOR : COLOR_CODES.DARK_GREY_3,
  ERROR_COLOR    : COLOR_CODES.WATERMELON,
  CONTACT_BROKER : COLOR_CODES.WATERMELON,
  WARN_COLOR     : COLOR_CODES.TANGERINE,
  LIVE_PRICE     : COLOR_CODES.BANANA,
  MY_PRICE       : COLOR_CODES.TANGERINE,
  LP_REQUEST     : COLOR_CODES.TANGERINE,
  PRIMARY_TEXT   : COLOR_CODES.WHITE
};

export const RFS_TIMER_PHASE = {
  BOOK_BUILDING_OVER : 'TRADING',
  DARK_BUILDING      : 'DARK',
  LIT_BUILDING       : 'LIT'
};

export const SERVICE_MSG_TYPE = {
  RFS : 'rfs',
  VC  : 'volumeclearing'
};
