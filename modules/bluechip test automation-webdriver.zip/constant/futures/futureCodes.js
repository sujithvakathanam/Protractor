const MONTH_NAMES = [
  'JAN',
  'FEB',
  'MAR',
  'APR',
  'MAY',
  'JUN',
  'JUL',
  'AUG',
  'SEP',
  'OCT',
  'NOV',
  'DEC'
];

const MONTH_CODES = {
  JAN : 'F',
  FEB : 'G',
  MAR : 'H',
  APR : 'J',
  MAY : 'K',
  JUN : 'M',
  JUL : 'N',
  AUG : 'Q',
  SEP : 'U',
  OCT : 'V',
  NOV : 'X',
  DEC : 'Z'
};

export default {
  MONTH_NAMES,
  MONTH_CODES
};
