const REUTERS_CODES = {
  SX5E : 'STXE',
  NKYO : 'JNI',
  NKYS : 'SSI'
};

export default REUTERS_CODES;
