const FUTURE_EXPIRY_MONTHS = {
  SX5E : [3, 6, 9, 12],

  // TODO : Verify if this is correct
  NKYO : [3, 6, 9, 12],
  NKYS : [3, 6, 9, 12]

};

export default FUTURE_EXPIRY_MONTHS;
