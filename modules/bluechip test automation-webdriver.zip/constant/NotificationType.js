export const NOTIFICATION_TYPE = {
  error          : 'X',
  volumeClearing : 'V',
  fillBuy        : 'B',
  fillSell       : 'S',
  rfsResponder   : 'R',
  rfsInitiator   : 'Q'
};

