import FenicsLogger from '@fenics/fenics-logging';
import FIXParser, {Field} from '../fixparser';
import MessageField from '../fixparser/Field';
import {FixGroups} from '../constant';

const fixParser = new FIXParser();
const logger = new FenicsLogger({
  context : 'FIX Encoder'
});

let mapField = null;

const buildFieldsFromObject = (obj, firstTag = null, dictionary) => {
  const allFields = Object.entries(obj)
    .map(([key, value]) => mapField({
      key,
      value,
      filterTag : firstTag,
      dictionary
    }))
    .reduce((arr, fields) => [...arr, ...fields], []);

  return firstTag ? [
    mapField({
      key   : firstTag,
      value : obj[firstTag],
      dictionary
    }),
    allFields
  ] : allFields;
};

/* eslint-disable complexity */
mapField = ({key, value, filterTag = null, dictionary}) => {
  // This is explicitly added at the top of the pile
  if (key === 'MsgType' || filterTag && key === filterTag) {
    return [];
  }

  if (Field[key]) {
    return [new MessageField(Field[key], value)];
  }

  if (FixGroups[key] && Array.isArray(value)) {
    const group = FixGroups[key];

    const fields = value
      .map(subValue => buildFieldsFromObject(subValue, group.firstTag, dictionary))
      .reduce((arr, subFields) => [...arr, ...subFields], []);

    const groupFields = [
      [new MessageField(Field[group.lengthTag], value.length)],
      ...fields
    ].reduce((arr, subFields) => [...arr, ...subFields], []);

    return groupFields;
  }

  if (Object.values(dictionary).includes(key)) {
    const inverted = Object.entries(dictionary).reduce((acc, [tag, tagName]) => ({
      ...acc,
      [tagName] : tag
    }), {});

    return [new MessageField(inverted[key], value)];
  }

  throw new Error(`The property name '${key}' is not a valid FIX tag name.`);
};

const resetSeqNum = () => fixParser.resetNextTargetMsgSeqNum();

const encoder = (fixObject, options) => {
  const completeObject = {
    ...options.commonTags,
    ...fixObject
  };

  if (!fixObject.MsgType) {
    throw new Error('The MsgType tag is a required FIX tag.');
  }

  const fields = [
    new MessageField(Field.BeginString, options.beginString),
    new MessageField(Field.MsgType, fixObject.MsgType),
    new MessageField(Field.MsgSeqNum, fixParser.getNextTargetMsgSeqNum()),
    new MessageField(Field.SendingTime, FIXParser.getTimestamp()),
    ...buildFieldsFromObject(completeObject, null, options.dictionary)
  ];

  const encoded = fixParser.createMessage(...fields).encode(options.separator);

  if (options.verbose) {
    logger.debug(JSON.stringify(completeObject), encoded);
  }

  return encoded;
};

export {
  resetSeqNum
};

export default encoder;
