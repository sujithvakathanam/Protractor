import FIXParser from '../fixparser';
import {FixGroups} from '../constant';
import FenicsLogger from '@fenics/fenics-logging';

const logger = new FenicsLogger({
  context : 'FIX Decoder'
});

const fixParser = new FIXParser();
const failedMessage = 'Failed to parse the FIX message: ';

const buildObjectFromArray = (tags, options) => {
  let group = null;

  /* eslint-disable complexity,max-statements */
  return tags.reduce((obj, tag) => {
    let reduced = {...obj};

    if (group) {
      /*
       * If we have an invalid tag for this group then we:
       *   1. have finished the groups and stepped out (group.count <= 0)
       *   2. have found an invalid tag with a group other than the last group
       */
      if (group.def.validTags.indexOf(tag.name) < 0) {
        if (group.count <= 1) {
          // We're done with this group, 91 above signifies last group
          reduced = {
            ...reduced,
            [group.name] : [
              ...group.objects,
              ...group.tags ? [buildObjectFromArray(group.tags, options)] : []
            ]
          };
          group = null;
        } else {
          // An invalid tag was found
          throw new Error(`Unexpected group tag ${tag.name}, found in group ${group.name}`);
        }

        /*
         * If we are building groups then we:
         *   1. Have found the first expected tag in a group object
         *   2. Have a valid group object tag
         *   3. Have found the first tag but it's not what we expect
         */
      } else if (group.def.firstTag === tag.name) {
        // This should be the first tag in the group object,
        if (group.tags) {
          // So if we have tags from the last group object process them
          group = {
            ...group,
            count   : group.count - 1,
            tags    : null,
            objects : [
              ...group.objects,
              ...group.tags ? [buildObjectFromArray(group.tags, options)] : []
            ]
          };
        }

        // Set the first tag of a new group
        group.tags = [tag];
      } else if (group.tags) {
        // This is a valid group object tag so put it in the group
        group.tags.push(tag);
      } else {
        // The first tag in the group object is not what we expect
        throw new Error(`Expected first group tag of ${group.def.firstTag}, but got ${tag.name}`);
      }
    }

    // We still need to perform operations for the current tag
    if (!group) {
      const groupEntry = Object
        .entries(FixGroups)
        .find(([, value]) => value.lengthTag === tag.name);

      if (groupEntry) {
        group = {
          name    : groupEntry[0],
          def     : groupEntry[1],
          count   : Number.parseInt(tag.value, 10),
          tags    : null,
          objects : []
        };
      }

      if (Reflect.has(options.dictionary, tag.name)) {
        reduced = {
          ...reduced,
          [options.dictionary[tag.name]] : tag.value
        };
      } else {
        reduced = {
          ...reduced,
          [tag.name] : tag.value
        };
      }
    }

    return reduced;
  }, {});
};

const decoder = (fixString, options) => {
  try {
    const parsed = fixParser.parse(fixString, options.separator);

    return parsed.map(singleMessage => {
      if (!singleMessage.bodyLengthValid && options.validateBodyLength) {
        throw new Error(`${failedMessage}the body length is invalid.`);
      }

      if (!singleMessage.checksumValid && options.validateChecksum) {
        throw new Error(`${failedMessage}the checksum is invalid.`);
      }

      const tagArray = singleMessage.data
        .map(({tag, name, value}) => ({
          tag,
          name : name || tag.toString(),
          value
        }));

      if (!options.asObject) {
        if (options.verbose) {
          logger.debug(fixString, JSON.stringify(tagArray));
        }

        return tagArray;
      }

      const fixObject = buildObjectFromArray(tagArray, options);

      if (options.verbose) {
        logger.debug(fixString, JSON.stringify(fixObject));
      }

      return fixObject;
    });
  } catch (err) {
    throw new Error(`${failedMessage}${err}`);
  }
};

export default decoder;
