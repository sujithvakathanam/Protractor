class Field {
  constructor (tag, value) {
    this.tag = Number.parseInt(tag, 10);
    this.value = value;
  }
}

export default Field;
