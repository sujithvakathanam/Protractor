const PosQtyStatus = {
  Submitted : '0',
  Accepted  : '1',
  Rejected  : '2'
};

export default PosQtyStatus;
