const QuoteStatus = {
  Accepted                      : '0',
  CancelForSymbol               : '1',
  Pending                       : '10',
  Pass                          : '11',
  LockedMarketWarning           : '12',
  CrossMarketWarning            : '13',
  CanceledDueToLockMarket       : '14',
  CanceledDueToCrossMarket      : '15',
  CanceledForSecurityType       : '2',
  CanceledForUnderlying         : '3',
  CanceledAll                   : '4',
  Rejected                      : '5',
  RemovedFromMarket             : '6',
  Expired                       : '7',
  Query                         : '8',
  QuoteNotFound                 : '9',
  Active                        : '16',
  Canceled                      : '17',
  UnsolicitedQuoteReplenishment : '18',
  PendingEndTrade               : '19',
  TooLateToEnd                  : '20'
};

export default QuoteStatus;
