const EncryptMethod = {
  None      : '0',
  PKCS      : '1',
  DES       : '2',
  PKCSDES   : '3',
  PGPDES    : '4',
  PGPDESMD5 : '5',
  PEM       : '6'
};

export default EncryptMethod;
