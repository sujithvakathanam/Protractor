const MassCancelRejectReason = {
  CreditBreach : '99'
};

export default MassCancelRejectReason;
