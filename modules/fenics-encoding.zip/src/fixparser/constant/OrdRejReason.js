const OrdRejReason = {
  Broker                                : '0',
  UnknownSymbol                         : '1',
  ExchangeClosed                        : '2',
  OrderExceedsLimit                     : '3',
  TooLateToEnter                        : '4',
  UnknownOrder                          : '5',
  DuplicateOrder                        : '6',
  DuplicateOfAVerballyCommunicatedOrder : '7',
  StaleOrder                            : '8',
  TradeAlongRequired                    : '9',
  InvalidInvestorID                     : '10',
  UnsupportedOrderCharacteristic        : '11',
  SurveillenceOption                    : '12',
  IncorrectQuantity                     : '13',
  IncorrectAllocatedQuantity            : '14',
  UnknownAccount                        : '15',
  PriceExceedsCurrentPriceBand          : '16',
  InvalidPriceIncrement                 : '18',
  Other                                 : '99'
};

export default OrdRejReason;
