const SecurityIDSource = {
  CUSIP                             : '1',
  SEDOL                             : '2',
  QUIK                              : '3',
  ISIN                              : '4',
  RICcode                           : '5',
  ISOCurrencyCode                   : '6',
  ISOCountryCode                    : '7',
  ExchangeSymbol                    : '8',
  ConsolidatedTapeAssociationSymbol : '9',
  BloombergSymbol                   : 'A',
  Wertpapier                        : 'B',
  Dutch                             : 'C',
  Valoren                           : 'D',
  Sicovam                           : 'E',
  Belgian                           : 'F',
  Common                            : 'G',
  ClearingHouseOrOrganization       : 'H',
  ISDAFpMLProductSpecification      : 'I',
  OptionPriceReportingAuthority     : 'J',
  LetterOfCredit                    : 'L',
  ISDAFpMLProductURL                : 'K',
  MarketplaceAssignedIdentifier     : 'M'
};

export default SecurityIDSource;
