const RoutingInst = {
  Dark : 'H',
  Lit  : 'B'
};

export default RoutingInst;
