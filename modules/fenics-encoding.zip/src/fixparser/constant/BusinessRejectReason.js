const BusinessRejecReason = {
  Other                               : '0',
  UnknownID                           : '1',
  UnknownSecurity                     : '2',
  UnsupportedMessageType              : '3',
  ApplicationNotAvailable             : '4',
  ConditionallyRequiredFieldMissing   : '5',
  NotAuthorized                       : '6',
  DeliverToFirmNotAvailableAtThisTime : '7',
  InvalidPriceIncrement               : '18'
};

export default BusinessRejecReason;
