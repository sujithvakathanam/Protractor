const HandlInst = {
  AutomatedExecutionNoIntervention : '1',
  AutomatedExecutionInterventionOK : '2',
  ManualOrder                      : '3'
};

export default HandlInst;
