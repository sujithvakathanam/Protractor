const AggressorIndicator = {
  Aggressor : 'Y',
  Passive   : 'N'
};

export default AggressorIndicator;
