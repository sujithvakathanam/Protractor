const OrdStatus = {
  New                : '0',
  PartiallyFilled    : '1',
  Filled             : '2',
  DoneForDay         : '3',
  Cancelled          : '4',
  PendingCancel      : '6',
  Stopped            : '7',
  Rejected           : '8',
  Suspended          : '9',
  PendingNew         : 'A',
  Calculated         : 'B',
  Expired            : 'C',
  AcceptedForBidding : 'D',
  PendingReplace     : 'E',
  Replaced           : '5'
};

export default OrdStatus;
