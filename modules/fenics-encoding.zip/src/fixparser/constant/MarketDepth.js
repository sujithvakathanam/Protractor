const MarketDepth = {
  FullBookDepth : '0',
  TopOfBook     : '1',
  AndAbove      : '2'
};

export default MarketDepth;
