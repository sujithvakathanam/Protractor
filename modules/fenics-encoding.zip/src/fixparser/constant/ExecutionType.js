const ExecutionType = {
  New                            : '0',
  DoneForDay                     : '3',
  Canceled                       : '4',
  Replaced                       : '5',
  PendingCancel                  : '6',
  Stopped                        : '7',
  Rejected                       : '8',
  Suspended                      : '9',
  PendingNew                     : 'A',
  Calculated                     : 'B',
  Expired                        : 'C',
  Restated                       : 'D',
  PendingReplace                 : 'E',
  Trade                          : 'F',
  TradeCorrect                   : 'G',
  TradeCancel                    : 'H',
  OrderStatus                    : 'I',
  TradeInAClearingHold           : 'J',
  TradeHasBeenReleasedToClearing : 'K',
  TriggeredOrActivatedBySystem   : 'L'
};

export default ExecutionType;
