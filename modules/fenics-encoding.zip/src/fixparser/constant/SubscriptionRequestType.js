const SubscriptionRequestType = {
  Snapshot                               : '0',
  SnapshotAndUpdate                      : '1',
  DisablePreviousSnaphotAndUpdateRequest : '2'
};

export default SubscriptionRequestType;
