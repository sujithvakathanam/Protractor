import {pad3} from './utils';

const CRC256 = 256;

class Message {
  constructor (fixVersion = 'FIXT.1.1', fields) {
    this.fixVersion = fixVersion;
    this.fields = fields;
  }

  static crc (message) {
    let sum = 0;

    for (let index = 0; index < message.length; index += 1) {
      sum += message.charCodeAt(index);
    }

    return sum % CRC256;
  }

  encode (seperator = '\u0001') {
    const parts = this.fields
      .map(field => `${field.tag}=${field.value}${seperator}`);

    const body = parts.slice(1).join('');
    const bodyLength = `9=${body.length}${seperator}`;
    const message = `${parts[0]}${bodyLength}${body}`;
    const checksum = `10=${pad3(Message.crc(message))}${seperator}`;

    return `${message}${checksum}`;
  }
}

export default Message;
