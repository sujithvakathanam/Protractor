const SECONDS_IN_MINUTE = 60000;
const PAD_TO_2 = 2;
const PAD_TO_3 = 3;

const adjustForTimezone = date => {
  const timeOffsetInMS = date.getTimezoneOffset() * SECONDS_IN_MINUTE;

  date.setTime(date.getTime() + timeOffsetInMS);

  return date;
};

const buildReverseMap = (mapObject = {}) => {
  const reverseMap = Object.entries(mapObject).reduce((acc, [key, value]) => {
    acc[value] = key;

    return acc;
  }, {});

  return reverseMap;
};

const pad = (value, size) => {
  const paddedString = `00${value}`;

  return paddedString.substr(paddedString.length - size);
};

const pad2 = value => pad(value, PAD_TO_2);
const pad3 = value => pad(value, PAD_TO_3);

export {
  adjustForTimezone,
  buildReverseMap,
  pad2,
  pad3
};
