import {adjustForTimezone, buildReverseMap, pad2, pad3} from './utils';
import Field from './constant/Field';
import Message from './Message';

class FIXParser {
  constructor (fixVersion = 'FIXT.1.1') {
    this.nextTargetMsgSeqNum = 1;
    this.fixVersion = fixVersion;
    this.reverseFieldMap = buildReverseMap(Field);
  }

  static buildMessage (data) {
    return {data};
  }

  buildTagObject (tag, value) {
    return {
      tag  : Number.parseInt(tag, 10),
      name : this.reverseFieldMap[tag],
      value
    };
  }

  parse (streamString, separator = '\u0001') {
    const pairs = streamString.split(separator);
    const messageArrays = [];
    let currentArray = null;

    pairs.forEach(pair => {
      const [tag, value] = pair.split('=');

      if (tag) {
        if (Number.parseInt(tag, 10) === Field.BeginString && currentArray !== null) {
          messageArrays.push(FIXParser.buildMessage(currentArray));

          currentArray = [this.buildTagObject(tag, value)];
        }

        if (currentArray === null) {
          currentArray = [];
        }

        currentArray.push(this.buildTagObject(tag, value));
      }
    });

    if (currentArray.length > 0) {
      messageArrays.push(FIXParser.buildMessage(currentArray));
    }

    return messageArrays;
  }

  createMessage (...field) {
    return new Message(this.fixVersion, field);
  }

  resetNextTargetMsgSeqNum () {
    this.nextTargetMsgSeqNum = 1;
  }

  getNextTargetMsgSeqNum () {
    const nextTargetMsgSeqNum = this.nextTargetMsgSeqNum;

    this.nextTargetMsgSeqNum += 1;

    return nextTargetMsgSeqNum;
  }

  static getTimestamp (dateObject = new Date()) {
    if (Number.isNaN(dateObject.getTime())) {
      throw new Error('Invalid date specified!');
    }

    const date = adjustForTimezone(dateObject);

    return [
      date.getFullYear(),
      pad2(date.getMonth() + 1),
      pad2(date.getDate()),
      `-${pad2(date.getHours())}`,
      `:${pad2(date.getMinutes())}`,
      `:${pad2(date.getSeconds())}`,
      `.${pad3(date.getMilliseconds())}`
    ].join('');
  }
}

export default FIXParser;
