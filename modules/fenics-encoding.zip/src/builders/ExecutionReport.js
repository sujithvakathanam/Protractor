import Message from '../fixparser/constant/Message';
import FixSecurityIDSource from '../fixparser/constant/SecurityIDSource';
import {generateClientOrderId} from './Util';

class ExecutionReport {
  MsgType = Message.ExecutionReport;

  ClOrdID = generateClientOrderId();

  CumQty = '';

  ExecID = '';

  ExecType = '';

  LeavesQty = '';

  MarketSegmentID = '';

  MatchIncrement = '';

  OrderID = '';

  OrderQty = '';

  OrdStatus = '';

  Price = '';

  SecurityID = '';

  SecurityIDSource = FixSecurityIDSource.ISIN;

  Side = '';

  Spread = '';

  Symbol = '';

  TradingSessionID = '';

  static build () {
    return new ExecutionReport();
  }

  withCumQty (CumQty) {
    this.CumQty = CumQty;

    return this;
  }

  withExecID (ExecID) {
    this.ExecID = ExecID;

    return this;
  }

  withExecType (ExecType) {
    this.ExecType = ExecType;

    return this;
  }

  withLeavesQty (LeavesQty) {
    this.LeavesQty = LeavesQty;

    return this;
  }

  withMatchIncrement (MatchIncrement) {
    this.MatchIncrement = MatchIncrement;

    return this;
  }

  withMarketSegmentID (MarketSegmentID) {
    this.MarketSegmentID = MarketSegmentID;

    return this;
  }

  withOrderID (OrderID) {
    this.OrderID = OrderID;

    return this;
  }

  withOrderQty (OrderQty) {
    this.OrderQty = OrderQty;

    return this;
  }

  withOrdStatus (OrdStatus) {
    this.OrdStatus = OrdStatus;

    return this;
  }

  withPrice (Price) {
    this.Price = Price;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withSecurityIDSource (SecurityIDSource) {
    this.SecurityIDSource = SecurityIDSource;

    return this;
  }

  withSide (Side) {
    this.Side = Side;

    return this;
  }

  withSpread (Spread) {
    this.Spread = Spread;

    return this;
  }

  withSymbol (Symbol) {
    this.Symbol = Symbol;

    return this;
  }

  withTradingSessionID (TradingSessionID) {
    this.TradingSessionID = TradingSessionID;

    return this;
  }

  withTradingSessionID2 (TradingSessionID2) {
    this.TradingSessionID2 = TradingSessionID2;

    return this;
  }
}

export default ExecutionReport;
