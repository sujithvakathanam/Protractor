class PositionQty {
  PosType = '';

  LongQty = '';

  ShortQty = '';

  PosQtyStatus = '';

  static build () {
    return new PositionQty();
  }

  withPosType (PosType) {
    this.PosType = PosType;

    return this;
  }

  withLongQty (LongQty) {
    this.LongQty = LongQty;

    return this;
  }

  withShortQty (ShortQty) {
    this.ShortQty = ShortQty;

    return this;
  }

  withPosQtyStatus (PosQtyStatus) {
    this.PosQtyStatus = PosQtyStatus;

    return this;
  }
}

export default PositionQty;
