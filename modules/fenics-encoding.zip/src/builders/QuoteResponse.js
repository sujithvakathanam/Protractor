import Message from '../fixparser/constant/Message';
import FixQuoteRespType from '../fixparser/constant/QuoteRespType';

class QuoteResponse {
  MsgType = Message.QuoteResponse;

  QuoteRespType = '';

  OrderQty = '';

  Price = '';

  QuoteID = '';

  constructor (tagPairs) {
    Object.entries(tagPairs).forEach(([key, value]) => {
      this[key] = value;
    });
  }

  static build (tagPairs = {}) {
    return new QuoteResponse(tagPairs);
  }

  withQuoteRespType (QuoteRespType) {
    this.QuoteRespType = QuoteRespType;

    return this;
  }

  withQuoteRespTypeCancel () {
    this.QuoteRespType = FixQuoteRespType.Pass;

    return this;
  }

  withQuoteRespTypeAccept () {
    this.QuoteRespType = FixQuoteRespType.HitLift;

    return this;
  }

  withQuoteRespTypeOwnPrice () {
    this.QuoteRespType = FixQuoteRespType.Counter;

    return this;
  }

  with

  withOrderQty (OrderQty) {
    this.OrderQty = OrderQty;

    return this;
  }

  withPrice (Price) {
    this.Price = Price;

    return this;
  }

  withQuoteID (QuoteID) {
    this.QuoteID = QuoteID;

    return this;
  }
}

export default QuoteResponse;
