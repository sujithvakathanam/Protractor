import Message from '../fixparser/constant/Message';
import OrdType from '../fixparser/constant/OrdType';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';
import {generateClientOrderId} from './Util';

class OrderCancelReplaceRequest {
  AggressorIndicator = '';

  MsgType = Message.OrderCancelReplaceRequest;

  ClOrdID = generateClientOrderId();

  OrdType = OrdType.Limit;

  SecurityIDSource = SecurityIDSource.ISIN;

  OrderID = '';

  OrderQty = '';

  Price = '';

  Side = '';

  SecurityID = '';

  TrdSessLstGrp = [];

  StrategyParameters = [];

  RoutingInst = '';

  OptAttribute = '';

  constructor (tagPairs) {
    Object.entries(tagPairs).forEach(([key, value]) => {
      this[key] = value;
    });
  }

  static build (tagPairs = {}) {
    return new OrderCancelReplaceRequest(tagPairs);
  }

  withOrderID (OrderID) {
    this.OrderID = OrderID;

    return this;
  }

  withOrderQty (OrderQty) {
    this.OrderQty = OrderQty;

    return this;
  }

  withPrice (Price) {
    this.Price = Price;

    return this;
  }

  withSide (Side) {
    this.Side = Side;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withTrdSessLstGrp (TrdSessLstGrp = []) {
    const repeatingGroups = Array.isArray(TrdSessLstGrp) ? TrdSessLstGrp : [TrdSessLstGrp];

    this.TrdSessLstGrp = [
      ...this.TrdSessLstGrp,
      ...repeatingGroups
    ];

    return this;
  }

  withStrategyParameters (StrategyParameters = [], overrideExistingValue) {
    const repeatingGroups = Array.isArray(StrategyParameters) ? StrategyParameters : [StrategyParameters];

    if (overrideExistingValue) {
      const concatenatedGroups = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];

      const reducedStrategies = concatenatedGroups.reduce((acc, strategy) => {
        const {StrategyParameterName} = strategy;

        acc[StrategyParameterName] = strategy;

        return acc;
      }, {});

      this.StrategyParameters = Object.values(reducedStrategies);
    } else {
      this.StrategyParameters = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];
    }

    return this;
  }

  withLitRoutingInst () {
    this.RoutingInst = 'B';

    return this;
  }

  withDarkRoutingInst () {
    this.RoutingInst = 'H';

    return this;
  }

  withOptAttribute (OptAttribute) {
    this.OptAttribute = OptAttribute;

    return this;
  }

  withRoutingInst (RoutingInst) {
    this.RoutingInst = RoutingInst;

    return this;
  }

  withAggressorIndicator (isAgressed) {
    this.AggressorIndicator = isAgressed ? 'Y' : 'N';

    return this;
  }
}

export default OrderCancelReplaceRequest;
