class StrategyParameter {
  StrategyParameterName = '';

  StrategyParameterValue = '';

  static build () {
    return new StrategyParameter();
  }

  withStrategyParameterName (StrategyParameterName) {
    this.StrategyParameterName = StrategyParameterName;

    return this;
  }

  withStrategyParameterValue (StrategyParameterValue) {
    this.StrategyParameterValue = StrategyParameterValue;

    return this;
  }
}

export default StrategyParameter;
