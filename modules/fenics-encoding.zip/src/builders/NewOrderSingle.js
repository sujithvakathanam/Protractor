import Message from '../fixparser/constant/Message';
import OrdType from '../fixparser/constant/OrdType';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';
import {generateClientOrderId} from './Util';

class NewOrderSingle {
  AggressorIndicator = '';

  MsgType = Message.NewOrderSingle;

  ClOrdID = generateClientOrderId();

  MatchIncrement = '';

  OrderQty = '';

  OrdType = OrdType.Limit;

  Price = '';

  SecurityID = '';

  SecurityIDSource = SecurityIDSource.ISIN;

  Side = '';

  Spread = '';

  Symbol = '';

  TrdSessLstGrp = [];

  StrategyParameters = [];

  RoutingInst = '';

  static build () {
    return new NewOrderSingle();
  }

  withMatchIncrement (MatchIncrement) {
    this.MatchIncrement = MatchIncrement;

    return this;
  }

  withOrderQty (OrderQty) {
    this.OrderQty = OrderQty;

    return this;
  }

  withPrice (Price) {
    this.Price = Price;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withSecurityIDSource (securityIDSource) {
    this.SecurityIDSource = securityIDSource;

    return this;
  }

  withSide (Side) {
    this.Side = Side;

    return this;
  }

  withSpread (Spread) {
    this.Spread = Spread;

    return this;
  }

  withTrdSessLstGrp (TrdSessLstGrp = []) {
    const repeatingGroups = Array.isArray(TrdSessLstGrp) ? TrdSessLstGrp : [TrdSessLstGrp];

    this.TrdSessLstGrp = [
      ...this.TrdSessLstGrp,
      ...repeatingGroups
    ];

    return this;
  }

  withStrategyParameters (StrategyParameters = [], overrideExistingValue) {
    const repeatingGroups = Array.isArray(StrategyParameters) ? StrategyParameters : [StrategyParameters];

    if (overrideExistingValue) {
      const concatenatedGroups = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];

      const reducedStrategies = concatenatedGroups.reduce((acc, strategy) => {
        const {StrategyParameterName} = strategy;

        acc[StrategyParameterName] = strategy;

        return acc;
      }, {});

      this.StrategyParameters = Object.values(reducedStrategies);
    } else {
      this.StrategyParameters = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];
    }

    return this;
  }

  withLitRoutingInst () {
    this.RoutingInst = 'B';

    return this;
  }

  withDarkRoutingInst () {
    this.RoutingInst = 'H';

    return this;
  }

  withAggressorIndicator (isAgressed) {
    this.AggressorIndicator = isAgressed ? 'Y' : 'N';

    return this;
  }

  withSymbol (symbol) {
    this.Symbol = symbol;

    return this;
  }
}

export default NewOrderSingle;
