import Message from '../fixparser/constant/Message';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';
import {generateClientOrderId} from './Util';

class OrderCancelRequest {
  MsgType = Message.OrderCancelRequest;

  ClOrdID = generateClientOrderId();

  SecurityIDSource = SecurityIDSource.ISIN;

  OrderID = '';

  OrderQty = '';

  OptAttribute = '';

  Side = '';

  OrigClOrdID = '';

  SecurityID = '';

  TrdSessLstGrp = [];

  RoutingInst = '';

  static build () {
    return new OrderCancelRequest();
  }

  withOrderID (OrderID) {
    this.OrderID = OrderID;
    this.OrigClOrdID = OrderID;

    return this;
  }

  withSide (Side) {
    this.Side = Side;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withTrdSessLstGrp (TrdSessLstGrp) {
    const asArray = Array.isArray(TrdSessLstGrp) ? TrdSessLstGrp : [TrdSessLstGrp];

    this.TrdSessLstGrp = [
      ...this.TrdSessLstGrp,
      ...asArray
    ];

    return this;
  }

  withOptAttribute (OptAttribute) {
    this.OptAttribute = OptAttribute;

    return this;
  }

  withRoutingInst (RoutingInst) {
    this.RoutingInst = RoutingInst;

    return this;
  }

  withLitRoutingInst () {
    this.RoutingInst = 'B';

    return this;
  }

  withDarkRoutingInst () {
    this.RoutingInst = 'H';

    return this;
  }

  withOrderQty (OrderQty) {
    this.OrderQty = OrderQty;

    return this;
  }
}

export default OrderCancelRequest;
