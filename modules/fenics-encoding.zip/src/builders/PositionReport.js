import Message from '../fixparser/constant/Message';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';

class PositionReport {
  MsgType = Message.PositionReport;

  MarketSegmentID = '';

  NoPositions = '0';

  PositionQty = [];

  RoutingInst = '';

  Symbol = '';

  SecurityID = '';

  SecurityIDSource = SecurityIDSource.ISIN;

  SettlPrice = '';

  StrategyParameters = [];

  Text = '';

  constructor (PositionQty = []) {
    const repeatingGroups = Array.isArray(PositionQty) ? PositionQty : [PositionQty];

    this.PositionQty = repeatingGroups;
    this.NoPositions = repeatingGroups.length.toString();
  }

  static build (options) {
    return new PositionReport(options);
  }

  withMarketSegmentID (MarketSegmentID) {
    this.MarketSegmentID = MarketSegmentID;

    return this;
  }

  withRoutingInst (RoutingInst) {
    this.RoutingInst = RoutingInst;

    return this;
  }

  withSymbol (Symbol) {
    this.Symbol = Symbol;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withSettlPrice (SettlPrice) {
    this.SettlPrice = SettlPrice;

    return this;
  }

  withText (Text) {
    this.Text = Text;

    return this;
  }

  withStrategyParameters (StrategyParameters = [], overrideExistingValue) {
    const repeatingGroups = Array.isArray(StrategyParameters) ? StrategyParameters : [StrategyParameters];

    if (overrideExistingValue) {
      const concatenatedGroups = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];

      const reducedStrategies = concatenatedGroups.reduce((acc, strategy) => {
        const {StrategyParameterName} = strategy;

        acc[StrategyParameterName] = strategy;

        return acc;
      }, {});

      this.StrategyParameters = Object.values(reducedStrategies);
    } else {
      this.StrategyParameters = [
        ...this.StrategyParameters,
        ...repeatingGroups
      ];
    }

    return this;
  }

  withPositionQty (PositionQty = []) {
    const repeatingGroups = Array.isArray(PositionQty) ? PositionQty : [PositionQty];

    this.PositionQty = [
      ...this.PositionQty,
      ...repeatingGroups
    ];

    this.NoPositions = this.PositionQty.length.toString();

    return this;
  }
}

export default PositionReport;
