import Message from '../fixparser/constant/Message';

class TradingSessionListUpdateReport {
  MsgType = Message.TradingSessionListUpdateReport;

  NoTradingSessions = '0';

  TrdSessLstGrp = [];

  constructor (TrdSessLstGrp = []) {
    const repeatingGroups = Array.isArray(TrdSessLstGrp) ? TrdSessLstGrp : [TrdSessLstGrp];

    this.NoTradingSessions = repeatingGroups.length.toString();
    this.TrdSessLstGrp = repeatingGroups;
  }

  static build (options) {
    return new TradingSessionListUpdateReport(options);
  }

  withTrdSessLstGrp (TrdSessLstGrp = []) {
    const repeatingGroups = Array.isArray(TrdSessLstGrp) ? TrdSessLstGrp : [TrdSessLstGrp];

    this.TrdSessLstGrp = [
      ...this.TrdSessLstGrp,
      ...repeatingGroups
    ];

    this.NoTradingSessions = this.TrdSessLstGrp.length.toString();

    return this;
  }
}

export default TradingSessionListUpdateReport;
