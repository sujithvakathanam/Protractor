class TargetParties {
  TargetPartyID = '';

  TargetPartyIDSource = '';

  TargetPartyRole = '';

  static build () {
    return new TargetParties();
  }

  withTargetPartyID (TargetPartyID) {
    this.TargetPartyID = TargetPartyID;

    return this;
  }

  withTargetPartyIDSource (TargetPartyIDSource) {
    this.TargetPartyIDSource = TargetPartyIDSource;

    return this;
  }

  withTargetPartyRole (TargetPartyRole) {
    this.TargetPartyRole = TargetPartyRole;

    return this;
  }
}

export default TargetParties;
