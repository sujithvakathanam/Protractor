class TrdSessLstGrp {
  TradingSessionID = '';

  TradSesStatus = '';

  TradSesOpenTime = '';

  TradSesEndTime = '';

  TradingSessionSubID = '';

  MarketSegmentID = '';

  TradingSessionDesc = '';

  TradingSessionID2 = '';

  static build () {
    return new TrdSessLstGrp();
  }

  withTradingSessionID (TradingSessionID) {
    this.TradingSessionID = TradingSessionID;

    return this;
  }

  withTradingSessionSubID (TradingSessionSubID) {
    this.TradingSessionSubID = TradingSessionSubID;

    return this;
  }

  withMarketSegmentID (MarketSegmentID) {
    this.MarketSegmentID = MarketSegmentID;

    return this;
  }

  withTradingSessionDesc (TradingSessionDesc) {
    this.TradingSessionDesc = TradingSessionDesc;

    return this;
  }

  withTradSesStatus (TradSesStatus) {
    this.TradSesStatus = TradSesStatus;

    return this;
  }

  withTradingSessionID2 (TradingSessionID2) {
    this.TradingSessionID2 = TradingSessionID2;

    return this;
  }

  withTradSesOpenTime (TradSesOpenTime) {
    this.TradSesOpenTime = TradSesOpenTime;

    return this;
  }

  withTradSesEndTime (TradSesEndTime) {
    this.TradSesEndTime = TradSesEndTime;

    return this;
  }
}

export default TrdSessLstGrp;
