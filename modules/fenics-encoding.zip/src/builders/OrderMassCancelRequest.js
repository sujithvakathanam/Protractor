import Message from '../fixparser/constant/Message';
import {generateClientOrderId} from './Util';

class OrderMassCancelRequest {
  MsgType = Message.OrderMassCancelRequest;

  ClOrdID = generateClientOrderId();

  MassCancelRequestType = '';

  TargetParties = [];

  static build () {
    return new OrderMassCancelRequest();
  }

  withMassCancelRequestType (MassCancelRequestType) {
    this.MassCancelRequestType = MassCancelRequestType;

    return this;
  }

  withTargetParties (TargetParties) {
    const asArray = Array.isArray(TargetParties) ? TargetParties : [TargetParties];

    this.TargetParties = [
      ...this.TargetParties,
      ...asArray
    ];

    return this;
  }
}

export default OrderMassCancelRequest;
