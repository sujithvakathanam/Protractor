import Message from '../fixparser/constant/Message';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';
import {generateClientOrderId} from './Util';

class IOI {
  MsgType = Message.IOI;

  IOIID = generateClientOrderId();

  IOITransType = 'N';

  SecurityID = '';

  SecurityIDSource = SecurityIDSource.ISIN;

  static build () {
    return new IOI();
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }
}

export default IOI;
