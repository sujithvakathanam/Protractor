import Message from '../fixparser/constant/Message';
import SecurityIDSource from '../fixparser/constant/SecurityIDSource';

class TradeCaptureReport {
  MsgType = Message.TradeCaptureReport;

  MarketSegmentID = '';

  MatchType = '';

  NoSides = '';

  OrderID = '';

  Side = '';

  LastPx = '';

  LastQty = '';

  SecurityIDSource = SecurityIDSource.ISIN;

  SecurityID = '';

  Symbol = '';

  TradeID = '';

  TradingSessionID = '';

  TradingSessionSubID = '';

  TransactTime = '';

  static build () {
    return new TradeCaptureReport();
  }

  withMarketSegmentID (MarketSegmentID) {
    this.MarketSegmentID = MarketSegmentID;

    return this;
  }

  withMatchType (MatchType) {
    this.MatchType = MatchType;

    return this;
  }

  withNoSides (NoSides) {
    this.NoSides = NoSides;

    return this;
  }

  withOrderID (OrderID) {
    this.OrderID = OrderID;

    return this;
  }

  withSide (Side) {
    this.Side = Side;

    return this;
  }

  withLastPx (LastPx) {
    this.LastPx = LastPx;

    return this;
  }

  withLastQty (LastQty) {
    this.LastQty = LastQty;

    return this;
  }

  withSecurityID (SecurityID) {
    this.SecurityID = SecurityID;

    return this;
  }

  withSymbol (Symbol) {
    this.Symbol = Symbol;

    return this;
  }

  withTradeID (TradeID) {
    this.TradeID = TradeID;

    return this;
  }

  withTradingSessionID (TradingSessionID) {
    this.TradingSessionID = TradingSessionID;

    return this;
  }

  withTradingSessionSubID (TradingSessionSubID) {
    this.TradingSessionSubID = TradingSessionSubID;

    return this;
  }

  withTransactTime (TransactTime) {
    this.TransactTime = TransactTime;

    return this;
  }
}

export default TradeCaptureReport;
