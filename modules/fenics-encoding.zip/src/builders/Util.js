const BASE = 16;

const generateClientOrderId = () => Math.random()
  .toString(BASE)
  .substring(2);

export {
  generateClientOrderId
};
