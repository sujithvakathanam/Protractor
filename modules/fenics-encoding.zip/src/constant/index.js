import {
  AggressorIndicator,
  BusinessRejectReason,
  EncryptMethod,
  ExecutionType,
  ExecInst,
  Field,
  HandlInst,
  MarketDepth,
  MassCancelRequestType,
  MassCancelRejectReason,
  MassCancelResponse,
  MDEntryType,
  Message,
  OrdRejReason,
  OrdStatus,
  OrdType,
  PosQtyStatus,
  PosReqType,
  QuoteRespType,
  QuoteStatus,
  RoutingInst,
  SecurityIDSource,
  Side,
  SubscriptionRequestType,
  TimeInForce
} from '../fixparser';

const Constants = {
  AggressorIndicator,
  BusinessRejectReason,
  EncryptMethod,
  ExecutionType,
  ExecInst,
  Field,
  HandlInst,
  MarketDepth,
  MDEntryType,
  MassCancelRequestType,
  MassCancelRejectReason,
  MassCancelResponse,
  Message,
  OrdRejReason,
  OrdStatus,
  OrdType,
  PosQtyStatus,
  PosReqType,
  QuoteRespType,
  QuoteStatus,
  RoutingInst,
  SecurityIDSource,
  Side,
  SubscriptionRequestType,
  TimeInForce
};

const FixGroups = {
  AffectedOrdGrp : {
    lengthTag : 'NoAffectedOrders',
    firstTag  : 'AffectedOrderID',
    validTags : [
      'AffectedOrderID',
      'AffectedSecondaryOrderID',
      'OrigClOrdID'
    ]
  },
  NotAffectedOrdersGrp : {
    lengthTag : 'NoNotAffectedOrders',
    firstTag  : 'NotAffectedOrderID',
    validTags : [
      'NotAffectedOrderID',
      'NotAffOrigClOrdID'
    ]
  },
  EvntGrp : {
    lengthTag : 'NoEvents',
    firstTag  : 'EventType',
    validTags : [
      'EventType',
      'EventDate',
      'EventPx',
      'EventText',
      'EventTime'
    ]
  },
  MDReqGrp : {
    lengthTag : 'NoMDEntryTypes',
    firstTag  : 'MDEntryType'
  },
  TrdSessLstGrp : {
    lengthTag : 'NoTradingSessions',
    firstTag  : 'TradingSessionID',
    validTags : [
      'BenchmarkSecurityDesc',
      'CreditRating',
      'Currency',
      'NoExecInstRules',
      'ExecInstValue',
      'MarketSegmentID',
      'MatchIncrement',
      'SecurityID',
      'SecurityIDSource',
      'Spread',
      'Symbol',
      'SecurityDesc',
      'Text',
      'TradingSessionID',
      'TradingSessionSubID',
      'TradingSessionDesc',
      'TradSesStatus',
      'TradSesOpenTime',
      'TradSesEndTime',
      'TradSesUpdateAction',
      'UnsolicitedIndicator',
      '5019',
      'LocationID'
    ]
  },
  PositionQty : {
    lengthTag : 'NoPositions',
    firstTag  : 'PosType',
    validTags : [
      'PosType',
      'LongQty',
      'ShortQty',
      'PosQtyStatus',
      'NestedParties',
      'QuantityDate'
    ]
  },
  NestedParties : {
    lengthTag : 'NoNestedPartyIDs',
    firstTag  : 'NestedPartyID',
    validTags : [
      'NestedPartyID',
      'NestedPartyIDSource',
      'NestedPartyRole',
      'NstdPtysSubGrp'
    ]
  },
  NstdPtysSubGrp : {
    lengthTag : 'NoNestedPartySubIDs',
    firstTag  : 'NestedPartySubID',
    validTags : [
      'NestedPartySubID',
      'NestedPartySubIDType'
    ]
  },
  LinesOfTextGrp : {
    lengthTag : 'NoLinesOfText',
    firstTag  : 'Text',
    validTags : [
      'Text',
      'EncodedTextLen',
      'EncodedText'
    ]
  },
  StrategyParameters : {
    lengthTag : 'NoStrategyParameters',
    firstTag  : 'StrategyParameterName',
    validTags : [
      'StrategyParameterName',
      'StrategyParameterValue'
    ]
  },
  TargetParties : {
    lengthTag : 'NoTargetPartyIDs',
    firstTag  : 'TargetPartyID',
    validTags : [
      'TargetPartyID',
      'TargetPartyIDSource',
      'TargetPartyRole'
    ]
  },
  UnderlyingInstrumentGrp : {
    lengthTag : 'NoUnderlyings',
    firstTag  : 'UnderlyingSecurityID',
    validTags : [
      'UnderlyingSecurityID',
      'UnderlyingOptAttribute',
      'UnderlyingFactor'
    ]
  }
};

export {
  Constants,
  FixGroups
};
