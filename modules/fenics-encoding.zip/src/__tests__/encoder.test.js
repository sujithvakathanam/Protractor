import {expect} from 'chai';

import Fix from '..';

/* eslint-disable max-statements, no-magic-numbers */
describe('FIX encoder', () => {
  beforeEach(() => {
    Fix.clearCommonTags();
    Fix.resetEncoderSequenceNumber();
  });

  it('should successfully encode a simple message', () => {
    const newOrderSingle = {
      MsgType      : Fix.Message.NewOrderSingle,
      SenderCompID : 'SENDER',
      TargetCompID : 'TARGET',
      ClOrdID      : '11223344',
      OrderQty     : '123',
      OrdType      : Fix.OrdType.Market,
      Side         : Fix.Side.Buy,
      Symbol       : '123.HK'
    };

    const encoded = Fix.encode(newOrderSingle);

    const parts = encoded.split('\u0001');
    expect(parts).to.have.length(14);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=94');
    expect(parts[2]).to.equal('35=D');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('49=SENDER');
    expect(parts[6]).to.equal('56=TARGET');
    expect(parts[7]).to.equal('11=11223344');
    expect(parts[8]).to.equal('38=123');
    expect(parts[9]).to.equal('40=1');
    expect(parts[10]).to.equal('54=1');
    expect(parts[11]).to.equal('55=123.HK');
  });

  it('should successfully encode a simple message using common tags', () => {
    const newOrderSingle = {
      MsgType  : Fix.Message.NewOrderSingle,
      ClOrdID  : '11223344',
      OrderQty : '123',
      OrdType  : Fix.OrdType.Market,
      Side     : Fix.Side.Buy,
      Symbol   : '123.HK'
    };

    Fix.setCommonTags({
      Account      : 'ACCOUNT',
      SenderCompID : 'SENDER',
      TargetCompID : 'TARGET'
    });

    const encoded = Fix.encode(newOrderSingle);

    const parts = encoded.split('\u0001');
    expect(parts).to.have.length(15);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=104');
    expect(parts[2]).to.equal('35=D');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('1=ACCOUNT');
    expect(parts[6]).to.equal('49=SENDER');
    expect(parts[7]).to.equal('56=TARGET');
    expect(parts[8]).to.equal('11=11223344');
    expect(parts[9]).to.equal('38=123');
    expect(parts[10]).to.equal('40=1');
    expect(parts[11]).to.equal('54=1');
    expect(parts[12]).to.equal('55=123.HK');
  });

  it('should successfully clear common tags', () => {
    const newOrderSingle = {
      MsgType  : Fix.Message.NewOrderSingle,
      ClOrdID  : '11223344',
      OrderQty : '123',
      OrdType  : Fix.OrdType.Market,
      Side     : Fix.Side.Buy,
      Symbol   : '123.HK'
    };

    Fix.setCommonTags({
      Account      : 'ACCOUNT',
      SenderCompID : 'SENDER',
      TargetCompID : 'TARGET'
    });

    Fix.clearCommonTags();

    const encoded = Fix.encode(newOrderSingle);

    const parts = encoded.split('\u0001');
    expect(parts).to.have.length(12);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=74');
    expect(parts[2]).to.equal('35=D');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('11=11223344');
    expect(parts[6]).to.equal('38=123');
    expect(parts[7]).to.equal('40=1');
    expect(parts[8]).to.equal('54=1');
    expect(parts[9]).to.equal('55=123.HK');
  });

  it('should successfully encode a message with custom tags', () => {
    const marketDefinitionRequest = {
      MsgType         : Fix.Message.MarketDefinitionRequest,
      SenderCompID    : 'SENDER',
      TargetCompID    : 'TARGET',
      TradSesOpenTime : '20180628-08:10:47.220',
      SecurityGroup   : 'Financial',
      PricingDuration : '10',
      PrivateDuration : '10',
      GroupDuration   : '10',
      Spread          : '1000',
      MinQty          : '500',
      MatchIncrement  : '100'
    };

    Fix.setDictionary({
      10042 : 'PricingDuration',
      10043 : 'PrivateDuration',
      10044 : 'GroupDuration'
    });

    const encoded = Fix.encode(marketDefinitionRequest);
    const parts = encoded.split('\u0001');

    expect(parts).to.have.length(17);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=150');
    expect(parts[2]).to.equal('35=BT');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('49=SENDER');
    expect(parts[6]).to.equal('56=TARGET');
    expect(parts[7]).to.equal('342=20180628-08:10:47.220');
    expect(parts[8]).to.equal('1151=Financial');
    expect(parts[9]).to.equal('10042=10');
    expect(parts[10]).to.equal('10043=10');
    expect(parts[11]).to.equal('10044=10');
    expect(parts[12]).to.equal('218=1000');
    expect(parts[13]).to.equal('110=500');
    expect(parts[14]).to.equal('1089=100');
  });

  it('should successfully encode a message with a repeating group', () => {
    const marketDataRequest = {
      MsgType                 : Fix.Message.MarketDataRequest,
      SenderCompID            : 'SENDER',
      TargetCompID            : 'TARGET',
      MDReqID                 : '11223344',
      SubscriptionRequestType : '0',
      MarketDepth             : '0',
      MDReqGrp                : [
        {MDEntryType : '0'},
        {MDEntryType : '1'},
        {MDEntryType : '4'},
        {MDEntryType : '5'},
        {MDEntryType : 'H'}
      ]
    };

    const encoded = Fix.encode(marketDataRequest);

    const parts = encoded.split('\u0001');
    expect(parts).to.have.length(18);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=116');
    expect(parts[2]).to.equal('35=V');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('49=SENDER');
    expect(parts[6]).to.equal('56=TARGET');
    expect(parts[7]).to.equal('262=11223344');
    expect(parts[8]).to.equal('263=0');
    expect(parts[9]).to.equal('264=0');
    expect(parts[10]).to.equal('267=5');
    expect(parts[11]).to.equal('269=0');
    expect(parts[12]).to.equal('269=1');
    expect(parts[13]).to.equal('269=4');
    expect(parts[14]).to.equal('269=5');
    expect(parts[15]).to.equal('269=H');
  });

  it('should successfully encode a message with a repeating group', () => {
    const cancelOrderRequest = {
      MsgType       : Fix.Message.OrderCancelRequest,
      SenderCompID  : 'SENDER',
      TargetCompID  : 'TARGET',
      MDReqID       : '11223344',
      OrderID       : 'ORDERID1',
      OrigClOrdID   : 'ORDERID1',
      Side          : '1',
      TrdSessLstGrp : [{
        TradingSessionID    : '1234-5678',
        TradingSessionSubID : 'ISIN1'
      }, {
        TradingSessionID    : '9101-1121',
        TradingSessionSubID : 'ISIN2'
      }]
    };

    const encoded = Fix.encode(cancelOrderRequest);

    const parts = encoded.split('\u0001');
    expect(parts).to.have.length(18);

    expect(parts[0]).to.equal('8=FIXT.1.1');
    expect(parts[1]).to.equal('9=151');
    expect(parts[2]).to.equal('35=F');
    expect(parts[3]).to.equal('34=1');

    expect(parts[5]).to.equal('49=SENDER');
    expect(parts[6]).to.equal('56=TARGET');
    expect(parts[7]).to.equal('262=11223344');
    expect(parts[8]).to.equal(`37=${cancelOrderRequest.OrderID}`);
    expect(parts[9]).to.equal(`41=${cancelOrderRequest.OrigClOrdID}`);
    expect(parts[10]).to.equal('54=1');
    expect(parts[11]).to.equal('386=2');
    expect(parts[12]).to.equal('336=1234-5678');
    expect(parts[13]).to.equal('625=ISIN1');
    expect(parts[14]).to.equal('336=9101-1121');
    expect(parts[15]).to.equal('625=ISIN2');
  });
});
