/* eslint-disable max-len, max-lines, max-statements, no-magic-numbers */

import {expect} from 'chai';

import Fix from '..';

describe('FIX decoder', () => {
  beforeEach(() => {
    Fix.clearCommonTags();
  });

  it('should successfully decode a simple message', () => {
    let message = '8=FIXT.1.1\u00019=94\u000135=D\u000134=1\u000152=20180625-10:47:33.551\u0001';
    message += '49=SENDER\u000156=TARGET\u000111=11223344\u000138=123\u000140=1\u000154=1\u0001';
    message += '55=123.HK\u000110=229\u0001';

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '94');
    expect(decoded).to.have.property('MsgType', 'D');
    expect(decoded).to.have.property('MsgSeqNum', '1');
    expect(decoded).to.have.property('SendingTime');
    expect(decoded).to.have.property('SenderCompID', 'SENDER');
    expect(decoded).to.have.property('TargetCompID', 'TARGET');
    expect(decoded).to.have.property('ClOrdID', '11223344');
    expect(decoded).to.have.property('OrderQty', '123');
    expect(decoded).to.have.property('OrdType', '1');
    expect(decoded).to.have.property('Side', '1');
    expect(decoded).to.have.property('Symbol', '123.HK');
    expect(decoded).to.have.property('CheckSum');
  });

  it('should successfully decode a message with a repeating group', () => {
    let message = '8=FIXT.1.1\u00019=184\u000135=BS\u0001386=2\u0001';

    message += '336=s\u0001340=3\u00015019=0\u0001342=20180621-14:13:33.500\u0001';
    message += '345=20180621-14:14:03.500\u00011300=Financial\u0001';

    message += '336=s\u0001340=2\u00015019=1\u0001342=20180621-14:14:03.500\u0001';
    message += '345=20180621-14:14:33.500\u00011300=Financial\u000110=252\u0001';

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '184');
    expect(decoded).to.have.property('MsgType', 'BS');
    expect(decoded).to.have.property('TrdSessLstGrp');

    expect(decoded.TrdSessLstGrp).to.be.an('array').of.length(2);

    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradingSessionID', 's');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesStatus', '3');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesOpenTime', '20180621-14:13:33.500');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesEndTime', '20180621-14:14:03.500');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('5019', '0');

    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradingSessionID', 's');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradSesStatus', '2');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradSesOpenTime', '20180621-14:14:03.500');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradSesEndTime', '20180621-14:14:33.500');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('5019', '1');
  });

  it('should successfully decode a message with a repeating group with 0 elements', () => {
    const message = '8=FIXT.1.1\u00019=23\u000135=BJ\u0001335=ts-id1\u0001386=0\u000110=119\u0001';

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '23');
    expect(decoded).to.have.property('MsgType', 'BJ');
    expect(decoded).to.have.property('TrdSessLstGrp');

    expect(decoded.TrdSessLstGrp).to.be.an('array').of.length(0);
  });

  it('should successfully decode a message with custom tags', () => {
    const message = '8=FIXT.1.1\u00019=198\u000135=BT\u000134=4\u000152=20180702-07:26:24.220\u000110042=10\u000110043=10\u000110044=10\u00011=00u1qftdc10hC7a1J0i7\u000149=Fenics\u000150=00u1qftdc10hC7a1J0i7\u000156=BGC\u000157=\u0001342=20180702-07:26:33.339\u00011151=Financial\u0001218=1000\u0001110=500\u00011089=100\u000110=174\u0001'; // eslint-disable-line

    Fix.setDictionary({
      10042 : 'SessionPricingDuration',
      10043 : 'SessionPrivateDuration',
      10044 : 'SessionGroupDuration'
    });

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '198');
    expect(decoded).to.have.property('MsgType', 'BT');

    expect(decoded).to.have.property('SessionPricingDuration', '10');
    expect(decoded).to.have.property('SessionPrivateDuration', '10');
    expect(decoded).to.have.property('SessionGroupDuration', '10');
    expect(decoded).to.have.property('TradSesOpenTime', '20180702-07:26:33.339');
    expect(decoded).to.have.property('Spread', '1000');
    expect(decoded).to.have.property('MinQty', '500');
    expect(decoded).to.have.property('MatchIncrement', '100');
    expect(decoded).to.have.property('SecurityGroup', 'Financial');
  });

  it('should successfully decode a message with custom tags inside repeating groups', () => {
    const message = '8=FIXT.1.1\u00019=98\u000134=\u000135=BS\u0001386=1\u0001336=s\u0001340=3\u00015019=2\u0001342=20180702-07:12:47.283\u0001345=20180702-07:12:57.283\u00011300=Financial\u000110=126\u0001'; // eslint-disable-line

    Fix.setDictionary({
      5019 : 'TradingSessionID2'
    });

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '98');
    expect(decoded).to.have.property('MsgType', 'BS');
    expect(decoded).to.have.property('TrdSessLstGrp');

    expect(decoded.TrdSessLstGrp).to.be.an('array').of.length(1);

    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradingSessionID', 's');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesStatus', '3');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesOpenTime', '20180702-07:12:47.283');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesEndTime', '20180702-07:12:57.283');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradingSessionID2', '2');
  });

  it('should successfully decode multiple messages in the same string', () => {
    let message = '8=FIXT.1.1\u00019=324\u000134=\u000135=AP\u000152=20180704-10:53:16.900\u0001';
    message += '49=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u1qftdc10hC7a1J0i7\u0001';
    message += '724=0\u0001721=1076a0aa-4b30-41b1-9f4e-f5862f7fe49f\u0001715=20180704-10:53:16.900\u0001';
    message += '48=US38148R6E89\u000122=4\u000155=GS 0 02/11/25\u00011300=Financial\u0001';
    message += '58=6dd5b5fa-ff69-474a-b0b2-e62e8006e611\u0001730=97.075\u0001702=1\u0001703=TOT\u0001';
    message += '705=1000\u0001706=0\u000160=20180704-10:53:16.900\u000110=197\u0001';

    message += '8=FIXT.1.1\u00019=328\u000134=\u000135=AP\u000152=20180704-10:53:16.904\u0001';
    message += '49=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u1qftdc10hC7a1J0i7\u0001';
    message += '724=0\u0001721=05cecf2d-29a2-460f-b392-1b153f2eb5e6\u0001715=20180704-10:53:16.904\u0001';
    message += '48=US38148JTJ06\u000122=4\u000155=GS 1.95 05/13/20\u00011300=Financial\u0001';
    message += '58=ca1547b4-e3c0-4e4f-ae71-9ffc3600874e\u0001730=750.015\u0001702=1\u0001703=TOT\u0001';
    message += '705=1000\u0001706=0\u000160=20180704-10:53:16.904\u000110=206\u0001';

    message += '8=FIXT.1.1\u00019=325\u000134=\u000135=AP\u000152=20180704-10:53:16.907\u0001';
    message += '49=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u1qftdc10hC7a1J0i7\u0001';
    message += '724=0\u0001721=18bc45cf-49f3-4b83-9b49-3e510b1c08f1\u0001715=20180704-10:53:16.907\u0001';
    message += '48=US38143ATX36\u000122=4\u000155=GS 0 07/01/19\u00011300=Financial\u0001';
    message += '58=bcb5ef54-da2b-4afd-93f2-dce045b31bac\u0001730=224.288\u0001702=1\u0001703=TOT\u0001';
    message += '704=1000\u0001706=0\u000160=20180704-10:53:16.907\u000110=002\u0001';

    message += '8=FIXT.1.1\u00019=328\u000134=\u000135=AP\u000152=20180704-10:53:16.909\u0001';
    message += '49=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u1qftdc10hC7a1J0i7\u0001';
    message += '724=0\u0001721=30540825-12cd-44f9-8b37-c21ca71b7cb3\u0001715=20180704-10:53:16.909\u0001';
    message += '48=US38143ARJ69\u000122=4\u000155=GS 2 1/4 05/02/19\u00011300=Financial\u0001';
    message += '58=55bc7553-4d64-49a5-a6b4-ec98f9461a44\u0001730=76.265\u0001702=1\u0001703=TOT\u0001';
    message += '704=1000\u0001706=0\u000160=20180704-10:53:16.909\u000110=187\u0001';

    const decoded = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.lengthOf(4);
  });

  it('should successfully decode a message with repeating group', () => {
    const message = '8=FIXT.1.1\u00019=404\u000134=\u000135=AP\u000152=20181005-08:30:15.505\u000149=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u202f0vwPm9wKm00i7\u0001724=0\u0001721=cb1546b5-20c8-4d7a-b1b6-962465897410\u0001715=20181005-08:30:15.505\u000148=US478375AQ13\u000122=4\u000155=JCI 4 5/8 01/15/23\u00011300=Industrial\u000158=28b90987-5cfc-47f5-abd4-55253c318eaa\u00019303=B\u0001957=2\u0001958=includeInCleanUp\u0001960=true\u0001958=includeInPublic\u0001960=false\u0001730=99.0\u0001702=1\u0001703=TOT\u0001704=1000000\u0001706=0\u000160=20181005-08:30:15.505\u000110=124\u0001'; // eslint-disable-line

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('StrategyParameters');
    expect(decoded.StrategyParameters).to.have.lengthOf(2);
    expect(decoded.StrategyParameters[0]).to.have.property('StrategyParameterName');
    expect(decoded.StrategyParameters[0]).to.have.property('StrategyParameterValue');

    expect(decoded).to.have.property('SettlPrice');
  });

  it('should successfully decode two consecutive groups', () => {
    const message = '8=FIXT.1.1\u00019=404\u000134=\u000135=AP\u000152=20181005-08:30:15.505\u000149=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u202f0vwPm9wKm00i7\u0001724=0\u0001721=cb1546b5-20c8-4d7a-b1b6-962465897410\u0001715=20181005-08:30:15.505\u000148=US478375AQ13\u000122=4\u000155=JCI 4 5/8 01/15/23\u00011300=Industrial\u000158=28b90987-5cfc-47f5-abd4-55253c318eaa\u00019303=B\u0001957=2\u0001958=includeInCleanUp\u0001960=true\u0001958=includeInPublic\u0001960=false\u0001702=1\u0001703=TOT\u0001704=1000000\u0001706=0\u0001730=99.0\u000160=20181005-08:30:15.505\u000110=124\u0001'; // eslint-disable-line

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('StrategyParameters');
    expect(decoded).to.have.property('PositionQty');
    expect(decoded).to.have.property('SettlPrice');
  });

  it('should no longer include the custom tag if defined in dictionary', () => {
    const message = '8=FIXT.1.1\u00019=361\u000134=1\u000135=AP\u000152=20181025-08:44:55.539\u000149=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u1qftdc10hC7a1J0i7\u0001721=f4e1183d-28ba-46e4-9e55-cf3beea906ee\u0001710=23da99ddd5362\u00011=00u1qftdc10hC7a1J0i7\u000148=US35906AAM09\u000122=4\u0001730=103.0\u000110051=AAABZqoXZTTsc3n5\u000110052=15ea94cc-0042-4628-9e0e-804f564bf4b1\u0001864=1\u0001865=99\u00011145=1540451951922\u0001107=FTR 7 1/8 01/15/23\u000110053=3\u0001702=1\u0001703=TOT\u0001704=1500000\u000110=122'; // eslint-disable-line
    const TAGS_REMOVED = [10051, 10052, 10053];

    let [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    TAGS_REMOVED.forEach(tag => {
      expect(decoded).to.have.property(tag);
    });

    Fix.setDictionary({
      10051 : 'PositionRptTradeID',
      10052 : 'PositionRptOrderID',
      10053 : 'PositionRptMatchType'
    });

    [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    TAGS_REMOVED.forEach(tag => {
      expect(decoded).not.to.have.property(tag);
    });
  });

  it('should throw in case of invalid fix message - invalid NoPositions', () => {
    const message = '8=FIXT.1.1\u00019=404\u000134=\u000135=AP\u000152=20181005-08:30:15.505\u000149=FENICS_CREDIT\u000150=TEST\u000156=hardcoded\u000157=00u202f0vwPm9wKm00i7\u0001724=0\u0001721=cb1546b5-20c8-4d7a-b1b6-962465897410\u0001715=20181005-08:30:15.505\u000148=US478375AQ13\u000122=4\u000155=JCI 4 5/8 01/15/23\u00011300=Industrial\u000158=28b90987-5cfc-47f5-abd4-55253c318eaa\u00019303=B\u0001957=2\u0001958=includeInCleanUp\u0001960=true\u0001958=includeInPublic\u0001960=false\u0001730=99.0\u0001702=2\u0001703=TOT\u0001704=1000000\u0001706=0\u000160=20181005-08:30:15.505\u000110=124\u0001'; // eslint-disable-line

    const decodeFn = () => Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decodeFn).to.throw();
  });

  it('should successfully decode a message having nested repeating groups', () => {
    const message = '8=FIXT.1.1\u00019=357\u000134=1\u000135=BJ\u000152=20190212-11:13:12.909\u000149=FENICS_CREDIT\u000150=TEST\u000156=773\u000157=00u21jjzf0cGs2kE60i7\u0001335=ts-id1\u0001386=2\u0001336=83a43d71-0b83-4e6a-a215-d71c661761a6\u0001340=2\u00015019=0\u0001342=20190212-11:13:11.879\u0001345=20190212-11:14:11.879\u00011326=p\u00011300=Financial\u00011327=G\u000158=500000\u0001255=HY\u00011232=1\u00011308=15\u0001336=83a43d71-0b83-4e6a-a215-d71c661761a6\u0001625=US489399AG06\u0001107=KW\u00015\u00017/8\u000104/01/24\u0001340=2\u000110=199\u0001';

    const [decoded] = Fix.decode(message, {
      validateBodyLength : false,
      validateChecksum   : false
    });

    expect(decoded).to.have.property('BeginString', 'FIXT.1.1');
    expect(decoded).to.have.property('BodyLength', '357');
    expect(decoded).to.have.property('MsgType', 'BJ');
    expect(decoded).to.have.property('TrdSessLstGrp');
    expect(decoded).to.have.property('TradSesStatus', '2');

    expect(decoded.TrdSessLstGrp).to.be.an('array').of.length(2);
    expect(decoded.TrdSessLstGrp[0]).to.be.an('object');
    expect(decoded.TrdSessLstGrp[1]).to.be.an('object');

    expect(decoded.TrdSessLstGrp[0]).to.have.property('5019', '0');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradingSessionID', '83a43d71-0b83-4e6a-a215-d71c661761a6');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesStatus', '2');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesOpenTime', '20190212-11:13:11.879');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesEndTime', '20190212-11:14:11.879');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradingSessionDesc', 'p');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('MarketSegmentID', 'Financial');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('TradSesUpdateAction', 'G');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('Text', '500000');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('CreditRating', 'HY');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('NoExecInstRules', '1');
    expect(decoded.TrdSessLstGrp[0]).to.have.property('ExecInstValue', '15');

    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradingSessionID', '83a43d71-0b83-4e6a-a215-d71c661761a6');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('TradingSessionSubID', 'US489399AG06');
    expect(decoded.TrdSessLstGrp[1]).to.have.property('SecurityDesc', 'KW');
  });
});
