import {Constants} from './constant';
import encodeUsingDictionary, {resetSeqNum} from './encoder';
import decodeUsingDictionary from './decoder';
import * as builders from './builders';

let dictionary = {};
let commonTags = {};

const DEFAULT_OPTIONS = {
  beginString        : 'FIXT.1.1',
  separator          : '\u0001',
  validateBodyLength : true,
  validateChecksum   : true,
  asObject           : true,
  verbose            : false
};

const fenicsEncoding = {
  ...Constants,
  builders,
  setDictionary : dict => {
    dictionary = dict;
  },
  setCommonTags : tags => {
    commonTags = tags;
  },
  clearCommonTags : () => {
    commonTags = {};
  },
  encode : (obj, options = {}) => encodeUsingDictionary(obj, {
    ...DEFAULT_OPTIONS,
    ...options,
    dictionary,
    commonTags
  }),
  decode : (obj, options = {}) => decodeUsingDictionary(obj, {
    ...DEFAULT_OPTIONS,
    ...options,
    dictionary
  }),
  resetEncoderSequenceNumber : resetSeqNum
};

export default fenicsEncoding;
