# fenics-encoding

> JavaScript library for working with FIX protocol messages. Compliant with FIX 5.0 SP2

## Table of Contents

* [Introduction](#introduction)
* [Installation](#installation)
* [Usage](#usage)
* [Api](#api)

## Introduction

This library provides functions for encoding and decoding message payloads. The current underlying serialisation format is based on [FIX 5.0 SP2](https://legacy.fixspec.com//FIX/5.0-SP2). The primary use case is to use it with [`fenics-transport`](https://github.fenicsone.com/fenics/fenics-transport) for client-server communication. The library will encode/decode the messages and it will validate that the message has the correct fields to be a valid FIX message.

## Installation

```sh
npm i --save @fenics/fenics-encoding
```

## Usage

```javascript
import Fix from '@fenics/fenics-encoding';

const userId = '01234567890asdasd';

Fix.setCommonTags({
  Account      : userId,
  SenderCompID : 'Fenics',
  SenderSubID  : userId,
  TargetCompID : 'BGC',
  TargetSubID  : ''
});

// New order single request
const payload = {
  MsgType          : 'D',
  SecurityID       : 'XISIN1',
  Price            : '100',
  OrderQty         : '1000000',
  Side             : '1',
  ClOrdID          : Math.random().toString(16).substring(2, 9),
  SecurityIDSource : '4',
  OrdType          : '2'
};

const encoded = Fix.encode(payload);

// 8=FIXT.1.1\u00019=151\u000135=D\u000134=1\u000152=20180628-14:33:20.324\u00011=01234567890asdasd\u000149=Fenics\u000150=01234567890asdasd\u000156=BGC\u000157=\u000148=XISIN1\u000144=100\u000138=1000000\u000154=1\u000111=b089283\u000122=4\u000140=2\u000110=249\u0001
console.log(encoded);

const [decoded] = Fix.decode(encoded);

/**
 * {
 *   BeginString      : 'FIXT.1.1',
 *   BodyLength       : '151',
 *   MsgType          : 'D',
 *   MsgSeqNum        : '1',
 *   SendingTime      : '20180628-14:35:43.112',
 *   Account          : '01234567890asdasd',
 *   SenderCompID     : 'Fenics',
 *   SenderSubID      : '01234567890asdasd',
 *   TargetCompID     : 'BGC',
 *   TargetSubID      : '',
 *   SecurityID       : 'XISIN1',
 *   Price            : '100',
 *   OrderQty         : '1000000',
 *   Side             : '1',
 *   ClOrdID          : 'fb7affe',
 *   SecurityIDSource : '4',
 *   OrdType          : '2',
 *   CheckSum         : '236'
 * }
 */
console.log(decoded);
```

## API

* [`setDictionary`](#api--set-dictionary)
* [`setCommonTags`](#api--set-common-tags)
* [`clearCommonTags`](#api--clear-common-tags)
* [`encode`](#api--encode)
* [`decode`](#api--decode)

All the methods are static, `commonTags` and `dictionary` are global to the `@fenics/fenics-encoding` library. Changes affecting any of the two will impact all the messages being encoded/decoded.

<a name="api--set-dictionary"></a>

### `setDictionary(dictionary: Object)`

Allows defining a human friendly names for custom fix tags. This should be done only once per application.

```javascript
import Fix from '@fenics/fenics-encoding';

Fix.setDictionary({
  5019  : 'TradingSessionID2',
  9303  : 'RoutingInst',
  10022 : 'SecondarySecurityIDSource',
  10042 : 'PricingDuration',
  10043 : 'PrivateDuration',
  10044 : 'GroupDuration',
  10048 : 'SecondarySecurityID',
  10051 : 'PositionRptTradeID',
  10052 : 'PositionRptOrderID',
  10053 : 'PositionRptMatchType'
});
```

**[⬆ back to api](#api)**

<a name="api--set-common-tags"></a>

### `setCommonTags(tags: Object)`

Allows setting a list of common tags to be used when encoding all the messages. Usually handy for standard header fields.

```javascript
const userId = '01234567890asdasd';

Fix.setCommonTags({
  Account      : userId,
  SenderCompID : 'Fenics',
  SenderSubID  : userId,
  TargetCompID : 'BGC',
  TargetSubID  : ''
});

/**
 * The encoder will use the common tags and append them to all
 * the encoded messages.
 */
const encoded = Fix.encode({
  // The rest of the fields
});
```

#### NOTE

There is no need to set the `BeginString (8)`, `MsgSeqNum (34)` and `SendingTime (52)` tags on the `commonTags`. Those are handled internally by the encoder.

**[⬆ back to api](#api)**

<a name="api--clear-common-tags"></a>

### `clearCommonTags()`

Twin method of `setCommonTags`. This will affect all the messages as `commonTags` is global relative to the library.

**[⬆ back to api](#api)**

<a name="api--encode"></a>

### `encode(payload: Object, options = {}: Object)`

Encodes the payload. All the property names should be valid fields in respect to FIX 5.0 SP2 schema. Any invalid tag will cause the encoder to throw. Any provided options will be merged with the `DEFAULT_OPTIONS`, `dictionary` and `commonTags`.

```javascript
const encodeFinalOptions = {
  ...DEFAULT_OPTIONS,
  ...options,
  dictionary,
  commonTags
};
```

#### `DEFAULT_OPTIONS`

| Property | Description | Type | Default |
| -------- | ----------- | ---- | ------- |
| beginString | Value for tag `8` | string | `'FIXT.1.1'` |
| separator | Fix fields separator | string | `'\u0001'` |
| validateBodyLength | Should we validate body length? | bool | `true` |
| validateCheckSum | Should we validate check sum? | bool | `true` |
| asObject | Should we return the decoded message as array of `<tag, value>` pairs or as an object | bool | `true` |

**[⬆ back to api](#api)**

<a name="api--decode"></a>

### `decode(payload: String, options = {}: Object)`

Decodes the given string, using the provided options (combined with the `DEFAULT_OPTIONS` and `dictionary`). It will always return an array of objects, even if the string has only one message.

```javascript
const decodeFinalOptions = {
  ...DEFAULT_OPTIONS,
  ...options,
  dictionary
};

const fixString = '...';

const [decoded] = Fix.decode(fixString, {
  validateBodyLength : false,
  validateChecksum   : false
});
```

**[⬆ back to api](#api)**
