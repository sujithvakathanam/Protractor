/* eslint-disable max-lines */

import {Client} from '@elastic/elasticsearch';
import {INDEX_NAME} from './constant';

class ElasticSearchProvider {
  constructor (options) {
    const {logger} = options;

    this.logger = logger;
    this.client = new Client(options);
  }

  static normalize (item) {
    return Array.isArray(item) ? item : [item];
  }

  static getAggregations () {
    return {
      eSpeedId : {
        terms : {
          field : 'espeedId.keyword'
        }
      },
      lei : {
        terms : {
          field : 'lei.keyword'
        }
      },
      location : {
        terms : {
          field : 'location.keyword'
        }
      },
      region : {
        terms : {
          field : 'region.keyword'
        }
      }
    };
  }

  async get (documentId) {
    this.logger.info(`Retrieving document for documentId ${documentId}`);

    const result = await this.client.get({
      id    : documentId,
      index : INDEX_NAME,
      type  : '_doc'
    });

    return result;
  }

  // eslint-disable-next-line complexity, max-statements
  static buildQuery (options = {}) {
    const DEFAULT_OFFSET = 0;
    const DEFAULT_SIZE = 100;
    const MATCH_ALL = 'match_all';
    const MULTI_MATCH = 'multi_match';
    const MUST_NOT = 'must_not';
    const {
      applicationState = [],
      windowState = [],
      offset = DEFAULT_OFFSET,
      size = DEFAULT_SIZE,
      email,
      name,
      lei,
      eSpeedId,
      region,
      location,
      isAssignedTo,
      includeAggregations,
      isNotAssignedTo,
      query,
      userId
    } = options;
    const esQuery = {
      bool : {
        must : []
      }
    };

    if (email) {
      esQuery.bool.must.push({
        terms : {
          'email.keyword' : ElasticSearchProvider.normalize(email)
        }
      });
    }

    if (name) {
      esQuery.bool.must.push({
        terms : {
          'name.keyword' : ElasticSearchProvider.normalize(name)
        }
      });
    }

    if (lei) {
      esQuery.bool.must.push({
        terms : {
          'lei.keyword' : ElasticSearchProvider.normalize(lei)
        }
      });
    }

    if (eSpeedId) {
      esQuery.bool.must.push({
        terms : {
          'espeedId.keyword' : ElasticSearchProvider.normalize(eSpeedId)
        }
      });
    }

    if (region) {
      esQuery.bool.must.push({
        terms : {
          'region.keyword' : ElasticSearchProvider.normalize(region)
        }
      });
    }

    if (location) {
      esQuery.bool.must.push({
        terms : {
          'location.keyword' : ElasticSearchProvider.normalize(location)
        }
      });
    }

    if (query) {
      esQuery.bool.must.push({
        [MULTI_MATCH] : {
          query,
          type : 'phrase_prefix'
        }
      });
    }

    if (applicationState.length) {
      applicationState.forEach(item => {
        esQuery.bool.must.push({
          term : {
            [`applicationState.${item.applicationName}.state.keyword`] : item.state
          }
        });
      });
    }

    if (windowState.length) {
      windowState.forEach(item => {
        esQuery.bool.must.push({
          term : {
            [`windowState.${item.windowName}.state.keyword`] : item.state
          }
        });
      });
    }

    if (isAssignedTo) {
      const asArray = Array.isArray(isAssignedTo) ? isAssignedTo : [isAssignedTo];

      esQuery.bool.must.push({
        terms : {
          'assignedApplications.keyword' : asArray
        }
      });
    }

    if (isNotAssignedTo) {
      const asArray = Array.isArray(isNotAssignedTo) ? isNotAssignedTo : [isNotAssignedTo];

      esQuery.bool[MUST_NOT] = esQuery.bool[MUST_NOT] || [];

      esQuery.bool[MUST_NOT].push({
        terms : {
          'assignedApplications.keyword' : asArray
        }
      });
    }

    if (userId) {
      esQuery.bool.must.push({
        term : {
          'id.keyword' : userId
        }
      });
    }

    if (esQuery.bool.must.length === 0) {
      esQuery.bool.must.push({
        [MATCH_ALL] : {}
      });
    }

    const esQueryBody = {
      from : offset,
      size,
      body : {
        query : esQuery
      }
    };

    if (includeAggregations) {
      esQueryBody.body.aggs = ElasticSearchProvider.getAggregations();
    }

    return esQueryBody;
  }

  async search (options) {
    const {userId} = options;
    const {from, size, body} = ElasticSearchProvider.buildQuery(options);

    try {
      if (userId) {
        const userDocument = await this.get(userId);

        if (userDocument) {
          const {body : {_source}} = userDocument;

          return {
            items : _source,
            total : 1
          };
        }

        return {
          items : [],
          total : 0
        };
      }

      const response = await this.client.search({
        index : INDEX_NAME,
        from,
        size,
        body
      });

      const {body : {hits : {hits : data = [], total = 0}, aggregations = []} = {}} = response;
      const items = data.map(({_id, _source : item}) => ({
        ...item,
        userId : _id
      }));
      const formattedAggregations = Object.entries(aggregations).reduce((acc, [name, aggregation]) => {
        const DOC_COUNT = 'doc_count';
        const {buckets} = aggregation;
        const formattedItems = buckets.map(({key : value, [DOC_COUNT] : numberOfDocuments}) => ({
          value,
          numberOfDocuments
        }));

        return {
          ...acc,
          [name] : formattedItems
        };
      }, {});

      return {
        aggregations : formattedAggregations,
        items,
        total
      };
    } catch (exception) {
      return {
        aggregations : [],
        items        : [],
        total        : 0
      };
    }
  }
}

export default ElasticSearchProvider;
