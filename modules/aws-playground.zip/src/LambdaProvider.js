import AWS from 'aws-sdk';

class LambdaProvider {
  constructor (options) {
    const {
      activityIngestorFn,
      logger,
      region
    } = options;

    this.logger = logger;
    this.activityIngestorFn = activityIngestorFn;
    this.client = new AWS.Lambda({
      region,
      httpOptions : {
        connectTimeout : 9e5,
        timeout        : 9e5
      }
    });
  }

  async invoke (data) {
    try {
      const results = await this.client.invoke({
        FunctionName   : this.activityIngestorFn,
        InvocationType : 'RequestResponse',
        LogType        : 'Tail',
        Payload        : JSON.stringify(data)
      }).promise();

      this.logger.info({
        results
      }, 'Successfully invoked activity ingestor');
    } catch (error) {
      this.logger.error({error}, 'Erro while invoking activity ingestor function');
    }
  }
}

export default LambdaProvider;
