import fetch from 'node-fetch';
import ftransport from '@fenics/fenics-transport';
import WebSocket from 'ws';

class StreamingService {
  constructor (options) {
    const {authHeader, tokenUrl, websocketUrl} = options;

    this.applicationName = 'fenics/fenics-support-app';
    this.isConnected = false;
    this.socket = null;
    this.tokenUrl = tokenUrl;
    this.websocketUrl = websocketUrl;

    ftransport().polyfills({
      fetch
    });

    this.api = ftransport(tokenUrl)
      .auth(authHeader)
      .accept('application/json')
      .content('application/json');
  }

  async connect () {
    global.console.log('Fetching websocket one time tocken');

    const {ott} = await this.api
      .json({
        group : this.applicationName
      })
      .post()
      .json();

    global.console.log(`Websocket one time tocken = ${ott}`);

    const websocketUrl = `${this.websocketUrl}?ott=${ott}`;

    global.console.log(`Websocket url = ${websocketUrl}`);

    this.socket = new WebSocket(websocketUrl);

    return new Promise(resolve => {
      this.socket.on('open', function open () {
        this.isConnected = true;

        global.console.log('Websocket connection opened');

        resolve();
      });
    });
  }

  subscribe () {
    this.socket.on('error', function onError (error) {
      global.console.log('Error event on websocket', error);
    });

    this.socket.on('message', function incoming (data) {
      const {topic, payload} = data;

      global.console.log(data);

      if (topic === 'fenics/support-response') {
        global.console.log(JSON.stringify(payload, null, 2));
      }
    });
  }
}

export default StreamingService;
