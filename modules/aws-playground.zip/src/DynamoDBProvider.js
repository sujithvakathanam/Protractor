/* eslint-disable id-length, max-lines */

const {createObjectCsvWriter : createCsvWriter} = require('csv-writer');
import {TABLE_NAME} from './constant';

class DynamoDBProvider {
  static throwIfMissing (parameterName) {
    throw new Error(`Parameter ${parameterName} is required`);
  }

  static requiredIfNot (otherParameterName, data) {
    return parameterName => {
      if (!Reflect.has(data, otherParameterName)) {
        throw new Error(`Parameter ${parameterName} is required`);
      }
    };
  }

  static getTableName (params) {
    const {
      applicationName,
      environment,
      separator = '_',
      tableName,
      tableStack
    } = params;

    return [
      applicationName,
      tableName,
      environment,
      tableStack
    ].filter(Boolean).join(separator);
  }

  constructor (options) {
    const {
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    } = options;

    this.applicationName = applicationName;
    this.converter = converter;
    this.dynamoDB = dynamoDB;
    this.environment = environment;
    this.tableStack = tableStack;
  }

  getLatestApplicationVersion (fenicsApplicationName) {
    const tableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.APPLICATION_VERSION,
      tableStack      : this.tableStack
    });
    let fenicsApplicationNames = [];

    if (Array.isArray(fenicsApplicationName?.values)) {
      fenicsApplicationNames = [...fenicsApplicationName.values];
    } else if (Array.isArray(fenicsApplicationName)) {
      fenicsApplicationNames = fenicsApplicationName;
    } else {
      fenicsApplicationNames = [fenicsApplicationName];
    }

    const Keys = fenicsApplicationNames.map(name => {
      const marshalledItem = this.converter.marshall({
        name
      });

      return marshalledItem;
    });
    const params = {
      RequestItems : {
        [tableName] : {
          Keys
        }
      }
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.batchGetItem(params, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Responses) {
          const {[tableName] : applicationVersions = []} = data.Responses;
          const unmarshalledResults = applicationVersions.map(this.converter.unmarshall);

          resolve(unmarshalledResults);
        } else {
          reject(new Error(`Unable to get application versions for ${fenicsApplicationName}`));
        }
      });
    });
  }

  lookupByField (fieldName, fieldValue) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.USER_DATA,
      tableStack      : this.tableStack
    });
    const ExpressionAttributeNames = {
      [`#${fieldName}`] : fieldName
    };
    const ExpressionAttributeValues = this.converter.marshall({
      [`:${fieldName}`] : fieldValue
    });
    const FilterExpression = `#${fieldName} = :${fieldName}`;
    const scanParams = {
      ExpressionAttributeNames,
      ExpressionAttributeValues,
      FilterExpression,
      TableName
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.scan(scanParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const users = data.Items.map(this.converter.unmarshall);

          resolve(users);
        } else {
          reject(new Error(`Unable to get user for ${fieldName} ${fieldValue}`));
        }
      });
    });
  }

  lookupByEmail (userEmail = DynamoDBProvider.throwIfMissing('userEmail')) {
    return this.lookupByField('email', userEmail);
  }

  lookupByName (name = DynamoDBProvider.throwIfMissing('name')) {
    return this.lookupByField('name', name);
  }

  lookupByLEI (lei = DynamoDBProvider.throwIfMissing('lei')) {
    return this.lookupByField('lei', lei);
  }

  lookupByESpeedId (espeedId = DynamoDBProvider.throwIfMissing('espeedId')) {
    return this.lookupByField('espeedId', espeedId);
  }

  lookupByRegion (region = DynamoDBProvider.throwIfMissing('region')) {
    return this.lookupByField('region', region);
  }

  lookupByLocation (location = DynamoDBProvider.throwIfMissing('location')) {
    return this.lookupByField('location', location);
  }

  updateUser (
    userId = DynamoDBProvider.throwIfMissing('userId'),
    userData = DynamoDBProvider.throwIfMissing('userData')
  ) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.USER_DATA,
      tableStack      : this.tableStack
    });
    const updateExpression = Object.keys(userData).reduce((acc, propertyName) => {
      const part = `#${propertyName} = :${propertyName}`;

      if (acc === '') {
        return part;
      }

      return `${acc}, ${part}`;
    }, '');
    const {ExpressionAttributeNames, ExpressionAttributeValues} = Object.entries(userData)
      .reduce((acc, [propertyName, propertyValue]) => ({
        ExpressionAttributeNames : {
          ...acc.ExpressionAttributeNames,
          [`#${propertyName}`] : propertyName
        },
        ExpressionAttributeValues : {
          ...acc.ExpressionAttributeValues,
          [`:${propertyName}`] : propertyValue
        }
      }), {
        ExpressionAttributeNames  : {},
        ExpressionAttributeValues : {}
      });

    const updateParams = {
      ExpressionAttributeNames,
      ExpressionAttributeValues : this.converter.marshall(ExpressionAttributeValues),
      Key                       : this.converter.marshall({
        id : userId
      }),
      UpdateExpression : `SET ${updateExpression}`,
      TableName
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.updateItem(updateParams, (error, data) => {
        if (error) {
          reject(error);
        }

        resolve(data);
      });
    });
  }

  // eslint-disable-next-line complexity, max-statements
  getConnectionIds (options) {
    const {
      group = DynamoDBProvider.requiredIfNot('userId', options)('group'),
      heartbeatThreshold = 2,
      userId = DynamoDBProvider.requiredIfNot('group', options)('userId')
    } = options;
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.WS_CONNECTIONS,
      tableStack      : this.tableStack
    });
    const now = new Date();
    let dynamoMethod = 'scan';

    now.setMinutes(now.getMinutes() - heartbeatThreshold);

    const expressionAttributeNames = {};
    const expressionAttributeValues = {
      ':heartbeat' : `${now.toISOString().slice(0, -1)}000`
    };

    if (userId) {
      expressionAttributeNames['#userId'] = 'userId';
      expressionAttributeValues[':userId'] = userId;
    }

    if (group) {
      expressionAttributeNames['#group'] = 'group';
      expressionAttributeValues[':group'] = group;
    }

    const FilterExpression = [
      'attribute_exists(heartbeatAt) and heartbeatAt > :heartbeat',
      ...userId ? ['#userId = :userId'] : []
    ].join(' and ');

    const dynamoParams = {
      ExpressionAttributeValues : this.converter.marshall(expressionAttributeValues),
      FilterExpression,
      TableName
    };

    if (Object.keys(expressionAttributeNames).length > 0) {
      dynamoParams.ExpressionAttributeNames = expressionAttributeNames;
    }

    if (group) {
      dynamoParams.KeyConditionExpression = '#group = :group';
      dynamoParams.IndexName = 'group-index';
      dynamoMethod = 'query';
    }

    return new Promise((resolve, reject) => {
      this.dynamoDB[dynamoMethod](dynamoParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const websocketConnectionIds = data.Items.map(this.converter.unmarshall);

          resolve(websocketConnectionIds);
        } else {
          reject(new Error('Cannot retrieve connections ids'));
        }
      });
    });
  }

  getUsersWithApplication (fenicsApplication = DynamoDBProvider.throwIfMissing('fenicsApplication')) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.APPLICATION_USER,
      tableStack      : this.tableStack
    });
    const expressionAttributeNames = {
      '#names' : 'names'
    };
    const expressionAttributeValues = fenicsApplication.reduce((acc, application, index) => ({
      ...acc,
      [`:application${index}`] : application
    }), {});
    const dynamoParams = {
      ExpressionAttributeNames  : expressionAttributeNames,
      ExpressionAttributeValues : this.converter.marshall(expressionAttributeValues),
      FilterExpression          : fenicsApplication
        .map((application, index) => `contains (#names, :application${index})`)
        .join(' OR '),
      TableName
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.scan(dynamoParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const userIds = data.Items.map(item => {
            const {userId} = this.converter.unmarshall(item);

            return userId;
          });

          resolve(userIds);
        } else {
          reject(new Error('Cannot retrieve user ids for application', fenicsApplication));
        }
      });
    });
  }

  getUserData (userIds) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.USER_DATA,
      tableStack      : this.tableStack
    });

    const dynamoParams = {
      TableName
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.scan(dynamoParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const allUsers = data.Items.map(item => {
            const userData = this.converter.unmarshall(item);

            return userData;
          });

          resolve(allUsers);
        } else {
          reject(new Error('Cannot retrieve user ids for application', userIds));
        }
      });
    });
  }

  getBondData (isin) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.BOND_REF_DATA,
      tableStack      : this.tableStack
    });

    const dynamoParams = {
      TableName,
      KeyConditionExpression   : '#isin = :isin',
      ExpressionAttributeNames : {
        '#isin' : 'isin'
      },
      ExpressionAttributeValues : {
        ':isin' : {
          S : isin
        }
      }
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.query(dynamoParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const allBonds = data.Items.map(item => {
            const bondData = this.converter.unmarshall(item);

            return bondData;
          });

          resolve(allBonds);
        } else {
          reject(new Error('Cannot retrieve bond data for', isin));
        }
      });
    });
  }

  async getBondsForTradingSessions ({rating, sector, quantity, size = -1}) {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.BOND_REF_DATA,
      tableStack      : this.tableStack
    });

    const dynamoParams = {
      TableName,
      ProjectionExpression : '#isin',
      FilterExpression     : `
        #bondStatus = :bondStatus
        and #stale = :stale
        and #isSpread = :isSpread
        and #industrySector = :industrySector
      `,
      ExpressionAttributeNames : {
        '#isin'           : 'isin',
        '#bondStatus'     : 'bondStatus',
        '#stale'          : 'stale',
        '#isSpread'       : 'isSpread',
        '#industrySector' : 'industrySector'
      },
      ExpressionAttributeValues : {
        ':bondStatus'     : {S : 'ok'},
        ':stale'          : {BOOL : false},
        ':isSpread'       : {S : rating === 'IG' ? 'Y' : 'N'},
        ':industrySector' : {S : sector}
      }
    };

    global.console.log(`Looking for [${quantity}] [${rating}] - [${sector}] bonds...`);

    const scanResults = [];
    let items = [];
    let bondsFound = 0;

    do {
      // eslint-disable-next-line no-await-in-loop
      items = await this.dynamoDB.scan(dynamoParams).promise();
      bondsFound += Number(items.Count);

      items.Items.forEach(item => {
        const result = this.converter.unmarshall(item);

        result.size = size;

        scanResults.push(result);
      });

      dynamoParams.ExclusiveStartKey = items.LastEvaluatedKey;
    } while (typeof items.LastEvaluatedKey !== undefined && bondsFound < quantity);

    const finalResults = scanResults.slice(0, quantity);
    const path = `${sector}_${rating}_${quantity}_${size > 0 ? 'Sell' : 'Buy'}_bonds.csv`;
    const csvWriter = createCsvWriter({
      path,
      append : false,
      header : ['isin', 'size']
    });

    await csvWriter.writeRecords(finalResults)
      .then(() => {
        global.console.log(`CSV finished - ${path}`);
      })
      .catch(err => {
        global.console.log('Unable to write to CSV', err);
      });

    return finalResults;
  }

  getBondsOverrideData () {
    const TableName = DynamoDBProvider.getTableName({
      applicationName : this.applicationName,
      environment     : this.environment,
      tableName       : TABLE_NAME.BOND_REF_DATA_OVERRIDES,
      tableStack      : this.tableStack
    });

    const dynamoParams = {
      TableName
    };

    return new Promise((resolve, reject) => {
      this.dynamoDB.scan(dynamoParams, (error, data) => {
        if (error) {
          reject(error);
        }

        if (data?.Items) {
          const allBonds = data.Items.map(item => {
            const bondData = this.converter.unmarshall(item);

            return bondData;
          });

          resolve(allBonds);
        } else {
          reject(new Error('Cannot retrieve bond overrides for', TableName));
        }
      });
    });
  }
}

export default DynamoDBProvider;
