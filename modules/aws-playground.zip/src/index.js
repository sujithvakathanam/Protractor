import AWS from 'aws-sdk';
import StreamingSDK from '@fenics/fenics-streaming-sdk';
import DeploymentUtil from './DeploymentUtil';
import DynamoDBProvider from './DynamoDBProvider';
import ElasticSearchProvider from './ElasticSearchProvider';
import KinesisProvider from './KinesisProvider';
import LambdaProvider from './LambdaProvider';
import {ENVIRONMENT} from './constant';

const credentials = new AWS.SharedIniFileCredentials({
  profile : 'fenics'
});

AWS.config.credentials = credentials;

AWS.config.update({
  region : 'eu-west-1'
});

const applicationName = 'fenics';
const converter = AWS.DynamoDB.Converter;
const dynamoDB = new AWS.DynamoDB();
const environment = ENVIRONMENT.DEV;
const tableStack = 'violet';
const region = 'eu-west-1';

// eslint-disable-next-line no-unused-vars
const provider = new DynamoDBProvider({
  applicationName,
  converter,
  dynamoDB,
  environment,
  tableStack
});

// eslint-disable-next-line no-unused-vars
const streamingSDK = new StreamingSDK({
  applicationName,
  converter,
  dynamoDB,
  environment,
  tableStack
});

// eslint-disable-next-line no-unused-vars
const lambda = new LambdaProvider({
  region,
  activityIngestorFn : 'fenics-dev--87c80275-e805-5b15-944b-a33ca1d34b4a',
  logger             : {
    error : console.error, // eslint-disable-line no-console
    info  : console.log // eslint-disable-line no-console
  }
});

// eslint-disable-next-line no-unused-vars
const esProvider = new ElasticSearchProvider({
  logger : {
    error : console.error, // eslint-disable-line no-console
    info  : console.log // eslint-disable-line no-console
  },
  node : 'https://search-es4ee8fb117bab5b9aa48306745b-ahv66ajxpqdpswvck2l7rsr7vq.eu-west-1.es.amazonaws.com',
  region
});

// eslint-disable-next-line no-unused-vars
async function searchES () {
  const result = await esProvider.search({
    isAssignedTo     : ['fenics/hydra-trader-app'],
    isNotAssignedTo  : ['frontdoor/frontdoor-whiteboard-app'],
    applicationState : [{
      applicationName : 'fenics/fenics-launchbar-app-dev',
      state           : 'application-connected'
    }],
    windowState : [{
      windowName : 'fenics/fenics-launchbar-app-dev',
      state      : 'window-blurred'
    }],
    userId              : '00u1qftdc10hC7a1J0i7',
    email               : 'vlad.coroiu@bgcpartners.com',
    eSpeedId            : 'fencrt01',
    region              : 'AMRS',
    lei                 : '777',
    includeAggregations : true
  });

  global.console.log(JSON.stringify(result, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function getConnectionIds () {
  const userConnectionIds = await provider.getConnectionIds({
    group  : 'fenics/nvm-volume-match-app',
    userId : '00u35itsnof5eru9x0i7'
  });
  const connectionIds = userConnectionIds.map(({connectionId}) => connectionId);

  global.console.log(connectionIds);
}

// eslint-disable-next-line no-unused-vars
function deleteConnection (ConnectionId) {
  const wsApi = new AWS.ApiGatewayManagementApi({
    endpoint : 'https://fenics-ws.dev.fenicsone.com',
    region
  });

  wsApi.deleteConnection({
    ConnectionId
  }, error => {
    if (error) {
      global.console.log('Failed to delete connection', error);
    }

    global.console.log('Successfully closed connection');
  });
}

// eslint-disable-next-line no-unused-vars
async function kickOffUser () {
  const userId = '<userId>';
  const kickedOffUser = await DeploymentUtil.kickOffUser(ENVIRONMENT.DEV, userId);

  global.console.log(JSON.stringify(kickedOffUser, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function kickOffDeltaXTraderUsers () {
  const kickedOffDeltaXTraderApplicationUsers = await DeploymentUtil.kickOffDeltaXTraderUsers(ENVIRONMENT.DEV);

  global.console.log(JSON.stringify(kickedOffDeltaXTraderApplicationUsers, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function kickOffFenicsGOUsers () {
  const kickedOffFenicsGOApplicationUsers = await DeploymentUtil.kickOffFenicsGOUsers(ENVIRONMENT.DEV);

  global.console.log(JSON.stringify(kickedOffFenicsGOApplicationUsers, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function promptForDownloadingLogs () {
  const userId = '00u2w0keltUemu6Dq0i7';
  const response = await DeploymentUtil.promptForDownloadLogs(userId, ENVIRONMENT.PROD);

  global.console.log(JSON.stringify(response, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function kinesisPlayground () {
  const kProvider = new KinesisProvider({
    port : 4567
  });

  await kProvider.start();
  await kProvider.createStream();

  const postedRecords = await kProvider.putRecords({
    foo : 'bar'
  });

  const shardIds = KinesisProvider.getShardIds(postedRecords);
  const shardIterators = await kProvider.getShardIterator(shardIds);
  const records = await kProvider.getRecords(shardIterators);
  const recordsData = records.reduce((acc, {data, success}) => {
    if (success) {
      const normalized = Array.isArray(data) ? data : [data];

      acc.push(...normalized);
    }

    return acc;
  }, []);
  const decodedData = await KinesisProvider.decodeRecords(recordsData);

  global.console.log(decodedData);
}

// eslint-disable-next-line no-unused-vars
async function getLogList () {
  const userId = '00u1qftdc10hC7a1J0i7';
  const response = await DeploymentUtil.getCLientLogList(userId, ENVIRONMENT.DEV);

  global.console.log(JSON.stringify(response, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function getLogContent () {
  const userId = '00u1qftdc10hC7a1J0i7';
  // const userId = '00u3gyvhs0ATxhpXh0i7'; // lawrence.latner@usbank.com
  const logList = [{
    name : 'debug.log'
  }];
  const response = await DeploymentUtil.getCLientLog(userId, logList, ENVIRONMENT.PROD);

  global.console.log(JSON.stringify(response, null, 2));
}

// eslint-disable-next-line no-unused-vars
async function getWindowSnapshots () {
  const userId = '00u1qftdc10hC7a1J0i7';
  const response = await DeploymentUtil.getClientSnapshots(userId, ENVIRONMENT.DEV);

  global.console.log(JSON.stringify(response, null, 2));
}

(async function main () {
  try {
    await kickOffDeltaXTraderUsers();
  } catch (error) {
    global.console.error(error);
  }
}());
