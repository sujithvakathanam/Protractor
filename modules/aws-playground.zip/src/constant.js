const TABLE_NAME = {
  APPLICATION_USER        : 'application_user',
  APPLICATION_VERSION     : 'application_version',
  BOND_REF_DATA           : 'bonds_reference_data',
  BOND_REF_DATA_OVERRIDES : 'bonds_override_reference_data',
  USER_DATA               : 'user_data',
  WS_CONNECTIONS          : 'ws_connections'
};

const ENVIRONMENT = {
  DEV  : 'dev',
  QA   : 'qa',
  UAT  : 'uat',
  PROD : 'prod'
};

const INDEX_NAME = 'fenics_activity';

module.exports = {
  ENVIRONMENT,
  INDEX_NAME,
  TABLE_NAME
};
