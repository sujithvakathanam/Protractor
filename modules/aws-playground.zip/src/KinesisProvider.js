/* eslint-disable max-lines */

import AWS from 'aws-sdk';
import kinesalite from 'kinesalite';
import zlib from 'zlib';

const DEFAULT_PORT = 4567;

class KinesisProvider {
  constructor (options) {
    this.options = options;
    this.kinesis = null;
    this.streamName = 'test-stream';
  }

  start () {
    const {port = DEFAULT_PORT} = this.options;
    const kinesaliteServer = kinesalite({
      createStreamMs : 50
    });

    return new Promise((resolve, reject) => {
      kinesaliteServer.listen(port, error => {
        if (error) {
          reject(error);
        }

        global.console.log(`Kinesalite started on port ${port}`);

        this.kinesis = new AWS.Kinesis({
          endpoint : `http://localhost:${port}`
        });

        resolve();
      });
    });
  }

  createStream (parameters = {}) {
    const {shardCount = 1, streamName = this.streamName} = parameters;
    const params = {
      ShardCount : shardCount,
      StreamName : streamName
    };

    return new Promise((resolve, reject) => {
      this.kinesis.createStream(params, (error, data) => {
        if (error) {
          reject(error);
        }

        const WAIT_BEFORE_RESOLVING = 1e3;

        global.setTimeout(() => {
          global.console.log(`Successfully created stream <<${streamName}>>`);

          resolve(data);
        }, WAIT_BEFORE_RESOLVING);
      });
    });
  }

  putRecords (data) {
    const Data = typeof data === 'string' ? data : JSON.stringify(data);
    const PartitionKey = 'test-parition-key';
    const params = {
      Records : [{
        Data,
        PartitionKey
      }],
      StreamName : this.streamName
    };

    return new Promise((resolve, reject) => {
      this.kinesis.putRecords(params, (error, recordsData) => {
        if (error) {
          reject(error);
        }

        resolve(recordsData);
      });
    });
  }

  static getShardIds (publishedRecords) {
    const {Records} = publishedRecords;

    return Records.map(({ShardId}) => ShardId);
  }

  async getShardIterator (shardIds) {
    if (Array.isArray(shardIds)) {
      const allPromises = shardIds.map(ShardId => {
        const params = {
          ShardId,
          ShardIteratorType : 'TRIM_HORIZON',
          StreamName        : this.streamName
        };

        return new Promise(resolve => {
          this.kinesis.getShardIterator(params, (error, data) => {
            if (error) {
              resolve({
                data    : null,
                success : false,
                error
              });
            } else {
              resolve({
                data,
                error   : null,
                success : true
              });
            }
          });
        });
      });

      const responses = await Promise.all(allPromises);
      const shardIterators = responses.reduce((acc, {data, success}) => {
        if (success) {
          acc.push(data.ShardIterator);
        }

        return acc;
      }, []);

      return shardIterators;
    }

    const params = {
      ShardId           : shardIds,
      ShardIteratorType : 'TRIM_HORIZON',
      StreamName        : this.streamName
    };

    return new Promise(resolve => {
      this.kinesis.getShardIterator(params, (error, data) => {
        if (error) {
          resolve({
            data    : null,
            success : false,
            error
          });
        } else {
          resolve({
            data,
            error   : null,
            success : true
          });
        }
      });
    });
  }

  async getRecords (shardIterator) {
    if (Array.isArray(shardIterator)) {
      const allPromises = shardIterator.map(ShardIterator => {
        const params = {
          ShardIterator
        };

        return new Promise(resolve => {
          this.kinesis.getRecords(params, (error, data) => {
            if (error) {
              resolve({
                data    : null,
                success : false,
                error
              });
            } else {
              resolve({
                data    : data.Records,
                error   : null,
                success : true
              });
            }
          });
        });
      });

      const allRecords = await Promise.all(allPromises);

      return allRecords;
    }

    return new Promise(resolve => {
      const params = {
        ShardIterator : shardIterator
      };

      this.kinesis.getRecords(params, (error, data) => {
        if (error) {
          resolve({
            data    : null,
            success : false,
            error
          });
        } else {
          resolve({
            data    : data.Records,
            error   : null,
            success : true
          });
        }
      });
    });
  }

  static unzipData (data) {
    return new Promise((resolve, reject) => {
      zlib.gunzip(data, (error, buffer) => {
        if (error) {
          reject(error);
        } else {
          resolve(buffer.toString());
        }
      });
    });
  }

  static async tryUnzipData (data) {
    try {
      const unzippedData = await KinesisProvider.unzipData(data);

      return unzippedData;
    } catch (error) {
      if (error.message.toLowerCase() === 'incorrect header check') {
        return data.toString();
      }

      throw error;
    }
  }

  static async decodeRecords (records) {
    const decodedRecordsPromises = records.map(async record => {
      const base64Decoded = Buffer.from(record.Data, 'base64');
      const unzippedData = await KinesisProvider.tryUnzipData(base64Decoded);
      const parsedData = JSON.parse(unzippedData);

      return parsedData;
    });
    const decodedRecords = await Promise.all(decodedRecordsPromises);

    return decodedRecords;
  }
}

export default KinesisProvider;
