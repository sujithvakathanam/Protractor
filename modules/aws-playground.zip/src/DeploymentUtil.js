import AWS from 'aws-sdk';
import StreamingSDK from '@fenics/fenics-streaming-sdk';
import {ENVIRONMENT} from './constant';

class DeploymentUtil {
  static async kickOffUser (environment = ENVIRONMENT.DEV, userId) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    global.console.log(`About to kick off user with id ${userId} in ${environment}`);

    const result = await streamingSDK.notify({
      userId,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'INVALIDATE_USER_SESSION'
        }
      })
    });

    return result;
  }

  static async kickOffApplicationUsers (environment = ENVIRONMENT.DEV, application) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    global.console.log(`About to kick off all users with ${application} assigned in ${environment}`);

    const result = await streamingSDK.notify({
      application,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'INVALIDATE_USER_SESSION'
        }
      })
    });

    return result;
  }

  static kickOffDeltaXTraderUsers (environment = ENVIRONMENT.DEV) {
    return DeploymentUtil.kickOffApplicationUsers(environment, 'fenics/hydra-trader-app');
  }

  static kickOffFenicsGOUsers (environment = ENVIRONMENT.DEV) {
    return DeploymentUtil.kickOffApplicationUsers(
      environment, [
        'bluechip/bluechip-trader-app',
        'bluechip/bluechip-operator-app'
      ]
    );
  }

  static async promptForDownloadLogs (userId, environment = ENVIRONMENT.DEV) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    global.console.log(`About to prompt for downloading logs user with id ${userId} in ${environment}`);

    const result = await streamingSDK.notify({
      userId,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'DOWNLOAD_CLIENT_LOGS'
        }
      })
    });

    return result;
  }

  static async getCLientLogList (userId, environment = ENVIRONMENT.DEV) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    global.console.log(`About to get log list for user with id ${userId} in ${environment}`);

    const result = await streamingSDK.notify({
      userId,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'SEND_CLIENT_LOG_LIST'
        }
      })
    });

    return result;
  }

  static async getCLientLog (userId, logList, environment = ENVIRONMENT.DEV) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    // eslint-disable-next-line max-len
    global.console.log(`About to get log content for user with id ${userId} in ${environment} for`, JSON.stringify(logList, null, 2));

    const result = await streamingSDK.notify({
      userId,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'SEND_CLIENT_LOG',
          userId,
          logList
        }
      })
    });

    return result;
  }

  static async getClientSnapshots (userId, environment = ENVIRONMENT.DEV) {
    const applicationName = 'fenics';
    const converter = AWS.DynamoDB.Converter;
    const dynamoDB = new AWS.DynamoDB();
    const tableStack = 'violet';
    const streamingSDK = new StreamingSDK({
      applicationName,
      converter,
      dynamoDB,
      environment,
      tableStack
    });

    global.console.log(`About to get window snapshots for user with id ${userId} in ${environment}`);

    const result = await streamingSDK.notify({
      userId,
      data : JSON.stringify({
        topic   : 'fenics/support',
        payload : {
          type : 'SEND_CLIENT_SNAPSHOTS',
          userId
        }
      })
    });

    return result;
  }
}

export default DeploymentUtil;
