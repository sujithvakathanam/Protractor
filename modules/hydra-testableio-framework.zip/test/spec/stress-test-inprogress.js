/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import {apiConfig} from '../../config/api.config';
import {FixHydraStrategy} from '../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../pages/FenicsCredit';
import {getNewOrder} from '../../utilities/orderCreator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../constant/Region';
import {Sector} from '../../constant/Sector';
import {TRADING_PROTOCOL} from '../../constant/Protocol';
import {log} from 'testable-utils';
import {MODULE_TITLES} from '../../constant/App';
import {TYPE} from '../../constant/TradingSession';


describe('DeltaX - Session Stress Testing  for HY-Energy', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  // eslint-disable-next-line no-unused-vars
  let sessionStrategy = null;
  let orderRemoverStrategy = null;
  let uiTrader = null;
  let uiUserPassword = null;
  let traderSide = null;
  let apiSessionCreator = null;
  let apiOrderRemover = null;

  const securityDescription = 'ALTMES 7 7/8 12/15/24';
  const type = TYPE.SESSION;
  const industrySector = Sector.ENERGY;
  const spread = 1;
  const size = 5000000;
  const rating = 'HY';
  const region = TICK_CONFIGURATION.US.HY;
  const orderMid = 100.5;

  const sessionConfiguration = {
    sector : industrySector,
    rating,
    type
  };

  // Total : 84 HY Energy ISINs
  const genOrders = buyOrSell => [
    {order       : getNewOrder('US021332AF81', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ALTMES 7 7/8 12/15/24'},
    {order       : getNewOrder('US198280AH20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CPGX 5.8 06/01/45'},
    {order       : getNewOrder('US17302XAJ54', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CITPET 6 1/4 08/15/22'},
    {order       : getNewOrder('US02564PAA66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : false,
      description : 'AMWOOD 9 09/15/22'},
    {order       : getNewOrder('US02753GAA76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AMID 8 1/2 12/15/21'},
    {order       : getNewOrder('US095796AA63', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BLURAC 6 1/8 11/15/22'},
    {order       : getNewOrder('US12532MAA18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : false,
      description : ''},
    {order       : getNewOrder('US12654TAA88', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CNXMPF 6 1/2 03/15/26'},
    {order       : getNewOrder('US13057QAG29', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : false,
      description : 'CRC 8 12/15/22'},
    {order       : getNewOrder('US13123XAZ50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CPE 6 3/8 07/01/26'}
  ];


  function getOrders (orders) {
    const ordersArray = orders.map(value => value.order);

    return ordersArray;
  }

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    configuration = context.getConfiguration();
    log.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // User setup
    apiSessionCreator = 'sujith.vakathanam.auto3@testing.fenicstools.com';
    apiOrderRemover = 'sujith.vakathanam.auto13@testing.fenicstools.com';

    sessionStrategy = new FixSessionStrategy(context, apiSessionCreator);
    orderRemoverStrategy = new FixHydraStrategy(context, apiOrderRemover);

    expect(browser).to.exist;
  });

  async function startSessionAction () {
    const info = await browser.testableInfo();
    // eslint-disable-next-line no-unused-vars,no-inline-comments
    const concurrentClientIndex = info.globalClientIndex ? info.globalClientIndex : 0; // global client index, or 0 for smoke tests

    log.info(`Testable global client index for :${uiTrader} is :${concurrentClientIndex}`);

    if (concurrentClientIndex === 0) {
      log.info('Starting Session.....');
      await sessionStrategy.createSession(sessionConfiguration);
    } else {
      log.info('Session start action performed by user with global client index : 0');
    }
  }

  async function hasCountdownPhaseStarted () {
    const expectedPhase = 'Countdown';

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasAffirmationPhaseStarted () {
    const expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasCleanUpPhaseStarted () {
    const expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasCleanUpPhaseEnded () {
    await hydraPageModel.getSessionPanel(rating, false, type);
    await browser.pause(configuration.veryShortTimeout);
    const expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has Ended.`);
  }

  async function loginSingleUser () {
    const rowPromise = await browser.testableCsvNext('users.csv');
    const row = rowPromise[0];

    log.info(`User for this session is : ${row.data.USERNAME}`);
    log.info(`SIDE for this session is : ${row.data.SIDE}`);
    uiTrader = row.data.USERNAME;
    uiUserPassword = row.data.PASSWORD;
    traderSide = row.data.SIDE;

    const hydraApiClientUser1 = new FixHydraStrategy(context, uiTrader);
    await orderRemoverStrategy.removeOrders(hydraApiClientUser1);

    // User Login and also capturing time to login
    await browser.testableStopwatch(async done => {
      await testCommons.traderLogin(uiTrader, uiUserPassword);
      done();
    }, 'Login UserTiming');
  }

  // eslint-disable-next-line no-unused-vars
  async function waitForAll (name) {
    const result = await browser.testableResult();
    const info = await browser.testableInfo();
    // eslint-disable-next-line no-inline-comments
    const numUsers = info.execution ? info.execution.concurrentClients : 1; // global user count, or 1 for smoke tests
    // eslint-disable-next-line no-undef
    log.info(`Number of users are : ${numUsers} to perform - ${name} - action`);
    await browser.testableCounter(result, name, 1, 'requests');
    // eslint-disable-next-line no-undef
    await browser.testableWaitForValue({namespace : 'User',
      name,
      value     : numUsers,
      timeout   : 300000});
  }


  // eslint-disable-next-line require-await
  it('All UI user logs into each EC2 instance concurrently', async () => {
    log.info('MODULE_TITLES.loginPageTitle is set as ', MODULE_TITLES.loginPageTitle);
    log.info('MODULE_TITLES.launchbarTitle is set as ', MODULE_TITLES.launchbarTitle);
    log.info('MODULE_TITLES.hydraPageTitle is set as ', MODULE_TITLES.hydraPageTitle);
    log.info('MODULE_TITLES.hydraOperatorPageTitle is set as ', MODULE_TITLES.hydraOperatorPageTitle);

    await loginSingleUser();

    await browser.testableScreenshot('loginSingleUser');
    await waitForAll('loginSingleUser');
  });

  it('All user loads ISINs', async () => {
    log.info('Adding Order Phase Started');

    const myOrders = getOrders(genOrders(traderSide));
    log.info(`User : ${uiTrader} is adding orders for - ${traderSide} - side`);

    await browser.testableStopwatch(async done => {
      await hydraPageModel.addOrders(myOrders);
      log.info(`User : ${uiTrader} has completed adding orders for - ${traderSide} - side`);
      done();
    }, 'AddOrders UserTiming');

    let countOfOrdersInSessionPanel = await hydraPageModel.getPortfolio().getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info('Count of Orders in Portfolio panel is ', countOfOrdersInSessionPanel);

    await browser.testableScreenshot('addOrders');
    await waitForAll('addOrders');
  });

  it('Operator starts session', async () => {
    await startSessionAction();
    await waitForAll('startSessionAction');
  });

  it('Waiting for COUNTDOWN phase', async () => {
    await hasCountdownPhaseStarted();

    await browser.testableScreenshot('hasCountdownPhaseStarted');
    await waitForAll('hasCountdownPhaseStarted');
  });

  it('User moves from AFFIRMATION phase to CLEAN UP phase', async () => {
    // Affirmation Phase
    await hasAffirmationPhaseStarted();

    await browser.testableStopwatch(async done => {
      // User to affirm all orders
      await hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .affirmAllOrders();
      log.info(`User : ${uiTrader} has affirmed all orders`);

      await browser.testableScreenshot('affirmAllOrders');

      // Clean up phase
      await hasCleanUpPhaseStarted();

      done();
    }, 'AffirmationPhase UserTiming');

    await browser.testableScreenshot('hasCleanUpPhaseStarted');
    await waitForAll('hasCleanUpPhaseStarted');
  });

  it('Waiting for all traders action panels to be emptied', async () => {
    await hasCleanUpPhaseEnded();

    await browser.testableScreenshot('hasCleanUpPhaseEnded');
    await waitForAll('hasCleanUpPhaseEnded');
  });

  it('Exit OpenFin Runtime', async () => {
    await browser.execute(() => {
      // eslint-disable-next-line no-undef
      fin.desktop.System.exit();
    });
    // eslint-disable-next-line no-inline-comments,no-magic-numbers,line-comment-position
    await browser.pause(1000); // Pause here to give Runtime time to exit
  });
});

