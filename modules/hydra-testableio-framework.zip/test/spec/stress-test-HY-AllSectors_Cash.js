/* eslint-disable max-statements,max-lines,complexity */
import {expect} from 'chai';
import {frameworkConfig} from '../../config/framework.config';
import {usersConfig} from '../../config/users.config';
import {apiConfig} from '../../config/api.config';
import {FixHydraStrategy} from '../../lib/hydra/fixHydraStrategy';
import {FixSessionStrategy} from '../../lib/sessions/fixSessionStrategy';
import FenicsCredit from '../../pages/FenicsCredit';
import {getNewOrder} from '../../utilities/orderCreator';
import {Bootstrap} from '@fenics/fenics-test-core';
import TestCommons from '../../utilities/TestCommons';
import {TICK_CONFIGURATION} from '../../constant/Region';
import {Sector} from '../../constant/Sector';
import {TRADING_PROTOCOL} from '../../constant/Protocol';
import {log} from 'testable-utils';
import {MODULE_TITLES} from '../../constant/App';


describe('DeltaX - Session Stress Testing  for HY-All Sectors', () => {
// Framework vars.
  const browser = global.browser;
  let bootstrapper = null;
  let context = null;
  let configuration = null;

  // Page object vars.
  let testCommons = null;
  let hydraPageModel = null;
  // eslint-disable-next-line no-unused-vars
  let sessionStrategy = null;
  let orderRemoverStrategy = null;
  let uiTrader = null;
  let uiUserPassword = null;
  let traderSide = null;
  let apiSessionCreator = null;
  let apiOrderRemover = null;

  const securityDescription = 'AES 9.67 01/02/29';
  const industrySector = Sector.ALL_SECTORS;
  const spread = 1;
  const size = 5000000;
  const rating = 'HY';
  const region = TICK_CONFIGURATION.US.HY;
  const orderMid = 100.5;

  const sessionConfiguration = {
    sector : industrySector,
    rating
  };

  // Total : 248 HY Cash ISINs
  const genOrders = buyOrSell => [
    {order       : getNewOrder('US416592AC73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TALRES 7.65 06/15/27'},
    {order       : getNewOrder('US38143VAA70', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GS 6.345 02/15/34'},
    {order       : getNewOrder('US38141EKZ15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GS Float 02/08/37'},
    {order       : getNewOrder('US381427AA15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GS Float PERP'},
    {order       : getNewOrder('US38144QAA76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GS Float PERP'},
    {order       : getNewOrder('US446283AD57', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HBAN Float 02/01/27'},
    {order       : getNewOrder('US441812JZ87', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HSBC 7 5/8 05/17/32'},
    {order       : getNewOrder('US440543AL07', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HOSS 5 7/8 04/01/20'},
    {order       : getNewOrder('US441812KB90', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HSBC 7.35 11/27/32'},
    {order       : getNewOrder('US253849AK97', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HPQ 7 3/4 04/01/23'},
    {order       : getNewOrder('US422317AB35', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HTV 7 1/2 11/15/27'},
    {order       : getNewOrder('US48667VAA26', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KEEXPT Float 02/25/25'},
    {order       : getNewOrder('US46284PAP99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'IRM 5 3/4 08/15/24'},
    {order       : getNewOrder('US49326MAA36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KEY Float 07/01/28'},
    {order       : getNewOrder('US49326QAA40', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KEY 7 3/4 07/15/29'},
    {order       : getNewOrder('US49326YAA73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KEY 6 7/8 03/17/29'},
    {order       : getNewOrder('US450679AT20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ITT 7.4 11/15/25'},
    {order       : getNewOrder('US46556MAF95', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ITAU 5.65 03/19/22'},
    {order       : getNewOrder('US46556LAH78', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ITAU 5 1/2 08/06/22'},
    {order       : getNewOrder('US46556MAJ18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ITAU 5 1/8 05/13/23'},
    {order       : getNewOrder('US482917AA91', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'KMI 7.63 04/15/28'},
    {order       : getNewOrder('US478366AU18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'JCI 5 03/30/20'},
    {order       : getNewOrder('US478366AX56', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'JCI 4 1/4 03/01/21'},
    {order       : getNewOrder('US478366AW73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'JCI 5.7 03/01/41'},
    {order       : getNewOrder('US478366BA45', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'JCI 3 3/4 12/01/21'},
    {order       : getNewOrder('US25271CAL63', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DO 5.7 10/15/39'},
    {order       : getNewOrder('US513075BE05', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LAMR 5 05/01/23'},
    {order       : getNewOrder('US47741VAA44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'JILGLS Float 10/26/23'},
    {order       : getNewOrder('US451713AA92', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RICOH 6 3/4 12/01/25'},
    {order       : getNewOrder('US06740L8C27', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BACR 7 5/8 11/21/22'},
    {order       : getNewOrder('US06846NAD66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HPR 7 10/15/22'},
    {order       : getNewOrder('US444454AA09', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SATS 7 5/8 06/15/21'},
    {order       : getNewOrder('US78442FEJ30', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NAVI 8 03/25/20'},
    {order       : getNewOrder('US78442FEL85', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NAVI 7 1/4 01/25/22'},
    {order       : getNewOrder('US780097AH44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RBS 7.648 PERP'},
    {order       : getNewOrder('US00077TAA25', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RBS 7 3/4 05/15/23'},
    {order       : getNewOrder('US00077TAB08', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RBS 7 1/8 10/15/93'},
    {order       : getNewOrder('US78442FAZ18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NAVI 5 5/8 08/01/33'},
    {order       : getNewOrder('US780099CE50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RBS 6 1/8 12/15/22'},
    {order       : getNewOrder('US779382AP57', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RDC 4 7/8 06/01/22'},
    {order       : getNewOrder('US779382AQ31', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RDC 5.4 12/01/42'},
    {order       : getNewOrder('US78442FEQ72', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NAVI 5 1/2 01/25/23'},
    {order       : getNewOrder('US832724AB40', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SKGID 7 1/2 11/20/25'},
    {order       : getNewOrder('US360271AK63', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FULT 3.6 03/16/22'},
    {order       : getNewOrder('US893830AF64', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 7 1/2 04/15/31'},
    {order       : getNewOrder('US893830AT68', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 6.8 03/15/38'},
    {order       : getNewOrder('US893830AY53', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 6 1/2 11/15/20'},
    {order       : getNewOrder('US893830BB42', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 6 3/8 12/15/21'},
    {order       : getNewOrder('US893830AZ29', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 7.35 12/15/41'},
    {order       : getNewOrder('US379352AL15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GLBMRN 7 06/01/28'},
    {order       : getNewOrder('US893830BC25', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RIG 3.8 10/15/22'},
    {order       : getNewOrder('US761735AP42', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'REYNOL 5 3/4 10/15/20'},
    {order       : getNewOrder('US852060AD48', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 6 7/8 11/15/28'},
    {order       : getNewOrder('US852060AT99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 8 3/4 03/15/32'},
    {order       : getNewOrder('US852061AA81', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 9 1/4 04/15/22'},
    {order       : getNewOrder('US75281AAM18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RRC 5 3/4 06/01/21'},
    {order       : getNewOrder('US75281AAN90', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'RRC 5 08/15/22'},
    {order       : getNewOrder('US852061AM20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 11 1/2 11/15/21'},
    {order       : getNewOrder('US852061AR17', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 7 08/15/20'},
    {order       : getNewOrder('US852061AS99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'S 6 11/15/22'},
    {order       : getNewOrder('US69352JAK34', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TLN 6 12/15/36'},
    {order       : getNewOrder('US69352JAN72', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TLN 4.6 12/15/21'},
    {order       : getNewOrder('US674215AD08', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'OAS 6 1/2 11/01/21'},
    {order       : getNewOrder('US71656MAF68', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PEMEX 6 5/8 PERP'},
    {order       : getNewOrder('US674215AE80', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'OAS 6 7/8 01/15/23'},
    {order       : getNewOrder('US680665AH97', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'OLN 5 1/2 08/15/22'},
    {order       : getNewOrder('US742651DR05', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PEFCO 2.05 11/15/22'},
    {order       : getNewOrder('US654902AC90', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NOKIA 6 5/8 05/15/39'},
    {order       : getNewOrder('US75952AAJ60', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GENONE 9.681 07/02/26'},
    {order       : getNewOrder('US92658TAQ13', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QBRCN 5 07/15/22'},
    {order       : getNewOrder('US74733VAA89', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QEP 6 7/8 03/01/21'},
    {order       : getNewOrder('US74733VAB62', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QEP 5 3/8 10/01/22'},
    {order       : getNewOrder('US74733VAC46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QEP 5 1/4 05/01/23'},
    {order       : getNewOrder('US67059TAB17', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NSUS 4.8 09/01/20'},
    {order       : getNewOrder('US67059TAC99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NSUS 4 3/4 02/01/22'},
    {order       : getNewOrder('US655844AA66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NSC 9 03/01/21'},
    {order       : getNewOrder('US880394AB71', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'REYNOL 7.95 12/15/25'},
    {order       : getNewOrder('US90470TAB44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'UNIFIN 7 01/15/25'},
    {order       : getNewOrder('US72447XAB38', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PBI 5 1/4 01/15/37'},
    {order       : getNewOrder('US694308GJ02', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 5.8 03/01/37'},
    {order       : getNewOrder('US694308GS01', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 5.4 01/15/40'},
    {order       : getNewOrder('US694308GT83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 3 1/2 10/01/20'},
    {order       : getNewOrder('US694308GV30', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 4 1/4 05/15/21'},
    {order       : getNewOrder('US694308GW13', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 3 1/4 09/15/21'},
    {order       : getNewOrder('US694308GY78', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 4 1/2 12/15/41'},
    {order       : getNewOrder('US694308GZ44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 4.45 04/15/42'},
    {order       : getNewOrder('US694308HA83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 3 3/4 08/15/42'},
    {order       : getNewOrder('US694308HB66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PCG 2.45 08/15/22'},
    {order       : getNewOrder('US736879AA54', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PRTLSG 1.741 10/22/24'},
    {order       : getNewOrder('US746388AA57', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PURPLC 2.735 08/01/23'},
    {order       : getNewOrder('US740212AE58', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PDCN 6 1/2 12/15/21'},
    {order       : getNewOrder('US65504LAD91', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 6.2 08/01/40'},
    {order       : getNewOrder('US65504LAC19', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 4.9 08/01/20'},
    {order       : getNewOrder('US65504LAF40', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 4 5/8 03/01/21'},
    {order       : getNewOrder('US65504LAG23', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 6.05 03/01/41'},
    {order       : getNewOrder('US65504LAJ61', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 3.95 03/15/22'},
    {order       : getNewOrder('US65504LAK35', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NE 5 1/4 03/15/42'},
    {order       : getNewOrder('US742651DP49', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'PEFCO 2.45 07/15/24'},
    {order       : getNewOrder('US55262CAD20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MBI 7.15 07/15/27'},
    {order       : getNewOrder('US55262CAE03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MBI 7 12/15/25'},
    {order       : getNewOrder('US55262CAF77', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MBI 6 5/8 10/01/28'},
    {order       : getNewOrder('US524909AW86', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LEH 7 1/2 08/01/26'},
    {order       : getNewOrder('US530715AD31', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LINTA 8 1/2 07/15/29'},
    {order       : getNewOrder('US530715AJ01', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LINTA 8 1/4 02/01/30'},
    {order       : getNewOrder('US59151KAG31', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MXCN 5 1/4 03/01/22'},
    {order       : getNewOrder('US552690AF65', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MDU 5.98 12/15/33'},
    {order       : getNewOrder('US553737AB39', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MSNAIR 1.631 12/14/24'},
    {order       : getNewOrder('US626717AA04', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MUR 7.05 05/01/29'},
    {order       : getNewOrder('US626717AD43', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MUR 4 06/01/22'},
    {order       : getNewOrder('US626717AF90', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MUR 3.7 12/01/22'},
    {order       : getNewOrder('US626717AG73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MUR 5 1/8 12/01/42'},
    {order       : getNewOrder('US629568AX43', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NBR 4 5/8 09/15/21'},
    {order       : getNewOrder('US629568AV86', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NBR 5 09/15/20'},
    {order       : getNewOrder('US53947MAJ53', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'LLOYDS Float 09/14/20'},
    {order       : getNewOrder('US92769VAC37', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VMED 5 1/4 02/15/22'},
    {order       : getNewOrder('US92769VAD10', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VMED 4 7/8 02/15/22'},
    {order       : getNewOrder('US362311AG75', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 6 3/4 05/15/27'},
    {order       : getNewOrder('US362333AH94', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 6.86 02/01/28'},
    {order       : getNewOrder('US362337AK38', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 6.73 02/15/28'},
    {order       : getNewOrder('US362338AQ80', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 8 1/2 11/15/31'},
    {order       : getNewOrder('US908256AA86', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'UNTHTN 1.863 01/22/25'},
    {order       : getNewOrder('US016090AA05', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'WIN 6 3/4 04/01/28'},
    {order       : getNewOrder('US743863AA09', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'UNM 7.405 03/15/38'},
    {order       : getNewOrder('US909218AB56', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'UNTUS 6 5/8 05/15/21'},
    {order       : getNewOrder('US98212BAD55', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'WPX 6 01/15/22'},
    {order       : getNewOrder('US91731KAA88', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'USB Float PERP'},
    {order       : getNewOrder('US984121CB79', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'XRXCRP 6 3/4 12/15/39'},
    {order       : getNewOrder('US984121CD36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'XRXCRP 4 1/2 05/15/21'},
    {order       : getNewOrder('US912909AD03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'X 6.65 06/01/37'},
    {order       : getNewOrder('US05518VAA35', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BAC Float PERP'},
    {order       : getNewOrder('US00104BAF76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AES 9.67 01/02/29'},
    {order       : getNewOrder('US256882AD30', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AES 7 1/4 10/15/21'},
    {order       : getNewOrder('US023663AB31', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ODP 5 03/01/30'},
    {order       : getNewOrder('US03512TAA97', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ANGSJ 5 3/8 04/15/20'},
    {order       : getNewOrder('US03512TAB70', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ANGSJ 6 1/2 04/15/40'},
    {order       : getNewOrder('US03512TAC53', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ANGSJ 5 1/8 08/01/22'},
    {order       : getNewOrder('US549463AC10', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ALUFP 6 1/2 01/15/28'},
    {order       : getNewOrder('US549463AE75', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ALUFP 6.45 03/15/29'},
    {order       : getNewOrder('US00164VAC72', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AMCX 4 3/4 12/15/22'},
    {order       : getNewOrder('US78412FAP99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SPN 7 1/8 12/15/21'},
    {order       : getNewOrder('US802722AB45', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SANROS 1.472 11/03/24'},
    {order       : getNewOrder('US86800XAA63', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TFC Float PERP'},
    {order       : getNewOrder('US410867AB18', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'THG 8.207 02/03/27'},
    {order       : getNewOrder('US87927VAM00', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TITIM 6 09/30/34'},
    {order       : getNewOrder('US87927VAF58', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TITIM 6 3/8 11/15/33'},
    {order       : getNewOrder('US87927VAR96', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TITIM 7.2 07/18/36'},
    {order       : getNewOrder('US87927VAV09', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TITIM 7.721 06/04/38'},
    {order       : getNewOrder('US87900YAA10', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TK 8 1/2 01/15/20'},
    {order       : getNewOrder('US029103AD00', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NOLSP 8 01/15/24'},
    {order       : getNewOrder('US845467AH21', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SWN 4.1 03/15/22'},
    {order       : getNewOrder('US882330AP86', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TXU 15 04/01/21'},
    {order       : getNewOrder('US882330AQ69', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TXU 15 04/01/21'},
    {order       : getNewOrder('US871503AH15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NLOK 4.2 09/15/20'},
    {order       : getNewOrder('US871503AK44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NLOK 3.95 06/15/22'},
    {order       : getNewOrder('US89346DAE76', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TACN 6 1/2 03/15/40'},
    {order       : getNewOrder('US89346DAF42', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TACN 4 1/2 11/15/22'},
    {order       : getNewOrder('US911684AD06', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'USM 6.7 12/15/33'},
    {order       : getNewOrder('US165167CG00', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHK 6 1/8 02/15/21'},
    {order       : getNewOrder('US165167BU03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHK 6 7/8 11/15/20'},
    {order       : getNewOrder('US165167CF27', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHK 6 5/8 08/15/20'},
    {order       : getNewOrder('US171875AD97', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CBB 6.3 12/01/28'},
    {order       : getNewOrder('US171870AK44', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CBB 7 1/4 06/15/23'},
    {order       : getNewOrder('US228255AH83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CCK 7 3/8 12/15/26'},
    {order       : getNewOrder('US118230AJ01', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BPL 4 7/8 02/01/21'},
    {order       : getNewOrder('US17305HAA68', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'C 7 5/8 12/01/36'},
    {order       : getNewOrder('US080555AE54', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TGNA 7 3/4 06/01/27'},
    {order       : getNewOrder('US080555AF20', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'TGNA 7 1/4 09/15/27'},
    {order       : getNewOrder('US058498AR71', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BLL 5 03/15/22'},
    {order       : getNewOrder('US110394AE39', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BRS 6 1/4 10/15/22'},
    {order       : getNewOrder('US172967GD72', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'C 5.95 PERP'},
    {order       : getNewOrder('US37247DAM83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GNW 7.7 06/15/20'},
    {order       : getNewOrder('US37247DAN66', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GNW 7.2 02/15/21'},
    {order       : getNewOrder('US17453BAJ08', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 9 08/15/31'},
    {order       : getNewOrder('US177342AL65', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 7.45 07/01/35'},
    {order       : getNewOrder('US177342AM49', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 7 11/01/25'},
    {order       : getNewOrder('US177342AP79', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 7.05 10/01/46'},
    {order       : getNewOrder('US17453BAS07', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 7 7/8 01/15/27'},
    {order       : getNewOrder('US35906AAK43', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 8 3/4 04/15/22'},
    {order       : getNewOrder('US35906AAH14', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 8 1/2 04/15/20'},
    {order       : getNewOrder('US35906AAL26', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 9 1/4 07/01/21'},
    {order       : getNewOrder('US35906AAM09', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FTR 7 1/8 01/15/23'},
    {order       : getNewOrder('US109043AG42', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BGG 6 7/8 12/15/20'},
    {order       : getNewOrder('US37247DAP15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GNW 7 5/8 09/24/21'},
    {order       : getNewOrder('US37247DAB29', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GNW 6 1/2 06/15/34'},
    {order       : getNewOrder('US37247DAG16', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GNW Float 11/15/36'},
    {order       : getNewOrder('US66977WAR07', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NCX 5 1/4 06/01/27'},
    {order       : getNewOrder('US66977WAQ24', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NCX 4 7/8 06/01/24'},
    {order       : getNewOrder('US209864AU14', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NSC 7 7/8 05/15/43'},
    {order       : getNewOrder('US156686AJ67', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 7.2 12/01/25'},
    {order       : getNewOrder('US156686AM96', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 6 7/8 01/15/28'},
    {order       : getNewOrder('US156700AM80', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 7.6 09/15/39'},
    {order       : getNewOrder('US156700AR77', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 6.45 06/15/21'},
    {order       : getNewOrder('US29078EAA38', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 7.995 06/01/36'},
    {order       : getNewOrder('US74913EAJ91', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QWECOM 7 3/4 02/15/31'},
    {order       : getNewOrder('US74913EAQ35', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QWECOM 7 5/8 08/03/21'},
    {order       : getNewOrder('US912912AQ52', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'QWECOM 6 7/8 07/15/28'},
    {order       : getNewOrder('US156700AS50', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 5.8 03/15/22'},
    {order       : getNewOrder('US156700AT34', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CTL 7.65 03/15/42'},
    {order       : getNewOrder('US12686CBB46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CVC 5 7/8 09/15/22'},
    {order       : getNewOrder('US126307AF48', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CSCHLD 6 3/4 11/15/21'},
    {order       : getNewOrder('US293561AU06', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ENRNQ 7 08/15/23'},
    {order       : getNewOrder('US26439XAC74', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DCP 8 1/8 08/16/30'},
    {order       : getNewOrder('US23311VAB36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DCP 4.95 04/01/22'},
    {order       : getNewOrder('US268787AB41', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'EPENEG 7 3/4 09/01/22'},
    {order       : getNewOrder('US294829AA48', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ERICB 4 1/8 05/15/22'},
    {order       : getNewOrder('US247025AE93', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DELL 7.1 04/15/28'},
    {order       : getNewOrder('US26874QAB68', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VAL 7.2 11/15/27'},
    {order       : getNewOrder('US74153QAH56', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VAL 6 7/8 08/15/20'},
    {order       : getNewOrder('US74153QAJ13', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'VAL 7 7/8 08/15/40'},
    {order       : getNewOrder('US29273VAC46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'ET 7 1/2 10/15/20'},
    {order       : getNewOrder('US24702RAF82', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DELL 6 1/2 04/15/38'},
    {order       : getNewOrder('US24702RAM34', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DELL 5.4 09/10/40'},
    {order       : getNewOrder('US24702RAQ48', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DELL 4 5/8 04/01/21'},
    {order       : getNewOrder('US29977HAB69', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'EPENEG 9 3/8 05/01/20'},
    {order       : getNewOrder('US30066CAA99', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'EXONEB 1.492 01/01/25'},
    {order       : getNewOrder('US25470XAE58', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DISH 6 3/4 06/01/21'},
    {order       : getNewOrder('US25470XAJ46', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DISH 5 7/8 07/15/22'},
    {order       : getNewOrder('US247916AC30', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DNR 6 3/8 08/15/21'},
    {order       : getNewOrder('US24823UAH14', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'DNR 4 5/8 07/15/23'},
    {order       : getNewOrder('US33766JAD54', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FE 6.05 08/15/21'},
    {order       : getNewOrder('US33766JAF03', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FE 6.8 08/15/39'},
    {order       : getNewOrder('US20854PAL31', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CNX 5 7/8 04/15/22'},
    {order       : getNewOrder('US1248EPAY96', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHTR 5 1/4 09/30/22'},
    {order       : getNewOrder('US1248EPAZ61', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CHTR 5 1/8 02/15/23'},
    {order       : getNewOrder('US05968LAG77', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'BCOLO 5.95 06/03/21'},
    {order       : getNewOrder('US125581GQ55', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CIT 5 08/15/22'},
    {order       : getNewOrder('US463588AA16', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'IRCPAR 8 3/4 03/23/23'},
    {order       : getNewOrder('US18683KAC53', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CLF 6 1/4 10/01/40'},
    {order       : getNewOrder('US55448QAQ91', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CLI 4 1/2 04/18/22'},
    {order       : getNewOrder('US879240AR06', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CMCSA 9 7/8 06/15/22'},
    {order       : getNewOrder('US717265AM45', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FCX 6 1/8 03/15/34'},
    {order       : getNewOrder('US35671DAU90', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FCX 3.55 03/01/22'},
    {order       : getNewOrder('US85172FAK57', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'AMGFIN 6 1/8 05/15/22'},
    {order       : getNewOrder('US63938CAH16', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NAVI 6 3/4 06/25/25'},
    {order       : getNewOrder('US62877PAA21', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'NTBKKK 2 3/4 05/30/22'},
    {order       : getNewOrder('US86614RAL15', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SUMMAT 5 1/8 06/01/25'},
    {order       : getNewOrder('US86723CAF59', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'SXCP 7 1/2 06/15/25'},
    {order       : getNewOrder('US900148AE73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GARAN 6 1/8 05/24/27'},
    {order       : getNewOrder('US30251GAU13', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FMGAU 4 3/4 05/15/22'},
    {order       : getNewOrder('US30251GAW78', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'FMGAU 5 1/8 05/15/24'},
    {order       : getNewOrder('US163851AE83', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CC 5 3/8 05/15/27'},
    {order       : getNewOrder('US139612AE59', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'CAPXAR 6 7/8 05/15/24'},
    {order       : getNewOrder('US362393AA80', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'GTT 7 7/8 12/31/24'},
    {order       : getNewOrder('US404280BL25', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'HSBC 6 PERP'},
    {order       : getNewOrder('US462044AG36', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'IO 9 1/8 12/15/21'},
    {order       : getNewOrder('US98105HAF73', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'WOORIB 5 1/4 PERP'},
    {order       : getNewOrder('US983919AJ06', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'XLNX 2.95 06/01/24'},
    {order       : getNewOrder('US55261FAL85', buyOrSell, spread, orderMid, size, rating, region),
      affirmOrder : true,
      description : 'MTB 5 PERP'}
  ];


  function getOrders (orders) {
    const ordersArray = orders.map(value => value.order);

    return ordersArray;
  }

  before(() => {
    // Framework setup.
    bootstrapper = new Bootstrap([frameworkConfig, usersConfig, apiConfig]);
    context = bootstrapper.getInstance();
    configuration = context.getConfiguration();
    log.info('Framework setup complete.');

    // Page object  setup.
    testCommons = new TestCommons(context);
    hydraPageModel = new FenicsCredit(context);

    // User setup
    apiSessionCreator = 'sujith.vakathanam.auto3@testing.fenicstools.com';
    apiOrderRemover = 'sujith.vakathanam.auto13@testing.fenicstools.com';

    sessionStrategy = new FixSessionStrategy(context, apiSessionCreator);
    orderRemoverStrategy = new FixHydraStrategy(context, apiOrderRemover);

    expect(browser).to.exist;
  });


  async function startSessionAction () {
    const info = await browser.testableInfo();
    // eslint-disable-next-line no-unused-vars,no-inline-comments
    const concurrentClientIndex = info.globalClientIndex ? info.globalClientIndex : 0; // global client index, or 0 for smoke tests

    log.info(`Testable global client index for :${uiTrader} is :${concurrentClientIndex}`);

    if (concurrentClientIndex === 0) {
      log.info('Starting Session.....');
      await sessionStrategy.createSession(sessionConfiguration);
    } else {
      log.info('Session start action performed by user with global client index : 0');
    }
  }

  async function hasCountdownPhaseStarted () {
    const expectedPhase = 'Countdown';

    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.mediumTimeout
      , `Timed out after ${configuration.mediumTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasAffirmationPhaseStarted () {
    const expectedPhase = 'Affirmation';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasCleanUpPhaseStarted () {
    const expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isCurrentPhase(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has started.`);

    let countOfOrdersInSessionPanel = await hydraPageModel.getSessionPanel(rating, false, type).getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info(`Count of Orders in Session panel during ${expectedPhase} is `, countOfOrdersInSessionPanel);
  }

  async function hasCleanUpPhaseEnded () {
    await hydraPageModel.getSessionPanel(rating, false, type);
    await browser.pause(configuration.veryShortTimeout);
    const expectedPhase = 'Cleanup';
    await browser.waitUntil(
      () => hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .isPhaseEnded(expectedPhase)
      , configuration.longTimeout
      , `Timed out after ${configuration.longTimeout} seconds, phase is not ${expectedPhase}.`
    );
    log.info(`${expectedPhase} phase has Ended.`);
  }

  async function loginSingleUser () {
    const rowPromise = await browser.testableCsvNext('users.csv');
    const row = rowPromise[0];

    log.info(`User for this session is : ${row.data.USERNAME}`);
    log.info(`SIDE for this session is : ${row.data.SIDE}`);
    uiTrader = row.data.USERNAME;
    uiUserPassword = row.data.PASSWORD;
    traderSide = row.data.SIDE;

    const hydraApiClientUser1 = new FixHydraStrategy(context, uiTrader);
    await orderRemoverStrategy.removeOrders(hydraApiClientUser1);

    // User Login and also capturing time to login
    await browser.testableStopwatch(async done => {
      await testCommons.traderLogin(uiTrader, uiUserPassword);
      done();
    }, 'Login UserTiming');
  }

  // eslint-disable-next-line no-unused-vars
  async function waitForAll (name) {
    const result = await browser.testableResult();
    const info = await browser.testableInfo();
    // eslint-disable-next-line no-inline-comments
    const numUsers = info.execution ? info.execution.concurrentClients : 1; // global user count, or 1 for smoke tests
    // eslint-disable-next-line no-undef
    log.info(`Number of users are : ${numUsers} to perform - ${name} - action`);
    await browser.testableCounter(result, name, 1, 'requests');
    // eslint-disable-next-line no-undef
    await browser.testableWaitForValue({namespace : 'User',
      name,
      value     : numUsers,
      timeout   : 300000});
  }


  // eslint-disable-next-line require-await
  it('All UI user logs into each EC2 instance concurrently', async () => {
    log.info('MODULE_TITLES.loginPageTitle is set as ', MODULE_TITLES.loginPageTitle);
    log.info('MODULE_TITLES.launchbarTitle is set as ', MODULE_TITLES.launchbarTitle);
    log.info('MODULE_TITLES.hydraPageTitle is set as ', MODULE_TITLES.hydraPageTitle);
    log.info('MODULE_TITLES.hydraOperatorPageTitle is set as ', MODULE_TITLES.hydraOperatorPageTitle);

    await loginSingleUser();

    await browser.testableScreenshot('loginSingleUser');
    await waitForAll('loginSingleUser');
  });

  it('All user loads ISINs', async () => {
    log.info('Adding Order Phase Started');

    const myOrders = getOrders(genOrders(traderSide));
    log.info(`User : ${uiTrader} is adding orders for - ${traderSide} - side`);

    await browser.testableStopwatch(async done => {
      await hydraPageModel.addOrders(myOrders);
      log.info(`User : ${uiTrader} has completed adding orders for - ${traderSide} - side`);
      done();
    }, 'AddOrders UserTiming');

    let countOfOrdersInSessionPanel = await hydraPageModel.getPortfolio().getPanelHeaderCount();
    countOfOrdersInSessionPanel = countOfOrdersInSessionPanel.slice(1, -1);
    log.info('Count of Orders in Portfolio panel is ', countOfOrdersInSessionPanel);

    await browser.testableScreenshot('addOrders');
    await waitForAll('addOrders');
  });

  it('Operator starts session', async () => {
    await startSessionAction();
    await waitForAll('startSessionAction');
  });

  it('Waiting for COUNTDOWN phase', async () => {
    await hasCountdownPhaseStarted();

    await browser.testableScreenshot('hasCountdownPhaseStarted');
    await waitForAll('hasCountdownPhaseStarted');
  });

  it('User moves from AFFIRMATION phase to CLEAN UP phase', async () => {
    // Affirmation Phase
    await hasAffirmationPhaseStarted();

    await browser.testableStopwatch(async done => {
      // User to affirm all orders
      await hydraPageModel.getSessionPanel(rating, false, type)
        .getOrderByDescription(securityDescription, TRADING_PROTOCOL.MATCHING_SESSION)
        .affirmAllOrders();
      log.info(`User : ${uiTrader} has affirmed all orders`);

      await browser.testableScreenshot('affirmAllOrders');

      // Clean up phase
      await hasCleanUpPhaseStarted();

      done();
    }, 'AffirmationPhase UserTiming');

    await browser.testableScreenshot('hasCleanUpPhaseStarted');
    await waitForAll('hasCleanUpPhaseStarted');
  });

  it('Waiting for all traders action panels to be emptied', async () => {
    await hasCleanUpPhaseEnded();

    await browser.testableScreenshot('hasCleanUpPhaseEnded');
    await waitForAll('hasCleanUpPhaseEnded');
  });

  it('Exit OpenFin Runtime', async () => {
    await browser.execute(() => {
      // eslint-disable-next-line no-undef
      fin.desktop.System.exit();
    });
    // eslint-disable-next-line no-inline-comments,no-magic-numbers,line-comment-position
    await browser.pause(1000); // Pause here to give Runtime time to exit
  });
});

