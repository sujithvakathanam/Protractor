// eslint-disable-next-line no-unused-vars
const {spawnSync} = require('child_process');
const {exec} = require('child_process');

const TARGET_ENV = process.env.TARGET_ENV ? process.env.TARGET_ENV : 'qa';
const CONFIG_URL = process.env.CONFIG_URL || `https://fenics-api.${TARGET_ENV}.fenicsone.com/v1/openfin-manifest?openFinApplication=fenics%2Ffenics-shell-app`;

exports.config = {
  specs : [
    'test/spec/stress-test-HY-Energy.js'
  ],
  exclude      : [],
  capabilities : [
    {
      browserName   : 'chrome',
      chromeOptions : {
        extensions : [],
        binary     : process.env.CONFIG_URL ? 'RunTestableOpenFin.bat' : 'RunOpenFin.bat',
        args       : [
          `--config=${CONFIG_URL}`,
          '--allow-insecure-localhost',
          '--allow-running-insecure-content',
          '--disable-web-security',
          '--noerrdialogs',
          '--v=1',
          '--ignore-certificate-errors',
          '--remember-cert-error-decisions',
          '--disk-cache-size=1'
        ]
      }
    }
  ],
  maxInstances   : 1,
  sync           : false,
  host           : 'localhost',
  port           : 9515,
  path           : '/',
  loglevel       : 'silent',
  coloredLogs    : true,
  framework      : 'mocha',
  waitforTimeout : 20000,
  mochaOpts      : {
    ui        : 'bdd',
    compilers : ['js:babel-register'],
    require   : ['isomorphic-fetch', 'jsdom-global/register'],
    timeout   : 500000
  },

  reporters       : ['spec'],
  reporterOptions : {
    captureStandardOutput : false,
    flowId                : true,
    message               : '[title]'
  },

  onPrepare : () => {
    if (!process.env.CONFIG_URL) {
      spawnSync(`${process.env.INIT_CWD}/TerminateChromedriver.bat`);
      exec('chromedriver.exe');
    }
  },

  onComplete : () => {
    if (!process.env.CONFIG_URL) {
      spawnSync(`${process.env.INIT_CWD}/TerminateOpenfin.bat`);
      spawnSync(`${process.env.INIT_CWD}/TerminateChromedriver.bat`);
    }
  }
};


