export const frameworkConfig = {
  clearDownScript        : 'TerminateOpenfin.bat',
  clearDownLogs          : false,
  expectedRuntimeVersion : '9.61.33.22',
  cleanUpRetry           : 1,
  veryShortTimeout       : 2000,
  shortTimeout           : 7000,
  mediumTimeout          : 20000,
  longTimeout            : 70000,
  veryLongTimeout        : 500000,
  username               : 'sujith.vakathanam.auto1@testing.fenicstools.com',
  password               : 'b5LzN7l6WcM3t2R4'
};
