// Please note that while running in local machine, it defatuls to run tests in QA env
const TARGET_ENV = process.env.TARGET_ENV  ? process.env.TARGET_ENV : 'qa';
const TARGET_STANDALONE = `https://hydra-api.${TARGET_ENV}.fenicsone.com/v1`;
const appDomain = `${TARGET_ENV}.fenicsone.com`;

export const apiConfig = {
  apiUrl : `${TARGET_STANDALONE}`,
  appDomain
};
