import Page from './Page.js';
import {UiHydraStrategy} from '../lib/hydra/uiHydraStrategy.js';
import Alerts from './Alerts';

class FenicsCredit extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.headerLogoSelector = '.header__logo__img';
    this.minimiseWindowButtonSelector = '//div[@class="window-control-icon"][2]';
    this.maximiseWindowButtonSelector = '//div[@class="window-control-icon"][2]/*[name()="svg"]';
    this.closeWindowButtonSelector = '//div[@class="window-control-icon"][3]';

    // Page object vars.
    this.uiHydraStrategy = new UiHydraStrategy(context);
  }

  get headerLogo () {
    return this.browser.element(this.headerLogoSelector);
  }

  get minimiseWindowButton () {
    return this.browser.element(this.minimiseWindowButtonSelector);
  }

  get maximiseWindowButton () {
    return this.browser.element(this.maximiseWindowButtonSelector);
  }

  get closeWindowButton () {
    return this.browser.element(this.closeWindowButtonSelector);
  }

  addOrdersFromFile (fileName) {
    return this.uiHydraStrategy.addOrdersFromFile(fileName);
  }

  addOrders (orders) {
    return this.uiHydraStrategy.addOrders(orders);
  }

  addOrdersByQuickUpload (securityId) {
    return this.uiHydraStrategy.addOrdersByQuickUpload(securityId);
  }

  async waitForPageLoad (timeout) {
    let foundUpload = false;
    await this.browser.waitUntil(async () => {
      try {
        const elements = await this.browser.elements(
          '//*[contains(@class, "fenics-upload-disabled")]',
          timeout
        );
        foundUpload = elements.value.length === 0;
      } catch (error) {
        foundUpload = false;
      }

      return foundUpload;
    });

    return this.browser.waitUntil(
      () => this.uiHydraStrategy.fileInput.isExisting(),
      timeout,
      `Timed out after ${timeout}ms, file upload input does not exist.`
    );
  }

  getPortfolio (click = false) {
    return this.uiHydraStrategy.getPortfolio(click);
  }

  getSessionPanel (rating = 'HY', click = false, type = 'Session') {
    return this.uiHydraStrategy.getSessionPanel(rating, click, type);
  }

  getTrades (click = false) {
    return this.uiHydraStrategy.getTrades(click);
  }

  getActionPanel () {
    return this.uiHydraStrategy.getActionPanel();
  }

  getAlerts () {
    return new Alerts(this.context);
  }

  refreshPage () {
    return this.browser.refresh();
  }

  clickMinimiseWindow () {
    return this.minimiseWindowButton.click();
  }

  async clickMaximiseWindow () {
    await this.browser.waitUntil(
      () => this.maximiseWindowButton.isVisible(),
      this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout}ms, Maximise Button does not exist`
    );

    return this.maximiseWindowButton.click();
  }

  clickCloseWindow () {
    return this.closeWindowButton.click();
  }
}

export default FenicsCredit;
