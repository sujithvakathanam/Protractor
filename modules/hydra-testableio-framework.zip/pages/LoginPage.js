import Page from './Page.js';

class LoginPage extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.txtboxUsernameSelector = 'input.fenics-input.fenics-input-lg.login__form__row__control';
    this.txtboxPasswordSelector = '#okta-signin-password';
    this.chkboxRememberUsernameSelector = 'input.fenics-checkbox-input';
    this.txtfldForgotUsernameSelector = 'section.login__form__row.login__form__row--extra-mt.text-cta';
    this.btnNextSelector = 'button.fenics-btn.login__form__row__cta.fenics-btn-primary';
    this.errorMessageSelector = 'div.login__form__row.login__form__row--error';
    this.signInErrorMessageSelector = 'div.okta-form-infobox-error.infobox.infobox-error';
    this.btnSignInSelector = '#okta-signin-submit';
  }

  get txtboxUsername () {
    return this.browser.element(this.txtboxUsernameSelector);
  }

  get txtboxPassword () {
    return this.browser.element(this.txtboxPasswordSelector);
  }

  get chkboxRememberUsername () {
    return this.browser.element(this.chkboxRememberUsernameSelector);
  }

  get txtfldForgotUsername () {
    return this.browser.element(this.txtfldForgotUsernameSelector);
  }

  get btnNext () {
    return this.browser.element(this.btnNextSelector);
  }

  get errorMessage () {
    return this.browser.element(this.errorMessageSelector);
  }

  get signInErrorMessage () {
    return this.browser.element(this.signInErrorMessageSelector);
  }

  get btnSignIn () {
    return this.browser.element(this.btnSignInSelector);
  }

  pageHasLoaded () {
    return super.pageHasLoaded(this.txtboxUsername);
  }

  waitForPasswordPageLoad (timeout) {
    return this.browser.waitUntil(
      () => this.txtboxPassword.isVisible(),
      this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout} seconds, password page did not load properly.`
    );
  }

  async enterUsername (username) {
    await this.txtboxUsername.setValue(username);
    this.logger.info(`Set login username text field to '${username}'.`);
  }

  async enterPassword (password) {
    await this.txtboxPassword.setValue(password);
    this.logger.info('Set password text field.');
  }

  async clickRememberUsername () {
    await this.chkboxRememberUsername.click();
    this.logger.info('Clicked remember username check box.');
  }

  async clickForgotUsername () {
    await this.txtfldForgotUsername.click();
    this.logger.info('Clicked forgot username text link.');
  }

  async clickNext () {
    await this.browser.waitUntil(
      () => this.btnNext.isEnabled()
      , this.configuration.mediumTimeout
      , `Timed out after ${this.configuration.mediumTimeout} seconds, password page did not load properly.`
    );
    await this.btnNext.click();
    this.logger.info('Clicked next button.');
  }

  async clickSignIn () {
    await this.btnSignIn.click();
    this.logger.info('Clicked sign in button.');
  }
}

export default LoginPage;
