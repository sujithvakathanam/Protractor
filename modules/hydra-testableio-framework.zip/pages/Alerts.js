import Page from './Page.js';

class Alerts extends Page {
  constructor (context) {
    super(context);

    // Framework vars.
    this.context = context;
    this.logger = context.getLogger();
    this.browser = global.browser;

    // Selectors vars.
    this.popUpAlertMessageTextSelector = '//div[@class="fenics-modal-body"]//div[@class="fenics-modal-confirm-body"]/span';
    this.notificationIconSelector = '//div[@class="notification-alert-body"]/i[@class="fenics-icon notification-alert-body__warning-icon"]';
    this.notificationCloseButtonSelector = '//div[@class="notification-alert-body"]/i[@class="fenics-icon notification-alert-body__close-icon"]';
    this.notificationMessageTextSelector = '.div.notification-alert-body.p';
    this.popUpAlertIconSelector = '//div[@class="fenics-modal-body"]//i';
    this.popUpAlertButtonSelector = buttonText => `//div[@class="fenics-modal-body"]//button/span[text() = "${buttonText}"]`;
  }

  get popUpAlertMessageText () {
    return this.browser.element(this.popUpAlertMessageTextSelector);
  }

  get notificationIcon () {
    return this.browser.element(this.notificationIconSelector);
  }

  get notificationCloseButton () {
    return this.browser.element(this.notificationCloseButtonSelector);
  }

  get notificationMessageText () {
    return this.browser.element(this.notificationMessageTextSelector);
  }

  get popUpAlertIcon () {
    return this.browser.element(this.popUpAlertIconSelector);
  }

  getPopUpAlertButton (buttonText) {
    return this.browser.element(this.popUpAlertButtonSelector(buttonText));
  }

  async getNotificationAlertMessage () {
    const alertBodyText = await this.notificationMessageText.getText();
    const alertType = await this.notificationIcon.getText();
    const alertMessage = {
      AlertType : '',
      AlertText : alertBodyText
    };

    if (alertType === 'warning') {
      alertMessage.AlertType = 'WARNING';
    } else {
      alertMessage.AlertType = 'UNKNOWN';
    }

    return alertMessage;
  }

  async getPopUpAlertMessage () {
    const alertBodyText = await this.popUpAlertMessageText.getText();
    const alertType = await this.popUpAlertIcon.getAttribute('class');
    const alertMessage = {
      AlertType : '',
      AlertText : alertBodyText
    };

    if (alertType === 'anticon anticon-question-circle') {
      alertMessage.AlertType = 'QUESTION';
    } else if (alertType === 'anticon anticon-close-circle') {
      alertMessage.AlertType = 'ERROR';
    } else {
      alertMessage.AlertType = 'UNKNOWN';
    }

    return alertMessage;
  }

  clickPopUpAlertButton (buttonText) {
    return this.getPopUpAlertButton(buttonText).click();
  }

  clickNotificationAlertCloseButton () {
    return this.notificationCloseButton.click();
  }

  async isNotificationAlertPresent () {
    let isPresent = false;
    try {
      await this.notificationIcon.getAttribute('class');
      isPresent = true;
    } catch (err) {
      isPresent = false;
    }

    return isPresent;
  }

  async isPopUpAlertPresent () {
    let isPresent = false;
    try {
      await this.popUpAlertIcon.getAttribute('class');
      isPresent = true;
    } catch (err) {
      isPresent = false;
    }

    return isPresent;
  }
}

export default Alerts;
