class Page {
  constructor (context) {
    // Framework vars.
    this.logger = context.getLogger();
    this.configuration = context.getConfiguration();
    this.browser = global.browser;
  }

  getElementWithSelector (selector) {
    return this.browser.element(selector);
  }

  pageHasLoaded (element) {
    return element.waitForVisible(this.configuration.shortTimeout);
  }

  async hasTabOpen (tabTitleSearched) {
    let found = false;
    const ids = await this.browser.getTabIds();

    for (let windowCounter = 0; windowCounter < ids.length; windowCounter += 1) {
      await this.browser.switchTab(ids[windowCounter]);
      const title = await this.browser.getTitle();
      if (title === tabTitleSearched) {
        found = true;
        this.logger.info(`Switched to open tab ${tabTitleSearched}.`);
      }
    }

    return found;
  }

  async waitForTab (tabTitleSearched) {
    await this.browser.waitUntil(
      () => this.hasTabOpen(tabTitleSearched)
      , this.configuration.mediumTimeout,
      `Timed out after ${this.configuration.mediumTimeout} seconds, waiting for tab: ${tabTitleSearched}.`
    );
  }

  async setTextValue (elementSelector, value) {
    const clearAndSet = async val => {
      await this.getElementWithSelector(elementSelector).clearElement();
      await this.getElementWithSelector(elementSelector).setValue(val);
      await this.getElementWithSelector(elementSelector).click();
    };

    let elementText = await this.getElementWithSelector(elementSelector).getValue();
    while (elementText !== value.toString()) {
      await clearAndSet(value);
      elementText = await this.getElementWithSelector(elementSelector).getValue();
    }
  }
}

export default Page;
