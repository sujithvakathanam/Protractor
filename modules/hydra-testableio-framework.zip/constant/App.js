const FIX_COMMON_TAGS = {
  senderCompId : 'Fenics',
  targetCompId : 'BGC',
  targetSubId  : ''
};

const suffix = process.env.TESTABLE_ITERATION_UID ? ` ${process.env.TESTABLE_ITERATION_UID}` : '';

const MODULE_TITLES = {
  hydraClientTitle       : 'Delta X',
  hydraOperatorTitle     : 'Delta X HQ',
  launchbarTitle         : 'Fenics Launchbar' + suffix,
  hydraPageTitle         : 'Fenics Delta X' + suffix,
  hydraOperatorPageTitle : 'Fenics Delta X HQ' + suffix,
  loginPageTitle         : 'Fenics Login' + suffix
};

export {
  FIX_COMMON_TAGS,
  MODULE_TITLES
};
