export const TRADING_SESSION_PHASE = {
  MS_COUNTDOWN   : -1,
  MS_AFFIRMATION : 0,
  PN_PRICING     : 0,
  PRIVATE        : 1,
  GROUP          : 2,
  CLEANUP        : 3,
  PUBLIC         : 4,
  NONE           : -99
};

export const PHASE = {
  PRE_PRICING : 'Pre PricingPage',
  PRICING     : 'PricingPage',
  PRIVATE     : 'Private',
  GROUP       : 'Group',
  CLEANUP     : 'Cleanup',
  PUBLIC      : 'Public',
  COUNTDOWN   : 'Countdown',
  AFFIRMATION : 'Affirmation'
};

export const TR_SESS_ID_TO_PHASE = {
  [TRADING_SESSION_PHASE.PRE_PRICING] : PHASE.PRE_PRICING,
  [TRADING_SESSION_PHASE.PN_PRICING]  : PHASE.PRICING,
  [TRADING_SESSION_PHASE.PRIVATE]     : PHASE.PRIVATE,
  [TRADING_SESSION_PHASE.GROUP]       : PHASE.GROUP,
  [TRADING_SESSION_PHASE.CLEANUP]     : PHASE.CLEANUP,
  [TRADING_SESSION_PHASE.PUBLIC]      : PHASE.PUBLIC
};

export const TRADING_SESSION_STATUS = {
  OPENED : 2,
  CLOSED : 3
};

export const TRADING_SESSION_TYPE = {
  MATCHING_SESSION    : 's',
  PRIVATE_NEGOTIATION : 'p',
  CLOB                : 'c'
};

export const DATE_TIME_FORMAT = 'yyyyLLdd-HH:mm:ss.SSS';

export const RATING = {
  HIGH_YIELD       : 'HIGH_YIELD',
  INVESTMENT_GRADE : 'INVESTMENT_GRADE'
};

export const TYPE = {
  OLX     : 'OLX',
  SESSION : 'SESSION',
  PN      : 'PN'
};


export const PHASE_DEFINITIONS = [
  {
    type              : PHASE.COUNTDOWN.toUpperCase(),
    durationInSeconds : 30,
    glowVisible       : false
  },
  {
    type              : PHASE.AFFIRMATION.toUpperCase(),
    durationInSeconds : 60,
    glowVisible       : false
  },
  {
    type              : 'CLEAN_UP',
    durationInSeconds : 60,
    glowVisible       : true
  }
];
