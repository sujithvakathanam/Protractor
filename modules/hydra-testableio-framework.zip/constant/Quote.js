export const QUOTE_SOURCE = {
  ASM         : 'asm',
  BEST_PRICE  : 'bestPrice',
  TOP_OF_BOOK : 'topOfBook'
};

export const QUOTE_TYPE = {
  BEST_PRICE  : 1,
  ASM         : 2,
  TOP_OF_BOOK : 3
};

export const QUOTE_TYPE_TO_QUOTE_SOURCE = {
  [QUOTE_TYPE.BEST_PRICE]  : QUOTE_SOURCE.BEST_PRICE,
  [QUOTE_TYPE.ASM]         : QUOTE_SOURCE.ASM,
  [QUOTE_TYPE.TOP_OF_BOOK] : QUOTE_SOURCE.TOP_OF_BOOK
};

export const PRICE_QUOTE_METHOD = {
  LEFT   : 'LEFT',
  MIDDLE : 'MIDDLE',
  RIGHT  : 'RIGHT'
};
