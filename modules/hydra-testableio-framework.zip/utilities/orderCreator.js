import {roundToTick} from './asmCalculator';
import {SIZE_MULTIPLIER} from '../constant/Order';
import {TRADED_DIRECTION} from '../constant/TradedDirection';

const getOrderPriceCalulation = (orderMid, spread, side, positiveDirection, negativeDirection) => {
  let price = null;

  if (orderMid !== null && spread !== null) {
    if (side === negativeDirection) {
      price = orderMid - spread / 2;
    } else if (side === positiveDirection) {
      price = orderMid + spread / 2;
    } else {
      throw Error(`Unhandled side ${side}`);
    }
  } else {
    price = '';
  }

  return price;
};

const transformSize = (direction, rawSize) => (direction === 'buy' ? -(rawSize / SIZE_MULTIPLIER) : rawSize / SIZE_MULTIPLIER);

export const getNewOrder = (securityId, side, spread, orderMid, size, rating = 'HY', regionConfig) => {
  let price = null;

  if (rating === 'HY') {
    price = getOrderPriceCalulation(orderMid, spread, side, 'sell', 'buy');
  } else if (rating === 'IG') {
    price = getOrderPriceCalulation(orderMid, spread, side, 'buy', 'sell');
  } else {
    throw Error(`Unhandled rating ${rating}`);
  }

  price = roundToTick(price, regionConfig.PRICE_INCREMENT_MIN_PRICE_TICKS, regionConfig.PRICE_INCREMENT_ROUND_TO_DECIMAL_POINT);

  return {
    SecurityID  : securityId,
    Side        : side,
    TradedSide  : side === 'buy' ? TRADED_DIRECTION.BOUGHT : TRADED_DIRECTION.SOLD,
    OrderQty    : transformSize(side, size),
    RawOrderQty : size,
    Price       : price
  };
};
