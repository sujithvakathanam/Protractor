/* eslint-disable complexity */
import Big from 'big.js';

const HALF_UP = 1;
const HALF_EVEN = 2;
const ROUND_TO = 2;

export const roundToTick = (value, tick, roundToDecimalPoint) => new Big(value)
  .div(tick)
  .round(ROUND_TO, HALF_EVEN)
  .round(0, HALF_UP)
  .times(tick)
  .toFixed(roundToDecimalPoint);

const calculateAverage = (weightings, prices) => {
  let averagePrice = new Big(0);
  if (weightings.length !== prices.length) {
    throw new Error('Length of weightings and prices do not match.');
  }

  for (let weightingsCount = 0; weightingsCount < weightings.length; weightingsCount += 1) {
    const weighting = new Big(weightings[weightingsCount]);
    const price = new Big(prices[weightingsCount]);

    if (weightings !== 0) {
      averagePrice = weighting.times(price).add(averagePrice);
    }
  }

  return averagePrice
    .toFixed(ROUND_TO)
    .valueOf();
};

export const calculateMid = (bid, offer) => {
  const bigBid = new Big(bid);
  const bigOffer = new Big(offer);
  const divider = new Big(2);


  return bigBid.add(bigOffer)
    .div(divider)
    .round(ROUND_TO, HALF_EVEN)
    .toFixed(ROUND_TO);
};

const calculateWeighting = (reduceFrom, addTo) => addTo + reduceFrom / 2;

const recalculateWeightingsForSession = weightings => {
  const hasIceWeightings = weightings.ice !== 0;
  const hasBloomberWeightings = weightings.bloomberg !== 0;
  let multiplier = 1;
  weightings.internal = 0;

  if (hasBloomberWeightings && !hasIceWeightings) {
    multiplier /= weightings.bloomberg;
    // eslint-disable-next-line operator-assignment
    weightings.bloomberg = multiplier * weightings.bloomberg;
    weightings.ice = 0;
  } else if (hasIceWeightings && !hasBloomberWeightings) {
    multiplier /= weightings.ice;
    weightings.bloomberg = 0;
    // eslint-disable-next-line operator-assignment
    weightings.ice = multiplier * weightings.ice;
  } else if (hasBloomberWeightings && hasIceWeightings) {
    multiplier /= weightings.bloomberg + weightings.ice;
    // eslint-disable-next-line operator-assignment
    weightings.bloomberg = multiplier * weightings.bloomberg;
    // eslint-disable-next-line operator-assignment
    weightings.ice = multiplier * weightings.ice;
  }

  return weightings;
};

const recalculateWeightings = (weightings, prices) => {
  const hasIcePrice = prices.ice !== 0;
  const hasBloombergPrice = prices.bloomberg !== 0;

  if (!hasIcePrice && hasBloombergPrice) {
    weightings.internal = calculateWeighting(weightings.ice, weightings.internal);
    weightings.bloomberg = calculateWeighting(weightings.ice, weightings.bloomberg);
    weightings.ice = 0;
  } else if (hasIcePrice && !hasBloombergPrice) {
    weightings.internal = calculateWeighting(weightings.bloomberg, weightings.internal);
    weightings.ice = calculateWeighting(weightings.bloomberg, weightings.ice);
    weightings.bloomberg = 0;
  } else if (!hasIcePrice && !hasBloombergPrice) {
    weightings.internal = 1;
    weightings.bloomberg = 0;
    weightings.ice = 0;
  }

  return weightings;
};

export const calculateAsmPrice = (weightings, prices, bid, offer, config, sessionProtocol = false) => {
  let recalculatedWeightings = null;
  if (sessionProtocol) {
    recalculatedWeightings = recalculateWeightingsForSession(weightings);
  } else {
    recalculatedWeightings = recalculateWeightings(weightings, prices);
  }

  const price = calculateAverage(
    [recalculatedWeightings.ice, recalculatedWeightings.bloomberg, recalculatedWeightings.internal]
    , [prices.ice, prices.bloomberg, calculateMid(bid, offer)]
  );

  return roundToTick(price, config.ASM_MIN_PRICE_TICKS, config.ASM_ROUND_TO_DECIMAL_POINT).valueOf();
};

export const getOrderMid = prices => {
  let orderMid = 0;
  const max = 120.99;
  const min = 70.01;
  const hasIcePrice = prices.ice !== 0;
  const hasBloombergPrice = prices.bloomberg !== 0;

  if (!hasIcePrice && hasBloombergPrice) {
    orderMid = prices.bloomberg;
  } else if (hasIcePrice && !hasBloombergPrice) {
    orderMid = prices.ice;
  } else if (!hasIcePrice && !hasBloombergPrice) {
    orderMid = (Math.random() * (max - min) + min).toFixed(2);
  } else if (hasIcePrice && hasBloombergPrice) {
    orderMid = calculateMid(prices.ice, prices.bloomberg);
  }

  if (typeof orderMid === 'string') {
    orderMid = parseFloat(orderMid);
  }

  return orderMid;
};
