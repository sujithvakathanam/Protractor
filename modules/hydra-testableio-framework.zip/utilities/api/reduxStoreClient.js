class ReduxStoreClient {
  constructor () {
    this.browser = global.browser;
  }

  getReduxDataObject (objectPath = '') {
    let reduxState = [];
    try {
      reduxState = this.browser.execute(`return window.QA.store.getState()${objectPath}`);
    } catch (err) {
      // Do nothing.
    }

    return reduxState;
  }

  async getOrders () {
    const reduxState = await this.getReduxDataObject('.order');
    const orders = reduxState.value;

    const allOrders = [];
    for (const key in orders) {
      if (Object.prototype.hasOwnProperty.call(orders, key)) {
        const order = orders[key];
        const side = order.Side === '1' ? '2' : '1';

        allOrders.push({
          MsgType              : order.MsgType,
          PosReqType           : '0',
          PosMaintRptID        : '',
          ClearingBusinessDate : order.TransactTime,
          SecurityID           : order.SecurityID,
          SecurityIDSource     : order.SecurityIDSource,
          Symbol               : order.Symbol,
          MarketSegmentID      : order.MarketSegmentID,
          RoutingInst          : order.RoutingInst,
          NoPositions          : 1,
          Side                 : side,
          OrderQty             : order.OrderQty,
          OrderID              : order.OrderID,
          Price                : order.Price,
          TradingSessionID2    : order.TradingSessionID2
        });
      }
    }

    return allOrders;
  }
}

export default ReduxStoreClient;
