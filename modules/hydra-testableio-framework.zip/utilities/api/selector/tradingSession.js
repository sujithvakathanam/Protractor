import get from 'lodash/get';

export const getTradingSessions = namespace => get(namespace, 'byId', {});
