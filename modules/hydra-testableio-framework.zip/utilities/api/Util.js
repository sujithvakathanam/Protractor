const BASE = 16;

export const coercer = collection => (
  Array.isArray(collection) ? collection : Object.values(collection)
);

export const generateClientOrderId = () => Math.random()
  .toString(BASE)
  .substring(2);

export const encodeURISpaces = string => string.replace(' ', '%20');
